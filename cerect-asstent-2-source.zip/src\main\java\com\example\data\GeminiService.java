package com.example.data;

import android.graphics.Bitmap;
import android.util.Base64;
import com.example.model.AnswerResult;
import com.example.model.OptionShape;
import com.example.model.SearchSource;
import io.ktor.sse.ServerSentEventKt;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.CoroutineDispatcher;
import kotlinx.coroutines.Dispatchers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: GeminiService.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0004\b\u0007\u0018\u0000  2\u00020\u0001:\u0002 !B\u0007¢\u0006\u0004\b\u0002\u0010\u0003JD\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\b\u0010\t\u001a\u0004\u0018\u00010\n2\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\f2\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\f2\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\u000fH\u0086@¢\u0006\u0004\b\u0010\u0010\u0011J\"\u0010\u0012\u001a\u0004\u0018\u00010\f2\u0006\u0010\u0013\u001a\u00020\f2\u0006\u0010\u0014\u001a\u00020\f2\u0006\u0010\u0015\u001a\u00020\fH\u0002J\u0010\u0010\u0016\u001a\u00020\f2\u0006\u0010\u0013\u001a\u00020\fH\u0002J2\u0010\u0017\u001a\u00020\b2\u0006\u0010\u0018\u001a\u00020\f2\u000e\b\u0002\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u001b0\u001a2\b\b\u0002\u0010\u001c\u001a\u00020\f2\b\b\u0002\u0010\u001d\u001a\u00020\u001eJ\u0010\u0010\u001f\u001a\u00020\f2\u0006\u0010\t\u001a\u00020\nH\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\""}, d2 = {"Lcom/example/data/GeminiService;", "", "<init>", "()V", "client", "Lokhttp3/OkHttpClient;", "analyzeScreen", "Lkotlin/Result;", "Lcom/example/model/AnswerResult;", "bitmap", "Landroid/graphics/Bitmap;", "customApiKey", "", "extraContext", "rateLimiter", "Lcom/example/data/GeminiRateLimiter;", "analyzeScreen-yxL6bBk", "(Landroid/graphics/Bitmap;Ljava/lang/String;Ljava/lang/String;Lcom/example/data/GeminiRateLimiter;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "executeModelRequest", "model", "apiKey", "requestBodyString", "formatModelDisplayName", "parseAnswerText", "rawText", "sources", "", "Lcom/example/model/SearchSource;", "modelUsed", "durationMs", "", "bitmapToBase64", "Companion", "QuotaExhaustedException", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class GeminiService {
    private static final long PER_MODEL_TIMEOUT_MS = 7000;
    private static final String TAG = "GeminiService";
    private static final long TOTAL_QUERY_TIMEOUT_MS = 16000;
    private final OkHttpClient client = new OkHttpClient.Builder().connectTimeout(5, TimeUnit.SECONDS).readTimeout(12, TimeUnit.SECONDS).writeTimeout(5, TimeUnit.SECONDS).callTimeout(15, TimeUnit.SECONDS).build();

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    public static final int $stable = 8;

    /* JADX INFO: compiled from: GeminiService.kt */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\t\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u0005H\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"Lcom/example/data/GeminiService$Companion;", "", "<init>", "()V", "TAG", "", "PER_MODEL_TIMEOUT_MS", "", "TOTAL_QUERY_TIMEOUT_MS", "getModelUrl", "model", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public final String getModelUrl(String model) {
            return "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent";
        }
    }

    /* JADX INFO: renamed from: analyzeScreen-yxL6bBk$default, reason: not valid java name */
    public static /* synthetic */ Object m6934analyzeScreenyxL6bBk$default(GeminiService geminiService, Bitmap bitmap, String str, String str2, GeminiRateLimiter geminiRateLimiter, Continuation continuation, int i, Object obj) {
        if ((i & 2) != 0) {
            str = null;
        }
        if ((i & 4) != 0) {
            str2 = null;
        }
        if ((i & 8) != 0) {
            geminiRateLimiter = null;
        }
        return geminiService.m6935analyzeScreenyxL6bBk(bitmap, str, str2, geminiRateLimiter, continuation);
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0016  */
    /* JADX INFO: renamed from: analyzeScreen-yxL6bBk, reason: not valid java name */
    public final Object m6935analyzeScreenyxL6bBk(Bitmap bitmap, String customApiKey, String extraContext, GeminiRateLimiter rateLimiter, Continuation<? super Result<AnswerResult>> continuation) {
        GeminiService$analyzeScreen$1 geminiService$analyzeScreen$1;
        Object objWithContext;
        if (continuation instanceof GeminiService$analyzeScreen$1) {
            geminiService$analyzeScreen$1 = (GeminiService$analyzeScreen$1) continuation;
            if ((geminiService$analyzeScreen$1.label & Integer.MIN_VALUE) != 0) {
                geminiService$analyzeScreen$1.label -= Integer.MIN_VALUE;
            } else {
                geminiService$analyzeScreen$1 = new GeminiService$analyzeScreen$1(this, continuation);
            }
        } else {
            geminiService$analyzeScreen$1 = new GeminiService$analyzeScreen$1(this, continuation);
        }
        Object $result = geminiService$analyzeScreen$1.result;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (geminiService$analyzeScreen$1.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                CoroutineDispatcher io2 = Dispatchers.getIO();
                GeminiService$analyzeScreen$2 geminiService$analyzeScreen$2 = new GeminiService$analyzeScreen$2(customApiKey, bitmap, this, rateLimiter, extraContext, null);
                geminiService$analyzeScreen$1.L$0 = SpillingKt.nullOutSpilledVariable(bitmap);
                geminiService$analyzeScreen$1.L$1 = SpillingKt.nullOutSpilledVariable(customApiKey);
                geminiService$analyzeScreen$1.L$2 = SpillingKt.nullOutSpilledVariable(extraContext);
                geminiService$analyzeScreen$1.L$3 = SpillingKt.nullOutSpilledVariable(rateLimiter);
                geminiService$analyzeScreen$1.label = 1;
                objWithContext = BuildersKt.withContext(io2, geminiService$analyzeScreen$2, geminiService$analyzeScreen$1);
                if (objWithContext == coroutine_suspended) {
                    return coroutine_suspended;
                }
                break;
            case 1:
                ResultKt.throwOnFailure($result);
                objWithContext = $result;
                break;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return ((Result) objWithContext).getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String executeModelRequest(String model, String apiKey, String requestBodyString) throws JSONException, IOException {
        String strOptString;
        JSONArray responseParts;
        JSONObject jSONObjectOptJSONObject;
        String modelUrl = INSTANCE.getModelUrl(model);
        RequestBody requestBody = RequestBody.INSTANCE.create(requestBodyString, MediaType.INSTANCE.get("application/json; charset=utf-8"));
        Request request = new Request.Builder().url(modelUrl + "?key=" + apiKey).post(requestBody).build();
        Response response = this.client.newCall(request).execute();
        ResponseBody responseBodyBody = response.body();
        String responseBody = responseBodyBody != null ? responseBodyBody.string() : null;
        if (responseBody == null) {
            responseBody = "";
        }
        if (!response.isSuccessful()) {
            if (response.code() == 429) {
                throw new QuotaExhaustedException("HTTP 429: Quota exhausted for " + model);
            }
            throw new IOException("HTTP " + response.code() + ": " + responseBody);
        }
        JSONObject json = new JSONObject(responseBody);
        JSONArray candidates = json.optJSONArray("candidates");
        if (candidates == null || candidates.length() <= 0) {
            return null;
        }
        JSONObject firstCandidate = candidates.getJSONObject(0);
        JSONObject content = firstCandidate.optJSONObject("content");
        if (content != null) {
            strOptString = null;
            responseParts = content.optJSONArray("parts");
        } else {
            strOptString = null;
            responseParts = null;
        }
        if (responseParts != null && (jSONObjectOptJSONObject = responseParts.optJSONObject(0)) != null) {
            strOptString = jSONObjectOptJSONObject.optString("text");
        }
        return strOptString == null ? "" : strOptString;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String formatModelDisplayName(String model) {
        switch (model.hashCode()) {
            case -1635246648:
                return !model.equals(GeminiRateLimiter.MODEL_38_FLASH) ? model : "Gemini 3.8 Flash";
            case -719549446:
                if (!model.equals(GeminiRateLimiter.MODEL_31_FLASH_LITE_STABLE)) {
                    return model;
                }
                return "Gemini 3.1 Flash Lite";
            case -203218570:
                return !model.equals(GeminiRateLimiter.MODEL_35_FLASH_LITE) ? model : "Gemini 3.5 Flash Lite";
            case -2790395:
                return !model.equals(GeminiRateLimiter.MODEL_35_FLASH) ? model : "Gemini 3.5 Flash";
            case 466860277:
                if (!model.equals(GeminiRateLimiter.MODEL_31_FLASH_LITE)) {
                    return model;
                }
                return "Gemini 3.1 Flash Lite";
            case 957039166:
                return !model.equals(GeminiRateLimiter.MODEL_30_FLASH) ? model : "Gemini 3.0 Flash";
            case 1662112959:
                return !model.equals(GeminiRateLimiter.MODEL_20_FLASH) ? model : "Gemini 2.0 Flash";
            case 1772216967:
                return !model.equals(GeminiRateLimiter.MODEL_37_FLASH) ? model : "Gemini 3.7 Flash";
            case 1804664068:
                return !model.equals(GeminiRateLimiter.MODEL_25_FLASH) ? model : "Gemini 2.5 Flash";
            default:
                return model;
        }
    }

    public final AnswerResult parseAnswerText(String rawText, List<SearchSource> sources, String modelUsed, long durationMs) {
        Object obj;
        String explanation;
        String explanation2;
        OptionShape found;
        Intrinsics.checkNotNullParameter(rawText, "rawText");
        Intrinsics.checkNotNullParameter(sources, "sources");
        Intrinsics.checkNotNullParameter(modelUsed, "modelUsed");
        OptionShape detectedShape = OptionShape.UNKNOWN;
        String directAnswer = "";
        String explanation3 = "";
        Iterable iterableLines = StringsKt.lines(rawText);
        Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterableLines, 10));
        Iterator it = iterableLines.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            arrayList.add(StringsKt.trim((CharSequence) new Regex("[*_#`]+").replace(new Regex("^[*_#\\-\\d.]+\\s*").replace(StringsKt.trim((CharSequence) it.next()).toString(), ""), "")).toString());
            detectedShape = detectedShape;
            directAnswer = directAnswer;
        }
        OptionShape detectedShape2 = detectedShape;
        String directAnswer2 = directAnswer;
        Collection arrayList2 = new ArrayList();
        for (Object obj2 : (List) arrayList) {
            if (!StringsKt.isBlank((String) obj2)) {
                arrayList2.add(obj2);
            }
        }
        List<String> cleanLines = (List) arrayList2;
        Iterator it2 = cleanLines.iterator();
        OptionShape detectedShape3 = detectedShape2;
        while (true) {
            obj = null;
            if (!it2.hasNext()) {
                break;
            }
            String line = (String) it2.next();
            String upper = line.toUpperCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(upper, "toUpperCase(...)");
            if (StringsKt.startsWith$default(upper, "OPTION:", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "OPTION:", false, 2, (Object) null) || StringsKt.startsWith$default(upper, "SHAPE:", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "SHAPE:", false, 2, (Object) null) || StringsKt.startsWith$default(upper, "CHOICE:", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "CHOICE:", false, 2, (Object) null)) {
                String shapePart = StringsKt.trim((CharSequence) StringsKt.substringAfter(line, ServerSentEventKt.COLON, "")).toString();
                OptionShape found2 = OptionShape.INSTANCE.fromText(shapePart);
                if (found2 != OptionShape.UNKNOWN) {
                    detectedShape3 = found2;
                }
            } else if (StringsKt.startsWith$default(upper, "ANSWER:", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "ANSWER:", false, 2, (Object) null)) {
                directAnswer2 = StringsKt.trim((CharSequence) StringsKt.substringAfter(line, ServerSentEventKt.COLON, "")).toString();
            } else if (StringsKt.startsWith$default(upper, "EXPLANATION:", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "EXPLANATION:", false, 2, (Object) null)) {
                explanation3 = StringsKt.trim((CharSequence) StringsKt.substringAfter(line, ServerSentEventKt.COLON, "")).toString();
            }
        }
        if (detectedShape3 == OptionShape.UNKNOWN) {
            for (String line2 : cleanLines) {
                String upper2 = line2.toUpperCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(upper2, "toUpperCase(...)");
                if (!StringsKt.startsWith$default(upper2, "EXPLANATION:", false, 2, (Object) null) && !StringsKt.contains$default((CharSequence) upper2, (CharSequence) "EXPLANATION:", false, 2, (Object) null) && (found = OptionShape.INSTANCE.fromText(line2)) != OptionShape.UNKNOWN) {
                    detectedShape3 = found;
                    break;
                }
            }
        }
        if (!StringsKt.isBlank(directAnswer2) || cleanLines.isEmpty()) {
            explanation = explanation3;
        } else {
            List list = cleanLines;
            Iterator it3 = list.iterator();
            while (true) {
                if (!it3.hasNext()) {
                    explanation = explanation3;
                    break;
                }
                Object next = it3.next();
                String upperCase = ((String) next).toUpperCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(upperCase, "toUpperCase(...)");
                List cleanLines2 = cleanLines;
                Iterable iterable = list;
                explanation = explanation3;
                if ((StringsKt.contains$default((CharSequence) upperCase, (CharSequence) "OPTION", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upperCase, (CharSequence) "SHAPE", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upperCase, (CharSequence) "CHOICE", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upperCase, (CharSequence) "EXPLANATION", false, 2, (Object) null)) ? false : true) {
                    obj = next;
                    break;
                }
                obj = null;
                explanation3 = explanation;
                list = iterable;
                cleanLines = cleanLines2;
            }
            String str = (String) obj;
            directAnswer2 = str != null ? str : "";
        }
        if (!StringsKt.isBlank(explanation)) {
            explanation2 = explanation;
        } else {
            explanation2 = detectedShape3 != OptionShape.UNKNOWN ? "Správná volba: " + detectedShape3.getCzechName() + " (" + detectedShape3.getSymbol() + ")" : "Ověřeno modelem Gemini.";
        }
        OptionShape detectedShape4 = detectedShape3;
        return new AnswerResult(detectedShape4, !StringsKt.isBlank(directAnswer2) ? directAnswer2 : detectedShape4.getCzechName(), explanation2, sources, null, 0L, modelUsed, durationMs, 48, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String bitmapToBase64(Bitmap bitmap) {
        Bitmap scaledBitmap;
        if (bitmap.getWidth() > 1440.0f || bitmap.getHeight() > 1440.0f) {
            float ratio = 1440.0f / Math.max(bitmap.getWidth(), bitmap.getHeight());
            scaledBitmap = Bitmap.createScaledBitmap(bitmap, RangesKt.coerceAtLeast((int) (bitmap.getWidth() * ratio), 1), RangesKt.coerceAtLeast((int) (bitmap.getHeight() * ratio), 1), true);
        } else {
            scaledBitmap = bitmap;
        }
        Intrinsics.checkNotNull(scaledBitmap);
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream);
        byte[] byteArray = stream.toByteArray();
        String strEncodeToString = Base64.encodeToString(byteArray, 2);
        Intrinsics.checkNotNullExpressionValue(strEncodeToString, "encodeToString(...)");
        return strEncodeToString;
    }

    /* JADX INFO: compiled from: GeminiService.kt */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0002\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005¨\u0006\u0006"}, d2 = {"Lcom/example/data/GeminiService$QuotaExhaustedException;", "Ljava/io/IOException;", "message", "", "<init>", "(Ljava/lang/String;)V", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    private static final class QuotaExhaustedException extends IOException {
        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public QuotaExhaustedException(String message) {
            super(message);
            Intrinsics.checkNotNullParameter(message, "message");
        }
    }
}
