package com.example.data;

import com.example.model.ModelQuotaInfo;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: GeminiRateLimiter.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B;\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\u0004\b\n\u0010\u000bJ\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J\u000f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\b0\u0007HÆ\u0003J\u000f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\b0\u0007HÆ\u0003JG\u0010\u0018\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\u000e\b\u0002\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\u0007HÆ\u0001J\u0013\u0010\u0019\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÖ\u0001J\t\u0010\u001d\u001a\u00020\u001eHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\rR\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0011¨\u0006\u001f"}, d2 = {"Lcom/example/data/RateLimiterOverview;", "", "totalLiteRemaining", "", "totalLiteCallsToday", "liteCallsThisMinute", "primaryModels", "", "Lcom/example/model/ModelQuotaInfo;", "emergencyModels", "<init>", "(IIILjava/util/List;Ljava/util/List;)V", "getTotalLiteRemaining", "()I", "getTotalLiteCallsToday", "getLiteCallsThisMinute", "getPrimaryModels", "()Ljava/util/List;", "getEmergencyModels", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "toString", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final /* data */ class RateLimiterOverview {
    public static final int $stable = 8;
    private final List<ModelQuotaInfo> emergencyModels;
    private final int liteCallsThisMinute;
    private final List<ModelQuotaInfo> primaryModels;
    private final int totalLiteCallsToday;
    private final int totalLiteRemaining;

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ RateLimiterOverview copy$default(RateLimiterOverview rateLimiterOverview, int i, int i2, int i3, List list, List list2, int i4, Object obj) {
        if ((i4 & 1) != 0) {
            i = rateLimiterOverview.totalLiteRemaining;
        }
        if ((i4 & 2) != 0) {
            i2 = rateLimiterOverview.totalLiteCallsToday;
        }
        if ((i4 & 4) != 0) {
            i3 = rateLimiterOverview.liteCallsThisMinute;
        }
        if ((i4 & 8) != 0) {
            list = rateLimiterOverview.primaryModels;
        }
        if ((i4 & 16) != 0) {
            list2 = rateLimiterOverview.emergencyModels;
        }
        List list3 = list2;
        int i5 = i3;
        return rateLimiterOverview.copy(i, i2, i5, list, list3);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getTotalLiteRemaining() {
        return this.totalLiteRemaining;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final int getTotalLiteCallsToday() {
        return this.totalLiteCallsToday;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final int getLiteCallsThisMinute() {
        return this.liteCallsThisMinute;
    }

    public final List<ModelQuotaInfo> component4() {
        return this.primaryModels;
    }

    public final List<ModelQuotaInfo> component5() {
        return this.emergencyModels;
    }

    public final RateLimiterOverview copy(int totalLiteRemaining, int totalLiteCallsToday, int liteCallsThisMinute, List<ModelQuotaInfo> primaryModels, List<ModelQuotaInfo> emergencyModels) {
        Intrinsics.checkNotNullParameter(primaryModels, "primaryModels");
        Intrinsics.checkNotNullParameter(emergencyModels, "emergencyModels");
        return new RateLimiterOverview(totalLiteRemaining, totalLiteCallsToday, liteCallsThisMinute, primaryModels, emergencyModels);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RateLimiterOverview)) {
            return false;
        }
        RateLimiterOverview rateLimiterOverview = (RateLimiterOverview) other;
        return this.totalLiteRemaining == rateLimiterOverview.totalLiteRemaining && this.totalLiteCallsToday == rateLimiterOverview.totalLiteCallsToday && this.liteCallsThisMinute == rateLimiterOverview.liteCallsThisMinute && Intrinsics.areEqual(this.primaryModels, rateLimiterOverview.primaryModels) && Intrinsics.areEqual(this.emergencyModels, rateLimiterOverview.emergencyModels);
    }

    public int hashCode() {
        return (((((((Integer.hashCode(this.totalLiteRemaining) * 31) + Integer.hashCode(this.totalLiteCallsToday)) * 31) + Integer.hashCode(this.liteCallsThisMinute)) * 31) + this.primaryModels.hashCode()) * 31) + this.emergencyModels.hashCode();
    }

    public String toString() {
        return "RateLimiterOverview(totalLiteRemaining=" + this.totalLiteRemaining + ", totalLiteCallsToday=" + this.totalLiteCallsToday + ", liteCallsThisMinute=" + this.liteCallsThisMinute + ", primaryModels=" + this.primaryModels + ", emergencyModels=" + this.emergencyModels + ")";
    }

    public RateLimiterOverview(int totalLiteRemaining, int totalLiteCallsToday, int liteCallsThisMinute, List<ModelQuotaInfo> primaryModels, List<ModelQuotaInfo> emergencyModels) {
        Intrinsics.checkNotNullParameter(primaryModels, "primaryModels");
        Intrinsics.checkNotNullParameter(emergencyModels, "emergencyModels");
        this.totalLiteRemaining = totalLiteRemaining;
        this.totalLiteCallsToday = totalLiteCallsToday;
        this.liteCallsThisMinute = liteCallsThisMinute;
        this.primaryModels = primaryModels;
        this.emergencyModels = emergencyModels;
    }

    public final int getTotalLiteRemaining() {
        return this.totalLiteRemaining;
    }

    public final int getTotalLiteCallsToday() {
        return this.totalLiteCallsToday;
    }

    public final int getLiteCallsThisMinute() {
        return this.liteCallsThisMinute;
    }

    public final List<ModelQuotaInfo> getPrimaryModels() {
        return this.primaryModels;
    }

    public final List<ModelQuotaInfo> getEmergencyModels() {
        return this.emergencyModels;
    }
}
