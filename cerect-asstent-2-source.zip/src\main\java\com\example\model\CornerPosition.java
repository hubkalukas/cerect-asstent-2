package com.example.model;

import io.ktor.http.LinkHeader;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Models.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\f\b\u0086\u0081\u0002\u0018\u0000 \u00102\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u0010B\u0019\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000f¨\u0006\u0011"}, d2 = {"Lcom/example/model/CornerPosition;", "", LinkHeader.Parameters.Title, "", "gravity", "", "<init>", "(Ljava/lang/String;ILjava/lang/String;I)V", "getTitle", "()Ljava/lang/String;", "getGravity", "()I", "TOP_RIGHT", "TOP_LEFT", "BOTTOM_RIGHT", "BOTTOM_LEFT", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public enum CornerPosition {
    TOP_RIGHT("Vpravo nahoře", 8388661),
    TOP_LEFT("Vlevo nahoře", 8388659),
    BOTTOM_RIGHT("Vpravo dole", 8388693),
    BOTTOM_LEFT("Vlevo dole", 8388691);

    private final int gravity;
    private final String title;
    private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);

    public static EnumEntries<CornerPosition> getEntries() {
        return $ENTRIES;
    }

    CornerPosition(String title, int gravity) {
        this.title = title;
        this.gravity = gravity;
    }

    public final int getGravity() {
        return this.gravity;
    }

    public final String getTitle() {
        return this.title;
    }

    /* JADX INFO: compiled from: Models.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007¨\u0006\b"}, d2 = {"Lcom/example/model/CornerPosition$Companion;", "", "<init>", "()V", "fromName", "Lcom/example/model/CornerPosition;", "name", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final CornerPosition fromName(String name) {
            Object next;
            Iterator<CornerPosition> it = CornerPosition.getEntries().iterator();
            do {
                if (!it.hasNext()) {
                    next = null;
                    break;
                }
                next = it.next();
            } while (!Intrinsics.areEqual(((CornerPosition) next).name(), name));
            CornerPosition cornerPosition = (CornerPosition) next;
            return cornerPosition == null ? CornerPosition.TOP_RIGHT : cornerPosition;
        }
    }
}
