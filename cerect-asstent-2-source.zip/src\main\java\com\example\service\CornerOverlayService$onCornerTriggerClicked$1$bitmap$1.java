package com.example.service;

import android.graphics.Bitmap;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.CoroutineScope;

/* JADX INFO: compiled from: CornerOverlayService.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Landroid/graphics/Bitmap;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@DebugMetadata(c = "com.example.service.CornerOverlayService$onCornerTriggerClicked$1$bitmap$1", f = "CornerOverlayService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
final class CornerOverlayService$onCornerTriggerClicked$1$bitmap$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Bitmap>, Object> {
    int label;
    final /* synthetic */ CornerOverlayService this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    CornerOverlayService$onCornerTriggerClicked$1$bitmap$1(CornerOverlayService cornerOverlayService, Continuation<? super CornerOverlayService$onCornerTriggerClicked$1$bitmap$1> continuation) {
        super(2, continuation);
        this.this$0 = cornerOverlayService;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new CornerOverlayService$onCornerTriggerClicked$1$bitmap$1(this.this$0, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Bitmap> continuation) {
        return ((CornerOverlayService$onCornerTriggerClicked$1$bitmap$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object $result) {
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                ScreenCaptureManager screenCaptureManager = this.this$0.screenCaptureManager;
                if (screenCaptureManager == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("screenCaptureManager");
                    screenCaptureManager = null;
                }
                return screenCaptureManager.captureScreen();
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }
}
