package com.example;

/* JADX INFO: loaded from: classes2.dex */
public final class R {

    public static final class color {
        public static int black = 0x7f020002;
        public static int purple_200 = 0x7f020012;
        public static int purple_500 = 0x7f020013;
        public static int purple_700 = 0x7f020014;
        public static int teal_200 = 0x7f020015;
        public static int teal_700 = 0x7f020016;
        public static int white = 0x7f020019;

        private color() {
        }
    }

    public static final class drawable {
        public static int ic_launcher_background = 0x7f04001d;
        public static int ic_launcher_foreground = 0x7f04001e;

        private drawable() {
        }
    }

    public static final class mipmap {
        public static int ic_launcher = 0x7f080000;
        public static int ic_launcher_round = 0x7f080001;

        private mipmap() {
        }
    }

    public static final class string {
        public static int app_name = 0x7f0a0001;

        private string() {
        }
    }

    public static final class style {
        public static int Theme_MyApplication = 0x7f0b000a;

        private style() {
        }
    }

    public static final class xml {
        public static int backup_rules = 0x7f0d0000;
        public static int data_extraction_rules = 0x7f0d0001;

        private xml() {
        }
    }

    private R() {
    }
}
