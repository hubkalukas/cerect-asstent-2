package com.example.data;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: AppPreferences.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b\u0014\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B?\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\n¢\u0006\u0004\b\u000b\u0010\fJ\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\nHÆ\u0003JO\u0010\u001d\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\nHÆ\u0001J\u0013\u0010\u001e\u001a\u00020\u001f2\b\u0010 \u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010!\u001a\u00020\u0003HÖ\u0001J\t\u0010\"\u001a\u00020\nHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000eR\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000eR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015¨\u0006#"}, d2 = {"Lcom/example/data/ApiUsageStats;", "", "usedToday", "", "dailyLimit", "remainingToday", "usedThisMinute", "minuteLimit", "remainingThisMinute", "lastResetDate", "", "<init>", "(IIIIIILjava/lang/String;)V", "getUsedToday", "()I", "getDailyLimit", "getRemainingToday", "getUsedThisMinute", "getMinuteLimit", "getRemainingThisMinute", "getLastResetDate", "()Ljava/lang/String;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "copy", "equals", "", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final /* data */ class ApiUsageStats {
    public static final int $stable = 0;
    private final int dailyLimit;
    private final String lastResetDate;
    private final int minuteLimit;
    private final int remainingThisMinute;
    private final int remainingToday;
    private final int usedThisMinute;
    private final int usedToday;

    public static /* synthetic */ ApiUsageStats copy$default(ApiUsageStats apiUsageStats, int i, int i2, int i3, int i4, int i5, int i6, String str, int i7, Object obj) {
        if ((i7 & 1) != 0) {
            i = apiUsageStats.usedToday;
        }
        if ((i7 & 2) != 0) {
            i2 = apiUsageStats.dailyLimit;
        }
        if ((i7 & 4) != 0) {
            i3 = apiUsageStats.remainingToday;
        }
        if ((i7 & 8) != 0) {
            i4 = apiUsageStats.usedThisMinute;
        }
        if ((i7 & 16) != 0) {
            i5 = apiUsageStats.minuteLimit;
        }
        if ((i7 & 32) != 0) {
            i6 = apiUsageStats.remainingThisMinute;
        }
        if ((i7 & 64) != 0) {
            str = apiUsageStats.lastResetDate;
        }
        int i8 = i6;
        String str2 = str;
        int i9 = i5;
        int i10 = i3;
        return apiUsageStats.copy(i, i2, i10, i4, i9, i8, str2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getUsedToday() {
        return this.usedToday;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final int getDailyLimit() {
        return this.dailyLimit;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final int getRemainingToday() {
        return this.remainingToday;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final int getUsedThisMinute() {
        return this.usedThisMinute;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final int getMinuteLimit() {
        return this.minuteLimit;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final int getRemainingThisMinute() {
        return this.remainingThisMinute;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final String getLastResetDate() {
        return this.lastResetDate;
    }

    public final ApiUsageStats copy(int usedToday, int dailyLimit, int remainingToday, int usedThisMinute, int minuteLimit, int remainingThisMinute, String lastResetDate) {
        Intrinsics.checkNotNullParameter(lastResetDate, "lastResetDate");
        return new ApiUsageStats(usedToday, dailyLimit, remainingToday, usedThisMinute, minuteLimit, remainingThisMinute, lastResetDate);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ApiUsageStats)) {
            return false;
        }
        ApiUsageStats apiUsageStats = (ApiUsageStats) other;
        return this.usedToday == apiUsageStats.usedToday && this.dailyLimit == apiUsageStats.dailyLimit && this.remainingToday == apiUsageStats.remainingToday && this.usedThisMinute == apiUsageStats.usedThisMinute && this.minuteLimit == apiUsageStats.minuteLimit && this.remainingThisMinute == apiUsageStats.remainingThisMinute && Intrinsics.areEqual(this.lastResetDate, apiUsageStats.lastResetDate);
    }

    public int hashCode() {
        return (((((((((((Integer.hashCode(this.usedToday) * 31) + Integer.hashCode(this.dailyLimit)) * 31) + Integer.hashCode(this.remainingToday)) * 31) + Integer.hashCode(this.usedThisMinute)) * 31) + Integer.hashCode(this.minuteLimit)) * 31) + Integer.hashCode(this.remainingThisMinute)) * 31) + this.lastResetDate.hashCode();
    }

    public String toString() {
        return "ApiUsageStats(usedToday=" + this.usedToday + ", dailyLimit=" + this.dailyLimit + ", remainingToday=" + this.remainingToday + ", usedThisMinute=" + this.usedThisMinute + ", minuteLimit=" + this.minuteLimit + ", remainingThisMinute=" + this.remainingThisMinute + ", lastResetDate=" + this.lastResetDate + ")";
    }

    public ApiUsageStats(int usedToday, int dailyLimit, int remainingToday, int usedThisMinute, int minuteLimit, int remainingThisMinute, String lastResetDate) {
        Intrinsics.checkNotNullParameter(lastResetDate, "lastResetDate");
        this.usedToday = usedToday;
        this.dailyLimit = dailyLimit;
        this.remainingToday = remainingToday;
        this.usedThisMinute = usedThisMinute;
        this.minuteLimit = minuteLimit;
        this.remainingThisMinute = remainingThisMinute;
        this.lastResetDate = lastResetDate;
    }

    public final int getUsedToday() {
        return this.usedToday;
    }

    public final int getDailyLimit() {
        return this.dailyLimit;
    }

    public final int getRemainingToday() {
        return this.remainingToday;
    }

    public final int getUsedThisMinute() {
        return this.usedThisMinute;
    }

    public final int getMinuteLimit() {
        return this.minuteLimit;
    }

    public final int getRemainingThisMinute() {
        return this.remainingThisMinute;
    }

    public final String getLastResetDate() {
        return this.lastResetDate;
    }
}
