package com.example.ui;

import androidx.compose.runtime.MutableState;
import com.example.data.AppPreferences;
import com.example.data.GeminiService;
import com.example.model.AnswerResult;
import com.example.model.OptionShape;
import com.example.model.ScanHistoryItem;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlinx.coroutines.CoroutineScope;
import org.json.JSONException;

/* JADX INFO: compiled from: QuizSandbox.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@DebugMetadata(c = "com.example.ui.QuizSandboxKt$QuizSandbox$triggerCornerScan$1", f = "QuizSandbox.kt", i = {}, l = {187}, m = "invokeSuspend", n = {}, s = {})
final class QuizSandboxKt$QuizSandbox$triggerCornerScan$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ MutableState<AnswerResult> $answerResult$delegate;
    final /* synthetic */ QuizOptionQuestion $currentQuestion;
    final /* synthetic */ MutableState<String> $customQuestionText$delegate;
    final /* synthetic */ MutableState<OptionShape> $detectedShape$delegate;
    final /* synthetic */ GeminiService $geminiService;
    final /* synthetic */ MutableState<Boolean> $isAnalyzing$delegate;
    final /* synthetic */ MutableState<Boolean> $isCustomMode$delegate;
    final /* synthetic */ AppPreferences $preferences;
    final /* synthetic */ String $questionText;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    QuizSandboxKt$QuizSandbox$triggerCornerScan$1(AppPreferences appPreferences, GeminiService geminiService, String str, MutableState<Boolean> mutableState, QuizOptionQuestion quizOptionQuestion, MutableState<AnswerResult> mutableState2, MutableState<OptionShape> mutableState3, MutableState<Boolean> mutableState4, MutableState<String> mutableState5, Continuation<? super QuizSandboxKt$QuizSandbox$triggerCornerScan$1> continuation) {
        super(2, continuation);
        this.$preferences = appPreferences;
        this.$geminiService = geminiService;
        this.$questionText = str;
        this.$isAnalyzing$delegate = mutableState;
        this.$currentQuestion = quizOptionQuestion;
        this.$answerResult$delegate = mutableState2;
        this.$detectedShape$delegate = mutableState3;
        this.$isCustomMode$delegate = mutableState4;
        this.$customQuestionText$delegate = mutableState5;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new QuizSandboxKt$QuizSandbox$triggerCornerScan$1(this.$preferences, this.$geminiService, this.$questionText, this.$isAnalyzing$delegate, this.$currentQuestion, this.$answerResult$delegate, this.$detectedShape$delegate, this.$isCustomMode$delegate, this.$customQuestionText$delegate, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((QuizSandboxKt$QuizSandbox$triggerCornerScan$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object $result) throws JSONException {
        Object result;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                this.$preferences.recordApiCall();
                this.label = 1;
                Object objM6935analyzeScreenyxL6bBk = this.$geminiService.m6935analyzeScreenyxL6bBk(null, this.$preferences.getCustomApiKey(), this.$questionText, this.$preferences.getRateLimiter(), this);
                if (objM6935analyzeScreenyxL6bBk == coroutine_suspended) {
                    return coroutine_suspended;
                }
                result = objM6935analyzeScreenyxL6bBk;
                break;
                break;
            case 1:
                ResultKt.throwOnFailure($result);
                result = ((Result) $result).getValue();
                break;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        QuizSandboxKt.QuizSandbox$lambda$14(this.$isAnalyzing$delegate, false);
        AppPreferences appPreferences = this.$preferences;
        QuizOptionQuestion quizOptionQuestion = this.$currentQuestion;
        MutableState<AnswerResult> mutableState = this.$answerResult$delegate;
        MutableState<OptionShape> mutableState2 = this.$detectedShape$delegate;
        MutableState<Boolean> mutableState3 = this.$isCustomMode$delegate;
        MutableState<String> mutableState4 = this.$customQuestionText$delegate;
        if (Result.m7092isSuccessimpl(result)) {
            AnswerResult answerResult = (AnswerResult) result;
            mutableState.setValue(answerResult);
            mutableState2.setValue(answerResult.getOptionShape());
            String string = UUID.randomUUID().toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            appPreferences.addHistoryItem(new ScanHistoryItem(string, answerResult.getOptionShape(), answerResult.getDirectAnswer(), answerResult.getExplanation(), QuizSandboxKt.QuizSandbox$lambda$10(mutableState3) ? StringsKt.take(QuizSandboxKt.QuizSandbox$lambda$7(mutableState4), 50) : quizOptionQuestion.getQuestion(), answerResult.getSearchSources(), answerResult.getTimestamp(), answerResult.getModelUsed(), answerResult.getDurationMs()));
        }
        QuizOptionQuestion quizOptionQuestion2 = this.$currentQuestion;
        MutableState<AnswerResult> mutableState5 = this.$answerResult$delegate;
        MutableState<OptionShape> mutableState6 = this.$detectedShape$delegate;
        if (Result.m7088exceptionOrNullimpl(result) != null) {
            mutableState5.setValue(new AnswerResult(quizOptionQuestion2.getCorrectShape(), quizOptionQuestion2.getCorrectShape().getCzechName(), "Cvičná odpověď pro tuto otázku.", CollectionsKt.emptyList(), null, 0L, "Cvičný režim", 0L, 176, null));
            mutableState6.setValue(quizOptionQuestion2.getCorrectShape());
        }
        return Unit.INSTANCE;
    }
}
