package com.example.ui;

import androidx.compose.runtime.MutableState;
import com.example.data.AppPreferences;
import com.example.model.OptionShape;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.DelayKt;

/* JADX INFO: compiled from: QuizSandbox.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@DebugMetadata(c = "com.example.ui.QuizSandboxKt$QuizSandbox$1$1", f = "QuizSandbox.kt", i = {}, l = {162}, m = "invokeSuspend", n = {}, s = {})
final class QuizSandboxKt$QuizSandbox$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ MutableState<OptionShape> $detectedShape$delegate;
    final /* synthetic */ AppPreferences $preferences;
    int label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    QuizSandboxKt$QuizSandbox$1$1(AppPreferences appPreferences, MutableState<OptionShape> mutableState, Continuation<? super QuizSandboxKt$QuizSandbox$1$1> continuation) {
        super(2, continuation);
        this.$preferences = appPreferences;
        this.$detectedShape$delegate = mutableState;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new QuizSandboxKt$QuizSandbox$1$1(this.$preferences, this.$detectedShape$delegate, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
        return ((QuizSandboxKt$QuizSandbox$1$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object $result) {
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                if (QuizSandboxKt.QuizSandbox$lambda$19(this.$detectedShape$delegate) != null && this.$preferences.getAutoDismissSeconds() > 0) {
                    this.label = 1;
                    if (DelayKt.delay(((long) this.$preferences.getAutoDismissSeconds()) * 1000, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    this.$detectedShape$delegate.setValue(null);
                }
                return Unit.INSTANCE;
            case 1:
                ResultKt.throwOnFailure($result);
                this.$detectedShape$delegate.setValue(null);
                return Unit.INSTANCE;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }
}
