package com.example.ui;

import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.filled.CheckCircleKt;
import androidx.compose.material.icons.filled.InfoKt;
import androidx.compose.material.icons.filled.RestartAltKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.text.TextLayoutResult;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.TextUnitKt;
import com.example.ui.theme.ColorKt;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: SettingsScreen.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
public final class ComposableSingletons$SettingsScreenKt {
    public static final ComposableSingletons$SettingsScreenKt INSTANCE = new ComposableSingletons$SettingsScreenKt();

    /* JADX INFO: renamed from: lambda$-1924913272, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f97lambda$1924913272 = ComposableLambdaKt.composableLambdaInstance(-1924913272, false, new Function3() { // from class: com.example.ui.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$SettingsScreenKt.lambda__1924913272$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$117102760 = ComposableLambdaKt.composableLambdaInstance(117102760, false, new Function2() { // from class: com.example.ui.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$SettingsScreenKt.lambda_117102760$lambda$2((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-899787907, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f101lambda$899787907 = ComposableLambdaKt.composableLambdaInstance(-899787907, false, new Function2() { // from class: com.example.ui.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$SettingsScreenKt.lambda__899787907$lambda$3((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$1567105667 = ComposableLambdaKt.composableLambdaInstance(1567105667, false, new Function2() { // from class: com.example.ui.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$SettingsScreenKt.lambda_1567105667$lambda$4((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-220087124, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f99lambda$220087124 = ComposableLambdaKt.composableLambdaInstance(-220087124, false, new Function3() { // from class: com.example.ui.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda4
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$SettingsScreenKt.lambda__220087124$lambda$5((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$1732457515 = ComposableLambdaKt.composableLambdaInstance(1732457515, false, new Function2() { // from class: com.example.ui.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda5
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$SettingsScreenKt.lambda_1732457515$lambda$6((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function3<RowScope, Composer, Integer, Unit> lambda$423725402 = ComposableLambdaKt.composableLambdaInstance(423725402, false, new Function3() { // from class: com.example.ui.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda6
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$SettingsScreenKt.lambda_423725402$lambda$7((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-612554179, reason: not valid java name */
    private static Function3<ColumnScope, Composer, Integer, Unit> f100lambda$612554179 = ComposableLambdaKt.composableLambdaInstance(-612554179, false, new Function3() { // from class: com.example.ui.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda7
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$SettingsScreenKt.lambda__612554179$lambda$11((ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-217806595, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f98lambda$217806595 = ComposableLambdaKt.composableLambdaInstance(-217806595, false, new Function2() { // from class: com.example.ui.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda8
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$SettingsScreenKt.lambda__217806595$lambda$12((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* JADX INFO: renamed from: getLambda$-1924913272$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m6945getLambda$1924913272$app() {
        return f97lambda$1924913272;
    }

    /* JADX INFO: renamed from: getLambda$-217806595$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m6946getLambda$217806595$app() {
        return f98lambda$217806595;
    }

    /* JADX INFO: renamed from: getLambda$-220087124$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m6947getLambda$220087124$app() {
        return f99lambda$220087124;
    }

    /* JADX INFO: renamed from: getLambda$-612554179$app, reason: not valid java name */
    public final Function3<ColumnScope, Composer, Integer, Unit> m6948getLambda$612554179$app() {
        return f100lambda$612554179;
    }

    /* JADX INFO: renamed from: getLambda$-899787907$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m6949getLambda$899787907$app() {
        return f101lambda$899787907;
    }

    public final Function2<Composer, Integer, Unit> getLambda$117102760$app() {
        return lambda$117102760;
    }

    public final Function2<Composer, Integer, Unit> getLambda$1567105667$app() {
        return lambda$1567105667;
    }

    public final Function2<Composer, Integer, Unit> getLambda$1732457515$app() {
        return lambda$1732457515;
    }

    public final Function3<RowScope, Composer, Integer, Unit> getLambda$423725402$app() {
        return lambda$423725402;
    }

    static final Unit lambda__1924913272$lambda$0(RowScope OutlinedButton, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(OutlinedButton, "$this$OutlinedButton");
        ComposerKt.sourceInformation($composer, "C218@8345L90,219@8448L39,220@8500L35:SettingsScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1924913272, $changed, -1, "com.example.ui.ComposableSingletons$SettingsScreenKt.lambda$-1924913272.<anonymous> (SettingsScreen.kt:218)");
            }
            IconKt.m2150Iconww6aTOc(RestartAltKt.getRestartAlt(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), 0L, $composer, 432, 8);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(4)), $composer, 6);
            TextKt.m2693Text4IGK_g("Resetovat", (Modifier) null, 0L, TextUnitKt.getSp(12), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3078, 0, 131062);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_117102760$lambda$2(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C259@9687L601:SettingsScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(117102760, $changed, -1, "com.example.ui.ComposableSingletons$SettingsScreenKt.lambda$117102760.<anonymous> (SettingsScreen.kt:259)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10));
            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically, $composer, ((390 >> 3) & 14) | ((390 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((390 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                $composer.createNode(constructor);
            } else {
                $composer.useNode();
            }
            Composer composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i2 = (i >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            int i3 = ((390 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, 1735512358, "C263@9833L194,269@10042L39,270@10096L178:SettingsScreen.kt#naom5h");
            IconKt.m2150Iconww6aTOc(CheckCircleKt.getCheckCircle(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(18)), ColorKt.getEmeraldSuccess(), $composer, 3504, 0);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), $composer, 6);
            TextKt.m2693Text4IGK_g("Systémový API klíč je nakonfigurován v AI Studio Secrets.", (Modifier) null, ColorKt.getEmeraldSuccess(), TextUnitKt.getSp(12), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3462, 0, 131058);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__899787907$lambda$3(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C315@11852L282:SettingsScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-899787907, $changed, -1, "com.example.ui.ComposableSingletons$SettingsScreenKt.lambda$-899787907.<anonymous> (SettingsScreen.kt:315)");
            }
            TextKt.m2693Text4IGK_g("Aktivní 🔓", PaddingKt.m671paddingVpY3zN4(Modifier.INSTANCE, Dp.m6622constructorimpl(6), Dp.m6622constructorimpl(2)), ColorKt.getEmeraldSuccess(), TextUnitKt.getSp(11), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 200118, 0, 131024);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1567105667$lambda$4(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C346@13039L29:SettingsScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1567105667, $changed, -1, "com.example.ui.ComposableSingletons$SettingsScreenKt.lambda$1567105667.<anonymous> (SettingsScreen.kt:346)");
            }
            TextKt.m2693Text4IGK_g("Heslo / PIN (3011)...", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 6, 0, 131070);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__220087124$lambda$5(RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C375@14216L17:SettingsScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-220087124, $changed, -1, "com.example.ui.ComposableSingletons$SettingsScreenKt.lambda$-220087124.<anonymous> (SettingsScreen.kt:375)");
            }
            TextKt.m2693Text4IGK_g("Odemknout", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 6, 0, 131070);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1732457515$lambda$6(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C414@15427L37:SettingsScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1732457515, $changed, -1, "com.example.ui.ComposableSingletons$SettingsScreenKt.lambda$1732457515.<anonymous> (SettingsScreen.kt:414)");
            }
            TextKt.m2693Text4IGK_g("Zadejte AI Studio API klíč...", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 6, 0, 131070);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_423725402$lambda$7(RowScope OutlinedButton, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(OutlinedButton, "$this$OutlinedButton");
        ComposerKt.sourceInformation($composer, "C456@16863L15:SettingsScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(423725402, $changed, -1, "com.example.ui.ComposableSingletons$SettingsScreenKt.lambda$423725402.<anonymous> (SettingsScreen.kt:456)");
            }
            TextKt.m2693Text4IGK_g("Vymazat", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 6, 0, 131070);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:28:0x01c4  */
    /* JADX WARN: Code duplicated, block: B:31:0x01d0  */
    /* JADX WARN: Code duplicated, block: B:32:0x01d6  */
    /* JADX WARN: Code duplicated, block: B:35:0x0207  */
    /* JADX WARN: Code duplicated, block: B:38:0x021a  */
    /* JADX WARN: Code duplicated, block: B:39:0x021d  */
    /* JADX WARN: Code duplicated, block: B:44:0x0365 A[LOOP:0: B:42:0x035f->B:44:0x0365, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:47:0x0401  */
    static final Unit lambda__612554179$lambda$11(ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        int i;
        Composer composer;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function1;
        Composer composerM3652constructorimpl;
        Composer composer2;
        List listListOf;
        List list;
        int i2;
        Iterator it;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C479@17582L1521:SettingsScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-612554179, $changed, -1, "com.example.ui.ComposableSingletons$SettingsScreenKt.lambda$-612554179.<anonymous> (SettingsScreen.kt:479)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i3 = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor2;
                $composer.createNode(function0);
            } else {
                function0 = constructor2;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl2 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl2.getInserting()) {
                i = 6;
            } else {
                i = 6;
                if (!Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i4 = (i3 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i5 = ((i >> 6) & 112) | 6;
                composer = $composer;
                ComposerKt.sourceInformationMarkerStart(composer, 951795964, "C480@17635L489,495@18134L41:SettingsScreen.kt#naom5h");
                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                Modifier modifier = Modifier.INSTANCE;
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically, composer, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composer, modifier);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i6 = ((((384 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    function1 = constructor;
                    composer.createNode(function1);
                } else {
                    function1 = constructor;
                    composer.useNode();
                }
                composerM3652constructorimpl = Updater.m3652constructorimpl(composer);
                Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (composerM3652constructorimpl.getInserting()) {
                    composer2 = composer;
                } else {
                    composer2 = composer;
                    if (!Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    }
                    Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                    int i7 = (i6 >> 6) & 14;
                    Composer composer3 = composer2;
                    ComposerKt.sourceInformationMarkerStart(composer3, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                    RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                    int i8 = ((384 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer3, 1646982477, "C481@17699L178,487@17888L39,490@18039L10,488@17938L176:SettingsScreen.kt#naom5h");
                    IconKt.m2150Iconww6aTOc(InfoKt.getInfo(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), ColorKt.getIndigoLight(), composer3, 3504, 0);
                    SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), composer3, 6);
                    TextKt.m2693Text4IGK_g("Návod k použití v ostatních aplikacích", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer3, MaterialTheme.$stable).getTitleSmall(), composer3, 196614, 0, 65502);
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer, 6);
                    listListOf = CollectionsKt.listOf((Object[]) new String[]{"1. Přejděte na záložku 'Překrytí' a klikněte na 'Spustit v rohu obrazovky'.", "2. Povolte vykreslování přes aplikace a potvrďte snímání obrazovky.", "3. Minimalizujte aplikaci a spusťte požadovaný kvíz nebo test.", "4. Jakmile se objeví otázka s možnostmi, klepněte na nenápadný bod v rohu obrazovky.", "5. Rohový bod se okamžitě přebarví a ukáže přímo symbol (▲ Červená, ◆ Modrá, ● Žlutá, ■ Zelená) bez jakéhokoliv rušivého textu.", "6. Klepnutím do rohu jej můžete kdykoliv resetovat zpět do neutrálního režimu."});
                    composer.startReplaceGroup(-523449932);
                    ComposerKt.sourceInformation(composer, "*509@18899L10,511@18987L11,507@18834L251");
                    list = listListOf;
                    i2 = 0;
                    it = list.iterator();
                    while (it.hasNext()) {
                        Composer composer4 = composer;
                        TextKt.m2693Text4IGK_g((String) it.next(), PaddingKt.m672paddingVpY3zN4$default(Modifier.INSTANCE, 0.0f, Dp.m6622constructorimpl(2), 1, null), MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, TextUnitKt.getSp(18), 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getBodySmall(), composer4, 48, 6, 64504);
                        listListOf = listListOf;
                        i2 = i2;
                        list = list;
                        composer = composer4;
                    }
                    Composer composer5 = composer;
                    composer5.endReplaceGroup();
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    $composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                }
                composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash2);
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i9 = (i6 >> 6) & 14;
                Composer composer6 = composer2;
                ComposerKt.sourceInformationMarkerStart(composer6, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                int i10 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer6, 1646982477, "C481@17699L178,487@17888L39,490@18039L10,488@17938L176:SettingsScreen.kt#naom5h");
                IconKt.m2150Iconww6aTOc(InfoKt.getInfo(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), ColorKt.getIndigoLight(), composer6, 3504, 0);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), composer6, 6);
                TextKt.m2693Text4IGK_g("Návod k použití v ostatních aplikacích", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer6, MaterialTheme.$stable).getTitleSmall(), composer6, 196614, 0, 65502);
                ComposerKt.sourceInformationMarkerEnd(composer6);
                ComposerKt.sourceInformationMarkerEnd(composer6);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer, 6);
                listListOf = CollectionsKt.listOf((Object[]) new String[]{"1. Přejděte na záložku 'Překrytí' a klikněte na 'Spustit v rohu obrazovky'.", "2. Povolte vykreslování přes aplikace a potvrďte snímání obrazovky.", "3. Minimalizujte aplikaci a spusťte požadovaný kvíz nebo test.", "4. Jakmile se objeví otázka s možnostmi, klepněte na nenápadný bod v rohu obrazovky.", "5. Rohový bod se okamžitě přebarví a ukáže přímo symbol (▲ Červená, ◆ Modrá, ● Žlutá, ■ Zelená) bez jakéhokoliv rušivého textu.", "6. Klepnutím do rohu jej můžete kdykoliv resetovat zpět do neutrálního režimu."});
                composer.startReplaceGroup(-523449932);
                ComposerKt.sourceInformation(composer, "*509@18899L10,511@18987L11,507@18834L251");
                list = listListOf;
                i2 = 0;
                it = list.iterator();
                while (it.hasNext()) {
                    Composer composer7 = composer;
                    TextKt.m2693Text4IGK_g((String) it.next(), PaddingKt.m672paddingVpY3zN4$default(Modifier.INSTANCE, 0.0f, Dp.m6622constructorimpl(2), 1, null), MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, TextUnitKt.getSp(18), 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getBodySmall(), composer7, 48, 6, 64504);
                    listListOf = listListOf;
                    i2 = i2;
                    list = list;
                    composer = composer7;
                }
                Composer composer8 = composer;
                composer8.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer8);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash);
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i11 = (i3 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
            int i12 = ((i >> 6) & 112) | 6;
            composer = $composer;
            ComposerKt.sourceInformationMarkerStart(composer, 951795964, "C480@17635L489,495@18134L41:SettingsScreen.kt#naom5h");
            Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            Modifier modifier2 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically2, composer, ((384 >> 3) & 14) | ((384 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            CompositionLocalMap currentCompositionLocalMap3 = composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composer, modifier2);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i13 = ((((384 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                function1 = constructor;
                composer.createNode(function1);
            } else {
                function1 = constructor;
                composer.useNode();
            }
            composerM3652constructorimpl = Updater.m3652constructorimpl(composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting()) {
                composer2 = composer;
                if (!Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i14 = (i13 >> 6) & 14;
                Composer composer9 = composer2;
                ComposerKt.sourceInformationMarkerStart(composer9, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance3 = RowScopeInstance.INSTANCE;
                int i15 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer9, 1646982477, "C481@17699L178,487@17888L39,490@18039L10,488@17938L176:SettingsScreen.kt#naom5h");
                IconKt.m2150Iconww6aTOc(InfoKt.getInfo(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), ColorKt.getIndigoLight(), composer9, 3504, 0);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), composer9, 6);
                TextKt.m2693Text4IGK_g("Návod k použití v ostatních aplikacích", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer9, MaterialTheme.$stable).getTitleSmall(), composer9, 196614, 0, 65502);
                ComposerKt.sourceInformationMarkerEnd(composer9);
                ComposerKt.sourceInformationMarkerEnd(composer9);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer, 6);
                listListOf = CollectionsKt.listOf((Object[]) new String[]{"1. Přejděte na záložku 'Překrytí' a klikněte na 'Spustit v rohu obrazovky'.", "2. Povolte vykreslování přes aplikace a potvrďte snímání obrazovky.", "3. Minimalizujte aplikaci a spusťte požadovaný kvíz nebo test.", "4. Jakmile se objeví otázka s možnostmi, klepněte na nenápadný bod v rohu obrazovky.", "5. Rohový bod se okamžitě přebarví a ukáže přímo symbol (▲ Červená, ◆ Modrá, ● Žlutá, ■ Zelená) bez jakéhokoliv rušivého textu.", "6. Klepnutím do rohu jej můžete kdykoliv resetovat zpět do neutrálního režimu."});
                composer.startReplaceGroup(-523449932);
                ComposerKt.sourceInformation(composer, "*509@18899L10,511@18987L11,507@18834L251");
                list = listListOf;
                i2 = 0;
                it = list.iterator();
                while (it.hasNext()) {
                    Composer composer10 = composer;
                    TextKt.m2693Text4IGK_g((String) it.next(), PaddingKt.m672paddingVpY3zN4$default(Modifier.INSTANCE, 0.0f, Dp.m6622constructorimpl(2), 1, null), MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, TextUnitKt.getSp(18), 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getBodySmall(), composer10, 48, 6, 64504);
                    listListOf = listListOf;
                    i2 = i2;
                    list = list;
                    composer = composer10;
                }
                Composer composer11 = composer;
                composer11.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer11);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composer2 = composer;
            }
            composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash3);
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
            int i16 = (i13 >> 6) & 14;
            Composer composer12 = composer2;
            ComposerKt.sourceInformationMarkerStart(composer12, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance4 = RowScopeInstance.INSTANCE;
            int i17 = ((384 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer12, 1646982477, "C481@17699L178,487@17888L39,490@18039L10,488@17938L176:SettingsScreen.kt#naom5h");
            IconKt.m2150Iconww6aTOc(InfoKt.getInfo(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), ColorKt.getIndigoLight(), composer12, 3504, 0);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), composer12, 6);
            TextKt.m2693Text4IGK_g("Návod k použití v ostatních aplikacích", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer12, MaterialTheme.$stable).getTitleSmall(), composer12, 196614, 0, 65502);
            ComposerKt.sourceInformationMarkerEnd(composer12);
            ComposerKt.sourceInformationMarkerEnd(composer12);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer, 6);
            listListOf = CollectionsKt.listOf((Object[]) new String[]{"1. Přejděte na záložku 'Překrytí' a klikněte na 'Spustit v rohu obrazovky'.", "2. Povolte vykreslování přes aplikace a potvrďte snímání obrazovky.", "3. Minimalizujte aplikaci a spusťte požadovaný kvíz nebo test.", "4. Jakmile se objeví otázka s možnostmi, klepněte na nenápadný bod v rohu obrazovky.", "5. Rohový bod se okamžitě přebarví a ukáže přímo symbol (▲ Červená, ◆ Modrá, ● Žlutá, ■ Zelená) bez jakéhokoliv rušivého textu.", "6. Klepnutím do rohu jej můžete kdykoliv resetovat zpět do neutrálního režimu."});
            composer.startReplaceGroup(-523449932);
            ComposerKt.sourceInformation(composer, "*509@18899L10,511@18987L11,507@18834L251");
            list = listListOf;
            i2 = 0;
            it = list.iterator();
            while (it.hasNext()) {
                Composer composer13 = composer;
                TextKt.m2693Text4IGK_g((String) it.next(), PaddingKt.m672paddingVpY3zN4$default(Modifier.INSTANCE, 0.0f, Dp.m6622constructorimpl(2), 1, null), MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, TextUnitKt.getSp(18), 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getBodySmall(), composer13, 48, 6, 64504);
                listListOf = listListOf;
                i2 = i2;
                list = list;
                composer = composer13;
            }
            Composer composer14 = composer;
            composer14.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer14);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__217806595$lambda$12(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C551@20137L256:SettingsScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-217806595, $changed, -1, "com.example.ui.ComposableSingletons$SettingsScreenKt.lambda$-217806595.<anonymous> (SettingsScreen.kt:551)");
            }
            TextKt.m2693Text4IGK_g("Primary", PaddingKt.m671paddingVpY3zN4(Modifier.INSTANCE, Dp.m6622constructorimpl(4), Dp.m6622constructorimpl(2)), ColorKt.getIndigoLight(), TextUnitKt.getSp(10), (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 200118, 0, 131024);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
