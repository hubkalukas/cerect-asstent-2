package com.example.ui.theme;

import kotlin.Metadata;

/* JADX INFO: compiled from: Color.kt */
/* JADX INFO: loaded from: classes3.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\"\"\u0013\u0010\u0000\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0002\u0010\u0003\"\u0013\u0010\u0005\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0006\u0010\u0003\"\u0013\u0010\u0007\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\b\u0010\u0003\"\u0013\u0010\t\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\n\u0010\u0003\"\u0013\u0010\u000b\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\f\u0010\u0003\"\u0013\u0010\r\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u000e\u0010\u0003\"\u0013\u0010\u000f\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0010\u0010\u0003\"\u0013\u0010\u0011\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0012\u0010\u0003\"\u0013\u0010\u0013\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0014\u0010\u0003\"\u0013\u0010\u0015\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0016\u0010\u0003\"\u0013\u0010\u0017\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0018\u0010\u0003\"\u0013\u0010\u0019\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001a\u0010\u0003\"\u0013\u0010\u001b\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001c\u0010\u0003\"\u0013\u0010\u001d\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u001e\u0010\u0003\"\u0013\u0010\u001f\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b \u0010\u0003\"\u0013\u0010!\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\"\u0010\u0003¨\u0006#"}, d2 = {"IndigoPrimary", "Landroidx/compose/ui/graphics/Color;", "getIndigoPrimary", "()J", "J", "IndigoLight", "getIndigoLight", "IndigoDark", "getIndigoDark", "AmberAccent", "getAmberAccent", "EmeraldSuccess", "getEmeraldSuccess", "CoralRed", "getCoralRed", "SlateBackgroundLight", "getSlateBackgroundLight", "SlateSurfaceLight", "getSlateSurfaceLight", "SlateBackgroundDark", "getSlateBackgroundDark", "SlateSurfaceDark", "getSlateSurfaceDark", "Purple80", "getPurple80", "PurpleGrey80", "getPurpleGrey80", "Pink80", "getPink80", "Purple40", "getPurple40", "PurpleGrey40", "getPurpleGrey40", "Pink40", "getPink40", "app"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class ColorKt {
    private static final long IndigoPrimary = androidx.compose.ui.graphics.ColorKt.Color(4283385573L);
    private static final long IndigoLight = androidx.compose.ui.graphics.ColorKt.Color(4284704497L);
    private static final long IndigoDark = androidx.compose.ui.graphics.ColorKt.Color(4281807011L);
    private static final long AmberAccent = androidx.compose.ui.graphics.ColorKt.Color(4294286859L);
    private static final long EmeraldSuccess = androidx.compose.ui.graphics.ColorKt.Color(4279286145L);
    private static final long CoralRed = androidx.compose.ui.graphics.ColorKt.Color(4293870660L);
    private static final long SlateBackgroundLight = androidx.compose.ui.graphics.ColorKt.Color(4294507260L);
    private static final long SlateSurfaceLight = androidx.compose.ui.graphics.ColorKt.Color(4294967295L);
    private static final long SlateBackgroundDark = androidx.compose.ui.graphics.ColorKt.Color(4279179050L);
    private static final long SlateSurfaceDark = androidx.compose.ui.graphics.ColorKt.Color(4280166715L);
    private static final long Purple80 = androidx.compose.ui.graphics.ColorKt.Color(4291285758L);
    private static final long PurpleGrey80 = androidx.compose.ui.graphics.ColorKt.Color(4291548641L);
    private static final long Pink80 = androidx.compose.ui.graphics.ColorKt.Color(4294692840L);
    private static final long Purple40 = androidx.compose.ui.graphics.ColorKt.Color(4282595530L);
    private static final long PurpleGrey40 = androidx.compose.ui.graphics.ColorKt.Color(4282865001L);
    private static final long Pink40 = androidx.compose.ui.graphics.ColorKt.Color(4288485197L);

    public static final long getIndigoPrimary() {
        return IndigoPrimary;
    }

    public static final long getIndigoLight() {
        return IndigoLight;
    }

    public static final long getIndigoDark() {
        return IndigoDark;
    }

    public static final long getAmberAccent() {
        return AmberAccent;
    }

    public static final long getEmeraldSuccess() {
        return EmeraldSuccess;
    }

    public static final long getCoralRed() {
        return CoralRed;
    }

    public static final long getSlateBackgroundLight() {
        return SlateBackgroundLight;
    }

    public static final long getSlateSurfaceLight() {
        return SlateSurfaceLight;
    }

    public static final long getSlateBackgroundDark() {
        return SlateBackgroundDark;
    }

    public static final long getSlateSurfaceDark() {
        return SlateSurfaceDark;
    }

    public static final long getPurple80() {
        return Purple80;
    }

    public static final long getPurpleGrey80() {
        return PurpleGrey80;
    }

    public static final long getPink80() {
        return Pink80;
    }

    public static final long getPurple40() {
        return Purple40;
    }

    public static final long getPurpleGrey40() {
        return PurpleGrey40;
    }

    public static final long getPink40() {
        return Pink40;
    }
}
