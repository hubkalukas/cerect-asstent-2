package com.example.ui;

import androidx.compose.foundation.layout.RowScope;
import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.filled.LockKt;
import androidx.compose.material3.AppBarKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.TopAppBarDefaults;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.text.TextLayoutResult;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.unit.TextUnitKt;
import com.example.ui.theme.ColorKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: MainScreen.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
public final class ComposableSingletons$MainScreenKt {
    public static final ComposableSingletons$MainScreenKt INSTANCE = new ComposableSingletons$MainScreenKt();

    /* JADX INFO: renamed from: lambda$-705719639, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f91lambda$705719639 = ComposableLambdaKt.composableLambdaInstance(-705719639, false, new Function3() { // from class: com.example.ui.ComposableSingletons$MainScreenKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$MainScreenKt.lambda__705719639$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-681639251, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f90lambda$681639251 = ComposableLambdaKt.composableLambdaInstance(-681639251, false, new Function3() { // from class: com.example.ui.ComposableSingletons$MainScreenKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$MainScreenKt.lambda__681639251$lambda$1((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$1957394812 = ComposableLambdaKt.composableLambdaInstance(1957394812, false, new Function2() { // from class: com.example.ui.ComposableSingletons$MainScreenKt$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$MainScreenKt.lambda_1957394812$lambda$2((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$23188413 = ComposableLambdaKt.composableLambdaInstance(23188413, false, new Function2() { // from class: com.example.ui.ComposableSingletons$MainScreenKt$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$MainScreenKt.lambda_23188413$lambda$3((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$19492653 = ComposableLambdaKt.composableLambdaInstance(19492653, false, new Function2() { // from class: com.example.ui.ComposableSingletons$MainScreenKt$$ExternalSyntheticLambda4
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$MainScreenKt.lambda_19492653$lambda$4((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-1515851156, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f89lambda$1515851156 = ComposableLambdaKt.composableLambdaInstance(-1515851156, false, new Function2() { // from class: com.example.ui.ComposableSingletons$MainScreenKt$$ExternalSyntheticLambda5
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$MainScreenKt.lambda__1515851156$lambda$5((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$1992941736 = ComposableLambdaKt.composableLambdaInstance(1992941736, false, new Function2() { // from class: com.example.ui.ComposableSingletons$MainScreenKt$$ExternalSyntheticLambda6
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$MainScreenKt.lambda_1992941736$lambda$6((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* JADX INFO: renamed from: getLambda$-1515851156$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m6937getLambda$1515851156$app() {
        return f89lambda$1515851156;
    }

    /* JADX INFO: renamed from: getLambda$-681639251$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m6938getLambda$681639251$app() {
        return f90lambda$681639251;
    }

    /* JADX INFO: renamed from: getLambda$-705719639$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m6939getLambda$705719639$app() {
        return f91lambda$705719639;
    }

    public final Function2<Composer, Integer, Unit> getLambda$19492653$app() {
        return lambda$19492653;
    }

    public final Function2<Composer, Integer, Unit> getLambda$1957394812$app() {
        return lambda$1957394812;
    }

    public final Function2<Composer, Integer, Unit> getLambda$1992941736$app() {
        return lambda$1992941736;
    }

    public final Function2<Composer, Integer, Unit> getLambda$23188413$app() {
        return lambda$23188413;
    }

    static final Unit lambda_1957394812$lambda$2(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C73@3036L125:MainScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1957394812, $changed, -1, "com.example.ui.ComposableSingletons$MainScreenKt.lambda$1957394812.<anonymous> (MainScreen.kt:73)");
            }
            IconKt.m2150Iconww6aTOc(LockKt.getLock(Icons.INSTANCE.getDefault()), (String) null, (Modifier) null, ColorKt.getIndigoLight(), $composer, 3120, 4);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_23188413$lambda$3(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C80@3195L138:MainScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(23188413, $changed, -1, "com.example.ui.ComposableSingletons$MainScreenKt.lambda$23188413.<anonymous> (MainScreen.kt:80)");
            }
            TextKt.m2693Text4IGK_g("Aktivace asistenta (První spuštění)", (Modifier) null, 0L, TextUnitKt.getSp(18), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 199686, 0, 131030);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_19492653$lambda$4(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C100@3964L29:MainScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(19492653, $changed, -1, "com.example.ui.ComposableSingletons$MainScreenKt.lambda$19492653.<anonymous> (MainScreen.kt:100)");
            }
            TextKt.m2693Text4IGK_g("Heslo / PIN (3011)...", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 6, 0, 131070);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__705719639$lambda$0(RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C135@5204L31:MainScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-705719639, $changed, -1, "com.example.ui.ComposableSingletons$MainScreenKt.lambda$-705719639.<anonymous> (MainScreen.kt:135)");
            }
            TextKt.m2693Text4IGK_g("Odemknout a zapamatovat", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 6, 0, 131070);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__681639251$lambda$1(RowScope OutlinedButton, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(OutlinedButton, "$this$OutlinedButton");
        ComposerKt.sourceInformation($composer, "C143@5424L21:MainScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-681639251, $changed, -1, "com.example.ui.ComposableSingletons$MainScreenKt.lambda$-681639251.<anonymous> (MainScreen.kt:143)");
            }
            TextKt.m2693Text4IGK_g("Zadat později", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 6, 0, 131070);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1992941736$lambda$6(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C169@6074L11,170@6139L11,168@6016L154,160@5803L375:MainScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1992941736, $changed, -1, "com.example.ui.ComposableSingletons$MainScreenKt.lambda$1992941736.<anonymous> (MainScreen.kt:160)");
            }
            AppBarKt.m1774TopAppBarGHTll3U(f89lambda$1515851156, null, null, null, 0.0f, null, TopAppBarDefaults.INSTANCE.m2864topAppBarColorszjMxDiM(MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getSurface(), 0L, 0L, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurface(), 0L, $composer, TopAppBarDefaults.$stable << 15, 22), null, $composer, 6, 190);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__1515851156$lambda$5(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C162@5842L127:MainScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1515851156, $changed, -1, "com.example.ui.ComposableSingletons$MainScreenKt.lambda$-1515851156.<anonymous> (MainScreen.kt:162)");
            }
            TextKt.m2693Text4IGK_g("cerect asstent 2", (Modifier) null, 0L, TextUnitKt.getSp(20), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 199686, 0, 131030);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
