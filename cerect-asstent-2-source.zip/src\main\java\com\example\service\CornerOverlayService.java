package com.example.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.NotificationCompat;
import androidx.core.view.GravityCompat;
import androidx.core.view.accessibility.AccessibilityEventCompat;
import com.example.MainActivity;
import com.example.R;
import com.example.data.AppPreferences;
import com.example.data.GeminiService;
import com.example.model.AnswerResult;
import com.example.model.CornerPosition;
import com.example.model.OptionShape;
import com.example.model.ScanHistoryItem;
import java.util.Arrays;
import java.util.Locale;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.CoroutineScopeKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.Job;
import kotlinx.coroutines.SupervisorKt;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;
import org.json.JSONException;

/* JADX INFO: compiled from: CornerOverlayService.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000\u0092\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0006\b\u0007\u0018\u0000 C2\u00020\u0001:\u0001CB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0014\u0010#\u001a\u0004\u0018\u00010$2\b\u0010%\u001a\u0004\u0018\u00010&H\u0016J\b\u0010'\u001a\u00020(H\u0016J\"\u0010)\u001a\u00020*2\b\u0010%\u001a\u0004\u0018\u00010&2\u0006\u0010+\u001a\u00020*2\u0006\u0010,\u001a\u00020*H\u0016J\b\u0010-\u001a\u00020(H\u0002J\b\u0010.\u001a\u00020(H\u0002J\b\u0010/\u001a\u00020(H\u0003J\u0012\u00100\u001a\u0002012\b\u00102\u001a\u0004\u0018\u00010\"H\u0002J\b\u00103\u001a\u00020(H\u0002J\u0010\u00104\u001a\u00020(2\u0006\u00105\u001a\u00020\"H\u0002J\b\u00106\u001a\u00020(H\u0002J\u0010\u00107\u001a\u00020(2\u0006\u00108\u001a\u000209H\u0002J\b\u0010:\u001a\u00020(H\u0002J\b\u0010;\u001a\u00020(H\u0002J\u0010\u0010<\u001a\u00020(2\u0006\u0010=\u001a\u00020>H\u0002J\b\u0010?\u001a\u00020(H\u0002J\u0010\u0010@\u001a\u00020*2\u0006\u0010A\u001a\u00020*H\u0002J\b\u0010B\u001a\u00020(H\u0016R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0015\u001a\u0004\u0018\u00010\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0017\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0018\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0019\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u001bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u001c\u001a\u0004\u0018\u00010\u001dX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010!\u001a\u0004\u0018\u00010\"X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006D"}, d2 = {"Lcom/example/service/CornerOverlayService;", "Landroid/app/Service;", "<init>", "()V", "serviceScope", "Lkotlinx/coroutines/CoroutineScope;", "windowManager", "Landroid/view/WindowManager;", "preferences", "Lcom/example/data/AppPreferences;", "screenCaptureManager", "Lcom/example/service/ScreenCaptureManager;", "geminiService", "Lcom/example/data/GeminiService;", "overlayView", "Landroid/widget/FrameLayout;", "triggerButton", "triggerIcon", "Landroid/widget/TextView;", "triggerProgressBar", "Landroid/widget/ProgressBar;", "answerCard", "Landroid/widget/LinearLayout;", "answerTextView", "explanationTextView", "sourceBadgeView", "mainHandler", "Landroid/os/Handler;", "autoDismissRunnable", "Ljava/lang/Runnable;", "isAnalyzing", "", "isCardExpanded", "currentDetectedShape", "Lcom/example/model/OptionShape;", "onBind", "Landroid/os/IBinder;", "intent", "Landroid/content/Intent;", "onCreate", "", "onStartCommand", "", "flags", "startId", "startForegroundNotification", "createNotificationChannel", "showOverlay", "createBadgeBackground", "Landroid/graphics/drawable/RippleDrawable;", "optionShape", "onCornerTriggerClicked", "showStealthOptionBadge", "shape", "resetCornerBadge", "showAnswerCard", "answer", "Lcom/example/model/AnswerResult;", "scheduleAutoDismiss", "hideAnswerCard", "copyToClipboard", "text", "", "vibrateFeedback", "dpToPx", "dp", "onDestroy", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class CornerOverlayService extends Service {
    private static final String CHANNEL_ID = "corner_assistant_overlay_channel";
    private static final String EXTRA_RESULT_CODE = "extra_result_code";
    private static final String EXTRA_RESULT_DATA = "extra_result_data";
    private static final int NOTIFICATION_ID = 4040;
    private LinearLayout answerCard;
    private TextView answerTextView;
    private Runnable autoDismissRunnable;
    private OptionShape currentDetectedShape;
    private TextView explanationTextView;
    private boolean isAnalyzing;
    private boolean isCardExpanded;
    private FrameLayout overlayView;
    private AppPreferences preferences;
    private ScreenCaptureManager screenCaptureManager;
    private TextView sourceBadgeView;
    private FrameLayout triggerButton;
    private TextView triggerIcon;
    private ProgressBar triggerProgressBar;
    private WindowManager windowManager;

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);
    public static final int $stable = 8;
    private static final MutableStateFlow<Boolean> _isServiceRunning = StateFlowKt.MutableStateFlow(false);
    private static final StateFlow<Boolean> isServiceRunning = FlowKt.asStateFlow(_isServiceRunning);
    private static final MutableStateFlow<AnswerResult> _lastDetectedAnswer = StateFlowKt.MutableStateFlow(null);
    private static final StateFlow<AnswerResult> lastDetectedAnswer = FlowKt.asStateFlow(_lastDetectedAnswer);
    private final CoroutineScope serviceScope = CoroutineScopeKt.CoroutineScope(SupervisorKt.SupervisorJob$default((Job) null, 1, (Object) null).plus(Dispatchers.getMain()));
    private final GeminiService geminiService = new GeminiService();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    /* JADX INFO: compiled from: CornerOverlayService.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[CornerPosition.values().length];
            try {
                iArr[CornerPosition.TOP_RIGHT.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[CornerPosition.BOTTOM_RIGHT.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[CornerPosition.TOP_LEFT.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[CornerPosition.BOTTOM_LEFT.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    /* JADX INFO: compiled from: CornerOverlayService.kt */
    @Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001e\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00052\u0006\u0010\u0019\u001a\u00020\u001aJ\u000e\u0010\u001b\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u0017R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u0014\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\r\u001a\b\u0012\u0004\u0012\u00020\f0\u000e¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000fR\u0016\u0010\u0010\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00110\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0019\u0010\u0012\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00110\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000f¨\u0006\u001c"}, d2 = {"Lcom/example/service/CornerOverlayService$Companion;", "", "<init>", "()V", "NOTIFICATION_ID", "", "CHANNEL_ID", "", "EXTRA_RESULT_CODE", "EXTRA_RESULT_DATA", "_isServiceRunning", "Lkotlinx/coroutines/flow/MutableStateFlow;", "", "isServiceRunning", "Lkotlinx/coroutines/flow/StateFlow;", "()Lkotlinx/coroutines/flow/StateFlow;", "_lastDetectedAnswer", "Lcom/example/model/AnswerResult;", "lastDetectedAnswer", "getLastDetectedAnswer", "start", "", "context", "Landroid/content/Context;", "resultCode", "data", "Landroid/content/Intent;", "stop", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final StateFlow<Boolean> isServiceRunning() {
            return CornerOverlayService.isServiceRunning;
        }

        public final StateFlow<AnswerResult> getLastDetectedAnswer() {
            return CornerOverlayService.lastDetectedAnswer;
        }

        public final void start(Context context, int resultCode, Intent data) {
            Intrinsics.checkNotNullParameter(context, "context");
            Intrinsics.checkNotNullParameter(data, "data");
            Intent intent = new Intent(context, (Class<?>) CornerOverlayService.class);
            intent.putExtra(CornerOverlayService.EXTRA_RESULT_CODE, resultCode);
            intent.putExtra(CornerOverlayService.EXTRA_RESULT_DATA, data);
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent);
            } else {
                context.startService(intent);
            }
        }

        public final void stop(Context context) {
            Intrinsics.checkNotNullParameter(context, "context");
            Intent intent = new Intent(context, (Class<?>) CornerOverlayService.class);
            context.stopService(intent);
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        this.preferences = new AppPreferences(this);
        Object systemService = getSystemService("window");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.view.WindowManager");
        this.windowManager = (WindowManager) systemService;
        this.screenCaptureManager = new ScreenCaptureManager(this);
        createNotificationChannel();
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int flags, int startId) {
        Intent resultData;
        if (intent == null) {
            stopSelf();
            return 2;
        }
        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0);
        if (Build.VERSION.SDK_INT >= 33) {
            resultData = (Intent) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        } else {
            resultData = (Intent) intent.getParcelableExtra(EXTRA_RESULT_DATA);
        }
        if (resultCode != 0 && resultData != null) {
            startForegroundNotification();
            DisplayMetrics metrics = getResources().getDisplayMetrics();
            ScreenCaptureManager screenCaptureManager = this.screenCaptureManager;
            if (screenCaptureManager == null) {
                Intrinsics.throwUninitializedPropertyAccessException("screenCaptureManager");
                screenCaptureManager = null;
            }
            screenCaptureManager.initialize(resultCode, resultData, metrics.widthPixels, metrics.heightPixels, metrics.densityDpi);
            showOverlay();
            _isServiceRunning.setValue(true);
        } else {
            stopSelf();
        }
        return 1;
    }

    private final void startForegroundNotification() {
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, (Class<?>) MainActivity.class), AccessibilityEventCompat.TYPE_VIEW_TARGETED_BY_SCROLL);
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID).setContentTitle("Rohový asistent je aktivní").setContentText("Klepněte do rohu obrazovky pro vyhodnocení").setSmallIcon(R.drawable.ic_launcher_foreground).setContentIntent(pendingIntent).setOngoing(true).setPriority(-1).build();
        Intrinsics.checkNotNullExpressionValue(notification, "build(...)");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, 32);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private final void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Corner Assistant Služba", 2);
            channel.setDescription("Běží na pozadí pro snímání obrazovky a zobrazení odpovědi");
            Object systemService = getSystemService("notification");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.app.NotificationManager");
            NotificationManager manager = (NotificationManager) systemService;
            manager.createNotificationChannel(channel);
        }
    }

    private final void showOverlay() {
        int i;
        WindowManager windowManager;
        if (this.overlayView != null) {
            return;
        }
        AppPreferences appPreferences = this.preferences;
        if (appPreferences == null) {
            Intrinsics.throwUninitializedPropertyAccessException("preferences");
            appPreferences = null;
        }
        final CornerPosition position = appPreferences.getCornerPosition();
        AppPreferences appPreferences2 = this.preferences;
        if (appPreferences2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("preferences");
            appPreferences2 = null;
        }
        float opacity = appPreferences2.getCornerOpacity();
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 2038, 776, -3);
        layoutParams.gravity = position.getGravity();
        layoutParams.x = dpToPx(10);
        layoutParams.y = dpToPx(14);
        FrameLayout root = new FrameLayout(this);
        this.overlayView = root;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        switch (WhenMappings.$EnumSwitchMapping$0[position.ordinal()]) {
            case 1:
            case 2:
                i = GravityCompat.END;
                break;
            case 3:
            case 4:
                i = GravityCompat.START;
                break;
            default:
                throw new NoWhenBranchMatchedException();
        }
        linearLayout.setGravity(i);
        FrameLayout frameLayout = new FrameLayout(this);
        int iDpToPx = dpToPx(42);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(iDpToPx, iDpToPx);
        int iDpToPx2 = dpToPx(4);
        layoutParams2.setMargins(iDpToPx2, iDpToPx2, iDpToPx2, iDpToPx2);
        frameLayout.setLayoutParams(layoutParams2);
        frameLayout.setAlpha(RangesKt.coerceIn(opacity, 0.05f, 1.0f));
        frameLayout.setBackground(createBadgeBackground(null));
        frameLayout.setClickable(true);
        frameLayout.setFocusable(true);
        frameLayout.setElevation(dpToPx(6));
        frameLayout.setOnClickListener(new View.OnClickListener() { // from class: com.example.service.CornerOverlayService$$ExternalSyntheticLambda1
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.onCornerTriggerClicked();
            }
        });
        this.triggerButton = frameLayout;
        TextView textView = new TextView(this);
        textView.setText("✦");
        textView.setTextSize(20.0f);
        textView.setTextColor(-1);
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setGravity(17);
        textView.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        this.triggerIcon = textView;
        frameLayout.addView(textView);
        ProgressBar progressBar = new ProgressBar(this);
        progressBar.setVisibility(8);
        progressBar.setIndeterminate(true);
        int iDpToPx3 = dpToPx(22);
        FrameLayout.LayoutParams layoutParams3 = new FrameLayout.LayoutParams(iDpToPx3, iDpToPx3);
        layoutParams3.gravity = 17;
        progressBar.setLayoutParams(layoutParams3);
        progressBar.setIndeterminateTintList(ColorStateList.valueOf(-1));
        this.triggerProgressBar = progressBar;
        frameLayout.addView(progressBar);
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(1);
        card.setVisibility(8);
        LinearLayout.LayoutParams layoutParams4 = new LinearLayout.LayoutParams(dpToPx(280), -2);
        int iDpToPx4 = dpToPx(6);
        layoutParams4.setMargins(iDpToPx4, iDpToPx4, iDpToPx4, iDpToPx4);
        card.setLayoutParams(layoutParams4);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setCornerRadius(dpToPx(16));
        gradientDrawable.setColor(Color.parseColor("#0F172A"));
        gradientDrawable.setStroke(dpToPx(1), Color.parseColor("#4338CA"));
        card.setBackground(gradientDrawable);
        int iDpToPx5 = dpToPx(14);
        card.setPadding(iDpToPx5, iDpToPx5, iDpToPx5, iDpToPx5);
        card.setElevation(dpToPx(16));
        final Ref.FloatRef floatRef = new Ref.FloatRef();
        final Ref.FloatRef floatRef2 = new Ref.FloatRef();
        final Ref.BooleanRef booleanRef = new Ref.BooleanRef();
        card.setOnTouchListener(new View.OnTouchListener() { // from class: com.example.service.CornerOverlayService$$ExternalSyntheticLambda2
            @Override // android.view.View.OnTouchListener
            public final boolean onTouch(View view, MotionEvent motionEvent) {
                return CornerOverlayService.showOverlay$lambda$12$lambda$11(floatRef, floatRef2, booleanRef, this, position, view, motionEvent);
            }
        });
        this.answerCard = card;
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(0);
        linearLayout2.setGravity(16);
        linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        TextView textView2 = new TextView(this);
        textView2.setText("SPRÁVNÁ ODPOVĚĎ • Potažením schovat");
        textView2.setTextSize(10.5f);
        textView2.setTypeface(Typeface.DEFAULT_BOLD);
        textView2.setTextColor(Color.parseColor("#94A3B8"));
        textView2.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        linearLayout2.addView(textView2);
        ImageView imageView = new ImageView(this);
        imageView.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        imageView.setColorFilter(Color.parseColor("#94A3B8"));
        int iDpToPx6 = dpToPx(22);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(iDpToPx6, iDpToPx6));
        imageView.setOnClickListener(new View.OnClickListener() { // from class: com.example.service.CornerOverlayService$$ExternalSyntheticLambda3
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                this.f$0.hideAnswerCard();
            }
        });
        linearLayout2.addView(imageView);
        card.addView(linearLayout2);
        TextView textView3 = new TextView(this);
        textView3.setText("");
        textView3.setTextSize(18.0f);
        textView3.setTypeface(Typeface.DEFAULT_BOLD);
        textView3.setTextColor(Color.parseColor("#34D399"));
        textView3.setPadding(0, dpToPx(6), 0, dpToPx(4));
        this.answerTextView = textView3;
        card.addView(textView3);
        TextView textView4 = new TextView(this);
        textView4.setText("");
        textView4.setTextSize(13.0f);
        textView4.setTextColor(Color.parseColor("#E2E8F0"));
        textView4.setLineSpacing(dpToPx(2), 1.15f);
        textView4.setPadding(0, 0, 0, dpToPx(8));
        this.explanationTextView = textView4;
        card.addView(textView4);
        LinearLayout linearLayout3 = new LinearLayout(this);
        linearLayout3.setOrientation(0);
        linearLayout3.setGravity(16);
        linearLayout3.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        TextView textView5 = new TextView(this);
        textView5.setText("⚡ Gemini AI");
        textView5.setTextSize(10.5f);
        textView5.setTextColor(Color.parseColor("#34D399"));
        int iDpToPx7 = dpToPx(4);
        textView5.setPadding(iDpToPx7, iDpToPx7, iDpToPx7, iDpToPx7);
        GradientDrawable gradientDrawable2 = new GradientDrawable();
        gradientDrawable2.setShape(0);
        gradientDrawable2.setCornerRadius(dpToPx(8));
        gradientDrawable2.setColor(Color.parseColor("#064E3B"));
        textView5.setBackground(gradientDrawable2);
        textView5.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1.0f));
        this.sourceBadgeView = textView5;
        linearLayout3.addView(textView5);
        TextView textView6 = new TextView(this);
        textView6.setText("Kopírovat");
        textView6.setTextSize(12.0f);
        textView6.setTypeface(Typeface.DEFAULT_BOLD);
        textView6.setTextColor(Color.parseColor("#818CF8"));
        int iDpToPx8 = dpToPx(6);
        textView6.setPadding(iDpToPx8, iDpToPx8, iDpToPx8, iDpToPx8);
        textView6.setOnClickListener(new View.OnClickListener() { // from class: com.example.service.CornerOverlayService$$ExternalSyntheticLambda4
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                CornerOverlayService.showOverlay$lambda$23$lambda$22(this.f$0, view);
            }
        });
        linearLayout3.addView(textView6);
        card.addView(linearLayout3);
        switch (WhenMappings.$EnumSwitchMapping$0[position.ordinal()]) {
            case 1:
            case 3:
                linearLayout.addView(frameLayout);
                linearLayout.addView(card);
                break;
            case 2:
            case 4:
                linearLayout.addView(card);
                linearLayout.addView(frameLayout);
                break;
            default:
                throw new NoWhenBranchMatchedException();
        }
        root.addView(linearLayout);
        try {
            WindowManager windowManager2 = this.windowManager;
            if (windowManager2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("windowManager");
                windowManager = null;
            } else {
                windowManager = windowManager2;
            }
            windowManager.addView(root, layoutParams);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static final boolean showOverlay$lambda$12$lambda$11(Ref.FloatRef $startTouchX, Ref.FloatRef $startTouchY, Ref.BooleanRef $isDragging, CornerOverlayService this$0, CornerPosition $position, View v, MotionEvent event) {
        boolean isSwipedToCorner = false;
        switch (event.getAction()) {
            case 0:
                $startTouchX.element = event.getRawX();
                $startTouchY.element = event.getRawY();
                $isDragging.element = false;
                return true;
            case 1:
            case 3:
                if ($isDragging.element) {
                    float deltaX = event.getRawX() - $startTouchX.element;
                    float deltaY = event.getRawY() - $startTouchY.element;
                    int threshold = this$0.dpToPx(35);
                    switch (WhenMappings.$EnumSwitchMapping$0[$position.ordinal()]) {
                        case 1:
                            if (deltaX > threshold || deltaY < (-threshold)) {
                                isSwipedToCorner = true;
                            }
                            break;
                        case 2:
                            if (deltaX > threshold || deltaY > threshold) {
                                isSwipedToCorner = true;
                            }
                            break;
                        case 3:
                            if (deltaX < (-threshold) || deltaY < (-threshold)) {
                                isSwipedToCorner = true;
                            }
                            break;
                        case 4:
                            if (deltaX < (-threshold) || deltaY > threshold) {
                                isSwipedToCorner = true;
                            }
                            break;
                        default:
                            throw new NoWhenBranchMatchedException();
                    }
                    if (isSwipedToCorner || Math.abs(deltaX) > this$0.dpToPx(60) || Math.abs(deltaY) > this$0.dpToPx(60)) {
                        this$0.vibrateFeedback();
                        this$0.hideAnswerCard();
                    } else {
                        v.animate().translationX(0.0f).translationY(0.0f).setDuration(150L).start();
                    }
                }
                return true;
            case 2:
                float deltaX2 = event.getRawX() - $startTouchX.element;
                float deltaY2 = event.getRawY() - $startTouchY.element;
                if (Math.hypot(deltaX2, deltaY2) > this$0.dpToPx(10)) {
                    $isDragging.element = true;
                    v.setTranslationX(deltaX2);
                    v.setTranslationY(deltaY2);
                }
                return true;
            default:
                return false;
        }
    }

    static final void showOverlay$lambda$23$lambda$22(CornerOverlayService this$0, View it) {
        TextView textView = this$0.answerTextView;
        CharSequence text = textView != null ? textView.getText() : null;
        TextView textView2 = this$0.explanationTextView;
        String textToCopy = ((Object) text) + "\n" + ((Object) (textView2 != null ? textView2.getText() : null));
        this$0.copyToClipboard(textToCopy);
        Toast.makeText(this$0, "Odpověď zkopírována", 0).show();
    }

    private final RippleDrawable createBadgeBackground(OptionShape optionShape) {
        String hexColor;
        if (optionShape != null && optionShape != OptionShape.UNKNOWN) {
            hexColor = optionShape.getColorHex();
        } else {
            hexColor = "#4F46E5";
        }
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(0);
        gradientDrawable.setCornerRadius(dpToPx(12));
        gradientDrawable.setColor(Color.parseColor(hexColor));
        gradientDrawable.setStroke(dpToPx(2), -1);
        return new RippleDrawable(ColorStateList.valueOf(Color.parseColor("#80FFFFFF")), gradientDrawable, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void onCornerTriggerClicked() {
        vibrateFeedback();
        if (this.currentDetectedShape != null || this.isCardExpanded) {
            resetCornerBadge();
            hideAnswerCard();
            return;
        }
        if (this.isAnalyzing) {
            return;
        }
        this.isAnalyzing = true;
        TextView textView = this.triggerIcon;
        if (textView != null) {
            textView.setVisibility(8);
        }
        ProgressBar progressBar = this.triggerProgressBar;
        if (progressBar != null) {
            progressBar.setVisibility(0);
        }
        FrameLayout frameLayout = this.triggerButton;
        if (frameLayout != null) {
            AppPreferences appPreferences = this.preferences;
            if (appPreferences == null) {
                Intrinsics.throwUninitializedPropertyAccessException("preferences");
                appPreferences = null;
            }
            frameLayout.setAlpha(RangesKt.coerceIn(appPreferences.getCornerOpacity(), 0.05f, 1.0f));
        }
        BuildersKt__Builders_commonKt.launch$default(this.serviceScope, null, null, new AnonymousClass1(null), 3, null);
    }

    /* JADX INFO: renamed from: com.example.service.CornerOverlayService$onCornerTriggerClicked$1, reason: invalid class name */
    /* JADX INFO: compiled from: CornerOverlayService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.service.CornerOverlayService$onCornerTriggerClicked$1", f = "CornerOverlayService.kt", i = {1}, l = {497, 505}, m = "invokeSuspend", n = {"bitmap"}, s = {"L$0"})
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        Object L$0;
        int label;

        AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
            super(2, continuation);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return CornerOverlayService.this.new AnonymousClass1(continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:13:0x0057  */
        /* JADX WARN: Code duplicated, block: B:16:0x006d  */
        /* JADX WARN: Code duplicated, block: B:19:0x007e  */
        /* JADX WARN: Code duplicated, block: B:22:0x009b A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:23:0x009c  */
        /* JADX WARN: Code duplicated, block: B:26:0x00ac  */
        /* JADX WARN: Code duplicated, block: B:29:0x00b9  */
        /* JADX WARN: Code duplicated, block: B:32:0x00c4  */
        /* JADX WARN: Code duplicated, block: B:34:0x00d5  */
        /* JADX WARN: Code duplicated, block: B:37:0x0114  */
        /* JADX WARN: Code duplicated, block: B:40:0x011e  */
        /* JADX WARN: Code duplicated, block: B:42:0x0124  */
        /* JADX WARN: Code duplicated, block: B:45:0x012e  */
        /* JADX WARN: Code duplicated, block: B:48:0x0137  */
        /* JADX WARN: Code duplicated, block: B:50:0x013a  */
        /* JADX WARN: Code duplicated, block: B:52:0x0142  */
        /* JADX WARN: Code duplicated, block: B:53:0x014a  */
        /* JADX WARN: Code duplicated, block: B:54:0x014e  */
        /* JADX WARN: Code duplicated, block: B:56:0x0156  */
        /* JADX WARN: Code duplicated, block: B:61:0x016a  */
        /* JADX WARN: Code duplicated, block: B:63:0x0171  */
        /* JADX WARN: Code duplicated, block: B:64:0x0175  */
        /* JADX WARN: Code duplicated, block: B:67:0x017c  */
        /* JADX WARN: Code duplicated, block: B:69:0x0187  */
        /* JADX WARN: Code duplicated, block: B:71:0x01a2  */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object $result) throws JSONException {
            Object objWithContext;
            AppPreferences appPreferences;
            AppPreferences appPreferences2;
            AppPreferences appPreferences3;
            Object result;
            ProgressBar progressBar;
            TextView textView;
            CornerOverlayService cornerOverlayService;
            CornerOverlayService cornerOverlayService2;
            Throwable thM7088exceptionOrNullimpl;
            AppPreferences appPreferences4;
            String localizedMessage;
            AnswerResult answerResult;
            AppPreferences appPreferences5;
            AppPreferences appPreferences6;
            AppPreferences appPreferences7;
            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
            boolean z = true;
            AppPreferences appPreferences8 = null;
            switch (this.label) {
                case 0:
                    ResultKt.throwOnFailure($result);
                    this.label = 1;
                    objWithContext = BuildersKt.withContext(Dispatchers.getDefault(), new CornerOverlayService$onCornerTriggerClicked$1$bitmap$1(CornerOverlayService.this, null), this);
                    if (objWithContext == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    Bitmap bitmap = (Bitmap) objWithContext;
                    appPreferences = CornerOverlayService.this.preferences;
                    if (appPreferences == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("preferences");
                        appPreferences = null;
                    }
                    appPreferences.recordApiCall();
                    GeminiService geminiService = CornerOverlayService.this.geminiService;
                    appPreferences2 = CornerOverlayService.this.preferences;
                    if (appPreferences2 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("preferences");
                        appPreferences2 = null;
                    }
                    String customApiKey = appPreferences2.getCustomApiKey();
                    appPreferences3 = CornerOverlayService.this.preferences;
                    if (appPreferences3 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("preferences");
                        appPreferences3 = null;
                    }
                    this.L$0 = SpillingKt.nullOutSpilledVariable(bitmap);
                    this.label = 2;
                    result = GeminiService.m6934analyzeScreenyxL6bBk$default(geminiService, bitmap, customApiKey, null, appPreferences3.getRateLimiter(), this, 4, null);
                    if (result == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    CornerOverlayService.this.isAnalyzing = false;
                    progressBar = CornerOverlayService.this.triggerProgressBar;
                    if (progressBar != null) {
                        progressBar.setVisibility(8);
                    }
                    textView = CornerOverlayService.this.triggerIcon;
                    if (textView != null) {
                        textView.setVisibility(0);
                    }
                    cornerOverlayService = CornerOverlayService.this;
                    if (Result.m7092isSuccessimpl(result)) {
                        answerResult = (AnswerResult) result;
                        CornerOverlayService._lastDetectedAnswer.setValue(answerResult);
                        appPreferences5 = cornerOverlayService.preferences;
                        if (appPreferences5 == null) {
                            Intrinsics.throwUninitializedPropertyAccessException("preferences");
                            appPreferences5 = null;
                        }
                        String string = UUID.randomUUID().toString();
                        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
                        appPreferences5.addHistoryItem(new ScanHistoryItem(string, answerResult.getOptionShape(), answerResult.getDirectAnswer(), answerResult.getExplanation(), answerResult.getQuestionSummary(), answerResult.getSearchSources(), System.currentTimeMillis(), answerResult.getModelUsed(), answerResult.getDurationMs()));
                        appPreferences6 = cornerOverlayService.preferences;
                        if (appPreferences6 == null) {
                            Intrinsics.throwUninitializedPropertyAccessException("preferences");
                            appPreferences6 = null;
                        }
                        if (!appPreferences6.isPopupCardDisabled()) {
                            appPreferences7 = cornerOverlayService.preferences;
                            if (appPreferences7 == null) {
                                Intrinsics.throwUninitializedPropertyAccessException("preferences");
                                appPreferences7 = null;
                            }
                            if (appPreferences7.isStealthBadgeMode() || answerResult.getOptionShape() == OptionShape.UNKNOWN) {
                                z = false;
                            }
                        }
                        if (!z) {
                            if (answerResult.getOptionShape() != OptionShape.UNKNOWN) {
                                cornerOverlayService.showStealthOptionBadge(answerResult.getOptionShape());
                            }
                            cornerOverlayService.showAnswerCard(answerResult);
                        } else if (answerResult.getOptionShape() != OptionShape.UNKNOWN) {
                            cornerOverlayService.showStealthOptionBadge(answerResult.getOptionShape());
                        } else {
                            cornerOverlayService.resetCornerBadge();
                        }
                    }
                    cornerOverlayService2 = CornerOverlayService.this;
                    thM7088exceptionOrNullimpl = Result.m7088exceptionOrNullimpl(result);
                    if (thM7088exceptionOrNullimpl != null) {
                        appPreferences4 = cornerOverlayService2.preferences;
                        if (appPreferences4 == null) {
                            Intrinsics.throwUninitializedPropertyAccessException("preferences");
                        } else {
                            appPreferences8 = appPreferences4;
                        }
                        if (appPreferences8.isPopupCardDisabled()) {
                            cornerOverlayService2.resetCornerBadge();
                        } else {
                            OptionShape optionShape = OptionShape.UNKNOWN;
                            localizedMessage = thM7088exceptionOrNullimpl.getLocalizedMessage();
                            if (localizedMessage == null) {
                                localizedMessage = "Nepodařilo se načíst odpověď. Zkontrolujte připojení k internetu a API klíč.";
                            }
                            cornerOverlayService2.showAnswerCard(new AnswerResult(optionShape, "Chyba při analýze", localizedMessage, CollectionsKt.emptyList(), null, 0L, null, 0L, 240, null));
                        }
                    }
                    return Unit.INSTANCE;
                case 1:
                    ResultKt.throwOnFailure($result);
                    objWithContext = $result;
                    Bitmap bitmap2 = (Bitmap) objWithContext;
                    appPreferences = CornerOverlayService.this.preferences;
                    if (appPreferences == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("preferences");
                        appPreferences = null;
                    }
                    appPreferences.recordApiCall();
                    GeminiService geminiService2 = CornerOverlayService.this.geminiService;
                    appPreferences2 = CornerOverlayService.this.preferences;
                    if (appPreferences2 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("preferences");
                        appPreferences2 = null;
                    }
                    String customApiKey2 = appPreferences2.getCustomApiKey();
                    appPreferences3 = CornerOverlayService.this.preferences;
                    if (appPreferences3 == null) {
                        Intrinsics.throwUninitializedPropertyAccessException("preferences");
                        appPreferences3 = null;
                    }
                    this.L$0 = SpillingKt.nullOutSpilledVariable(bitmap2);
                    this.label = 2;
                    result = GeminiService.m6934analyzeScreenyxL6bBk$default(geminiService2, bitmap2, customApiKey2, null, appPreferences3.getRateLimiter(), this, 4, null);
                    if (result == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    CornerOverlayService.this.isAnalyzing = false;
                    progressBar = CornerOverlayService.this.triggerProgressBar;
                    if (progressBar != null) {
                        progressBar.setVisibility(8);
                    }
                    textView = CornerOverlayService.this.triggerIcon;
                    if (textView != null) {
                        textView.setVisibility(0);
                    }
                    cornerOverlayService = CornerOverlayService.this;
                    if (Result.m7092isSuccessimpl(result)) {
                        answerResult = (AnswerResult) result;
                        CornerOverlayService._lastDetectedAnswer.setValue(answerResult);
                        appPreferences5 = cornerOverlayService.preferences;
                        if (appPreferences5 == null) {
                            Intrinsics.throwUninitializedPropertyAccessException("preferences");
                            appPreferences5 = null;
                        }
                        String string2 = UUID.randomUUID().toString();
                        Intrinsics.checkNotNullExpressionValue(string2, "toString(...)");
                        appPreferences5.addHistoryItem(new ScanHistoryItem(string2, answerResult.getOptionShape(), answerResult.getDirectAnswer(), answerResult.getExplanation(), answerResult.getQuestionSummary(), answerResult.getSearchSources(), System.currentTimeMillis(), answerResult.getModelUsed(), answerResult.getDurationMs()));
                        appPreferences6 = cornerOverlayService.preferences;
                        if (appPreferences6 == null) {
                            Intrinsics.throwUninitializedPropertyAccessException("preferences");
                            appPreferences6 = null;
                        }
                        if (!appPreferences6.isPopupCardDisabled()) {
                            appPreferences7 = cornerOverlayService.preferences;
                            if (appPreferences7 == null) {
                                Intrinsics.throwUninitializedPropertyAccessException("preferences");
                                appPreferences7 = null;
                            }
                            if (appPreferences7.isStealthBadgeMode()) {
                                z = false;
                            } else {
                                z = false;
                            }
                        }
                        if (!z) {
                            if (answerResult.getOptionShape() != OptionShape.UNKNOWN) {
                                cornerOverlayService.showStealthOptionBadge(answerResult.getOptionShape());
                            }
                            cornerOverlayService.showAnswerCard(answerResult);
                        } else if (answerResult.getOptionShape() != OptionShape.UNKNOWN) {
                            cornerOverlayService.showStealthOptionBadge(answerResult.getOptionShape());
                        } else {
                            cornerOverlayService.resetCornerBadge();
                        }
                    }
                    cornerOverlayService2 = CornerOverlayService.this;
                    thM7088exceptionOrNullimpl = Result.m7088exceptionOrNullimpl(result);
                    if (thM7088exceptionOrNullimpl != null) {
                        appPreferences4 = cornerOverlayService2.preferences;
                        if (appPreferences4 == null) {
                            Intrinsics.throwUninitializedPropertyAccessException("preferences");
                        } else {
                            appPreferences8 = appPreferences4;
                        }
                        if (appPreferences8.isPopupCardDisabled()) {
                            OptionShape optionShape2 = OptionShape.UNKNOWN;
                            localizedMessage = thM7088exceptionOrNullimpl.getLocalizedMessage();
                            if (localizedMessage == null) {
                                localizedMessage = "Nepodařilo se načíst odpověď. Zkontrolujte připojení k internetu a API klíč.";
                            }
                            cornerOverlayService2.showAnswerCard(new AnswerResult(optionShape2, "Chyba při analýze", localizedMessage, CollectionsKt.emptyList(), null, 0L, null, 0L, 240, null));
                        } else {
                            cornerOverlayService2.resetCornerBadge();
                        }
                    }
                    return Unit.INSTANCE;
                case 2:
                    ResultKt.throwOnFailure($result);
                    result = ((Result) $result).getValue();
                    CornerOverlayService.this.isAnalyzing = false;
                    progressBar = CornerOverlayService.this.triggerProgressBar;
                    if (progressBar != null) {
                        progressBar.setVisibility(8);
                    }
                    textView = CornerOverlayService.this.triggerIcon;
                    if (textView != null) {
                        textView.setVisibility(0);
                    }
                    cornerOverlayService = CornerOverlayService.this;
                    if (Result.m7092isSuccessimpl(result)) {
                        answerResult = (AnswerResult) result;
                        CornerOverlayService._lastDetectedAnswer.setValue(answerResult);
                        appPreferences5 = cornerOverlayService.preferences;
                        if (appPreferences5 == null) {
                            Intrinsics.throwUninitializedPropertyAccessException("preferences");
                            appPreferences5 = null;
                        }
                        String string3 = UUID.randomUUID().toString();
                        Intrinsics.checkNotNullExpressionValue(string3, "toString(...)");
                        appPreferences5.addHistoryItem(new ScanHistoryItem(string3, answerResult.getOptionShape(), answerResult.getDirectAnswer(), answerResult.getExplanation(), answerResult.getQuestionSummary(), answerResult.getSearchSources(), System.currentTimeMillis(), answerResult.getModelUsed(), answerResult.getDurationMs()));
                        appPreferences6 = cornerOverlayService.preferences;
                        if (appPreferences6 == null) {
                            Intrinsics.throwUninitializedPropertyAccessException("preferences");
                            appPreferences6 = null;
                        }
                        if (!appPreferences6.isPopupCardDisabled()) {
                            appPreferences7 = cornerOverlayService.preferences;
                            if (appPreferences7 == null) {
                                Intrinsics.throwUninitializedPropertyAccessException("preferences");
                                appPreferences7 = null;
                            }
                            if (appPreferences7.isStealthBadgeMode()) {
                                z = false;
                            } else {
                                z = false;
                            }
                        }
                        if (!z) {
                            if (answerResult.getOptionShape() != OptionShape.UNKNOWN) {
                                cornerOverlayService.showStealthOptionBadge(answerResult.getOptionShape());
                            }
                            cornerOverlayService.showAnswerCard(answerResult);
                        } else if (answerResult.getOptionShape() != OptionShape.UNKNOWN) {
                            cornerOverlayService.showStealthOptionBadge(answerResult.getOptionShape());
                        } else {
                            cornerOverlayService.resetCornerBadge();
                        }
                    }
                    cornerOverlayService2 = CornerOverlayService.this;
                    thM7088exceptionOrNullimpl = Result.m7088exceptionOrNullimpl(result);
                    if (thM7088exceptionOrNullimpl != null) {
                        appPreferences4 = cornerOverlayService2.preferences;
                        if (appPreferences4 == null) {
                            Intrinsics.throwUninitializedPropertyAccessException("preferences");
                        } else {
                            appPreferences8 = appPreferences4;
                        }
                        if (appPreferences8.isPopupCardDisabled()) {
                            OptionShape optionShape3 = OptionShape.UNKNOWN;
                            localizedMessage = thM7088exceptionOrNullimpl.getLocalizedMessage();
                            if (localizedMessage == null) {
                                localizedMessage = "Nepodařilo se načíst odpověď. Zkontrolujte připojení k internetu a API klíč.";
                            }
                            cornerOverlayService2.showAnswerCard(new AnswerResult(optionShape3, "Chyba při analýze", localizedMessage, CollectionsKt.emptyList(), null, 0L, null, 0L, 240, null));
                        } else {
                            cornerOverlayService2.resetCornerBadge();
                        }
                    }
                    return Unit.INSTANCE;
                default:
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void showStealthOptionBadge(OptionShape shape) {
        this.currentDetectedShape = shape;
        FrameLayout frameLayout = this.triggerButton;
        if (frameLayout != null) {
            frameLayout.setBackground(createBadgeBackground(shape));
        }
        FrameLayout frameLayout2 = this.triggerButton;
        if (frameLayout2 != null) {
            frameLayout2.setAlpha(1.0f);
        }
        TextView textView = this.triggerIcon;
        if (textView != null) {
            textView.setText(shape.getSymbol());
        }
        TextView textView2 = this.triggerIcon;
        if (textView2 != null) {
            textView2.setTextSize(24.0f);
        }
        scheduleAutoDismiss();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void resetCornerBadge() {
        AppPreferences appPreferences = null;
        this.currentDetectedShape = null;
        FrameLayout frameLayout = this.triggerButton;
        if (frameLayout != null) {
            frameLayout.setBackground(createBadgeBackground(null));
        }
        FrameLayout frameLayout2 = this.triggerButton;
        if (frameLayout2 != null) {
            AppPreferences appPreferences2 = this.preferences;
            if (appPreferences2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("preferences");
            } else {
                appPreferences = appPreferences2;
            }
            frameLayout2.setAlpha(RangesKt.coerceIn(appPreferences.getCornerOpacity(), 0.05f, 1.0f));
        }
        TextView textView = this.triggerIcon;
        if (textView != null) {
            textView.setText("✦");
        }
        TextView textView2 = this.triggerIcon;
        if (textView2 != null) {
            textView2.setTextSize(20.0f);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void showAnswerCard(AnswerResult answer) {
        String timeLabel;
        LinearLayout linearLayout = this.answerCard;
        if (linearLayout != null) {
            linearLayout.setTranslationX(0.0f);
        }
        LinearLayout linearLayout2 = this.answerCard;
        if (linearLayout2 != null) {
            linearLayout2.setTranslationY(0.0f);
        }
        TextView textView = this.answerTextView;
        if (textView != null) {
            textView.setText(answer.getDirectAnswer());
        }
        TextView textView2 = this.explanationTextView;
        if (textView2 != null) {
            textView2.setText(answer.getExplanation());
        }
        if (answer.getDurationMs() > 0) {
            StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
            timeLabel = String.format(Locale.US, "%.1fs", Arrays.copyOf(new Object[]{Double.valueOf(answer.getDurationMs() / 1000.0d)}, 1));
            Intrinsics.checkNotNullExpressionValue(timeLabel, "format(...)");
        } else {
            timeLabel = "";
        }
        String modelUsed = answer.getModelUsed();
        if (StringsKt.isBlank(modelUsed)) {
            modelUsed = "Gemini Flash Lite";
        }
        String modelLabel = modelUsed;
        TextView textView3 = this.sourceBadgeView;
        if (textView3 != null) {
            textView3.setText("⚡ " + modelLabel + (StringsKt.isBlank(timeLabel) ? "" : " • " + timeLabel));
        }
        TextView textView4 = this.sourceBadgeView;
        if (textView4 != null) {
            textView4.setVisibility(0);
        }
        LinearLayout linearLayout3 = this.answerCard;
        if (linearLayout3 != null) {
            linearLayout3.setVisibility(0);
        }
        this.isCardExpanded = true;
        scheduleAutoDismiss();
    }

    private final void scheduleAutoDismiss() {
        Runnable runnable = this.autoDismissRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        AppPreferences appPreferences = this.preferences;
        if (appPreferences == null) {
            Intrinsics.throwUninitializedPropertyAccessException("preferences");
            appPreferences = null;
        }
        long autoDismissDelay = ((long) appPreferences.getAutoDismissSeconds()) * 1000;
        if (autoDismissDelay > 0) {
            Runnable runnable2 = new Runnable() { // from class: com.example.service.CornerOverlayService$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    CornerOverlayService.scheduleAutoDismiss$lambda$27(this.f$0);
                }
            };
            this.autoDismissRunnable = runnable2;
            this.mainHandler.postDelayed(runnable2, autoDismissDelay);
        }
    }

    static final void scheduleAutoDismiss$lambda$27(CornerOverlayService this$0) {
        this$0.resetCornerBadge();
        this$0.hideAnswerCard();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void hideAnswerCard() {
        Runnable runnable = this.autoDismissRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        LinearLayout linearLayout = this.answerCard;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        LinearLayout linearLayout2 = this.answerCard;
        if (linearLayout2 != null) {
            linearLayout2.setTranslationX(0.0f);
        }
        LinearLayout linearLayout3 = this.answerCard;
        if (linearLayout3 != null) {
            linearLayout3.setTranslationY(0.0f);
        }
        this.isCardExpanded = false;
    }

    private final void copyToClipboard(String text) {
        Object systemService = getSystemService("clipboard");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.content.ClipboardManager");
        ClipboardManager clipboard = (ClipboardManager) systemService;
        ClipData clip = ClipData.newPlainText("Správná odpověď", text);
        clipboard.setPrimaryClip(clip);
    }

    private final void vibrateFeedback() {
        AppPreferences appPreferences = this.preferences;
        if (appPreferences == null) {
            Intrinsics.throwUninitializedPropertyAccessException("preferences");
            appPreferences = null;
        }
        if (appPreferences.isVibrationEnabled()) {
            try {
                if (Build.VERSION.SDK_INT >= 31) {
                    Object systemService = getSystemService("vibrator_manager");
                    Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.os.VibratorManager");
                    VibratorManager vibratorManager = (VibratorManager) systemService;
                    vibratorManager.getDefaultVibrator().vibrate(VibrationEffect.createOneShot(30L, -1));
                } else {
                    Object systemService2 = getSystemService("vibrator");
                    Intrinsics.checkNotNull(systemService2, "null cannot be cast to non-null type android.os.Vibrator");
                    Vibrator vibrator = (Vibrator) systemService2;
                    if (Build.VERSION.SDK_INT >= 26) {
                        vibrator.vibrate(VibrationEffect.createOneShot(30L, -1));
                    } else {
                        vibrator.vibrate(30L);
                    }
                }
            } catch (Exception e) {
            }
        }
    }

    private final int dpToPx(int dp) {
        return (int) TypedValue.applyDimension(1, dp, getResources().getDisplayMetrics());
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        _isServiceRunning.setValue(false);
        ScreenCaptureManager screenCaptureManager = null;
        CoroutineScopeKt.cancel$default(this.serviceScope, null, 1, null);
        Runnable runnable = this.autoDismissRunnable;
        if (runnable != null) {
            this.mainHandler.removeCallbacks(runnable);
        }
        if (this.overlayView != null) {
            try {
                WindowManager windowManager = this.windowManager;
                if (windowManager == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("windowManager");
                    windowManager = null;
                }
                windowManager.removeView(this.overlayView);
            } catch (Exception e) {
                e.printStackTrace();
            }
            this.overlayView = null;
        }
        ScreenCaptureManager screenCaptureManager2 = this.screenCaptureManager;
        if (screenCaptureManager2 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("screenCaptureManager");
        } else {
            screenCaptureManager = screenCaptureManager2;
        }
        screenCaptureManager.release();
    }
}
