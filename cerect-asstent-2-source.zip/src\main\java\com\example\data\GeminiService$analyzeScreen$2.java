package com.example.data;

import android.graphics.Bitmap;
import android.util.Log;
import com.example.BuildConfig;
import com.example.model.AnswerResult;
import com.example.model.OptionShape;
import java.util.List;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.text.StringsKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.TimeoutKt;
import org.json.JSONArray;
import org.json.JSONObject;

/* JADX INFO: compiled from: GeminiService.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u0003H\n"}, d2 = {"<anonymous>", "Lkotlin/Result;", "Lcom/example/model/AnswerResult;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@DebugMetadata(c = "com.example.data.GeminiService$analyzeScreen$2", f = "GeminiService.kt", i = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, l = {152}, m = "invokeSuspend", n = {"apiKey", "requestJson", "systemInstruction", "sysParts", "sysTextPart", "contents", "contentItem", "parts", "promptText", "genConfig", "requestBodyString", "candidateModels", "successfulResult", "overallStartTime"}, s = {"L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "L$10", "L$11", "L$12", "J$0"})
final class GeminiService$analyzeScreen$2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Result<? extends AnswerResult>>, Object> {
    final /* synthetic */ Bitmap $bitmap;
    final /* synthetic */ String $customApiKey;
    final /* synthetic */ String $extraContext;
    final /* synthetic */ GeminiRateLimiter $rateLimiter;
    long J$0;
    Object L$0;
    Object L$1;
    Object L$10;
    Object L$11;
    Object L$12;
    Object L$2;
    Object L$3;
    Object L$4;
    Object L$5;
    Object L$6;
    Object L$7;
    Object L$8;
    Object L$9;
    int label;
    final /* synthetic */ GeminiService this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    GeminiService$analyzeScreen$2(String str, Bitmap bitmap, GeminiService geminiService, GeminiRateLimiter geminiRateLimiter, String str2, Continuation<? super GeminiService$analyzeScreen$2> continuation) {
        super(2, continuation);
        this.$customApiKey = str;
        this.$bitmap = bitmap;
        this.this$0 = geminiService;
        this.$rateLimiter = geminiRateLimiter;
        this.$extraContext = str2;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new GeminiService$analyzeScreen$2(this.$customApiKey, this.$bitmap, this.this$0, this.$rateLimiter, this.$extraContext, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public /* bridge */ /* synthetic */ Object invoke(CoroutineScope coroutineScope, Continuation<? super Result<? extends AnswerResult>> continuation) {
        return invoke2(coroutineScope, (Continuation<? super Result<AnswerResult>>) continuation);
    }

    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
    public final Object invoke2(CoroutineScope coroutineScope, Continuation<? super Result<AnswerResult>> continuation) {
        return ((GeminiService$analyzeScreen$2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    /* JADX WARN: Code duplicated, block: B:53:0x0279 A[Catch: Exception -> 0x005e, TRY_ENTER, TRY_LEAVE, TryCatch #0 {Exception -> 0x005e, blocks: (B:7:0x0053, B:53:0x0279), top: B:68:0x0053 }] */
    /* JADX WARN: Code duplicated, block: B:55:0x0289 A[Catch: Exception -> 0x02d6, TRY_ENTER, TRY_LEAVE, TryCatch #2 {Exception -> 0x02d6, blocks: (B:51:0x0275, B:55:0x0289), top: B:71:0x0275 }] */
    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object $result) {
        long overallStartTime;
        List<String> listListOf;
        Ref.ObjectRef successfulResult;
        Object objM7085constructorimpl;
        String string = BuildConfig.GEMINI_API_KEY;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                long overallStartTime2 = System.currentTimeMillis();
                try {
                    String str = this.$customApiKey;
                    if (!(str == null || StringsKt.isBlank(str))) {
                        string = StringsKt.trim((CharSequence) this.$customApiKey).toString();
                    } else if (StringsKt.isBlank(BuildConfig.GEMINI_API_KEY)) {
                        string = "";
                    }
                    String apiKey = string;
                    if (StringsKt.isBlank(apiKey)) {
                        Result.Companion companion = Result.INSTANCE;
                        return Result.m7084boximpl(Result.m7085constructorimpl(ResultKt.createFailure(new IllegalStateException("Není nastaven Gemini API klíč. Zadejte jej v nastavení aplikace nebo v AI Studio Secrets."))));
                    }
                    JSONObject jSONObject = new JSONObject();
                    JSONObject jSONObject2 = new JSONObject();
                    JSONArray sysParts = new JSONArray();
                    JSONObject sysTextPart = new JSONObject();
                    sysTextPart.put("text", "You are an elite, ultra-smart multiple-choice assessment and quiz competition champion. Your task is to analyze the question, images/diagrams, and options on screen, solve the problem with 100% accuracy, and select the correct option quadrant color/shape.\n\nStandard 4-option color/shape quadrant layout:\n- RED ▲ (Triangle) / Červená: Top-left option in 2x2 grid, or TRUE (Pravda/Ano) in True/False.\n- BLUE ◆ (Diamond) / Modrá: Top-right option in 2x2 grid, or FALSE (Nepravda/Ne) in True/False.\n- YELLOW ● (Circle) / Žlutá: Bottom-left option in 2x2 grid.\n- GREEN ■ (Square) / Zelená: Bottom-right option in 2x2 grid.\n- Standard A/B/C/D or 1/2/3/4 mapping: A/1 = RED_TRIANGLE, B/2 = BLUE_DIAMOND, C/3 = YELLOW_CIRCLE, D/4 = GREEN_SQUARE.\n\nCritical Problem Solving & Intelligence Directives:\n1. Question Comprehension: Pay extreme attention to negatives (NOT, NENÍ, KROMĚ, EXCEPT, NEPLATÍ, ŽÁDNÁ Z MOŽNOSTÍ), trick questions, wordplays, and superlatives (největší, nejmenší, první, poslední).\n2. Visual Analysis: If a picture, map, flag, geometric figure, or equation is on screen, inspect it thoroughly to confirm the factual answer.\n3. Spatial Verification: Once you know the correct answer, verify WHICH colored shape/button holds that exact answer text.\n4. Strict output format (3 lines ONLY, NO MARKDOWN BOLD, NO ASTERISKS):\nOPTION: [RED_TRIANGLE or BLUE_DIAMOND or YELLOW_CIRCLE or GREEN_SQUARE or UNKNOWN]\nANSWER: [precise correct answer text]\nEXPLANATION: [short sharp explanation in the question language]");
                    sysParts.put(sysTextPart);
                    jSONObject2.put("parts", sysParts);
                    jSONObject.put("systemInstruction", jSONObject2);
                    JSONArray jSONArray = new JSONArray();
                    JSONObject jSONObject3 = new JSONObject();
                    JSONArray jSONArray2 = new JSONArray();
                    String str2 = this.$extraContext;
                    StringBuilder sb = new StringBuilder();
                    sb.append("Identify the quiz question on screen and select the correct answer matching its exact option shape and color.");
                    String str3 = str2;
                    if (!(str3 == null || StringsKt.isBlank(str3))) {
                        sb.append("\nQuiz text content:\n").append(str2);
                    }
                    String promptText = sb.toString();
                    JSONObject jSONObject4 = new JSONObject();
                    jSONObject4.put("text", promptText);
                    jSONArray2.put(jSONObject4);
                    if (this.$bitmap != null) {
                        String base64Data = this.this$0.bitmapToBase64(this.$bitmap);
                        JSONObject jSONObject5 = new JSONObject();
                        JSONObject jSONObject6 = new JSONObject();
                        jSONObject6.put("mimeType", "image/jpeg");
                        jSONObject6.put("data", base64Data);
                        jSONObject5.put("inlineData", jSONObject6);
                        jSONArray2.put(jSONObject5);
                    }
                    jSONObject3.put("parts", jSONArray2);
                    jSONArray.put(jSONObject3);
                    jSONObject.put("contents", jSONArray);
                    JSONObject jSONObject7 = new JSONObject();
                    jSONObject7.put("temperature", 0.1d);
                    jSONObject7.put("maxOutputTokens", 256);
                    jSONObject.put("generationConfig", jSONObject7);
                    String requestBodyString = jSONObject.toString();
                    Intrinsics.checkNotNullExpressionValue(requestBodyString, "toString(...)");
                    GeminiRateLimiter geminiRateLimiter = this.$rateLimiter;
                    if (geminiRateLimiter == null || (listListOf = geminiRateLimiter.getCandidateModels()) == null) {
                        listListOf = CollectionsKt.listOf((Object[]) new String[]{GeminiRateLimiter.MODEL_35_FLASH_LITE, GeminiRateLimiter.MODEL_31_FLASH_LITE, GeminiRateLimiter.MODEL_25_FLASH});
                    }
                    Ref.ObjectRef successfulResult2 = new Ref.ObjectRef();
                    List<String> list = listListOf;
                    this.L$0 = SpillingKt.nullOutSpilledVariable(apiKey);
                    this.L$1 = SpillingKt.nullOutSpilledVariable(jSONObject);
                    this.L$2 = SpillingKt.nullOutSpilledVariable(jSONObject2);
                    this.L$3 = SpillingKt.nullOutSpilledVariable(sysParts);
                    this.L$4 = SpillingKt.nullOutSpilledVariable(sysTextPart);
                    this.L$5 = SpillingKt.nullOutSpilledVariable(jSONArray);
                    this.L$6 = SpillingKt.nullOutSpilledVariable(jSONObject3);
                    this.L$7 = SpillingKt.nullOutSpilledVariable(jSONArray2);
                    this.L$8 = SpillingKt.nullOutSpilledVariable(promptText);
                    this.L$9 = SpillingKt.nullOutSpilledVariable(jSONObject7);
                    this.L$10 = SpillingKt.nullOutSpilledVariable(requestBodyString);
                    this.L$11 = SpillingKt.nullOutSpilledVariable(list);
                    this.L$12 = successfulResult2;
                    this.J$0 = overallStartTime2;
                    this.label = 1;
                    if (TimeoutKt.withTimeoutOrNull(16000L, new AnonymousClass2(list, this.$rateLimiter, this.this$0, successfulResult2, apiKey, requestBodyString, null), this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                    successfulResult = successfulResult2;
                    overallStartTime = overallStartTime2;
                    try {
                        if (successfulResult.element != 0) {
                            Result.Companion companion2 = Result.INSTANCE;
                            T t = successfulResult.element;
                            Intrinsics.checkNotNull(t);
                            return Result.m7084boximpl(Result.m7085constructorimpl(t));
                        }
                        long totalElapsed = System.currentTimeMillis() - overallStartTime;
                        long overallStartTime3 = overallStartTime;
                        try {
                            Log.w("GeminiService", "All candidate models failed or total time limit (" + totalElapsed + " ms) reached. Using Zero-Error Fallback.");
                            AnswerResult fallbackResult = new AnswerResult(OptionShape.UNKNOWN, "Nápověda nedostupná (Časový strop)", "Všechny AI modely vyčerpaly časový limit nebo jsou dočasně vytížené.", CollectionsKt.emptyList(), "", System.currentTimeMillis(), "Záložní režim (Timeout)", totalElapsed);
                            Result.Companion companion3 = Result.INSTANCE;
                            objM7085constructorimpl = Result.m7085constructorimpl(fallbackResult);
                        } catch (Exception e) {
                            e = e;
                            overallStartTime = overallStartTime3;
                            Log.e("GeminiService", "Unexpected error in analyzeScreen", e);
                            long totalElapsed2 = System.currentTimeMillis() - overallStartTime;
                            Result.Companion companion4 = Result.INSTANCE;
                            objM7085constructorimpl = Result.m7085constructorimpl(new AnswerResult(OptionShape.UNKNOWN, "Nápověda selhala", "Došlo k neočekávané chybě připojení.", CollectionsKt.emptyList(), null, System.currentTimeMillis(), "Záložní režim", totalElapsed2, 16, null));
                        }
                        return Result.m7084boximpl(objM7085constructorimpl);
                    } catch (Exception e2) {
                        e = e2;
                    }
                    Log.e("GeminiService", "Unexpected error in analyzeScreen", e);
                    long totalElapsed3 = System.currentTimeMillis() - overallStartTime;
                    Result.Companion companion5 = Result.INSTANCE;
                    objM7085constructorimpl = Result.m7085constructorimpl(new AnswerResult(OptionShape.UNKNOWN, "Nápověda selhala", "Došlo k neočekávané chybě připojení.", CollectionsKt.emptyList(), null, System.currentTimeMillis(), "Záložní režim", totalElapsed3, 16, null));
                    return Result.m7084boximpl(objM7085constructorimpl);
                } catch (Exception e3) {
                    e = e3;
                    overallStartTime = overallStartTime2;
                }
                break;
            case 1:
                overallStartTime = this.J$0;
                Ref.ObjectRef successfulResult3 = (Ref.ObjectRef) this.L$12;
                try {
                    ResultKt.throwOnFailure($result);
                    successfulResult = successfulResult3;
                    if (successfulResult.element != 0) {
                        Result.Companion companion6 = Result.INSTANCE;
                        T t2 = successfulResult.element;
                        Intrinsics.checkNotNull(t2);
                        return Result.m7084boximpl(Result.m7085constructorimpl(t2));
                    }
                    long totalElapsed4 = System.currentTimeMillis() - overallStartTime;
                    long overallStartTime4 = overallStartTime;
                    Log.w("GeminiService", "All candidate models failed or total time limit (" + totalElapsed4 + " ms) reached. Using Zero-Error Fallback.");
                    AnswerResult fallbackResult2 = new AnswerResult(OptionShape.UNKNOWN, "Nápověda nedostupná (Časový strop)", "Všechny AI modely vyčerpaly časový limit nebo jsou dočasně vytížené.", CollectionsKt.emptyList(), "", System.currentTimeMillis(), "Záložní režim (Timeout)", totalElapsed4);
                    Result.Companion companion7 = Result.INSTANCE;
                    objM7085constructorimpl = Result.m7085constructorimpl(fallbackResult2);
                    return Result.m7084boximpl(objM7085constructorimpl);
                } catch (Exception e4) {
                    e = e4;
                }
                Log.e("GeminiService", "Unexpected error in analyzeScreen", e);
                long totalElapsed5 = System.currentTimeMillis() - overallStartTime;
                Result.Companion companion8 = Result.INSTANCE;
                objM7085constructorimpl = Result.m7085constructorimpl(new AnswerResult(OptionShape.UNKNOWN, "Nápověda selhala", "Došlo k neočekávané chybě připojení.", CollectionsKt.emptyList(), null, System.currentTimeMillis(), "Záložní režim", totalElapsed5, 16, null));
                return Result.m7084boximpl(objM7085constructorimpl);
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }

    /* JADX INFO: renamed from: com.example.data.GeminiService$analyzeScreen$2$2, reason: invalid class name */
    /* JADX INFO: compiled from: GeminiService.kt */
    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
    @DebugMetadata(c = "com.example.data.GeminiService$analyzeScreen$2$2", f = "GeminiService.kt", i = {0, 0}, l = {157}, m = "invokeSuspend", n = {"model", "modelStartTime"}, s = {"L$1", "J$0"})
    static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ String $apiKey;
        final /* synthetic */ List<String> $candidateModels;
        final /* synthetic */ GeminiRateLimiter $rateLimiter;
        final /* synthetic */ String $requestBodyString;
        final /* synthetic */ Ref.ObjectRef<AnswerResult> $successfulResult;
        long J$0;
        Object L$0;
        Object L$1;
        int label;
        final /* synthetic */ GeminiService this$0;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass2(List<String> list, GeminiRateLimiter geminiRateLimiter, GeminiService geminiService, Ref.ObjectRef<AnswerResult> objectRef, String str, String str2, Continuation<? super AnonymousClass2> continuation) {
            super(2, continuation);
            this.$candidateModels = list;
            this.$rateLimiter = geminiRateLimiter;
            this.this$0 = geminiService;
            this.$successfulResult = objectRef;
            this.$apiKey = str;
            this.$requestBodyString = str2;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
            return new AnonymousClass2(this.$candidateModels, this.$rateLimiter, this.this$0, this.$successfulResult, this.$apiKey, this.$requestBodyString, continuation);
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX WARN: Code duplicated, block: B:20:0x0061  */
        /* JADX WARN: Code duplicated, block: B:29:0x0096 A[RETURN] */
        /* JADX WARN: Code duplicated, block: B:30:0x0097  */
        /* JADX WARN: Code duplicated, block: B:33:0x00a4 A[Catch: Exception -> 0x00fa, QuotaExhaustedException -> 0x00fd, CancellationException -> 0x0100, TimeoutCancellationException -> 0x0103, TryCatch #12 {QuotaExhaustedException -> 0x00fd, TimeoutCancellationException -> 0x0103, CancellationException -> 0x0100, Exception -> 0x00fa, blocks: (B:31:0x009f, B:33:0x00a4, B:35:0x00ae, B:36:0x00b1, B:38:0x00f2), top: B:89:0x009f }] */
        /* JADX WARN: Code duplicated, block: B:35:0x00ae A[Catch: Exception -> 0x00fa, QuotaExhaustedException -> 0x00fd, CancellationException -> 0x0100, TimeoutCancellationException -> 0x0103, TryCatch #12 {QuotaExhaustedException -> 0x00fd, TimeoutCancellationException -> 0x0103, CancellationException -> 0x0100, Exception -> 0x00fa, blocks: (B:31:0x009f, B:33:0x00a4, B:35:0x00ae, B:36:0x00b1, B:38:0x00f2), top: B:89:0x009f }] */
        /* JADX WARN: Code duplicated, block: B:38:0x00f2 A[Catch: Exception -> 0x00fa, QuotaExhaustedException -> 0x00fd, CancellationException -> 0x0100, TimeoutCancellationException -> 0x0103, TRY_LEAVE, TryCatch #12 {QuotaExhaustedException -> 0x00fd, TimeoutCancellationException -> 0x0103, CancellationException -> 0x0100, Exception -> 0x00fa, blocks: (B:31:0x009f, B:33:0x00a4, B:35:0x00ae, B:36:0x00b1, B:38:0x00f2), top: B:89:0x009f }] */
        /* JADX WARN: Type inference failed for: r0v35, types: [T, com.example.model.AnswerResult] */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:30:0x0097 -> B:89:0x009f). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:51:0x0112 -> B:77:0x01df). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:59:0x013d -> B:77:0x01df). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:67:0x0170 -> B:77:0x01df). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:74:0x01a1 -> B:18:0x005b). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:76:0x01d4 -> B:77:0x01df). Please report as a decompilation issue!!! */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:86:0x021d -> B:18:0x005b). Please report as a decompilation issue!!! */
        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
            jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
            */
        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final java.lang.Object invokeSuspend(java.lang.Object r21) {
            /*
                Method dump skipped, instruction units count: 588
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: com.example.data.GeminiService$analyzeScreen$2.AnonymousClass2.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }
}
