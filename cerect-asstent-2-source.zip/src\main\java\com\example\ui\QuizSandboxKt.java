package com.example.ui;

import androidx.compose.foundation.BackgroundKt;
import androidx.compose.foundation.BorderKt;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.foundation.BorderStrokeKt;
import androidx.compose.foundation.ClickableKt;
import androidx.compose.foundation.ScrollKt;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.OffsetKt;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.shape.RoundedCornerShape;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.foundation.text.KeyboardActions;
import androidx.compose.foundation.text.KeyboardOptions;
import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.filled.AutoAwesomeKt;
import androidx.compose.material.icons.filled.CheckCircleKt;
import androidx.compose.material.icons.filled.CloudQueueKt;
import androidx.compose.material.icons.filled.PsychologyKt;
import androidx.compose.material3.ButtonColors;
import androidx.compose.material3.ButtonDefaults;
import androidx.compose.material3.ButtonKt;
import androidx.compose.material3.CardColors;
import androidx.compose.material3.CardDefaults;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.IconButtonKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.OutlinedTextFieldDefaults;
import androidx.compose.material3.OutlinedTextFieldKt;
import androidx.compose.material3.ProgressIndicatorKt;
import androidx.compose.material3.SurfaceKt;
import androidx.compose.material3.TextFieldColors;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.CompositionScopedCoroutineScopeCanceller;
import androidx.compose.runtime.EffectsKt;
import androidx.compose.runtime.MutableFloatState;
import androidx.compose.runtime.MutableIntState;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.PrimitiveSnapshotStateKt;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotIntStateKt;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.draw.AlphaKt;
import androidx.compose.ui.draw.ClipKt;
import androidx.compose.ui.draw.ShadowKt;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.ui.input.pointer.PointerInputScope;
import androidx.compose.ui.input.pointer.SuspendingPointerInputFilterKt;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.TestTagKt;
import androidx.compose.ui.text.TextLayoutResult;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.input.VisualTransformation;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.unit.Density;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.IntOffset;
import androidx.compose.ui.unit.IntOffsetKt;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.profileinstaller.ProfileVerifier;
import com.example.data.ApiUsageStats;
import com.example.data.AppPreferences;
import com.example.data.GeminiService;
import com.example.model.AnswerResult;
import com.example.model.CornerPosition;
import com.example.model.OptionShape;
import com.example.ui.theme.ColorKt;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;

/* JADX INFO: compiled from: QuizSandbox.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0007\n\u0000\u001a'\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\fH\u0007¢\u0006\u0002\u0010\r\u001a+\u0010\u000e\u001a\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u00122\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00060\u0014H\u0003¢\u0006\u0002\u0010\u0015\"\u0017\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001¢\u0006\b\n\u0000\u001a\u0004\b\u0003\u0010\u0004¨\u0006\u0016²\u0006\n\u0010\u0017\u001a\u00020\u0018X\u008a\u008e\u0002²\u0006\f\u0010\u0019\u001a\u0004\u0018\u00010\u001aX\u008a\u008e\u0002²\u0006\n\u0010\u001b\u001a\u00020\u001cX\u008a\u008e\u0002²\u0006\n\u0010\u001d\u001a\u00020\u001eX\u008a\u008e\u0002²\u0006\n\u0010\u001f\u001a\u00020\u001eX\u008a\u008e\u0002²\u0006\f\u0010 \u001a\u0004\u0018\u00010\u0010X\u008a\u008e\u0002²\u0006\f\u0010!\u001a\u0004\u0018\u00010\u001aX\u008a\u008e\u0002²\u0006\n\u0010\"\u001a\u00020#X\u008a\u0084\u0002²\u0006\n\u0010$\u001a\u00020%X\u008a\u008e\u0002²\u0006\n\u0010&\u001a\u00020%X\u008a\u008e\u0002"}, d2 = {"SampleQuizQuestions", "", "Lcom/example/ui/QuizOptionQuestion;", "getSampleQuizQuestions", "()Ljava/util/List;", "QuizSandbox", "", "preferences", "Lcom/example/data/AppPreferences;", "geminiService", "Lcom/example/data/GeminiService;", "modifier", "Landroidx/compose/ui/Modifier;", "(Lcom/example/data/AppPreferences;Lcom/example/data/GeminiService;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "SandboxAnswerCard", "answer", "Lcom/example/model/AnswerResult;", "cornerPos", "Lcom/example/model/CornerPosition;", "onDismiss", "Lkotlin/Function0;", "(Lcom/example/model/AnswerResult;Lcom/example/model/CornerPosition;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V", "app", "currentQuestionIndex", "", "selectedShape", "Lcom/example/model/OptionShape;", "customQuestionText", "", "isCustomMode", "", "isAnalyzing", "answerResult", "detectedShape", "apiUsage", "Lcom/example/data/ApiUsageStats;", "offsetX", "", "offsetY"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class QuizSandboxKt {
    private static final List<QuizOptionQuestion> SampleQuizQuestions = CollectionsKt.listOf((Object[]) new QuizOptionQuestion[]{new QuizOptionQuestion(1, "Zeměpis", "Které město je hlavním městem Francie?", "Paříž", "Londýn", "Řím", "Madrid", OptionShape.RED_TRIANGLE), new QuizOptionQuestion(2, "Příroda & Věda", "Jaká je chemická značka vody?", "CO2", "H2O", "NaCl", "O2", OptionShape.BLUE_DIAMOND), new QuizOptionQuestion(3, "Kosmos", "Která planeta je největší ve sluneční soustavě?", "Mars", "Země", "Jupiter", "Saturn", OptionShape.YELLOW_CIRCLE), new QuizOptionQuestion(4, "Chemie", "Který chemický prvek má značku Au?", "Stříbro", "Hliník", "Platina", "Zlato", OptionShape.GREEN_SQUARE)});

    /* JADX INFO: compiled from: QuizSandbox.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[CornerPosition.values().length];
            try {
                iArr[CornerPosition.TOP_RIGHT.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[CornerPosition.TOP_LEFT.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[CornerPosition.BOTTOM_RIGHT.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[CornerPosition.BOTTOM_LEFT.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    static final Unit QuizSandbox$lambda$70(AppPreferences appPreferences, GeminiService geminiService, Modifier modifier, int i, int i2, Composer composer, int i3) {
        QuizSandbox(appPreferences, geminiService, modifier, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    static final Unit SandboxAnswerCard$lambda$83(AnswerResult answerResult, CornerPosition cornerPosition, Function0 function0, int i, Composer composer, int i2) {
        SandboxAnswerCard(answerResult, cornerPosition, function0, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    public static final List<QuizOptionQuestion> getSampleQuizQuestions() {
        return SampleQuizQuestions;
    }

    /* JADX WARN: Code duplicated, block: B:110:0x062c  */
    /* JADX WARN: Code duplicated, block: B:113:0x0638  */
    /* JADX WARN: Code duplicated, block: B:114:0x063e  */
    /* JADX WARN: Code duplicated, block: B:117:0x0671  */
    /* JADX WARN: Code duplicated, block: B:120:0x0684  */
    /* JADX WARN: Code duplicated, block: B:121:0x0687  */
    /* JADX WARN: Code duplicated, block: B:125:0x06e2  */
    /* JADX WARN: Code duplicated, block: B:126:0x06f0  */
    /* JADX WARN: Code duplicated, block: B:129:0x0710  */
    /* JADX WARN: Code duplicated, block: B:130:0x0720  */
    /* JADX WARN: Code duplicated, block: B:133:0x0780  */
    /* JADX WARN: Code duplicated, block: B:134:0x078e  */
    /* JADX WARN: Code duplicated, block: B:137:0x07c2  */
    /* JADX WARN: Code duplicated, block: B:138:0x07d0  */
    /* JADX WARN: Code duplicated, block: B:141:0x07f0  */
    /* JADX WARN: Code duplicated, block: B:142:0x0800  */
    /* JADX WARN: Code duplicated, block: B:145:0x0860  */
    /* JADX WARN: Code duplicated, block: B:146:0x086e  */
    /* JADX WARN: Code duplicated, block: B:149:0x08cb  */
    /* JADX WARN: Code duplicated, block: B:150:0x0965  */
    /* JADX WARN: Code duplicated, block: B:153:0x0a57  */
    /* JADX WARN: Code duplicated, block: B:157:0x0a7e  */
    /* JADX WARN: Code duplicated, block: B:160:0x0b24  */
    /* JADX WARN: Code duplicated, block: B:162:0x0b2c  */
    /* JADX WARN: Code duplicated, block: B:163:0x0b33  */
    /* JADX WARN: Code duplicated, block: B:164:0x0b3a  */
    /* JADX WARN: Code duplicated, block: B:165:0x0b41  */
    /* JADX WARN: Code duplicated, block: B:168:0x0bc0  */
    /* JADX WARN: Code duplicated, block: B:171:0x0bcc  */
    /* JADX WARN: Code duplicated, block: B:172:0x0bd2  */
    /* JADX WARN: Code duplicated, block: B:175:0x0c05  */
    /* JADX WARN: Code duplicated, block: B:179:0x0c1b A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:183:0x0c6e  */
    /* JADX WARN: Code duplicated, block: B:186:0x0c7f  */
    /* JADX WARN: Code duplicated, block: B:189:0x0c95  */
    /* JADX WARN: Code duplicated, block: B:191:0x0c9d  */
    /* JADX WARN: Code duplicated, block: B:192:0x0ca4  */
    /* JADX WARN: Code duplicated, block: B:195:0x0d30  */
    /* JADX WARN: Code duplicated, block: B:198:0x0d3c  */
    /* JADX WARN: Code duplicated, block: B:199:0x0d40  */
    /* JADX WARN: Code duplicated, block: B:202:0x0d6f  */
    /* JADX WARN: Code duplicated, block: B:206:0x0d85 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:210:0x0dd7  */
    /* JADX WARN: Code duplicated, block: B:215:0x0de6  */
    /* JADX WARN: Code duplicated, block: B:217:0x0dea  */
    /* JADX WARN: Code duplicated, block: B:228:0x0e49 A[ADDED_TO_REGION, REMOVE] */
    /* JADX WARN: Code duplicated, block: B:232:0x0e69  */
    /* JADX WARN: Code duplicated, block: B:233:0x0e6e  */
    /* JADX WARN: Code duplicated, block: B:236:0x0ec5  */
    /* JADX WARN: Code duplicated, block: B:237:0x0ed0  */
    /* JADX WARN: Code duplicated, block: B:240:0x0eff  */
    /* JADX WARN: Code duplicated, block: B:241:0x0f01  */
    /* JADX WARN: Code duplicated, block: B:244:0x0f2e  */
    /* JADX WARN: Code duplicated, block: B:248:0x0f5f  */
    /* JADX WARN: Code duplicated, block: B:251:0x1012  */
    /* JADX WARN: Code duplicated, block: B:254:0x101e  */
    /* JADX WARN: Code duplicated, block: B:255:0x1024  */
    /* JADX WARN: Code duplicated, block: B:258:0x1055  */
    /* JADX WARN: Code duplicated, block: B:262:0x106b A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:266:0x10c1  */
    /* JADX WARN: Code duplicated, block: B:267:0x10fd  */
    /* JADX WARN: Code duplicated, block: B:269:0x110a  */
    /* JADX WARN: Code duplicated, block: B:271:0x1110  */
    /* JADX WARN: Code duplicated, block: B:274:0x1116  */
    /* JADX WARN: Code duplicated, block: B:275:0x1119  */
    /* JADX WARN: Code duplicated, block: B:279:0x117c  */
    /* JADX WARN: Code duplicated, block: B:290:0x11cd A[ADDED_TO_REGION, REMOVE] */
    /* JADX WARN: Code duplicated, block: B:294:0x1223  */
    public static final void QuizSandbox(final AppPreferences preferences, final GeminiService geminiService, Modifier modifier, Composer $composer, final int $changed, final int i) {
        Modifier modifier2;
        Modifier modifier3;
        Object compositionScopedCoroutineScopeCanceller;
        Object objMutableIntStateOf;
        Object objMutableStateOf$default;
        Object objMutableStateOf$default2;
        Object objMutableStateOf$default3;
        Object objMutableStateOf$default4;
        Function0<ComposeUiNode> function0;
        Composer composer;
        Composer composer2;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function1;
        Composer composerM3652constructorimpl;
        Composer composer3;
        Composer composer4;
        long surfaceVariant;
        long onSurfaceVariant;
        Object objRememberedValue;
        long surfaceVariant2;
        long onSurfaceVariant2;
        Object objRememberedValue2;
        boolean zChanged;
        final MutableState answerResult$delegate;
        boolean z;
        Object obj;
        QuizOptionQuestion currentQuestion;
        final MutableState isAnalyzing$delegate;
        GeminiService geminiService2;
        final CoroutineScope scope;
        AppPreferences appPreferences;
        MutableState isAnalyzing$delegate2;
        Alignment topEnd;
        final MutableState customQuestionText$delegate;
        int currentCompositeKeyHash2;
        Function0<ComposeUiNode> constructor2;
        Function0<ComposeUiNode> function2;
        Composer composerM3652constructorimpl2;
        OptionShape optionShapeQuizSandbox$lambda$19;
        long jColor;
        Alignment.Horizontal end;
        Composer composer5;
        int currentCompositeKeyHash3;
        Function0<ComposeUiNode> constructor3;
        Composer composerM3652constructorimpl3;
        Composer composer6;
        boolean z2;
        float fCoerceIn;
        float fM6622constructorimpl;
        int iOrdinal;
        boolean zChanged2;
        final MutableState isAnalyzing$delegate3;
        Composer $composer2;
        final OptionShape optionShape;
        final MutableState detectedShape$delegate;
        Object obj2;
        final MutableState answerResult$delegate2;
        Object isCustomMode$delegate;
        OptionShape optionShape2;
        int currentCompositeKeyHash4;
        Function0<ComposeUiNode> constructor4;
        Function0<ComposeUiNode> function3;
        Composer composerM3652constructorimpl4;
        Composer composer7;
        String symbol;
        int i2;
        final Modifier modifier4;
        Object obj3;
        Intrinsics.checkNotNullParameter(preferences, "preferences");
        Intrinsics.checkNotNullParameter(geminiService, "geminiService");
        Composer $composer3 = $composer.startRestartGroup(2136771363);
        ComposerKt.sourceInformation($composer3, "C(QuizSandbox)P(2)144@5117L24,145@5172L33,146@5229L47,147@5305L31,148@5359L34,151@5457L34,152@5514L48,153@5586L47,159@5803L161,159@5773L191,223@7941L15308:QuizSandbox.kt#naom5h");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer3.changedInstance(preferences) ? 4 : 2;
        }
        if (($changed & 48) == 0) {
            $dirty |= $composer3.changedInstance(geminiService) ? 32 : 16;
        }
        int i3 = i & 4;
        if (i3 != 0) {
            $dirty |= 384;
            modifier2 = modifier;
        } else if (($changed & 384) == 0) {
            modifier2 = modifier;
            $dirty |= $composer3.changed(modifier2) ? 256 : 128;
        } else {
            modifier2 = modifier;
        }
        int $dirty2 = $dirty;
        if (($dirty2 & 147) == 146 && $composer3.getSkipping()) {
            $composer3.skipToGroupEnd();
            modifier4 = modifier2;
            $composer2 = $composer3;
        } else {
            if (i3 != 0) {
                modifier3 = Modifier.INSTANCE;
            } else {
                modifier3 = modifier2;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2136771363, $dirty2, -1, "com.example.ui.QuizSandbox (QuizSandbox.kt:143)");
            }
            ComposerKt.sourceInformationMarkerStart($composer3, 773894976, "CC(rememberCoroutineScope)482@20332L144:Effects.kt#9igjgp");
            ComposerKt.sourceInformationMarkerStart($composer3, -954367824, "CC(remember):Effects.kt#9igjgp");
            Object objRememberedValue3 = $composer3.rememberedValue();
            if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                compositionScopedCoroutineScopeCanceller = new CompositionScopedCoroutineScopeCanceller(EffectsKt.createCompositionCoroutineScope(EmptyCoroutineContext.INSTANCE, $composer3));
                $composer3.updateRememberedValue(compositionScopedCoroutineScopeCanceller);
            } else {
                compositionScopedCoroutineScopeCanceller = objRememberedValue3;
            }
            ComposerKt.sourceInformationMarkerEnd(r0);
            final CoroutineScope scope2 = ((CompositionScopedCoroutineScopeCanceller) compositionScopedCoroutineScopeCanceller).getCoroutineScope();
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerStart($composer3, 442918692, "CC(remember):QuizSandbox.kt#9igjgp");
            Object objRememberedValue4 = $composer3.rememberedValue();
            if (objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                objMutableIntStateOf = SnapshotIntStateKt.mutableIntStateOf(0);
                $composer3.updateRememberedValue(objMutableIntStateOf);
            } else {
                objMutableIntStateOf = objRememberedValue4;
            }
            final MutableIntState currentQuestionIndex$delegate = (MutableIntState) objMutableIntStateOf;
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerStart($composer3, 442920530, "CC(remember):QuizSandbox.kt#9igjgp");
            Object objRememberedValue5 = $composer3.rememberedValue();
            if (objRememberedValue5 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(null, null, 2, null);
                $composer3.updateRememberedValue(objMutableStateOf$default);
            } else {
                objMutableStateOf$default = objRememberedValue5;
            }
            final MutableState selectedShape$delegate = (MutableState) objMutableStateOf$default;
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerStart($composer3, 442922946, "CC(remember):QuizSandbox.kt#9igjgp");
            Object objRememberedValue6 = $composer3.rememberedValue();
            if (objRememberedValue6 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default2 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
                $composer3.updateRememberedValue(objMutableStateOf$default2);
            } else {
                objMutableStateOf$default2 = objRememberedValue6;
            }
            final MutableState customQuestionText$delegate2 = (MutableState) objMutableStateOf$default2;
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerStart($composer3, 442924677, "CC(remember):QuizSandbox.kt#9igjgp");
            Object objRememberedValue7 = $composer3.rememberedValue();
            if (objRememberedValue7 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default3 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                $composer3.updateRememberedValue(objMutableStateOf$default3);
            } else {
                objMutableStateOf$default3 = objRememberedValue7;
            }
            final MutableState isCustomMode$delegate2 = (MutableState) objMutableStateOf$default3;
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerStart($composer3, 442927813, "CC(remember):QuizSandbox.kt#9igjgp");
            Object objRememberedValue8 = $composer3.rememberedValue();
            if (objRememberedValue8 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default4 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                $composer3.updateRememberedValue(objMutableStateOf$default4);
            } else {
                objMutableStateOf$default4 = objRememberedValue8;
            }
            final MutableState isAnalyzing$delegate4 = (MutableState) objMutableStateOf$default4;
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerStart($composer3, 442929651, "CC(remember):QuizSandbox.kt#9igjgp");
            Object objRememberedValue9 = $composer3.rememberedValue();
            if (objRememberedValue9 == Composer.INSTANCE.getEmpty()) {
                objRememberedValue9 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(null, null, 2, null);
                $composer3.updateRememberedValue(objRememberedValue9);
            }
            MutableState answerResult$delegate3 = (MutableState) objRememberedValue9;
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerStart($composer3, 442931954, "CC(remember):QuizSandbox.kt#9igjgp");
            Object objRememberedValue10 = $composer3.rememberedValue();
            if (objRememberedValue10 == Composer.INSTANCE.getEmpty()) {
                objRememberedValue10 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(null, null, 2, null);
                $composer3.updateRememberedValue(objRememberedValue10);
            }
            final MutableState detectedShape$delegate2 = (MutableState) objRememberedValue10;
            ComposerKt.sourceInformationMarkerEnd($composer3);
            CornerPosition cornerPos = preferences.getCornerPosition();
            final QuizOptionQuestion currentQuestion2 = SampleQuizQuestions.get(QuizSandbox$lambda$1(currentQuestionIndex$delegate));
            OptionShape optionShapeQuizSandbox$lambda$110 = QuizSandbox$lambda$19(detectedShape$delegate2);
            ComposerKt.sourceInformationMarkerStart($composer3, 442939012, "CC(remember):QuizSandbox.kt#9igjgp");
            boolean zChangedInstance = $composer3.changedInstance(preferences);
            QuizSandboxKt$QuizSandbox$1$1 quizSandboxKt$QuizSandbox$1$1RememberedValue = $composer3.rememberedValue();
            if (zChangedInstance || quizSandboxKt$QuizSandbox$1$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                quizSandboxKt$QuizSandbox$1$1RememberedValue = new QuizSandboxKt$QuizSandbox$1$1(preferences, detectedShape$delegate2, null);
                $composer3.updateRememberedValue(quizSandboxKt$QuizSandbox$1$1RememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd($composer3);
            EffectsKt.LaunchedEffect(optionShapeQuizSandbox$lambda$110, (Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object>) quizSandboxKt$QuizSandbox$1$1RememberedValue, $composer3, 0);
            Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(modifier3, 0.0f, 1, null);
            ComposerKt.sourceInformationMarkerStart($composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
            Modifier modifier5 = modifier3;
            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.INSTANCE.getTopStart(), false);
            ComposerKt.sourceInformationMarkerStart($composer3, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash($composer3, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer3.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer3, modifierFillMaxSize$default);
            Function0<ComposeUiNode> constructor5 = ComposeUiNode.INSTANCE.getConstructor();
            int i4 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer3.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer3.startReusableNode();
            if ($composer3.getInserting()) {
                function0 = constructor5;
                $composer3.createNode(function0);
            } else {
                function0 = constructor5;
                $composer3.useNode();
            }
            Composer composerM3652constructorimpl5 = Updater.m3652constructorimpl($composer3);
            Updater.m3659setimpl(composerM3652constructorimpl5, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl5, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl5.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl5.rememberedValue(), Integer.valueOf(currentCompositeKeyHash5))) {
                composerM3652constructorimpl5.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash5));
                composerM3652constructorimpl5.apply(Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash);
            }
            Updater.m3659setimpl(composerM3652constructorimpl5, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i5 = (i4 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
            BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
            int i6 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer3, -986312641, "C227@8067L21,224@7986L11940,553@20288L2957:QuizSandbox.kt#naom5h");
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(ScrollKt.verticalScroll$default(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), ScrollKt.rememberScrollState(0, $composer3, 0, 1), false, null, false, 14, null), Dp.m6622constructorimpl(16));
            ComposerKt.sourceInformationMarkerStart($composer3, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer3, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer3, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash6 = ComposablesKt.getCurrentCompositeKeyHash($composer3, 0);
            CompositionLocalMap currentCompositionLocalMap2 = $composer3.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer3, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor6 = ComposeUiNode.INSTANCE.getConstructor();
            int i7 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer3.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer3.startReusableNode();
            if ($composer3.getInserting()) {
                $composer3.createNode(constructor6);
            } else {
                $composer3.useNode();
            }
            Composer composerM3652constructorimpl6 = Updater.m3652constructorimpl($composer3);
            Updater.m3659setimpl(composerM3652constructorimpl6, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl6, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl6.getInserting()) {
                composer = $composer3;
                if (!Intrinsics.areEqual(composerM3652constructorimpl6.rememberedValue(), Integer.valueOf(currentCompositeKeyHash6))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl6, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i8 = (i7 >> 6) & 14;
                composer2 = composer;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i9 = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 2106618599, "C231@8220L16,234@8332L11,233@8279L108,238@8483L2208,232@8243L2448,299@10699L41,302@10809L1137,333@11954L41,521@19180L41,529@19459L64,525@19295L23,533@19575L296,524@19269L602,542@19879L41:QuizSandbox.kt#naom5h");
                final State stateCollectAsState = SnapshotStateKt.collectAsState(preferences.getApiUsageFlow(), null, composer2, 0, 1);
                CardDefaults cardDefaults = CardDefaults.INSTANCE;
                long surfaceVariant3 = MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurfaceVariant();
                CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(16)), cardDefaults.m1829cardColorsro_MJ88(Color.m4157copywmQWz5c(surfaceVariant3, (14 & 1) != 0 ? Color.m4161getAlphaimpl(surfaceVariant3) : 0.6f, (14 & 2) != 0 ? Color.m4165getRedimpl(surfaceVariant3) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(surfaceVariant3) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(surfaceVariant3) : 0.0f), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, null, ComposableLambdaKt.rememberComposableLambda(-1324086255, true, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj4, Object obj5, Object obj6) {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$29(stateCollectAsState, (ColumnScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                    }
                }, composer2, 54), composer2, 196614, 24);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal horizontalM550spacedBy0680j_4 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalM550spacedBy0680j_4, Alignment.INSTANCE.getTop(), composer2, ((54 >> 3) & 14) | ((54 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i10 = ((((54 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function1 = constructor;
                    composer2.createNode(function1);
                } else {
                    function1 = constructor;
                    composer2.useNode();
                }
                composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl.getInserting()) {
                    composer3 = composer2;
                    if (!Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    }
                    Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                    int i11 = (i10 >> 6) & 14;
                    composer4 = composer3;
                    ComposerKt.sourceInformationMarkerStart(composer4, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                    int i12 = ((54 >> 6) & 112) | 6;
                    RowScope rowScope = RowScopeInstance.INSTANCE;
                    ComposerKt.sourceInformationMarkerStart(composer4, 20056789, "C308@11023L240,307@10963L24,306@10935L499,321@11531L238,320@11472L23,319@11444L494:QuizSandbox.kt#naom5h");
                    ButtonDefaults buttonDefaults = ButtonDefaults.INSTANCE;
                    if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                        composer4.startReplaceGroup(970483569);
                        ComposerKt.sourceInformation(composer4, "309@11118L11");
                        surfaceVariant = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getSurfaceVariant();
                        composer4.endReplaceGroup();
                    } else {
                        composer4.startReplaceGroup(970482128);
                        composer4.endReplaceGroup();
                        surfaceVariant = ColorKt.getIndigoPrimary();
                    }
                    if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                        composer4.startReplaceGroup(970486931);
                        ComposerKt.sourceInformation(composer4, "310@11223L11");
                        onSurfaceVariant = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                        composer4.endReplaceGroup();
                    } else {
                        composer4.startReplaceGroup(970485736);
                        composer4.endReplaceGroup();
                        onSurfaceVariant = Color.INSTANCE.m4196getWhite0d7_KjU();
                    }
                    ButtonColors buttonColorsM1809buttonColorsro_MJ88 = buttonDefaults.m1809buttonColorsro_MJ88(surfaceVariant, onSurfaceVariant, 0L, 0L, composer4, ButtonDefaults.$stable << 12, 12);
                    Modifier modifierTestTag = TestTagKt.testTag(RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), "sample_quiz_button");
                    ComposerKt.sourceInformationMarkerStart(composer4, 970478235, "CC(remember):QuizSandbox.kt#9igjgp");
                    objRememberedValue = composer4.rememberedValue();
                    if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                        objRememberedValue = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda14
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$34$lambda$31$lambda$30(isCustomMode$delegate2);
                            }
                        };
                        composer4.updateRememberedValue(objRememberedValue);
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    ButtonKt.Button((Function0) objRememberedValue, modifierTestTag, false, null, buttonColorsM1809buttonColorsro_MJ88, null, null, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.m6943getLambda$2084070797$app(), composer4, 805306374, 492);
                    ButtonDefaults buttonDefaults2 = ButtonDefaults.INSTANCE;
                    if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                        composer4.startReplaceGroup(970498352);
                        composer4.endReplaceGroup();
                        surfaceVariant2 = ColorKt.getIndigoPrimary();
                    } else {
                        composer4.startReplaceGroup(970499793);
                        ComposerKt.sourceInformation(composer4, "322@11625L11");
                        surfaceVariant2 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getSurfaceVariant();
                        composer4.endReplaceGroup();
                    }
                    if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                        composer4.startReplaceGroup(970501928);
                        composer4.endReplaceGroup();
                        onSurfaceVariant2 = Color.INSTANCE.m4196getWhite0d7_KjU();
                    } else {
                        composer4.startReplaceGroup(970503123);
                        ComposerKt.sourceInformation(composer4, "323@11729L11");
                        onSurfaceVariant2 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                        composer4.endReplaceGroup();
                    }
                    ButtonColors buttonColorsM1809buttonColorsro_MJ89 = buttonDefaults2.m1809buttonColorsro_MJ88(surfaceVariant2, onSurfaceVariant2, 0L, 0L, composer4, ButtonDefaults.$stable << 12, 12);
                    Modifier modifierTestTag2 = TestTagKt.testTag(RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), "custom_quiz_button");
                    ComposerKt.sourceInformationMarkerStart(composer4, 970494522, "CC(remember):QuizSandbox.kt#9igjgp");
                    objRememberedValue2 = composer4.rememberedValue();
                    if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                        objRememberedValue2 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda15
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$34$lambda$33$lambda$32(isCustomMode$delegate2);
                            }
                        };
                        composer4.updateRememberedValue(objRememberedValue2);
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    ButtonKt.Button((Function0) objRememberedValue2, modifierTestTag2, false, null, buttonColorsM1809buttonColorsro_MJ89, null, null, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.getLambda$1461881386$app(), composer4, 805306374, 492);
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    composer3.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                    if (!QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                        composer2.startReplaceGroup(2110242095);
                        ComposerKt.sourceInformation(composer2, "339@12150L11,338@12095L86,342@12260L20,346@12403L5263,337@12057L5609");
                        CardKt.Card(ShadowKt.m3823shadows4CzXII$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(4), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(20)), false, 0L, 0L, 28, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(20)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(1545147052, true, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda16
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj4, Object obj5, Object obj6) {
                                return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51(currentQuestion2, currentQuestionIndex$delegate, selectedShape$delegate, detectedShape$delegate2, (ColumnScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                            }
                        }, composer2, 54), composer2, ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 8);
                        composer2.endReplaceGroup();
                    } else {
                        composer2.startReplaceGroup(2115725871);
                        ComposerKt.sourceInformation(composer2, "486@17803L11,486@17761L62,488@17902L20,490@17979L1185,485@17723L1441");
                        CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(20)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(-1021124683, true, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda17
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj4, Object obj5, Object obj6) {
                                return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$55(customQuestionText$delegate2, (ColumnScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                            }
                        }, composer2, 54), composer2, 196614, 8);
                        composer2.endReplaceGroup();
                    }
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), composer2, 6);
                    Modifier modifierTestTag3 = TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "solve_current_question_button");
                    ButtonColors buttonColorsM1809buttonColorsro_MJ810 = ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(ColorKt.getIndigoPrimary(), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14);
                    RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(14));
                    ComposerKt.sourceInformationMarkerStart(composer2, 1592320086, "CC(remember):QuizSandbox.kt#9igjgp");
                    zChanged = $composer3.changed(currentQuestion2) | $composer3.changedInstance(scope2) | $composer3.changedInstance(preferences) | $composer3.changedInstance(geminiService);
                    Object objRememberedValue11 = composer2.rememberedValue();
                    if (!zChanged || objRememberedValue11 == Composer.INSTANCE.getEmpty()) {
                        answerResult$delegate = answerResult$delegate3;
                        z = true;
                        obj = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda18
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$57$lambda$56(scope2, isAnalyzing$delegate4, isCustomMode$delegate2, customQuestionText$delegate2, currentQuestion2, preferences, geminiService, answerResult$delegate, detectedShape$delegate2);
                            }
                        };
                        currentQuestion = currentQuestion2;
                        isAnalyzing$delegate = isAnalyzing$delegate4;
                        geminiService2 = geminiService;
                        customQuestionText$delegate2 = customQuestionText$delegate2;
                        scope = scope2;
                        appPreferences = preferences;
                        composer2.updateRememberedValue(obj);
                    } else {
                        appPreferences = preferences;
                        obj = objRememberedValue11;
                        scope = scope2;
                        isAnalyzing$delegate = isAnalyzing$delegate4;
                        currentQuestion = currentQuestion2;
                        answerResult$delegate = answerResult$delegate3;
                        geminiService2 = geminiService;
                        z = true;
                    }
                    ComposerKt.sourceInformationMarkerEnd(r1);
                    isAnalyzing$delegate2 = isAnalyzing$delegate;
                    ButtonKt.Button((Function0) obj, modifierTestTag3, false, roundedCornerShapeM953RoundedCornerShape0680j_4, buttonColorsM1809buttonColorsro_MJ810, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-211234033, z, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda19
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj4, Object obj5, Object obj6) {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$58(isAnalyzing$delegate, (RowScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                        }
                    }, composer2, 54), composer2, 805306416, 484);
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(80)), composer2, 6);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    switch (WhenMappings.$EnumSwitchMapping$0[r138.ordinal()]) {
                        case 1:
                            topEnd = Alignment.INSTANCE.getTopEnd();
                            break;
                        case 2:
                            topEnd = Alignment.INSTANCE.getTopStart();
                            break;
                        case 3:
                            topEnd = Alignment.INSTANCE.getBottomEnd();
                            break;
                        case 4:
                            topEnd = Alignment.INSTANCE.getBottomStart();
                            break;
                        default:
                            throw new NoWhenBranchMatchedException();
                    }
                    Alignment alignment = topEnd;
                    Modifier modifierM670padding3ABfNKs2 = PaddingKt.m670padding3ABfNKs(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(16));
                    customQuestionText$delegate = customQuestionText$delegate2;
                    ComposerKt.sourceInformationMarkerStart($composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                    MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy2 = BoxKt.maybeCachedBoxMeasurePolicy(alignment, false);
                    ComposerKt.sourceInformationMarkerStart($composer3, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer3, 0);
                    CompositionLocalMap currentCompositionLocalMap4 = $composer3.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier($composer3, modifierM670padding3ABfNKs2);
                    constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                    int i13 = ((((6 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart($composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!($composer3.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    $composer3.startReusableNode();
                    if ($composer3.getInserting()) {
                        function2 = constructor2;
                        $composer3.createNode(function2);
                    } else {
                        function2 = constructor2;
                        $composer3.useNode();
                    }
                    composerM3652constructorimpl2 = Updater.m3652constructorimpl($composer3);
                    Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyMaybeCachedBoxMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (!composerM3652constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                        composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                        composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash4);
                    }
                    Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                    int i14 = (i13 >> 6) & 14;
                    ComposerKt.sourceInformationMarkerStart($composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                    BoxScopeInstance boxScopeInstance2 = BoxScopeInstance.INSTANCE;
                    int i15 = ((6 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart($composer3, -1033182445, "C566@20669L2570:QuizSandbox.kt#naom5h");
                    optionShapeQuizSandbox$lambda$19 = QuizSandbox$lambda$19(detectedShape$delegate2);
                    if (optionShapeQuizSandbox$lambda$19 == null && optionShapeQuizSandbox$lambda$19 != OptionShape.UNKNOWN) {
                        jColor = androidx.compose.ui.graphics.ColorKt.Color(android.graphics.Color.parseColor(optionShapeQuizSandbox$lambda$19.getColorHex()));
                    } else {
                        jColor = androidx.compose.ui.graphics.ColorKt.Color(4283385573L);
                    }
                    long j = jColor;
                    switch (WhenMappings.$EnumSwitchMapping$0[r138.ordinal()]) {
                        case 1:
                        case 3:
                            end = Alignment.INSTANCE.getEnd();
                            break;
                        case 2:
                        case 4:
                            end = Alignment.INSTANCE.getStart();
                            break;
                        default:
                            throw new NoWhenBranchMatchedException();
                    }
                    Arrangement.Vertical verticalM550spacedBy0680j_4 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
                    composer5 = $composer3;
                    ComposerKt.sourceInformationMarkerStart(composer5, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                    Modifier modifier6 = Modifier.INSTANCE;
                    MeasurePolicy measurePolicyColumnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(verticalM550spacedBy0680j_4, end, composer5, ((48 >> 3) & 14) | ((48 >> 3) & 112));
                    ComposerKt.sourceInformationMarkerStart(composer5, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer5, 0);
                    CompositionLocalMap currentCompositionLocalMap5 = composer5.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier(composer5, modifier6);
                    constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                    int i16 = ((((48 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer5, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer5.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composer5.startReusableNode();
                    if (composer5.getInserting()) {
                        composer5.createNode(constructor3);
                    } else {
                        composer5.useNode();
                    }
                    composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer5);
                    Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyColumnMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (!composerM3652constructorimpl3.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                        composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                        composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash5);
                    }
                    Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
                    int i17 = (i16 >> 6) & 14;
                    ComposerKt.sourceInformationMarkerStart(composer5, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                    ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
                    int i18 = ((48 >> 6) & 112) | 6;
                    composer6 = composer5;
                    ComposerKt.sourceInformationMarkerStart(composer6, 406854957, "C599@22034L241,587@21553L1338:QuizSandbox.kt#naom5h");
                    if (!appPreferences.isPopupCardDisabled() || QuizSandbox$lambda$16(answerResult$delegate) == null || QuizSandbox$lambda$19(detectedShape$delegate2) == null) {
                        z2 = false;
                    } else {
                        z2 = true;
                    }
                    if (z2 || !(r138 == CornerPosition.BOTTOM_RIGHT || cornerPos == CornerPosition.BOTTOM_LEFT)) {
                        composer6.startReplaceGroup(385885533);
                    } else {
                        composer6.startReplaceGroup(407001524);
                        ComposerKt.sourceInformation(composer6, "579@21405L84,576@21290L211");
                        AnswerResult answerResultQuizSandbox$lambda$16 = QuizSandbox$lambda$16(answerResult$delegate);
                        Intrinsics.checkNotNull(answerResultQuizSandbox$lambda$16);
                        ComposerKt.sourceInformationMarkerStart(composer6, 705869657, "CC(remember):QuizSandbox.kt#9igjgp");
                        Object objRememberedValue12 = composer6.rememberedValue();
                        composer5 = composer5;
                        if (objRememberedValue12 == Composer.INSTANCE.getEmpty()) {
                            objRememberedValue12 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda20
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return QuizSandboxKt.QuizSandbox$lambda$69$lambda$68$lambda$67$lambda$61$lambda$60(detectedShape$delegate2, answerResult$delegate);
                                }
                            };
                            composer6.updateRememberedValue(objRememberedValue12);
                        }
                        ComposerKt.sourceInformationMarkerEnd(composer6);
                        SandboxAnswerCard(answerResultQuizSandbox$lambda$16, r138, (Function0) objRememberedValue12, composer6, 384);
                    }
                    composer6.endReplaceGroup();
                    Modifier modifierM715size3ABfNKs = SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(44));
                    if (optionShapeQuizSandbox$lambda$19 != null) {
                        fCoerceIn = 1.0f;
                    } else {
                        fCoerceIn = RangesKt.coerceIn(appPreferences.getCornerOpacity(), 0.05f, 1.0f);
                    }
                    Modifier modifierM225backgroundbw27NRU$default = BackgroundKt.m225backgroundbw27NRU$default(ClipKt.clip(ShadowKt.m3823shadows4CzXII$default(AlphaKt.alpha(modifierM715size3ABfNKs, fCoerceIn), Dp.m6622constructorimpl(8), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)), false, 0L, 0L, 28, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12))), j, null, 2, null);
                    if (optionShapeQuizSandbox$lambda$19 != null) {
                        fM6622constructorimpl = Dp.m6622constructorimpl((float) 2.5d);
                    } else {
                        fM6622constructorimpl = Dp.m6622constructorimpl((float) 1.5d);
                    }
                    Modifier modifierM236borderxT4_qwU = BorderKt.m236borderxT4_qwU(modifierM225backgroundbw27NRU$default, fM6622constructorimpl, Color.INSTANCE.m4196getWhite0d7_KjU(), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)));
                    ComposerKt.sourceInformationMarkerStart(composer6, 705889942, "CC(remember):QuizSandbox.kt#9igjgp");
                    if (optionShapeQuizSandbox$lambda$19 == null) {
                        iOrdinal = -1;
                    } else {
                        iOrdinal = optionShapeQuizSandbox$lambda$19.ordinal();
                    }
                    zChanged2 = $composer3.changed(iOrdinal) | $composer3.changed(currentQuestion) | $composer3.changedInstance(scope) | $composer3.changedInstance(appPreferences) | $composer3.changedInstance(geminiService2);
                    Object objRememberedValue13 = composer6.rememberedValue();
                    if (!zChanged2 || objRememberedValue13 == Composer.INSTANCE.getEmpty()) {
                        final QuizOptionQuestion currentQuestion3 = currentQuestion;
                        isAnalyzing$delegate3 = isAnalyzing$delegate2;
                        $composer2 = $composer3;
                        final AppPreferences appPreferences2 = appPreferences;
                        final GeminiService geminiService3 = geminiService2;
                        optionShape = optionShapeQuizSandbox$lambda$19;
                        final MutableState answerResult$delegate4 = answerResult$delegate;
                        Function0 function4 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda21
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return QuizSandboxKt.QuizSandbox$lambda$69$lambda$68$lambda$67$lambda$63$lambda$62(optionShape, detectedShape$delegate2, answerResult$delegate4, scope, isAnalyzing$delegate3, isCustomMode$delegate2, customQuestionText$delegate, currentQuestion3, appPreferences2, geminiService3);
                            }
                        };
                        detectedShape$delegate = detectedShape$delegate2;
                        obj2 = function4;
                        currentQuestion = currentQuestion3;
                        answerResult$delegate2 = answerResult$delegate4;
                        isCustomMode$delegate = isCustomMode$delegate2;
                        composer6.updateRememberedValue(obj2);
                    } else {
                        isAnalyzing$delegate3 = isAnalyzing$delegate2;
                        $composer2 = $composer3;
                        obj2 = objRememberedValue13;
                        optionShape = optionShapeQuizSandbox$lambda$19;
                        detectedShape$delegate = detectedShape$delegate2;
                        answerResult$delegate2 = answerResult$delegate;
                        isCustomMode$delegate = isCustomMode$delegate2;
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer6);
                    Modifier modifierTestTag4 = TestTagKt.testTag(ClickableKt.m258clickableXHw0xAI$default(modifierM236borderxT4_qwU, false, null, null, (Function0) obj2, 7, null), "floating_corner_trigger");
                    Alignment center = Alignment.INSTANCE.getCenter();
                    ComposerKt.sourceInformationMarkerStart(composer6, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                    MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy3 = BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                    optionShape2 = optionShape;
                    ComposerKt.sourceInformationMarkerStart(composer6, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer6, 0);
                    CompositionLocalMap currentCompositionLocalMap6 = composer6.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier6 = ComposedModifierKt.materializeModifier(composer6, modifierTestTag4);
                    constructor4 = ComposeUiNode.INSTANCE.getConstructor();
                    int i19 = ((((48 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer6, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer6.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composer6.startReusableNode();
                    if (composer6.getInserting()) {
                        function3 = constructor4;
                        composer6.createNode(function3);
                    } else {
                        function3 = constructor4;
                        composer6.useNode();
                    }
                    composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer6);
                    Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyMaybeCachedBoxMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap6, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash6 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (!composerM3652constructorimpl4.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl4.rememberedValue(), Integer.valueOf(currentCompositeKeyHash4))) {
                        composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
                        composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash6);
                    }
                    Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier6, ComposeUiNode.INSTANCE.getSetModifier());
                    int i20 = (i19 >> 6) & 14;
                    composer7 = composer6;
                    ComposerKt.sourceInformationMarkerStart(composer7, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                    BoxScopeInstance boxScopeInstance3 = BoxScopeInstance.INSTANCE;
                    int i21 = ((48 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer7, -1577986672, "C:QuizSandbox.kt#naom5h");
                    if (QuizSandbox$lambda$13(isAnalyzing$delegate3)) {
                        composer7.startReplaceGroup(-1577790629);
                        ComposerKt.sourceInformation(composer7, "618@22611L258");
                        if (optionShape2 != null || (symbol = optionShape2.getSymbol()) == null) {
                            symbol = "✦";
                        }
                        String str = symbol;
                        if (optionShape2 != null) {
                            i2 = 24;
                        } else {
                            i2 = 18;
                        }
                        TextKt.m2693Text4IGK_g(str, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(i2), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, TextAlign.m6482boximpl(TextAlign.INSTANCE.m6489getCentere0LSkKk()), 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer7, 196992, 0, 130514);
                        composer7.endReplaceGroup();
                    } else {
                        composer7.startReplaceGroup(-1577979326);
                        ComposerKt.sourceInformation(composer7, "612@22424L155");
                        ProgressIndicatorKt.m2367CircularProgressIndicatorLxG7B9w(SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), Color.INSTANCE.m4196getWhite0d7_KjU(), Dp.m6622constructorimpl(2), 0L, 0, composer7, 438, 24);
                        composer7 = composer7;
                        composer7.endReplaceGroup();
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer7);
                    ComposerKt.sourceInformationMarkerEnd(composer7);
                    composer6.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer6);
                    ComposerKt.sourceInformationMarkerEnd(composer6);
                    ComposerKt.sourceInformationMarkerEnd(composer6);
                    if (z2 || !(r76 == CornerPosition.TOP_RIGHT || r138 == CornerPosition.TOP_LEFT)) {
                        composer6.startReplaceGroup(385885533);
                    } else {
                        composer6 = composer6;
                        composer6.startReplaceGroup(408707764);
                        ComposerKt.sourceInformation(composer6, "632@23125L84,629@23010L211");
                        AnswerResult answerResultQuizSandbox$lambda$17 = QuizSandbox$lambda$16(answerResult$delegate2);
                        Intrinsics.checkNotNull(answerResultQuizSandbox$lambda$17);
                        ComposerKt.sourceInformationMarkerStart(composer6, 705924697, "CC(remember):QuizSandbox.kt#9igjgp");
                        Object objRememberedValue14 = composer6.rememberedValue();
                        if (objRememberedValue14 == Composer.INSTANCE.getEmpty()) {
                            obj3 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda1
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return QuizSandboxKt.QuizSandbox$lambda$69$lambda$68$lambda$67$lambda$66$lambda$65(detectedShape$delegate, answerResult$delegate2);
                                }
                            };
                            composer6.updateRememberedValue(obj3);
                        } else {
                            obj3 = objRememberedValue14;
                        }
                        ComposerKt.sourceInformationMarkerEnd(composer6);
                        SandboxAnswerCard(answerResultQuizSandbox$lambda$17, r76, (Function0) obj3, composer6, 384);
                    }
                    composer6.endReplaceGroup();
                    ComposerKt.sourceInformationMarkerEnd(composer6);
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    composer5.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    ComposerKt.sourceInformationMarkerEnd($composer3);
                    ComposerKt.sourceInformationMarkerEnd($composer3);
                    $composer3.endNode();
                    ComposerKt.sourceInformationMarkerEnd($composer3);
                    ComposerKt.sourceInformationMarkerEnd($composer3);
                    ComposerKt.sourceInformationMarkerEnd($composer3);
                    ComposerKt.sourceInformationMarkerEnd($composer3);
                    ComposerKt.sourceInformationMarkerEnd($composer3);
                    $composer3.endNode();
                    ComposerKt.sourceInformationMarkerEnd($composer3);
                    ComposerKt.sourceInformationMarkerEnd($composer3);
                    ComposerKt.sourceInformationMarkerEnd($composer3);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                    modifier4 = modifier5;
                } else {
                    composer3 = composer2;
                }
                composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash3);
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i110 = (i10 >> 6) & 14;
                composer4 = composer3;
                ComposerKt.sourceInformationMarkerStart(composer4, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                int i111 = ((54 >> 6) & 112) | 6;
                RowScope rowScope2 = RowScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composer4, 20056789, "C308@11023L240,307@10963L24,306@10935L499,321@11531L238,320@11472L23,319@11444L494:QuizSandbox.kt#naom5h");
                ButtonDefaults buttonDefaults3 = ButtonDefaults.INSTANCE;
                if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                    composer4.startReplaceGroup(970482128);
                    composer4.endReplaceGroup();
                    surfaceVariant = ColorKt.getIndigoPrimary();
                } else {
                    composer4.startReplaceGroup(970483569);
                    ComposerKt.sourceInformation(composer4, "309@11118L11");
                    surfaceVariant = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getSurfaceVariant();
                    composer4.endReplaceGroup();
                }
                if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                    composer4.startReplaceGroup(970485736);
                    composer4.endReplaceGroup();
                    onSurfaceVariant = Color.INSTANCE.m4196getWhite0d7_KjU();
                } else {
                    composer4.startReplaceGroup(970486931);
                    ComposerKt.sourceInformation(composer4, "310@11223L11");
                    onSurfaceVariant = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                    composer4.endReplaceGroup();
                }
                ButtonColors buttonColorsM1809buttonColorsro_MJ811 = buttonDefaults3.m1809buttonColorsro_MJ88(surfaceVariant, onSurfaceVariant, 0L, 0L, composer4, ButtonDefaults.$stable << 12, 12);
                Modifier modifierTestTag5 = TestTagKt.testTag(RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), "sample_quiz_button");
                ComposerKt.sourceInformationMarkerStart(composer4, 970478235, "CC(remember):QuizSandbox.kt#9igjgp");
                objRememberedValue = composer4.rememberedValue();
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda14
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$34$lambda$31$lambda$30(isCustomMode$delegate2);
                        }
                    };
                    composer4.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ButtonKt.Button((Function0) objRememberedValue, modifierTestTag5, false, null, buttonColorsM1809buttonColorsro_MJ811, null, null, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.m6943getLambda$2084070797$app(), composer4, 805306374, 492);
                ButtonDefaults buttonDefaults4 = ButtonDefaults.INSTANCE;
                if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                    composer4.startReplaceGroup(970498352);
                    composer4.endReplaceGroup();
                    surfaceVariant2 = ColorKt.getIndigoPrimary();
                } else {
                    composer4.startReplaceGroup(970499793);
                    ComposerKt.sourceInformation(composer4, "322@11625L11");
                    surfaceVariant2 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getSurfaceVariant();
                    composer4.endReplaceGroup();
                }
                if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                    composer4.startReplaceGroup(970501928);
                    composer4.endReplaceGroup();
                    onSurfaceVariant2 = Color.INSTANCE.m4196getWhite0d7_KjU();
                } else {
                    composer4.startReplaceGroup(970503123);
                    ComposerKt.sourceInformation(composer4, "323@11729L11");
                    onSurfaceVariant2 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                    composer4.endReplaceGroup();
                }
                ButtonColors buttonColorsM1809buttonColorsro_MJ812 = buttonDefaults4.m1809buttonColorsro_MJ88(surfaceVariant2, onSurfaceVariant2, 0L, 0L, composer4, ButtonDefaults.$stable << 12, 12);
                Modifier modifierTestTag6 = TestTagKt.testTag(RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), "custom_quiz_button");
                ComposerKt.sourceInformationMarkerStart(composer4, 970494522, "CC(remember):QuizSandbox.kt#9igjgp");
                objRememberedValue2 = composer4.rememberedValue();
                if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue2 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda15
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$34$lambda$33$lambda$32(isCustomMode$delegate2);
                        }
                    };
                    composer4.updateRememberedValue(objRememberedValue2);
                }
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ButtonKt.Button((Function0) objRememberedValue2, modifierTestTag6, false, null, buttonColorsM1809buttonColorsro_MJ812, null, null, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.getLambda$1461881386$app(), composer4, 805306374, 492);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                composer3.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer3);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                if (!QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                    composer2.startReplaceGroup(2110242095);
                    ComposerKt.sourceInformation(composer2, "339@12150L11,338@12095L86,342@12260L20,346@12403L5263,337@12057L5609");
                    CardKt.Card(ShadowKt.m3823shadows4CzXII$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(4), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(20)), false, 0L, 0L, 28, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(20)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(1545147052, true, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda16
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj4, Object obj5, Object obj6) {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51(currentQuestion2, currentQuestionIndex$delegate, selectedShape$delegate, detectedShape$delegate2, (ColumnScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                        }
                    }, composer2, 54), composer2, ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 8);
                    composer2.endReplaceGroup();
                } else {
                    composer2.startReplaceGroup(2115725871);
                    ComposerKt.sourceInformation(composer2, "486@17803L11,486@17761L62,488@17902L20,490@17979L1185,485@17723L1441");
                    CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(20)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(-1021124683, true, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda17
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj4, Object obj5, Object obj6) {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$55(customQuestionText$delegate2, (ColumnScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                        }
                    }, composer2, 54), composer2, 196614, 8);
                    composer2.endReplaceGroup();
                }
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), composer2, 6);
                Modifier modifierTestTag7 = TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "solve_current_question_button");
                ButtonColors buttonColorsM1809buttonColorsro_MJ813 = ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(ColorKt.getIndigoPrimary(), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14);
                RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_5 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(14));
                ComposerKt.sourceInformationMarkerStart(composer2, 1592320086, "CC(remember):QuizSandbox.kt#9igjgp");
                zChanged = $composer3.changed(currentQuestion2) | $composer3.changedInstance(scope2) | $composer3.changedInstance(preferences) | $composer3.changedInstance(geminiService);
                Object objRememberedValue15 = composer2.rememberedValue();
                if (!zChanged) {
                    answerResult$delegate = answerResult$delegate3;
                    z = true;
                    obj = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda18
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$57$lambda$56(scope2, isAnalyzing$delegate4, isCustomMode$delegate2, customQuestionText$delegate2, currentQuestion2, preferences, geminiService, answerResult$delegate, detectedShape$delegate2);
                        }
                    };
                    currentQuestion = currentQuestion2;
                    isAnalyzing$delegate = isAnalyzing$delegate4;
                    geminiService2 = geminiService;
                    customQuestionText$delegate2 = customQuestionText$delegate2;
                    scope = scope2;
                    appPreferences = preferences;
                    composer2.updateRememberedValue(obj);
                } else {
                    answerResult$delegate = answerResult$delegate3;
                    z = true;
                    obj = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda18
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$57$lambda$56(scope2, isAnalyzing$delegate4, isCustomMode$delegate2, customQuestionText$delegate2, currentQuestion2, preferences, geminiService, answerResult$delegate, detectedShape$delegate2);
                        }
                    };
                    currentQuestion = currentQuestion2;
                    isAnalyzing$delegate = isAnalyzing$delegate4;
                    geminiService2 = geminiService;
                    customQuestionText$delegate2 = customQuestionText$delegate2;
                    scope = scope2;
                    appPreferences = preferences;
                    composer2.updateRememberedValue(obj);
                }
                ComposerKt.sourceInformationMarkerEnd(r1);
                isAnalyzing$delegate2 = isAnalyzing$delegate;
                ButtonKt.Button((Function0) obj, modifierTestTag7, false, roundedCornerShapeM953RoundedCornerShape0680j_5, buttonColorsM1809buttonColorsro_MJ813, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-211234033, z, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda19
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj4, Object obj5, Object obj6) {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$58(isAnalyzing$delegate, (RowScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                    }
                }, composer2, 54), composer2, 805306416, 484);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(80)), composer2, 6);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                switch (WhenMappings.$EnumSwitchMapping$0[r138.ordinal()]) {
                    case 1:
                        topEnd = Alignment.INSTANCE.getTopEnd();
                        break;
                    case 2:
                        topEnd = Alignment.INSTANCE.getTopStart();
                        break;
                    case 3:
                        topEnd = Alignment.INSTANCE.getBottomEnd();
                        break;
                    case 4:
                        topEnd = Alignment.INSTANCE.getBottomStart();
                        break;
                    default:
                        throw new NoWhenBranchMatchedException();
                }
                Alignment alignment2 = topEnd;
                Modifier modifierM670padding3ABfNKs3 = PaddingKt.m670padding3ABfNKs(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(16));
                customQuestionText$delegate = customQuestionText$delegate2;
                ComposerKt.sourceInformationMarkerStart($composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy4 = BoxKt.maybeCachedBoxMeasurePolicy(alignment2, false);
                ComposerKt.sourceInformationMarkerStart($composer3, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer3, 0);
                CompositionLocalMap currentCompositionLocalMap7 = $composer3.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier7 = ComposedModifierKt.materializeModifier($composer3, modifierM670padding3ABfNKs3);
                constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                int i112 = ((((6 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart($composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!($composer3.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                $composer3.startReusableNode();
                if ($composer3.getInserting()) {
                    function2 = constructor2;
                    $composer3.createNode(function2);
                } else {
                    function2 = constructor2;
                    $composer3.useNode();
                }
                composerM3652constructorimpl2 = Updater.m3652constructorimpl($composer3);
                Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyMaybeCachedBoxMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap7, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash7 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl2.getInserting()) {
                }
                composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash7);
                Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier7, ComposeUiNode.INSTANCE.getSetModifier());
                int i113 = (i112 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                BoxScopeInstance boxScopeInstance4 = BoxScopeInstance.INSTANCE;
                int i114 = ((6 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer3, -1033182445, "C566@20669L2570:QuizSandbox.kt#naom5h");
                optionShapeQuizSandbox$lambda$19 = QuizSandbox$lambda$19(detectedShape$delegate2);
                if (optionShapeQuizSandbox$lambda$19 == null) {
                    jColor = androidx.compose.ui.graphics.ColorKt.Color(4283385573L);
                } else {
                    jColor = androidx.compose.ui.graphics.ColorKt.Color(4283385573L);
                }
                long j2 = jColor;
                switch (WhenMappings.$EnumSwitchMapping$0[r138.ordinal()]) {
                    case 1:
                    case 3:
                        end = Alignment.INSTANCE.getEnd();
                        break;
                    case 2:
                    case 4:
                        end = Alignment.INSTANCE.getStart();
                        break;
                    default:
                        throw new NoWhenBranchMatchedException();
                }
                Arrangement.Vertical verticalM550spacedBy0680j_5 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
                composer5 = $composer3;
                ComposerKt.sourceInformationMarkerStart(composer5, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                Modifier modifier7 = Modifier.INSTANCE;
                MeasurePolicy measurePolicyColumnMeasurePolicy3 = ColumnKt.columnMeasurePolicy(verticalM550spacedBy0680j_5, end, composer5, ((48 >> 3) & 14) | ((48 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer5, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer5, 0);
                CompositionLocalMap currentCompositionLocalMap8 = composer5.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier8 = ComposedModifierKt.materializeModifier(composer5, modifier7);
                constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                int i115 = ((((48 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer5, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer5.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer5.startReusableNode();
                if (composer5.getInserting()) {
                    composer5.createNode(constructor3);
                } else {
                    composer5.useNode();
                }
                composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer5);
                Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyColumnMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap8, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash8 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl3.getInserting()) {
                }
                composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash8);
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier8, ComposeUiNode.INSTANCE.getSetModifier());
                int i116 = (i115 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer5, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance3 = ColumnScopeInstance.INSTANCE;
                int i117 = ((48 >> 6) & 112) | 6;
                composer6 = composer5;
                ComposerKt.sourceInformationMarkerStart(composer6, 406854957, "C599@22034L241,587@21553L1338:QuizSandbox.kt#naom5h");
                if (appPreferences.isPopupCardDisabled()) {
                    z2 = false;
                } else {
                    z2 = false;
                }
                if (z2) {
                }
                composer6.startReplaceGroup(385885533);
                composer6.endReplaceGroup();
                Modifier modifierM715size3ABfNKs2 = SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(44));
                if (optionShapeQuizSandbox$lambda$19 != null) {
                    fCoerceIn = 1.0f;
                } else {
                    fCoerceIn = RangesKt.coerceIn(appPreferences.getCornerOpacity(), 0.05f, 1.0f);
                }
                Modifier modifierM225backgroundbw27NRU$default2 = BackgroundKt.m225backgroundbw27NRU$default(ClipKt.clip(ShadowKt.m3823shadows4CzXII$default(AlphaKt.alpha(modifierM715size3ABfNKs2, fCoerceIn), Dp.m6622constructorimpl(8), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)), false, 0L, 0L, 28, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12))), j2, null, 2, null);
                if (optionShapeQuizSandbox$lambda$19 != null) {
                    fM6622constructorimpl = Dp.m6622constructorimpl((float) 2.5d);
                } else {
                    fM6622constructorimpl = Dp.m6622constructorimpl((float) 1.5d);
                }
                Modifier modifierM236borderxT4_qwU2 = BorderKt.m236borderxT4_qwU(modifierM225backgroundbw27NRU$default2, fM6622constructorimpl, Color.INSTANCE.m4196getWhite0d7_KjU(), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)));
                ComposerKt.sourceInformationMarkerStart(composer6, 705889942, "CC(remember):QuizSandbox.kt#9igjgp");
                if (optionShapeQuizSandbox$lambda$19 == null) {
                    iOrdinal = -1;
                } else {
                    iOrdinal = optionShapeQuizSandbox$lambda$19.ordinal();
                }
                zChanged2 = $composer3.changed(iOrdinal) | $composer3.changed(currentQuestion) | $composer3.changedInstance(scope) | $composer3.changedInstance(appPreferences) | $composer3.changedInstance(geminiService2);
                Object objRememberedValue16 = composer6.rememberedValue();
                if (!zChanged2) {
                    final QuizOptionQuestion currentQuestion4 = currentQuestion;
                    isAnalyzing$delegate3 = isAnalyzing$delegate2;
                    $composer2 = $composer3;
                    final AppPreferences appPreferences3 = appPreferences;
                    final GeminiService geminiService4 = geminiService2;
                    optionShape = optionShapeQuizSandbox$lambda$19;
                    final MutableState answerResult$delegate5 = answerResult$delegate;
                    Function0 function5 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda21
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$68$lambda$67$lambda$63$lambda$62(optionShape, detectedShape$delegate2, answerResult$delegate5, scope, isAnalyzing$delegate3, isCustomMode$delegate2, customQuestionText$delegate, currentQuestion4, appPreferences3, geminiService4);
                        }
                    };
                    detectedShape$delegate = detectedShape$delegate2;
                    obj2 = function5;
                    currentQuestion = currentQuestion4;
                    answerResult$delegate2 = answerResult$delegate5;
                    isCustomMode$delegate = isCustomMode$delegate2;
                    composer6.updateRememberedValue(obj2);
                } else {
                    final QuizOptionQuestion currentQuestion5 = currentQuestion;
                    isAnalyzing$delegate3 = isAnalyzing$delegate2;
                    $composer2 = $composer3;
                    final AppPreferences appPreferences4 = appPreferences;
                    final GeminiService geminiService5 = geminiService2;
                    optionShape = optionShapeQuizSandbox$lambda$19;
                    final MutableState answerResult$delegate6 = answerResult$delegate;
                    Function0 function6 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda21
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$68$lambda$67$lambda$63$lambda$62(optionShape, detectedShape$delegate2, answerResult$delegate6, scope, isAnalyzing$delegate3, isCustomMode$delegate2, customQuestionText$delegate, currentQuestion5, appPreferences4, geminiService5);
                        }
                    };
                    detectedShape$delegate = detectedShape$delegate2;
                    obj2 = function6;
                    currentQuestion = currentQuestion5;
                    answerResult$delegate2 = answerResult$delegate6;
                    isCustomMode$delegate = isCustomMode$delegate2;
                    composer6.updateRememberedValue(obj2);
                }
                ComposerKt.sourceInformationMarkerEnd(composer6);
                Modifier modifierTestTag8 = TestTagKt.testTag(ClickableKt.m258clickableXHw0xAI$default(modifierM236borderxT4_qwU2, false, null, null, (Function0) obj2, 7, null), "floating_corner_trigger");
                Alignment center2 = Alignment.INSTANCE.getCenter();
                ComposerKt.sourceInformationMarkerStart(composer6, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy5 = BoxKt.maybeCachedBoxMeasurePolicy(center2, false);
                optionShape2 = optionShape;
                ComposerKt.sourceInformationMarkerStart(composer6, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer6, 0);
                CompositionLocalMap currentCompositionLocalMap9 = composer6.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier9 = ComposedModifierKt.materializeModifier(composer6, modifierTestTag8);
                constructor4 = ComposeUiNode.INSTANCE.getConstructor();
                int i118 = ((((48 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer6, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer6.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer6.startReusableNode();
                if (composer6.getInserting()) {
                    function3 = constructor4;
                    composer6.createNode(function3);
                } else {
                    function3 = constructor4;
                    composer6.useNode();
                }
                composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer6);
                Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyMaybeCachedBoxMeasurePolicy5, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap9, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash9 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl4.getInserting()) {
                }
                composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
                composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash9);
                Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier9, ComposeUiNode.INSTANCE.getSetModifier());
                int i22 = (i118 >> 6) & 14;
                composer7 = composer6;
                ComposerKt.sourceInformationMarkerStart(composer7, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                BoxScopeInstance boxScopeInstance5 = BoxScopeInstance.INSTANCE;
                int i23 = ((48 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer7, -1577986672, "C:QuizSandbox.kt#naom5h");
                if (QuizSandbox$lambda$13(isAnalyzing$delegate3)) {
                    composer7.startReplaceGroup(-1577790629);
                    ComposerKt.sourceInformation(composer7, "618@22611L258");
                    if (optionShape2 != null) {
                        symbol = "✦";
                    } else {
                        symbol = "✦";
                    }
                    String str2 = symbol;
                    if (optionShape2 != null) {
                        i2 = 24;
                    } else {
                        i2 = 18;
                    }
                    TextKt.m2693Text4IGK_g(str2, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(i2), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, TextAlign.m6482boximpl(TextAlign.INSTANCE.m6489getCentere0LSkKk()), 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer7, 196992, 0, 130514);
                    composer7.endReplaceGroup();
                } else {
                    composer7.startReplaceGroup(-1577979326);
                    ComposerKt.sourceInformation(composer7, "612@22424L155");
                    ProgressIndicatorKt.m2367CircularProgressIndicatorLxG7B9w(SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), Color.INSTANCE.m4196getWhite0d7_KjU(), Dp.m6622constructorimpl(2), 0L, 0, composer7, 438, 24);
                    composer7 = composer7;
                    composer7.endReplaceGroup();
                }
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                composer6.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer6);
                ComposerKt.sourceInformationMarkerEnd(composer6);
                ComposerKt.sourceInformationMarkerEnd(composer6);
                if (z2) {
                }
                composer6.startReplaceGroup(385885533);
                composer6.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer6);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                composer5.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer5);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                $composer3.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                $composer3.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
                modifier4 = modifier5;
            } else {
                composer = $composer3;
            }
            composerM3652constructorimpl6.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash6));
            composerM3652constructorimpl6.apply(Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash2);
            Updater.m3659setimpl(composerM3652constructorimpl6, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            int i24 = (i7 >> 6) & 14;
            composer2 = composer;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance4 = ColumnScopeInstance.INSTANCE;
            int i25 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 2106618599, "C231@8220L16,234@8332L11,233@8279L108,238@8483L2208,232@8243L2448,299@10699L41,302@10809L1137,333@11954L41,521@19180L41,529@19459L64,525@19295L23,533@19575L296,524@19269L602,542@19879L41:QuizSandbox.kt#naom5h");
            final State stateCollectAsState2 = SnapshotStateKt.collectAsState(preferences.getApiUsageFlow(), null, composer2, 0, 1);
            CardDefaults cardDefaults2 = CardDefaults.INSTANCE;
            long surfaceVariant4 = MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurfaceVariant();
            CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(16)), cardDefaults2.m1829cardColorsro_MJ88(Color.m4157copywmQWz5c(surfaceVariant4, (14 & 1) != 0 ? Color.m4161getAlphaimpl(surfaceVariant4) : 0.6f, (14 & 2) != 0 ? Color.m4165getRedimpl(surfaceVariant4) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(surfaceVariant4) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(surfaceVariant4) : 0.0f), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, null, ComposableLambdaKt.rememberComposableLambda(-1324086255, true, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj4, Object obj5, Object obj6) {
                    return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$29(stateCollectAsState2, (ColumnScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                }
            }, composer2, 54), composer2, 196614, 24);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
            Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal horizontalM550spacedBy0680j_5 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(horizontalM550spacedBy0680j_5, Alignment.INSTANCE.getTop(), composer2, ((54 >> 3) & 14) | ((54 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap10 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier10 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default2);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i119 = ((((54 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function1 = constructor;
                composer2.createNode(function1);
            } else {
                function1 = constructor;
                composer2.useNode();
            }
            composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap10, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash10 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl.getInserting()) {
                composer3 = composer2;
                if (!Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier10, ComposeUiNode.INSTANCE.getSetModifier());
                int i1110 = (i119 >> 6) & 14;
                composer4 = composer3;
                ComposerKt.sourceInformationMarkerStart(composer4, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                int i1111 = ((54 >> 6) & 112) | 6;
                RowScope rowScope3 = RowScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composer4, 20056789, "C308@11023L240,307@10963L24,306@10935L499,321@11531L238,320@11472L23,319@11444L494:QuizSandbox.kt#naom5h");
                ButtonDefaults buttonDefaults5 = ButtonDefaults.INSTANCE;
                if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                    composer4.startReplaceGroup(970482128);
                    composer4.endReplaceGroup();
                    surfaceVariant = ColorKt.getIndigoPrimary();
                } else {
                    composer4.startReplaceGroup(970483569);
                    ComposerKt.sourceInformation(composer4, "309@11118L11");
                    surfaceVariant = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getSurfaceVariant();
                    composer4.endReplaceGroup();
                }
                if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                    composer4.startReplaceGroup(970485736);
                    composer4.endReplaceGroup();
                    onSurfaceVariant = Color.INSTANCE.m4196getWhite0d7_KjU();
                } else {
                    composer4.startReplaceGroup(970486931);
                    ComposerKt.sourceInformation(composer4, "310@11223L11");
                    onSurfaceVariant = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                    composer4.endReplaceGroup();
                }
                ButtonColors buttonColorsM1809buttonColorsro_MJ814 = buttonDefaults5.m1809buttonColorsro_MJ88(surfaceVariant, onSurfaceVariant, 0L, 0L, composer4, ButtonDefaults.$stable << 12, 12);
                Modifier modifierTestTag9 = TestTagKt.testTag(RowScope.weight$default(rowScope3, Modifier.INSTANCE, 1.0f, false, 2, null), "sample_quiz_button");
                ComposerKt.sourceInformationMarkerStart(composer4, 970478235, "CC(remember):QuizSandbox.kt#9igjgp");
                objRememberedValue = composer4.rememberedValue();
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda14
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$34$lambda$31$lambda$30(isCustomMode$delegate2);
                        }
                    };
                    composer4.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ButtonKt.Button((Function0) objRememberedValue, modifierTestTag9, false, null, buttonColorsM1809buttonColorsro_MJ814, null, null, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.m6943getLambda$2084070797$app(), composer4, 805306374, 492);
                ButtonDefaults buttonDefaults6 = ButtonDefaults.INSTANCE;
                if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                    composer4.startReplaceGroup(970498352);
                    composer4.endReplaceGroup();
                    surfaceVariant2 = ColorKt.getIndigoPrimary();
                } else {
                    composer4.startReplaceGroup(970499793);
                    ComposerKt.sourceInformation(composer4, "322@11625L11");
                    surfaceVariant2 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getSurfaceVariant();
                    composer4.endReplaceGroup();
                }
                if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                    composer4.startReplaceGroup(970501928);
                    composer4.endReplaceGroup();
                    onSurfaceVariant2 = Color.INSTANCE.m4196getWhite0d7_KjU();
                } else {
                    composer4.startReplaceGroup(970503123);
                    ComposerKt.sourceInformation(composer4, "323@11729L11");
                    onSurfaceVariant2 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                    composer4.endReplaceGroup();
                }
                ButtonColors buttonColorsM1809buttonColorsro_MJ815 = buttonDefaults6.m1809buttonColorsro_MJ88(surfaceVariant2, onSurfaceVariant2, 0L, 0L, composer4, ButtonDefaults.$stable << 12, 12);
                Modifier modifierTestTag10 = TestTagKt.testTag(RowScope.weight$default(rowScope3, Modifier.INSTANCE, 1.0f, false, 2, null), "custom_quiz_button");
                ComposerKt.sourceInformationMarkerStart(composer4, 970494522, "CC(remember):QuizSandbox.kt#9igjgp");
                objRememberedValue2 = composer4.rememberedValue();
                if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue2 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda15
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$34$lambda$33$lambda$32(isCustomMode$delegate2);
                        }
                    };
                    composer4.updateRememberedValue(objRememberedValue2);
                }
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ButtonKt.Button((Function0) objRememberedValue2, modifierTestTag10, false, null, buttonColorsM1809buttonColorsro_MJ815, null, null, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.getLambda$1461881386$app(), composer4, 805306374, 492);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                composer3.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer3);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                if (!QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                    composer2.startReplaceGroup(2110242095);
                    ComposerKt.sourceInformation(composer2, "339@12150L11,338@12095L86,342@12260L20,346@12403L5263,337@12057L5609");
                    CardKt.Card(ShadowKt.m3823shadows4CzXII$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(4), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(20)), false, 0L, 0L, 28, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(20)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(1545147052, true, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda16
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj4, Object obj5, Object obj6) {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51(currentQuestion2, currentQuestionIndex$delegate, selectedShape$delegate, detectedShape$delegate2, (ColumnScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                        }
                    }, composer2, 54), composer2, ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 8);
                    composer2.endReplaceGroup();
                } else {
                    composer2.startReplaceGroup(2115725871);
                    ComposerKt.sourceInformation(composer2, "486@17803L11,486@17761L62,488@17902L20,490@17979L1185,485@17723L1441");
                    CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(20)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(-1021124683, true, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda17
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj4, Object obj5, Object obj6) {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$55(customQuestionText$delegate2, (ColumnScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                        }
                    }, composer2, 54), composer2, 196614, 8);
                    composer2.endReplaceGroup();
                }
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), composer2, 6);
                Modifier modifierTestTag11 = TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "solve_current_question_button");
                ButtonColors buttonColorsM1809buttonColorsro_MJ816 = ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(ColorKt.getIndigoPrimary(), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14);
                RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_6 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(14));
                ComposerKt.sourceInformationMarkerStart(composer2, 1592320086, "CC(remember):QuizSandbox.kt#9igjgp");
                zChanged = $composer3.changed(currentQuestion2) | $composer3.changedInstance(scope2) | $composer3.changedInstance(preferences) | $composer3.changedInstance(geminiService);
                Object objRememberedValue17 = composer2.rememberedValue();
                if (!zChanged) {
                    answerResult$delegate = answerResult$delegate3;
                    z = true;
                    obj = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda18
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$57$lambda$56(scope2, isAnalyzing$delegate4, isCustomMode$delegate2, customQuestionText$delegate2, currentQuestion2, preferences, geminiService, answerResult$delegate, detectedShape$delegate2);
                        }
                    };
                    currentQuestion = currentQuestion2;
                    isAnalyzing$delegate = isAnalyzing$delegate4;
                    geminiService2 = geminiService;
                    customQuestionText$delegate2 = customQuestionText$delegate2;
                    scope = scope2;
                    appPreferences = preferences;
                    composer2.updateRememberedValue(obj);
                } else {
                    answerResult$delegate = answerResult$delegate3;
                    z = true;
                    obj = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda18
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$57$lambda$56(scope2, isAnalyzing$delegate4, isCustomMode$delegate2, customQuestionText$delegate2, currentQuestion2, preferences, geminiService, answerResult$delegate, detectedShape$delegate2);
                        }
                    };
                    currentQuestion = currentQuestion2;
                    isAnalyzing$delegate = isAnalyzing$delegate4;
                    geminiService2 = geminiService;
                    customQuestionText$delegate2 = customQuestionText$delegate2;
                    scope = scope2;
                    appPreferences = preferences;
                    composer2.updateRememberedValue(obj);
                }
                ComposerKt.sourceInformationMarkerEnd(r1);
                isAnalyzing$delegate2 = isAnalyzing$delegate;
                ButtonKt.Button((Function0) obj, modifierTestTag11, false, roundedCornerShapeM953RoundedCornerShape0680j_6, buttonColorsM1809buttonColorsro_MJ816, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-211234033, z, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda19
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj4, Object obj5, Object obj6) {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$58(isAnalyzing$delegate, (RowScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                    }
                }, composer2, 54), composer2, 805306416, 484);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(80)), composer2, 6);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                switch (WhenMappings.$EnumSwitchMapping$0[r138.ordinal()]) {
                    case 1:
                        topEnd = Alignment.INSTANCE.getTopEnd();
                        break;
                    case 2:
                        topEnd = Alignment.INSTANCE.getTopStart();
                        break;
                    case 3:
                        topEnd = Alignment.INSTANCE.getBottomEnd();
                        break;
                    case 4:
                        topEnd = Alignment.INSTANCE.getBottomStart();
                        break;
                    default:
                        throw new NoWhenBranchMatchedException();
                }
                Alignment alignment3 = topEnd;
                Modifier modifierM670padding3ABfNKs4 = PaddingKt.m670padding3ABfNKs(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(16));
                customQuestionText$delegate = customQuestionText$delegate2;
                ComposerKt.sourceInformationMarkerStart($composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy6 = BoxKt.maybeCachedBoxMeasurePolicy(alignment3, false);
                ComposerKt.sourceInformationMarkerStart($composer3, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer3, 0);
                CompositionLocalMap currentCompositionLocalMap11 = $composer3.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier11 = ComposedModifierKt.materializeModifier($composer3, modifierM670padding3ABfNKs4);
                constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                int i1112 = ((((6 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart($composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!($composer3.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                $composer3.startReusableNode();
                if ($composer3.getInserting()) {
                    function2 = constructor2;
                    $composer3.createNode(function2);
                } else {
                    function2 = constructor2;
                    $composer3.useNode();
                }
                composerM3652constructorimpl2 = Updater.m3652constructorimpl($composer3);
                Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyMaybeCachedBoxMeasurePolicy6, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap11, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash11 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl2.getInserting()) {
                }
                composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash11);
                Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier11, ComposeUiNode.INSTANCE.getSetModifier());
                int i1113 = (i1112 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                BoxScopeInstance boxScopeInstance6 = BoxScopeInstance.INSTANCE;
                int i1114 = ((6 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer3, -1033182445, "C566@20669L2570:QuizSandbox.kt#naom5h");
                optionShapeQuizSandbox$lambda$19 = QuizSandbox$lambda$19(detectedShape$delegate2);
                if (optionShapeQuizSandbox$lambda$19 == null) {
                    jColor = androidx.compose.ui.graphics.ColorKt.Color(4283385573L);
                } else {
                    jColor = androidx.compose.ui.graphics.ColorKt.Color(4283385573L);
                }
                long j3 = jColor;
                switch (WhenMappings.$EnumSwitchMapping$0[r138.ordinal()]) {
                    case 1:
                    case 3:
                        end = Alignment.INSTANCE.getEnd();
                        break;
                    case 2:
                    case 4:
                        end = Alignment.INSTANCE.getStart();
                        break;
                    default:
                        throw new NoWhenBranchMatchedException();
                }
                Arrangement.Vertical verticalM550spacedBy0680j_6 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
                composer5 = $composer3;
                ComposerKt.sourceInformationMarkerStart(composer5, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                Modifier modifier8 = Modifier.INSTANCE;
                MeasurePolicy measurePolicyColumnMeasurePolicy4 = ColumnKt.columnMeasurePolicy(verticalM550spacedBy0680j_6, end, composer5, ((48 >> 3) & 14) | ((48 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer5, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer5, 0);
                CompositionLocalMap currentCompositionLocalMap12 = composer5.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier12 = ComposedModifierKt.materializeModifier(composer5, modifier8);
                constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                int i1115 = ((((48 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer5, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer5.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer5.startReusableNode();
                if (composer5.getInserting()) {
                    composer5.createNode(constructor3);
                } else {
                    composer5.useNode();
                }
                composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer5);
                Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyColumnMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap12, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash12 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl3.getInserting()) {
                }
                composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash12);
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier12, ComposeUiNode.INSTANCE.getSetModifier());
                int i1116 = (i1115 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer5, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance5 = ColumnScopeInstance.INSTANCE;
                int i1117 = ((48 >> 6) & 112) | 6;
                composer6 = composer5;
                ComposerKt.sourceInformationMarkerStart(composer6, 406854957, "C599@22034L241,587@21553L1338:QuizSandbox.kt#naom5h");
                if (appPreferences.isPopupCardDisabled()) {
                    z2 = false;
                } else {
                    z2 = false;
                }
                if (z2) {
                }
                composer6.startReplaceGroup(385885533);
                composer6.endReplaceGroup();
                Modifier modifierM715size3ABfNKs3 = SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(44));
                if (optionShapeQuizSandbox$lambda$19 != null) {
                    fCoerceIn = 1.0f;
                } else {
                    fCoerceIn = RangesKt.coerceIn(appPreferences.getCornerOpacity(), 0.05f, 1.0f);
                }
                Modifier modifierM225backgroundbw27NRU$default3 = BackgroundKt.m225backgroundbw27NRU$default(ClipKt.clip(ShadowKt.m3823shadows4CzXII$default(AlphaKt.alpha(modifierM715size3ABfNKs3, fCoerceIn), Dp.m6622constructorimpl(8), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)), false, 0L, 0L, 28, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12))), j3, null, 2, null);
                if (optionShapeQuizSandbox$lambda$19 != null) {
                    fM6622constructorimpl = Dp.m6622constructorimpl((float) 2.5d);
                } else {
                    fM6622constructorimpl = Dp.m6622constructorimpl((float) 1.5d);
                }
                Modifier modifierM236borderxT4_qwU3 = BorderKt.m236borderxT4_qwU(modifierM225backgroundbw27NRU$default3, fM6622constructorimpl, Color.INSTANCE.m4196getWhite0d7_KjU(), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)));
                ComposerKt.sourceInformationMarkerStart(composer6, 705889942, "CC(remember):QuizSandbox.kt#9igjgp");
                if (optionShapeQuizSandbox$lambda$19 == null) {
                    iOrdinal = -1;
                } else {
                    iOrdinal = optionShapeQuizSandbox$lambda$19.ordinal();
                }
                zChanged2 = $composer3.changed(iOrdinal) | $composer3.changed(currentQuestion) | $composer3.changedInstance(scope) | $composer3.changedInstance(appPreferences) | $composer3.changedInstance(geminiService2);
                Object objRememberedValue18 = composer6.rememberedValue();
                if (!zChanged2) {
                    final QuizOptionQuestion currentQuestion6 = currentQuestion;
                    isAnalyzing$delegate3 = isAnalyzing$delegate2;
                    $composer2 = $composer3;
                    final AppPreferences appPreferences5 = appPreferences;
                    final GeminiService geminiService6 = geminiService2;
                    optionShape = optionShapeQuizSandbox$lambda$19;
                    final MutableState answerResult$delegate7 = answerResult$delegate;
                    Function0 function7 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda21
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$68$lambda$67$lambda$63$lambda$62(optionShape, detectedShape$delegate2, answerResult$delegate7, scope, isAnalyzing$delegate3, isCustomMode$delegate2, customQuestionText$delegate, currentQuestion6, appPreferences5, geminiService6);
                        }
                    };
                    detectedShape$delegate = detectedShape$delegate2;
                    obj2 = function7;
                    currentQuestion = currentQuestion6;
                    answerResult$delegate2 = answerResult$delegate7;
                    isCustomMode$delegate = isCustomMode$delegate2;
                    composer6.updateRememberedValue(obj2);
                } else {
                    final QuizOptionQuestion currentQuestion7 = currentQuestion;
                    isAnalyzing$delegate3 = isAnalyzing$delegate2;
                    $composer2 = $composer3;
                    final AppPreferences appPreferences6 = appPreferences;
                    final GeminiService geminiService7 = geminiService2;
                    optionShape = optionShapeQuizSandbox$lambda$19;
                    final MutableState answerResult$delegate8 = answerResult$delegate;
                    Function0 function8 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda21
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$68$lambda$67$lambda$63$lambda$62(optionShape, detectedShape$delegate2, answerResult$delegate8, scope, isAnalyzing$delegate3, isCustomMode$delegate2, customQuestionText$delegate, currentQuestion7, appPreferences6, geminiService7);
                        }
                    };
                    detectedShape$delegate = detectedShape$delegate2;
                    obj2 = function8;
                    currentQuestion = currentQuestion7;
                    answerResult$delegate2 = answerResult$delegate8;
                    isCustomMode$delegate = isCustomMode$delegate2;
                    composer6.updateRememberedValue(obj2);
                }
                ComposerKt.sourceInformationMarkerEnd(composer6);
                Modifier modifierTestTag12 = TestTagKt.testTag(ClickableKt.m258clickableXHw0xAI$default(modifierM236borderxT4_qwU3, false, null, null, (Function0) obj2, 7, null), "floating_corner_trigger");
                Alignment center3 = Alignment.INSTANCE.getCenter();
                ComposerKt.sourceInformationMarkerStart(composer6, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy7 = BoxKt.maybeCachedBoxMeasurePolicy(center3, false);
                optionShape2 = optionShape;
                ComposerKt.sourceInformationMarkerStart(composer6, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer6, 0);
                CompositionLocalMap currentCompositionLocalMap13 = composer6.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier13 = ComposedModifierKt.materializeModifier(composer6, modifierTestTag12);
                constructor4 = ComposeUiNode.INSTANCE.getConstructor();
                int i1118 = ((((48 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer6, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer6.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer6.startReusableNode();
                if (composer6.getInserting()) {
                    function3 = constructor4;
                    composer6.createNode(function3);
                } else {
                    function3 = constructor4;
                    composer6.useNode();
                }
                composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer6);
                Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyMaybeCachedBoxMeasurePolicy7, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap13, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash13 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl4.getInserting()) {
                }
                composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
                composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash13);
                Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier13, ComposeUiNode.INSTANCE.getSetModifier());
                int i26 = (i1118 >> 6) & 14;
                composer7 = composer6;
                ComposerKt.sourceInformationMarkerStart(composer7, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                BoxScopeInstance boxScopeInstance7 = BoxScopeInstance.INSTANCE;
                int i27 = ((48 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer7, -1577986672, "C:QuizSandbox.kt#naom5h");
                if (QuizSandbox$lambda$13(isAnalyzing$delegate3)) {
                    composer7.startReplaceGroup(-1577790629);
                    ComposerKt.sourceInformation(composer7, "618@22611L258");
                    if (optionShape2 != null) {
                        symbol = "✦";
                    } else {
                        symbol = "✦";
                    }
                    String str3 = symbol;
                    if (optionShape2 != null) {
                        i2 = 24;
                    } else {
                        i2 = 18;
                    }
                    TextKt.m2693Text4IGK_g(str3, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(i2), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, TextAlign.m6482boximpl(TextAlign.INSTANCE.m6489getCentere0LSkKk()), 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer7, 196992, 0, 130514);
                    composer7.endReplaceGroup();
                } else {
                    composer7.startReplaceGroup(-1577979326);
                    ComposerKt.sourceInformation(composer7, "612@22424L155");
                    ProgressIndicatorKt.m2367CircularProgressIndicatorLxG7B9w(SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), Color.INSTANCE.m4196getWhite0d7_KjU(), Dp.m6622constructorimpl(2), 0L, 0, composer7, 438, 24);
                    composer7 = composer7;
                    composer7.endReplaceGroup();
                }
                ComposerKt.sourceInformationMarkerEnd(composer7);
                ComposerKt.sourceInformationMarkerEnd(composer7);
                composer6.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer6);
                ComposerKt.sourceInformationMarkerEnd(composer6);
                ComposerKt.sourceInformationMarkerEnd(composer6);
                if (z2) {
                }
                composer6.startReplaceGroup(385885533);
                composer6.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer6);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                composer5.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer5);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                $composer3.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                $composer3.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                ComposerKt.sourceInformationMarkerEnd($composer3);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
                modifier4 = modifier5;
            } else {
                composer3 = composer2;
            }
            composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash10);
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier10, ComposeUiNode.INSTANCE.getSetModifier());
            int i1119 = (i119 >> 6) & 14;
            composer4 = composer3;
            ComposerKt.sourceInformationMarkerStart(composer4, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            int i11110 = ((54 >> 6) & 112) | 6;
            RowScope rowScope4 = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer4, 20056789, "C308@11023L240,307@10963L24,306@10935L499,321@11531L238,320@11472L23,319@11444L494:QuizSandbox.kt#naom5h");
            ButtonDefaults buttonDefaults7 = ButtonDefaults.INSTANCE;
            if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                composer4.startReplaceGroup(970482128);
                composer4.endReplaceGroup();
                surfaceVariant = ColorKt.getIndigoPrimary();
            } else {
                composer4.startReplaceGroup(970483569);
                ComposerKt.sourceInformation(composer4, "309@11118L11");
                surfaceVariant = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getSurfaceVariant();
                composer4.endReplaceGroup();
            }
            if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                composer4.startReplaceGroup(970485736);
                composer4.endReplaceGroup();
                onSurfaceVariant = Color.INSTANCE.m4196getWhite0d7_KjU();
            } else {
                composer4.startReplaceGroup(970486931);
                ComposerKt.sourceInformation(composer4, "310@11223L11");
                onSurfaceVariant = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                composer4.endReplaceGroup();
            }
            ButtonColors buttonColorsM1809buttonColorsro_MJ817 = buttonDefaults7.m1809buttonColorsro_MJ88(surfaceVariant, onSurfaceVariant, 0L, 0L, composer4, ButtonDefaults.$stable << 12, 12);
            Modifier modifierTestTag13 = TestTagKt.testTag(RowScope.weight$default(rowScope4, Modifier.INSTANCE, 1.0f, false, 2, null), "sample_quiz_button");
            ComposerKt.sourceInformationMarkerStart(composer4, 970478235, "CC(remember):QuizSandbox.kt#9igjgp");
            objRememberedValue = composer4.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda14
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$34$lambda$31$lambda$30(isCustomMode$delegate2);
                    }
                };
                composer4.updateRememberedValue(objRememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(composer4);
            ButtonKt.Button((Function0) objRememberedValue, modifierTestTag13, false, null, buttonColorsM1809buttonColorsro_MJ817, null, null, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.m6943getLambda$2084070797$app(), composer4, 805306374, 492);
            ButtonDefaults buttonDefaults8 = ButtonDefaults.INSTANCE;
            if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                composer4.startReplaceGroup(970498352);
                composer4.endReplaceGroup();
                surfaceVariant2 = ColorKt.getIndigoPrimary();
            } else {
                composer4.startReplaceGroup(970499793);
                ComposerKt.sourceInformation(composer4, "322@11625L11");
                surfaceVariant2 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getSurfaceVariant();
                composer4.endReplaceGroup();
            }
            if (QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                composer4.startReplaceGroup(970501928);
                composer4.endReplaceGroup();
                onSurfaceVariant2 = Color.INSTANCE.m4196getWhite0d7_KjU();
            } else {
                composer4.startReplaceGroup(970503123);
                ComposerKt.sourceInformation(composer4, "323@11729L11");
                onSurfaceVariant2 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                composer4.endReplaceGroup();
            }
            ButtonColors buttonColorsM1809buttonColorsro_MJ818 = buttonDefaults8.m1809buttonColorsro_MJ88(surfaceVariant2, onSurfaceVariant2, 0L, 0L, composer4, ButtonDefaults.$stable << 12, 12);
            Modifier modifierTestTag14 = TestTagKt.testTag(RowScope.weight$default(rowScope4, Modifier.INSTANCE, 1.0f, false, 2, null), "custom_quiz_button");
            ComposerKt.sourceInformationMarkerStart(composer4, 970494522, "CC(remember):QuizSandbox.kt#9igjgp");
            objRememberedValue2 = composer4.rememberedValue();
            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                objRememberedValue2 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda15
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$34$lambda$33$lambda$32(isCustomMode$delegate2);
                    }
                };
                composer4.updateRememberedValue(objRememberedValue2);
            }
            ComposerKt.sourceInformationMarkerEnd(composer4);
            ButtonKt.Button((Function0) objRememberedValue2, modifierTestTag14, false, null, buttonColorsM1809buttonColorsro_MJ818, null, null, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.getLambda$1461881386$app(), composer4, 805306374, 492);
            ComposerKt.sourceInformationMarkerEnd(composer4);
            ComposerKt.sourceInformationMarkerEnd(composer4);
            composer3.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer3);
            ComposerKt.sourceInformationMarkerEnd(composer3);
            ComposerKt.sourceInformationMarkerEnd(composer3);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
            if (!QuizSandbox$lambda$10(isCustomMode$delegate2)) {
                composer2.startReplaceGroup(2110242095);
                ComposerKt.sourceInformation(composer2, "339@12150L11,338@12095L86,342@12260L20,346@12403L5263,337@12057L5609");
                CardKt.Card(ShadowKt.m3823shadows4CzXII$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(4), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(20)), false, 0L, 0L, 28, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(20)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(1545147052, true, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda16
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj4, Object obj5, Object obj6) {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51(currentQuestion2, currentQuestionIndex$delegate, selectedShape$delegate, detectedShape$delegate2, (ColumnScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                    }
                }, composer2, 54), composer2, ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 8);
                composer2.endReplaceGroup();
            } else {
                composer2.startReplaceGroup(2115725871);
                ComposerKt.sourceInformation(composer2, "486@17803L11,486@17761L62,488@17902L20,490@17979L1185,485@17723L1441");
                CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(20)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(-1021124683, true, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda17
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj4, Object obj5, Object obj6) {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$55(customQuestionText$delegate2, (ColumnScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                    }
                }, composer2, 54), composer2, 196614, 8);
                composer2.endReplaceGroup();
            }
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), composer2, 6);
            Modifier modifierTestTag15 = TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "solve_current_question_button");
            ButtonColors buttonColorsM1809buttonColorsro_MJ819 = ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(ColorKt.getIndigoPrimary(), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14);
            RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_7 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(14));
            ComposerKt.sourceInformationMarkerStart(composer2, 1592320086, "CC(remember):QuizSandbox.kt#9igjgp");
            zChanged = $composer3.changed(currentQuestion2) | $composer3.changedInstance(scope2) | $composer3.changedInstance(preferences) | $composer3.changedInstance(geminiService);
            Object objRememberedValue19 = composer2.rememberedValue();
            if (!zChanged) {
                answerResult$delegate = answerResult$delegate3;
                z = true;
                obj = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda18
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$57$lambda$56(scope2, isAnalyzing$delegate4, isCustomMode$delegate2, customQuestionText$delegate2, currentQuestion2, preferences, geminiService, answerResult$delegate, detectedShape$delegate2);
                    }
                };
                currentQuestion = currentQuestion2;
                isAnalyzing$delegate = isAnalyzing$delegate4;
                geminiService2 = geminiService;
                customQuestionText$delegate2 = customQuestionText$delegate2;
                scope = scope2;
                appPreferences = preferences;
                composer2.updateRememberedValue(obj);
            } else {
                answerResult$delegate = answerResult$delegate3;
                z = true;
                obj = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda18
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$57$lambda$56(scope2, isAnalyzing$delegate4, isCustomMode$delegate2, customQuestionText$delegate2, currentQuestion2, preferences, geminiService, answerResult$delegate, detectedShape$delegate2);
                    }
                };
                currentQuestion = currentQuestion2;
                isAnalyzing$delegate = isAnalyzing$delegate4;
                geminiService2 = geminiService;
                customQuestionText$delegate2 = customQuestionText$delegate2;
                scope = scope2;
                appPreferences = preferences;
                composer2.updateRememberedValue(obj);
            }
            ComposerKt.sourceInformationMarkerEnd(r1);
            isAnalyzing$delegate2 = isAnalyzing$delegate;
            ButtonKt.Button((Function0) obj, modifierTestTag15, false, roundedCornerShapeM953RoundedCornerShape0680j_7, buttonColorsM1809buttonColorsro_MJ819, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-211234033, z, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda19
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj4, Object obj5, Object obj6) {
                    return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$58(isAnalyzing$delegate, (RowScope) obj4, (Composer) obj5, ((Integer) obj6).intValue());
                }
            }, composer2, 54), composer2, 805306416, 484);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(80)), composer2, 6);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            switch (WhenMappings.$EnumSwitchMapping$0[r138.ordinal()]) {
                case 1:
                    topEnd = Alignment.INSTANCE.getTopEnd();
                    break;
                case 2:
                    topEnd = Alignment.INSTANCE.getTopStart();
                    break;
                case 3:
                    topEnd = Alignment.INSTANCE.getBottomEnd();
                    break;
                case 4:
                    topEnd = Alignment.INSTANCE.getBottomStart();
                    break;
                default:
                    throw new NoWhenBranchMatchedException();
            }
            Alignment alignment4 = topEnd;
            Modifier modifierM670padding3ABfNKs5 = PaddingKt.m670padding3ABfNKs(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(16));
            customQuestionText$delegate = customQuestionText$delegate2;
            ComposerKt.sourceInformationMarkerStart($composer3, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy8 = BoxKt.maybeCachedBoxMeasurePolicy(alignment4, false);
            ComposerKt.sourceInformationMarkerStart($composer3, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer3, 0);
            CompositionLocalMap currentCompositionLocalMap14 = $composer3.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier14 = ComposedModifierKt.materializeModifier($composer3, modifierM670padding3ABfNKs5);
            constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i11111 = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer3, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer3.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer3.startReusableNode();
            if ($composer3.getInserting()) {
                function2 = constructor2;
                $composer3.createNode(function2);
            } else {
                function2 = constructor2;
                $composer3.useNode();
            }
            composerM3652constructorimpl2 = Updater.m3652constructorimpl($composer3);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyMaybeCachedBoxMeasurePolicy8, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap14, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash14 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl2.getInserting()) {
            }
            composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash14);
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier14, ComposeUiNode.INSTANCE.getSetModifier());
            int i11112 = (i11111 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer3, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
            BoxScopeInstance boxScopeInstance8 = BoxScopeInstance.INSTANCE;
            int i11113 = ((6 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer3, -1033182445, "C566@20669L2570:QuizSandbox.kt#naom5h");
            optionShapeQuizSandbox$lambda$19 = QuizSandbox$lambda$19(detectedShape$delegate2);
            if (optionShapeQuizSandbox$lambda$19 == null) {
                jColor = androidx.compose.ui.graphics.ColorKt.Color(4283385573L);
            } else {
                jColor = androidx.compose.ui.graphics.ColorKt.Color(4283385573L);
            }
            long j4 = jColor;
            switch (WhenMappings.$EnumSwitchMapping$0[r138.ordinal()]) {
                case 1:
                case 3:
                    end = Alignment.INSTANCE.getEnd();
                    break;
                case 2:
                case 4:
                    end = Alignment.INSTANCE.getStart();
                    break;
                default:
                    throw new NoWhenBranchMatchedException();
            }
            Arrangement.Vertical verticalM550spacedBy0680j_7 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
            composer5 = $composer3;
            ComposerKt.sourceInformationMarkerStart(composer5, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            Modifier modifier9 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyColumnMeasurePolicy5 = ColumnKt.columnMeasurePolicy(verticalM550spacedBy0680j_7, end, composer5, ((48 >> 3) & 14) | ((48 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer5, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer5, 0);
            CompositionLocalMap currentCompositionLocalMap15 = composer5.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier15 = ComposedModifierKt.materializeModifier(composer5, modifier9);
            constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            int i11114 = ((((48 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer5, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer5.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer5.startReusableNode();
            if (composer5.getInserting()) {
                composer5.createNode(constructor3);
            } else {
                composer5.useNode();
            }
            composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer5);
            Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyColumnMeasurePolicy5, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap15, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash15 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl3.getInserting()) {
            }
            composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
            composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash15);
            Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier15, ComposeUiNode.INSTANCE.getSetModifier());
            int i11115 = (i11114 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer5, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance6 = ColumnScopeInstance.INSTANCE;
            int i11116 = ((48 >> 6) & 112) | 6;
            composer6 = composer5;
            ComposerKt.sourceInformationMarkerStart(composer6, 406854957, "C599@22034L241,587@21553L1338:QuizSandbox.kt#naom5h");
            if (appPreferences.isPopupCardDisabled()) {
                z2 = false;
            } else {
                z2 = false;
            }
            if (z2) {
            }
            composer6.startReplaceGroup(385885533);
            composer6.endReplaceGroup();
            Modifier modifierM715size3ABfNKs4 = SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(44));
            if (optionShapeQuizSandbox$lambda$19 != null) {
                fCoerceIn = 1.0f;
            } else {
                fCoerceIn = RangesKt.coerceIn(appPreferences.getCornerOpacity(), 0.05f, 1.0f);
            }
            Modifier modifierM225backgroundbw27NRU$default4 = BackgroundKt.m225backgroundbw27NRU$default(ClipKt.clip(ShadowKt.m3823shadows4CzXII$default(AlphaKt.alpha(modifierM715size3ABfNKs4, fCoerceIn), Dp.m6622constructorimpl(8), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)), false, 0L, 0L, 28, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12))), j4, null, 2, null);
            if (optionShapeQuizSandbox$lambda$19 != null) {
                fM6622constructorimpl = Dp.m6622constructorimpl((float) 2.5d);
            } else {
                fM6622constructorimpl = Dp.m6622constructorimpl((float) 1.5d);
            }
            Modifier modifierM236borderxT4_qwU4 = BorderKt.m236borderxT4_qwU(modifierM225backgroundbw27NRU$default4, fM6622constructorimpl, Color.INSTANCE.m4196getWhite0d7_KjU(), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)));
            ComposerKt.sourceInformationMarkerStart(composer6, 705889942, "CC(remember):QuizSandbox.kt#9igjgp");
            if (optionShapeQuizSandbox$lambda$19 == null) {
                iOrdinal = -1;
            } else {
                iOrdinal = optionShapeQuizSandbox$lambda$19.ordinal();
            }
            zChanged2 = $composer3.changed(iOrdinal) | $composer3.changed(currentQuestion) | $composer3.changedInstance(scope) | $composer3.changedInstance(appPreferences) | $composer3.changedInstance(geminiService2);
            Object objRememberedValue110 = composer6.rememberedValue();
            if (!zChanged2) {
                final QuizOptionQuestion currentQuestion8 = currentQuestion;
                isAnalyzing$delegate3 = isAnalyzing$delegate2;
                $composer2 = $composer3;
                final AppPreferences appPreferences7 = appPreferences;
                final GeminiService geminiService8 = geminiService2;
                optionShape = optionShapeQuizSandbox$lambda$19;
                final MutableState answerResult$delegate9 = answerResult$delegate;
                Function0 function9 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda21
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$68$lambda$67$lambda$63$lambda$62(optionShape, detectedShape$delegate2, answerResult$delegate9, scope, isAnalyzing$delegate3, isCustomMode$delegate2, customQuestionText$delegate, currentQuestion8, appPreferences7, geminiService8);
                    }
                };
                detectedShape$delegate = detectedShape$delegate2;
                obj2 = function9;
                currentQuestion = currentQuestion8;
                answerResult$delegate2 = answerResult$delegate9;
                isCustomMode$delegate = isCustomMode$delegate2;
                composer6.updateRememberedValue(obj2);
            } else {
                final QuizOptionQuestion currentQuestion9 = currentQuestion;
                isAnalyzing$delegate3 = isAnalyzing$delegate2;
                $composer2 = $composer3;
                final AppPreferences appPreferences8 = appPreferences;
                final GeminiService geminiService9 = geminiService2;
                optionShape = optionShapeQuizSandbox$lambda$19;
                final MutableState answerResult$delegate10 = answerResult$delegate;
                Function0 function10 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda21
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$68$lambda$67$lambda$63$lambda$62(optionShape, detectedShape$delegate2, answerResult$delegate10, scope, isAnalyzing$delegate3, isCustomMode$delegate2, customQuestionText$delegate, currentQuestion9, appPreferences8, geminiService9);
                    }
                };
                detectedShape$delegate = detectedShape$delegate2;
                obj2 = function10;
                currentQuestion = currentQuestion9;
                answerResult$delegate2 = answerResult$delegate10;
                isCustomMode$delegate = isCustomMode$delegate2;
                composer6.updateRememberedValue(obj2);
            }
            ComposerKt.sourceInformationMarkerEnd(composer6);
            Modifier modifierTestTag16 = TestTagKt.testTag(ClickableKt.m258clickableXHw0xAI$default(modifierM236borderxT4_qwU4, false, null, null, (Function0) obj2, 7, null), "floating_corner_trigger");
            Alignment center4 = Alignment.INSTANCE.getCenter();
            ComposerKt.sourceInformationMarkerStart(composer6, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy9 = BoxKt.maybeCachedBoxMeasurePolicy(center4, false);
            optionShape2 = optionShape;
            ComposerKt.sourceInformationMarkerStart(composer6, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer6, 0);
            CompositionLocalMap currentCompositionLocalMap16 = composer6.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier16 = ComposedModifierKt.materializeModifier(composer6, modifierTestTag16);
            constructor4 = ComposeUiNode.INSTANCE.getConstructor();
            int i11117 = ((((48 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer6, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer6.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer6.startReusableNode();
            if (composer6.getInserting()) {
                function3 = constructor4;
                composer6.createNode(function3);
            } else {
                function3 = constructor4;
                composer6.useNode();
            }
            composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer6);
            Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyMaybeCachedBoxMeasurePolicy9, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap16, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash16 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl4.getInserting()) {
            }
            composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
            composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash16);
            Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier16, ComposeUiNode.INSTANCE.getSetModifier());
            int i28 = (i11117 >> 6) & 14;
            composer7 = composer6;
            ComposerKt.sourceInformationMarkerStart(composer7, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
            BoxScopeInstance boxScopeInstance9 = BoxScopeInstance.INSTANCE;
            int i29 = ((48 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer7, -1577986672, "C:QuizSandbox.kt#naom5h");
            if (QuizSandbox$lambda$13(isAnalyzing$delegate3)) {
                composer7.startReplaceGroup(-1577790629);
                ComposerKt.sourceInformation(composer7, "618@22611L258");
                if (optionShape2 != null) {
                    symbol = "✦";
                } else {
                    symbol = "✦";
                }
                String str4 = symbol;
                if (optionShape2 != null) {
                    i2 = 24;
                } else {
                    i2 = 18;
                }
                TextKt.m2693Text4IGK_g(str4, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(i2), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, TextAlign.m6482boximpl(TextAlign.INSTANCE.m6489getCentere0LSkKk()), 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer7, 196992, 0, 130514);
                composer7.endReplaceGroup();
            } else {
                composer7.startReplaceGroup(-1577979326);
                ComposerKt.sourceInformation(composer7, "612@22424L155");
                ProgressIndicatorKt.m2367CircularProgressIndicatorLxG7B9w(SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), Color.INSTANCE.m4196getWhite0d7_KjU(), Dp.m6622constructorimpl(2), 0L, 0, composer7, 438, 24);
                composer7 = composer7;
                composer7.endReplaceGroup();
            }
            ComposerKt.sourceInformationMarkerEnd(composer7);
            ComposerKt.sourceInformationMarkerEnd(composer7);
            composer6.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer6);
            ComposerKt.sourceInformationMarkerEnd(composer6);
            ComposerKt.sourceInformationMarkerEnd(composer6);
            if (z2) {
            }
            composer6.startReplaceGroup(385885533);
            composer6.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer6);
            ComposerKt.sourceInformationMarkerEnd(composer5);
            composer5.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer5);
            ComposerKt.sourceInformationMarkerEnd(composer5);
            ComposerKt.sourceInformationMarkerEnd(composer5);
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerEnd($composer3);
            $composer3.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerEnd($composer3);
            $composer3.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerEnd($composer3);
            ComposerKt.sourceInformationMarkerEnd($composer3);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            modifier4 = modifier5;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda11
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj4, Object obj5) {
                    return QuizSandboxKt.QuizSandbox$lambda$70(preferences, geminiService, modifier4, $changed, i, (Composer) obj4, ((Integer) obj5).intValue());
                }
            });
        }
    }

    private static final int QuizSandbox$lambda$1(MutableIntState $currentQuestionIndex$delegate) {
        return $currentQuestionIndex$delegate.getIntValue();
    }

    private static final OptionShape QuizSandbox$lambda$4(MutableState<OptionShape> mutableState) {
        return mutableState.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final String QuizSandbox$lambda$7(MutableState<String> mutableState) {
        return mutableState.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean QuizSandbox$lambda$10(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void QuizSandbox$lambda$11(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    private static final boolean QuizSandbox$lambda$13(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void QuizSandbox$lambda$14(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    private static final AnswerResult QuizSandbox$lambda$16(MutableState<AnswerResult> mutableState) {
        return mutableState.getValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final OptionShape QuizSandbox$lambda$19(MutableState<OptionShape> mutableState) {
        return mutableState.getValue();
    }

    private static final void QuizSandbox$triggerCornerScan(CoroutineScope scope, MutableState<Boolean> mutableState, MutableState<Boolean> mutableState2, MutableState<String> mutableState3, QuizOptionQuestion currentQuestion, AppPreferences $preferences, GeminiService $geminiService, MutableState<AnswerResult> mutableState4, MutableState<OptionShape> mutableState5) {
        String string;
        if (QuizSandbox$lambda$13(mutableState)) {
            return;
        }
        QuizSandbox$lambda$14(mutableState, true);
        if (QuizSandbox$lambda$10(mutableState2) && !StringsKt.isBlank(QuizSandbox$lambda$7(mutableState3))) {
            string = QuizSandbox$lambda$7(mutableState3);
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append(currentQuestion.getQuestion()).append("\n");
            sb.append("RED ▲: ").append(currentQuestion.getRedOption()).append("\n");
            sb.append("BLUE ◆: ").append(currentQuestion.getBlueOption()).append("\n");
            sb.append("YELLOW ●: ").append(currentQuestion.getYellowOption()).append("\n");
            sb.append("GREEN ■: ").append(currentQuestion.getGreenOption()).append("\n");
            string = sb.toString();
        }
        String questionText = string;
        BuildersKt__Builders_commonKt.launch$default(scope, null, null, new QuizSandboxKt$QuizSandbox$triggerCornerScan$1($preferences, $geminiService, questionText, mutableState, currentQuestion, mutableState4, mutableState5, mutableState2, mutableState3, null), 3, null);
    }

    private static final ApiUsageStats QuizSandbox$lambda$69$lambda$59$lambda$23(State<ApiUsageStats> state) {
        return (ApiUsageStats) state.getValue();
    }

    /* JADX WARN: Code duplicated, block: B:43:0x033e  */
    /* JADX WARN: Code duplicated, block: B:46:0x034a  */
    /* JADX WARN: Code duplicated, block: B:47:0x0350  */
    /* JADX WARN: Code duplicated, block: B:50:0x0381  */
    /* JADX WARN: Code duplicated, block: B:53:0x0394  */
    /* JADX WARN: Code duplicated, block: B:54:0x0397  */
    /* JADX WARN: Code duplicated, block: B:58:0x049d  */
    /* JADX WARN: Code duplicated, block: B:59:0x04a2  */
    /* JADX WARN: Code duplicated, block: B:62:0x0516  */
    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$29(final State $apiUsage$delegate, ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        Function0<ComposeUiNode> function1;
        Composer composer;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function2;
        Composer composerM3652constructorimpl;
        Composer composer2;
        long jColor;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C239@8493L2190:QuizSandbox.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1324086255, $changed, -1, "com.example.ui.QuizSandbox.<anonymous>.<anonymous>.<anonymous> (QuizSandbox.kt:239)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(14));
            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
            Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor2;
                $composer.createNode(function0);
            } else {
                function0 = constructor2;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl2 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash);
            }
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i2 = (i >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            int i3 = ((438 >> 6) & 112) | 6;
            RowScope rowScope = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart($composer, -178686991, "C246@8724L880,271@9616L39,276@9867L806,273@9667L1006:QuizSandbox.kt#naom5h");
            Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
            Modifier modifierWeight$default = RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null);
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically2, $composer, ((384 >> 3) & 14) | ((384 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap2 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifierWeight$default);
            Function0<ComposeUiNode> constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            int i4 = ((((384 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function1 = constructor3;
                $composer.createNode(function1);
            } else {
                function1 = constructor3;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl3 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl3.getInserting()) {
                composer = $composer;
            } else {
                composer = $composer;
                if (!Intrinsics.areEqual(composerM3652constructorimpl3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i5 = (i4 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                int i6 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, 2022834860, "C250@8858L195,256@9066L40,257@9119L473:QuizSandbox.kt#naom5h");
                IconKt.m2150Iconww6aTOc(AutoAwesomeKt.getAutoAwesome(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(24)), ColorKt.getIndigoLight(), $composer, 3504, 0);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), $composer, 6);
                ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                Modifier modifier = Modifier.INSTANCE;
                MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
                CompositionLocalMap currentCompositionLocalMap3 = $composer.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier($composer, modifier);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i7 = ((((0 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!($composer.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                $composer.startReusableNode();
                if ($composer.getInserting()) {
                    function2 = constructor;
                    $composer.createNode(function2);
                } else {
                    function2 = constructor;
                    $composer.useNode();
                }
                composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
                Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (composerM3652constructorimpl.getInserting()) {
                    composer2 = $composer;
                } else {
                    composer2 = $composer;
                    if (!Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    }
                    Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                    int i8 = (i7 >> 6) & 14;
                    Composer composer3 = composer2;
                    ComposerKt.sourceInformationMarkerStart(composer3, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                    ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                    int i9 = ((0 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer3, -302478560, "C260@9235L10,258@9142L176,265@9474L10,266@9534L11,263@9333L245:QuizSandbox.kt#naom5h");
                    TextKt.m2693Text4IGK_g("Cvičná Obrazovka Kvízu", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer3, MaterialTheme.$stable).getTitleSmall(), composer3, 196614, 0, 65502);
                    TextKt.m2693Text4IGK_g("Klepněte do rohu obrazovky (✦). Zobrazí se POUZE maličký znak a barva!", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer3, MaterialTheme.$stable).getBodySmall(), composer3, 6, 0, 65530);
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    $composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), $composer, 6);
                    if (QuizSandbox$lambda$69$lambda$59$lambda$23($apiUsage$delegate).getRemainingToday() > 100) {
                        jColor = ColorKt.getEmeraldSuccess();
                    } else {
                        jColor = androidx.compose.ui.graphics.ColorKt.Color(4292617766L);
                    }
                    SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8)), Color.m4157copywmQWz5c(jColor, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jColor) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jColor) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jColor) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jColor) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(1580429776, true, new Function2() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda13
                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj, Object obj2) {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$29$lambda$28$lambda$27($apiUsage$delegate, (Composer) obj, ((Integer) obj2).intValue());
                        }
                    }, $composer, 54), $composer, 12582912, 121);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                }
                composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash3);
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i10 = (i7 >> 6) & 14;
                Composer composer4 = composer2;
                ComposerKt.sourceInformationMarkerStart(composer4, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
                int i11 = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer4, -302478560, "C260@9235L10,258@9142L176,265@9474L10,266@9534L11,263@9333L245:QuizSandbox.kt#naom5h");
                TextKt.m2693Text4IGK_g("Cvičná Obrazovka Kvízu", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer4, MaterialTheme.$stable).getTitleSmall(), composer4, 196614, 0, 65502);
                TextKt.m2693Text4IGK_g("Klepněte do rohu obrazovky (✦). Zobrazí se POUZE maličký znak a barva!", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer4, MaterialTheme.$stable).getBodySmall(), composer4, 6, 0, 65530);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), $composer, 6);
                if (QuizSandbox$lambda$69$lambda$59$lambda$23($apiUsage$delegate).getRemainingToday() > 100) {
                    jColor = ColorKt.getEmeraldSuccess();
                } else {
                    jColor = androidx.compose.ui.graphics.ColorKt.Color(4292617766L);
                }
                SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8)), Color.m4157copywmQWz5c(jColor, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jColor) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jColor) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jColor) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jColor) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(1580429776, true, new Function2() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda13
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$29$lambda$28$lambda$27($apiUsage$delegate, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, $composer, 54), $composer, 12582912, 121);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
            composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash2);
            Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            int i12 = (i4 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
            int i13 = ((384 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, 2022834860, "C250@8858L195,256@9066L40,257@9119L473:QuizSandbox.kt#naom5h");
            IconKt.m2150Iconww6aTOc(AutoAwesomeKt.getAutoAwesome(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(24)), ColorKt.getIndigoLight(), $composer, 3504, 0);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), $composer, 6);
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            Modifier modifier2 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyColumnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap4 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier($composer, modifier2);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i14 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function2 = constructor;
                $composer.createNode(function2);
            } else {
                function2 = constructor;
                $composer.useNode();
            }
            composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyColumnMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting()) {
                composer2 = $composer;
                if (!Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                int i15 = (i14 >> 6) & 14;
                Composer composer5 = composer2;
                ComposerKt.sourceInformationMarkerStart(composer5, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance3 = ColumnScopeInstance.INSTANCE;
                int i16 = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer5, -302478560, "C260@9235L10,258@9142L176,265@9474L10,266@9534L11,263@9333L245:QuizSandbox.kt#naom5h");
                TextKt.m2693Text4IGK_g("Cvičná Obrazovka Kvízu", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer5, MaterialTheme.$stable).getTitleSmall(), composer5, 196614, 0, 65502);
                TextKt.m2693Text4IGK_g("Klepněte do rohu obrazovky (✦). Zobrazí se POUZE maličký znak a barva!", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer5, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer5, MaterialTheme.$stable).getBodySmall(), composer5, 6, 0, 65530);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), $composer, 6);
                if (QuizSandbox$lambda$69$lambda$59$lambda$23($apiUsage$delegate).getRemainingToday() > 100) {
                    jColor = ColorKt.getEmeraldSuccess();
                } else {
                    jColor = androidx.compose.ui.graphics.ColorKt.Color(4292617766L);
                }
                SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8)), Color.m4157copywmQWz5c(jColor, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jColor) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jColor) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jColor) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jColor) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(1580429776, true, new Function2() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda13
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$29$lambda$28$lambda$27($apiUsage$delegate, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, $composer, 54), $composer, 12582912, 121);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composer2 = $composer;
            }
            composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash4);
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
            int i17 = (i14 >> 6) & 14;
            Composer composer6 = composer2;
            ComposerKt.sourceInformationMarkerStart(composer6, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance4 = ColumnScopeInstance.INSTANCE;
            int i18 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer6, -302478560, "C260@9235L10,258@9142L176,265@9474L10,266@9534L11,263@9333L245:QuizSandbox.kt#naom5h");
            TextKt.m2693Text4IGK_g("Cvičná Obrazovka Kvízu", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer6, MaterialTheme.$stable).getTitleSmall(), composer6, 196614, 0, 65502);
            TextKt.m2693Text4IGK_g("Klepněte do rohu obrazovky (✦). Zobrazí se POUZE maličký znak a barva!", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer6, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer6, MaterialTheme.$stable).getBodySmall(), composer6, 6, 0, 65530);
            ComposerKt.sourceInformationMarkerEnd(composer6);
            ComposerKt.sourceInformationMarkerEnd(composer6);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), $composer, 6);
            if (QuizSandbox$lambda$69$lambda$59$lambda$23($apiUsage$delegate).getRemainingToday() > 100) {
                jColor = ColorKt.getEmeraldSuccess();
            } else {
                jColor = androidx.compose.ui.graphics.ColorKt.Color(4292617766L);
            }
            SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8)), Color.m4157copywmQWz5c(jColor, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jColor) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jColor) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jColor) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jColor) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(1580429776, true, new Function2() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda13
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$29$lambda$28$lambda$27($apiUsage$delegate, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, $composer, 54), $composer, 12582912, 121);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$29$lambda$28$lambda$27(State $apiUsage$delegate, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C277@9881L780:QuizSandbox.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1580429776, $changed, -1, "com.example.ui.QuizSandbox.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (QuizSandbox.kt:277)");
            }
            Modifier modifierM671paddingVpY3zN4 = PaddingKt.m671paddingVpY3zN4(Modifier.INSTANCE, Dp.m6622constructorimpl(8), Dp.m6622constructorimpl(4));
            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically, $composer, ((390 >> 3) & 14) | ((390 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM671paddingVpY3zN4);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((390 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                $composer.createNode(constructor);
            } else {
                $composer.useNode();
            }
            Composer composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i2 = (i >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            int i3 = ((390 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, 201848616, "C281@10056L265,287@10336L39,288@10390L257:QuizSandbox.kt#naom5h");
            IconKt.m2150Iconww6aTOc(CloudQueueKt.getCloudQueue(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14)), QuizSandbox$lambda$69$lambda$59$lambda$23($apiUsage$delegate).getRemainingToday() > 100 ? ColorKt.getEmeraldSuccess() : androidx.compose.ui.graphics.ColorKt.Color(4292617766L), $composer, 432, 0);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(4)), $composer, 6);
            TextKt.m2693Text4IGK_g(QuizSandbox$lambda$69$lambda$59$lambda$23($apiUsage$delegate).getRemainingToday() + " zbývá", (Modifier) null, QuizSandbox$lambda$69$lambda$59$lambda$23($apiUsage$delegate).getRemainingToday() > 100 ? ColorKt.getEmeraldSuccess() : androidx.compose.ui.graphics.ColorKt.Color(4292617766L), TextUnitKt.getSp(11), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 199680, 0, 131026);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$34$lambda$31$lambda$30(MutableState $isCustomMode$delegate) {
        QuizSandbox$lambda$11($isCustomMode$delegate, false);
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$34$lambda$33$lambda$32(MutableState $isCustomMode$delegate) {
        QuizSandbox$lambda$11($isCustomMode$delegate, true);
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:101:0x080a  */
    /* JADX WARN: Code duplicated, block: B:102:0x0818  */
    /* JADX WARN: Code duplicated, block: B:105:0x0829  */
    /* JADX WARN: Code duplicated, block: B:106:0x082c  */
    /* JADX WARN: Code duplicated, block: B:109:0x085e  */
    /* JADX WARN: Code duplicated, block: B:110:0x086c  */
    /* JADX WARN: Code duplicated, block: B:113:0x08aa  */
    /* JADX WARN: Code duplicated, block: B:114:0x08b8  */
    /* JADX WARN: Code duplicated, block: B:117:0x08d3  */
    /* JADX WARN: Code duplicated, block: B:118:0x08d6  */
    /* JADX WARN: Code duplicated, block: B:121:0x0922  */
    /* JADX WARN: Code duplicated, block: B:124:0x0694 A[EDGE_INSN: B:124:0x0694->B:84:0x0694 BREAK  A[LOOP:0: B:57:0x056a->B:83:0x0647], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:28:0x01de  */
    /* JADX WARN: Code duplicated, block: B:31:0x01ea  */
    /* JADX WARN: Code duplicated, block: B:32:0x01f0  */
    /* JADX WARN: Code duplicated, block: B:43:0x04ae  */
    /* JADX WARN: Code duplicated, block: B:46:0x04ba  */
    /* JADX WARN: Code duplicated, block: B:47:0x04c0  */
    /* JADX WARN: Code duplicated, block: B:59:0x0574  */
    /* JADX WARN: Code duplicated, block: B:61:0x058e  */
    /* JADX WARN: Code duplicated, block: B:62:0x0590  */
    /* JADX WARN: Code duplicated, block: B:65:0x0599  */
    /* JADX WARN: Code duplicated, block: B:66:0x059b  */
    /* JADX WARN: Code duplicated, block: B:69:0x05a4  */
    /* JADX WARN: Code duplicated, block: B:70:0x05a6  */
    /* JADX WARN: Code duplicated, block: B:73:0x05be  */
    /* JADX WARN: Code duplicated, block: B:74:0x05d7  */
    /* JADX WARN: Code duplicated, block: B:86:0x0745  */
    /* JADX WARN: Code duplicated, block: B:89:0x0751  */
    /* JADX WARN: Code duplicated, block: B:90:0x0757  */
    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$51(final QuizOptionQuestion $currentQuestion, final MutableIntState $currentQuestionIndex$delegate, final MutableState $selectedShape$delegate, final MutableState $detectedShape$delegate, ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        Composer composer;
        Composer composer2;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function1;
        Composer composerM3652constructorimpl;
        int i;
        int currentCompositeKeyHash2;
        Modifier modifierMaterializeModifier;
        Function0<ComposeUiNode> constructor2;
        Function0<ComposeUiNode> function2;
        Composer composerM3652constructorimpl2;
        int i2;
        int i3;
        Iterable iterable;
        int i4;
        Iterator it;
        Iterable iterable2;
        int currentCompositeKeyHash3;
        Function0<ComposeUiNode> constructor3;
        Function0<ComposeUiNode> function3;
        Composer composerM3652constructorimpl3;
        Object objRememberedValue;
        boolean z;
        Object objRememberedValue2;
        Object objRememberedValue3;
        boolean z2;
        final OptionShape shape;
        boolean z3;
        boolean z4;
        final boolean z5;
        BorderStroke borderStrokeM252BorderStrokecXLIe8U;
        boolean zChanged;
        Object obj;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C347@12415L5241:QuizSandbox.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1545147052, $changed, -1, "com.example.ui.QuizSandbox.<anonymous>.<anonymous>.<anonymous> (QuizSandbox.kt:347)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(18));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            int i5 = (6 << 3) & 112;
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor4 = ComposeUiNode.INSTANCE.getConstructor();
            int i6 = ((i5 << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor4;
                $composer.createNode(function0);
            } else {
                function0 = constructor4;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl4 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl4.getInserting()) {
                composer = $composer;
            } else {
                composer = $composer;
                if (!Intrinsics.areEqual(composerM3652constructorimpl4.rememberedValue(), Integer.valueOf(currentCompositeKeyHash4))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i7 = (i6 >> 6) & 14;
                composer2 = composer;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i8 = ((6 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 1418656173, "C348@12472L904,373@13390L41,377@13534L10,375@13445L207,382@13666L41,392@14212L1965,439@16191L41,442@16284L1360:QuizSandbox.kt#naom5h");
                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap2 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i9 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function1 = constructor;
                    composer2.createNode(function1);
                } else {
                    function1 = constructor;
                    composer2.useNode();
                }
                composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                    composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash2);
                }
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i10 = (i9 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                int i11 = ((438 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 1491485589, "C356@12815L318,353@12682L451,369@13318L11,366@13149L213:QuizSandbox.kt#naom5h");
                long indigoPrimary = ColorKt.getIndigoPrimary();
                SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8)), Color.m4157copywmQWz5c(indigoPrimary, (14 & 1) != 0 ? Color.m4161getAlphaimpl(indigoPrimary) : 0.12f, (14 & 2) != 0 ? Color.m4165getRedimpl(indigoPrimary) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(indigoPrimary) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(indigoPrimary) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(-1985690335, true, new Function2() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj2, Object obj3) {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$36$lambda$35($currentQuestion, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 12583296, 121);
                TextKt.m2693Text4IGK_g("Otázka " + (QuizSandbox$lambda$1($currentQuestionIndex$delegate) + 1) + " / " + SampleQuizQuestions.size(), (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(12), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3072, 0, 131058);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer2, 6);
                TextKt.m2693Text4IGK_g($currentQuestion.getQuestion(), (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, TextUnitKt.getSp(22), 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleMedium(), composer2, ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 6, 64478);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                Iterable iterableListOf = CollectionsKt.listOf((Object[]) new QuizOptionTile[]{new QuizOptionTile(OptionShape.RED_TRIANGLE, $currentQuestion.getRedOption(), androidx.compose.ui.graphics.ColorKt.Color(4293008188L), null), new QuizOptionTile(OptionShape.BLUE_DIAMOND, $currentQuestion.getBlueOption(), androidx.compose.ui.graphics.ColorKt.Color(4279462094L), null), new QuizOptionTile(OptionShape.YELLOW_CIRCLE, $currentQuestion.getYellowOption(), androidx.compose.ui.graphics.ColorKt.Color(4292386304L), null), new QuizOptionTile(OptionShape.GREEN_SQUARE, $currentQuestion.getGreenOption(), androidx.compose.ui.graphics.ColorKt.Color(4280715532L), null)});
                Arrangement.Vertical verticalM550spacedBy0680j_4 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
                i = 0;
                ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                Modifier modifier = Modifier.INSTANCE;
                MeasurePolicy measurePolicyColumnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(verticalM550spacedBy0680j_4, Alignment.INSTANCE.getStart(), composer2, ((48 >> 3) & 14) | ((48 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
                modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer2, modifier);
                constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                int i12 = ((((48 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function2 = constructor2;
                    composer2.createNode(function2);
                } else {
                    function2 = constructor2;
                    composer2.useNode();
                }
                composerM3652constructorimpl2 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyColumnMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                    composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                    composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash3);
                }
                Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i13 = (i12 >> 6) & 14;
                i2 = 0;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
                i3 = ((48 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -66472747, "C:QuizSandbox.kt#naom5h");
                composer2.startReplaceGroup(274950568);
                ComposerKt.sourceInformation(composer2, "*400@14584L25,407@14978L1169,399@14547L1600");
                iterable = iterableListOf;
                i4 = 0;
                it = iterable.iterator();
                while (true) {
                    iterable2 = iterable;
                    if (it.hasNext()) {
                        break;
                    }
                    int i14 = i4;
                    final QuizOptionTile quizOptionTile = (QuizOptionTile) it.next();
                    int i15 = i2;
                    shape = quizOptionTile.getShape();
                    Modifier modifier2 = modifierMaterializeModifier;
                    if (QuizSandbox$lambda$4($selectedShape$delegate) == shape) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                    if (shape == $currentQuestion.getCorrectShape()) {
                        z4 = true;
                    } else {
                        z4 = false;
                    }
                    if (QuizSandbox$lambda$19($detectedShape$delegate) == shape) {
                        z5 = true;
                    } else {
                        z5 = false;
                    }
                    long jM6953getColor0d7_KjU = quizOptionTile.m6953getColor0d7_KjU();
                    int i16 = i3;
                    int i17 = i;
                    RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12));
                    if (z5) {
                        borderStrokeM252BorderStrokecXLIe8U = BorderStrokeKt.m252BorderStrokecXLIe8U(Dp.m6622constructorimpl(3), Color.INSTANCE.m4196getWhite0d7_KjU());
                    } else {
                        borderStrokeM252BorderStrokecXLIe8U = null;
                    }
                    int i18 = i5;
                    Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                    String lowerCase = shape.name().toLowerCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                    Modifier modifierTestTag = TestTagKt.testTag(modifierFillMaxWidth$default2, "option_tile_" + lowerCase);
                    ComposerKt.sourceInformationMarkerStart(composer2, 1381339080, "CC(remember):QuizSandbox.kt#9igjgp");
                    zChanged = composer2.changed(shape.ordinal());
                    Object objRememberedValue4 = composer2.rememberedValue();
                    if (!zChanged || objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                        obj = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda3
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$42$lambda$41$lambda$38$lambda$37(shape, $selectedShape$delegate);
                            }
                        };
                        composer2.updateRememberedValue(obj);
                    } else {
                        obj = objRememberedValue4;
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    SurfaceKt.m2546Surfaceo_FOJdg((Function0) obj, modifierTestTag, false, roundedCornerShapeM953RoundedCornerShape0680j_4, jM6953getColor0d7_KjU, 0L, 0.0f, 0.0f, borderStrokeM252BorderStrokecXLIe8U, null, ComposableLambdaKt.rememberComposableLambda(-893168668, true, new Function2() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj2, Object obj3) {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$42$lambda$41$lambda$40(shape, quizOptionTile, z5, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }, composer2, 54), composer2, 0, 6, 740);
                    iterable = iterable2;
                    i4 = i14;
                    i2 = i15;
                    modifierMaterializeModifier = modifier2;
                    i3 = i16;
                    i = i17;
                    measurePolicyColumnMeasurePolicy = measurePolicyColumnMeasurePolicy;
                    i5 = i18;
                }
                composer2.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                Modifier modifierFillMaxWidth$default3 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween2 = Arrangement.INSTANCE.getSpaceBetween();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(spaceBetween2, Alignment.INSTANCE.getTop(), composer2, ((54 >> 3) & 14) | ((54 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap4 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default3);
                constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                int i19 = ((((54 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function3 = constructor3;
                    composer2.createNode(function3);
                } else {
                    function3 = constructor3;
                    composer2.useNode();
                }
                composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl3.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                    composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                    composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash4);
                }
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                int i20 = (i19 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                int i21 = ((54 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 162345464, "C447@16470L214,446@16432L430,460@16916L97,459@16878L253,469@17185L241,468@17147L483:QuizSandbox.kt#naom5h");
                ComposerKt.sourceInformationMarkerStart(composer2, 697973843, "CC(remember):QuizSandbox.kt#9igjgp");
                objRememberedValue = composer2.rememberedValue();
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda5
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$49$lambda$44$lambda$43($currentQuestionIndex$delegate, $selectedShape$delegate, $detectedShape$delegate);
                        }
                    };
                    composer2.updateRememberedValue(objRememberedValue);
                }
                Function0 function4 = (Function0) objRememberedValue;
                ComposerKt.sourceInformationMarkerEnd(composer2);
                if (QuizSandbox$lambda$1($currentQuestionIndex$delegate) > 0) {
                    z = true;
                } else {
                    z = false;
                }
                IconButtonKt.IconButton(function4, null, z, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.getLambda$1435506970$app(), composer2, 196614, 26);
                ComposerKt.sourceInformationMarkerStart(composer2, 697987998, "CC(remember):QuizSandbox.kt#9igjgp");
                objRememberedValue2 = composer2.rememberedValue();
                if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue2 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda6
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$49$lambda$46$lambda$45($selectedShape$delegate, $detectedShape$delegate);
                        }
                    };
                    composer2.updateRememberedValue(objRememberedValue2);
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                IconButtonKt.IconButton((Function0) objRememberedValue2, null, false, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.getLambda$1964883409$app(), composer2, 196614, 30);
                ComposerKt.sourceInformationMarkerStart(composer2, 697996750, "CC(remember):QuizSandbox.kt#9igjgp");
                objRememberedValue3 = composer2.rememberedValue();
                if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue3 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda7
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$49$lambda$48$lambda$47($currentQuestionIndex$delegate, $selectedShape$delegate, $detectedShape$delegate);
                        }
                    };
                    composer2.updateRememberedValue(objRememberedValue3);
                }
                Function0 function5 = (Function0) objRememberedValue3;
                ComposerKt.sourceInformationMarkerEnd(composer2);
                if (QuizSandbox$lambda$1($currentQuestionIndex$delegate) < SampleQuizQuestions.size() - 1) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                IconButtonKt.IconButton(function5, null, z2, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.getLambda$1983310162$app(), composer2, 196614, 26);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
            composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash);
            Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            int i22 = (i6 >> 6) & 14;
            composer2 = composer;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance3 = ColumnScopeInstance.INSTANCE;
            int i23 = ((6 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 1418656173, "C348@12472L904,373@13390L41,377@13534L10,375@13445L207,382@13666L41,392@14212L1965,439@16191L41,442@16284L1360:QuizSandbox.kt#naom5h");
            Modifier modifierFillMaxWidth$default4 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween3 = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy3 = RowKt.rowMeasurePolicy(spaceBetween3, centerVertically2, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap5 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default4);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i24 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function1 = constructor;
                composer2.createNode(function1);
            } else {
                function1 = constructor;
                composer2.useNode();
            }
            composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl.getInserting()) {
            }
            composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash5);
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
            int i110 = (i24 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance3 = RowScopeInstance.INSTANCE;
            int i111 = ((438 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 1491485589, "C356@12815L318,353@12682L451,369@13318L11,366@13149L213:QuizSandbox.kt#naom5h");
            long indigoPrimary2 = ColorKt.getIndigoPrimary();
            SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8)), Color.m4157copywmQWz5c(indigoPrimary2, (14 & 1) != 0 ? Color.m4161getAlphaimpl(indigoPrimary2) : 0.12f, (14 & 2) != 0 ? Color.m4165getRedimpl(indigoPrimary2) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(indigoPrimary2) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(indigoPrimary2) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(-1985690335, true, new Function2() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$36$lambda$35($currentQuestion, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer2, 54), composer2, 12583296, 121);
            TextKt.m2693Text4IGK_g("Otázka " + (QuizSandbox$lambda$1($currentQuestionIndex$delegate) + 1) + " / " + SampleQuizQuestions.size(), (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(12), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3072, 0, 131058);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer2, 6);
            TextKt.m2693Text4IGK_g($currentQuestion.getQuestion(), (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, TextUnitKt.getSp(22), 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleMedium(), composer2, ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 6, 64478);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
            Iterable iterableListOf2 = CollectionsKt.listOf((Object[]) new QuizOptionTile[]{new QuizOptionTile(OptionShape.RED_TRIANGLE, $currentQuestion.getRedOption(), androidx.compose.ui.graphics.ColorKt.Color(4293008188L), null), new QuizOptionTile(OptionShape.BLUE_DIAMOND, $currentQuestion.getBlueOption(), androidx.compose.ui.graphics.ColorKt.Color(4279462094L), null), new QuizOptionTile(OptionShape.YELLOW_CIRCLE, $currentQuestion.getYellowOption(), androidx.compose.ui.graphics.ColorKt.Color(4292386304L), null), new QuizOptionTile(OptionShape.GREEN_SQUARE, $currentQuestion.getGreenOption(), androidx.compose.ui.graphics.ColorKt.Color(4280715532L), null)});
            Arrangement.Vertical verticalM550spacedBy0680j_5 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
            i = 0;
            ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            Modifier modifier3 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyColumnMeasurePolicy3 = ColumnKt.columnMeasurePolicy(verticalM550spacedBy0680j_5, Alignment.INSTANCE.getStart(), composer2, ((48 >> 3) & 14) | ((48 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap6 = composer2.getCurrentCompositionLocalMap();
            modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer2, modifier3);
            constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i112 = ((((48 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function2 = constructor2;
                composer2.createNode(function2);
            } else {
                function2 = constructor2;
                composer2.useNode();
            }
            composerM3652constructorimpl2 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyColumnMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap6, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash6 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl2.getInserting()) {
            }
            composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash6);
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i113 = (i112 >> 6) & 14;
            i2 = 0;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance4 = ColumnScopeInstance.INSTANCE;
            i3 = ((48 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -66472747, "C:QuizSandbox.kt#naom5h");
            composer2.startReplaceGroup(274950568);
            ComposerKt.sourceInformation(composer2, "*400@14584L25,407@14978L1169,399@14547L1600");
            iterable = iterableListOf2;
            i4 = 0;
            it = iterable.iterator();
            while (true) {
                iterable2 = iterable;
                if (it.hasNext()) {
                    break;
                    break;
                }
                int i114 = i4;
                final QuizOptionTile quizOptionTile2 = (QuizOptionTile) it.next();
                int i115 = i2;
                shape = quizOptionTile2.getShape();
                Modifier modifier4 = modifierMaterializeModifier;
                if (QuizSandbox$lambda$4($selectedShape$delegate) == shape) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                if (shape == $currentQuestion.getCorrectShape()) {
                    z4 = true;
                } else {
                    z4 = false;
                }
                if (QuizSandbox$lambda$19($detectedShape$delegate) == shape) {
                    z5 = true;
                } else {
                    z5 = false;
                }
                long jM6953getColor0d7_KjU2 = quizOptionTile2.m6953getColor0d7_KjU();
                int i116 = i3;
                int i117 = i;
                RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_5 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12));
                if (z5) {
                    borderStrokeM252BorderStrokecXLIe8U = BorderStrokeKt.m252BorderStrokecXLIe8U(Dp.m6622constructorimpl(3), Color.INSTANCE.m4196getWhite0d7_KjU());
                } else {
                    borderStrokeM252BorderStrokecXLIe8U = null;
                }
                int i118 = i5;
                Modifier modifierFillMaxWidth$default5 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                String lowerCase2 = shape.name().toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue(lowerCase2, "toLowerCase(...)");
                Modifier modifierTestTag2 = TestTagKt.testTag(modifierFillMaxWidth$default5, "option_tile_" + lowerCase2);
                ComposerKt.sourceInformationMarkerStart(composer2, 1381339080, "CC(remember):QuizSandbox.kt#9igjgp");
                zChanged = composer2.changed(shape.ordinal());
                Object objRememberedValue5 = composer2.rememberedValue();
                if (zChanged) {
                }
                obj = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$42$lambda$41$lambda$38$lambda$37(shape, $selectedShape$delegate);
                    }
                };
                composer2.updateRememberedValue(obj);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SurfaceKt.m2546Surfaceo_FOJdg((Function0) obj, modifierTestTag2, false, roundedCornerShapeM953RoundedCornerShape0680j_5, jM6953getColor0d7_KjU2, 0L, 0.0f, 0.0f, borderStrokeM252BorderStrokecXLIe8U, null, ComposableLambdaKt.rememberComposableLambda(-893168668, true, new Function2() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj2, Object obj3) {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$42$lambda$41$lambda$40(shape, quizOptionTile2, z5, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 0, 6, 740);
                iterable = iterable2;
                i4 = i114;
                i2 = i115;
                modifierMaterializeModifier = modifier4;
                i3 = i116;
                i = i117;
                measurePolicyColumnMeasurePolicy = measurePolicyColumnMeasurePolicy;
                i5 = i118;
            }
            composer2.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
            Modifier modifierFillMaxWidth$default6 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween4 = Arrangement.INSTANCE.getSpaceBetween();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy4 = RowKt.rowMeasurePolicy(spaceBetween4, Alignment.INSTANCE.getTop(), composer2, ((54 >> 3) & 14) | ((54 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap7 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier6 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default6);
            constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            int i119 = ((((54 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function3 = constructor3;
                composer2.createNode(function3);
            } else {
                function3 = constructor3;
                composer2.useNode();
            }
            composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap7, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash7 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl3.getInserting()) {
            }
            composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
            composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash7);
            Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier6, ComposeUiNode.INSTANCE.getSetModifier());
            int i25 = (i119 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance4 = RowScopeInstance.INSTANCE;
            int i26 = ((54 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 162345464, "C447@16470L214,446@16432L430,460@16916L97,459@16878L253,469@17185L241,468@17147L483:QuizSandbox.kt#naom5h");
            ComposerKt.sourceInformationMarkerStart(composer2, 697973843, "CC(remember):QuizSandbox.kt#9igjgp");
            objRememberedValue = composer2.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda5
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$49$lambda$44$lambda$43($currentQuestionIndex$delegate, $selectedShape$delegate, $detectedShape$delegate);
                    }
                };
                composer2.updateRememberedValue(objRememberedValue);
            }
            Function0 function6 = (Function0) objRememberedValue;
            ComposerKt.sourceInformationMarkerEnd(composer2);
            if (QuizSandbox$lambda$1($currentQuestionIndex$delegate) > 0) {
                z = true;
            } else {
                z = false;
            }
            IconButtonKt.IconButton(function6, null, z, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.getLambda$1435506970$app(), composer2, 196614, 26);
            ComposerKt.sourceInformationMarkerStart(composer2, 697987998, "CC(remember):QuizSandbox.kt#9igjgp");
            objRememberedValue2 = composer2.rememberedValue();
            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                objRememberedValue2 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$49$lambda$46$lambda$45($selectedShape$delegate, $detectedShape$delegate);
                    }
                };
                composer2.updateRememberedValue(objRememberedValue2);
            }
            ComposerKt.sourceInformationMarkerEnd(composer2);
            IconButtonKt.IconButton((Function0) objRememberedValue2, null, false, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.getLambda$1964883409$app(), composer2, 196614, 30);
            ComposerKt.sourceInformationMarkerStart(composer2, 697996750, "CC(remember):QuizSandbox.kt#9igjgp");
            objRememberedValue3 = composer2.rememberedValue();
            if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                objRememberedValue3 = new Function0() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda7
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$49$lambda$48$lambda$47($currentQuestionIndex$delegate, $selectedShape$delegate, $detectedShape$delegate);
                    }
                };
                composer2.updateRememberedValue(objRememberedValue3);
            }
            Function0 function7 = (Function0) objRememberedValue3;
            ComposerKt.sourceInformationMarkerEnd(composer2);
            if (QuizSandbox$lambda$1($currentQuestionIndex$delegate) < SampleQuizQuestions.size() - 1) {
                z2 = true;
            } else {
                z2 = false;
            }
            IconButtonKt.IconButton(function7, null, z2, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.getLambda$1983310162$app(), composer2, 196614, 26);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$36$lambda$35(QuizOptionQuestion $currentQuestion, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C357@12833L284:QuizSandbox.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1985690335, $changed, -1, "com.example.ui.QuizSandbox.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (QuizSandbox.kt:357)");
            }
            TextKt.m2693Text4IGK_g($currentQuestion.getCategory(), PaddingKt.m671paddingVpY3zN4(Modifier.INSTANCE, Dp.m6622constructorimpl(10), Dp.m6622constructorimpl(4)), ColorKt.getIndigoLight(), TextUnitKt.getSp(12), (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 200112, 0, 131024);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$42$lambda$41$lambda$38$lambda$37(OptionShape $shape, MutableState $selectedShape$delegate) {
        $selectedShape$delegate.setValue($shape);
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$42$lambda$41$lambda$40(OptionShape $shape, QuizOptionTile $tile, boolean $isRevealed, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C408@14998L1131:QuizSandbox.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-893168668, $changed, -1, "com.example.ui.QuizSandbox.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (QuizSandbox.kt:408)");
            }
            Modifier modifierM671paddingVpY3zN4 = PaddingKt.m671paddingVpY3zN4(Modifier.INSTANCE, Dp.m6622constructorimpl(16), Dp.m6622constructorimpl(12));
            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically, $composer, ((390 >> 3) & 14) | ((390 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM671paddingVpY3zN4);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((390 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                $composer.createNode(constructor);
            } else {
                $composer.useNode();
            }
            Composer composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i2 = (i >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            int i3 = ((390 >> 6) & 112) | 6;
            RowScope rowScope = RowScopeInstance.INSTANCE;
            Composer composer = $composer;
            ComposerKt.sourceInformationMarkerStart(composer, 1895709813, "C412@15199L204,418@15424L40,421@15576L10,419@15485L283:QuizSandbox.kt#naom5h");
            TextKt.m2693Text4IGK_g($shape.getSymbol(), (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(22), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 200064, 0, 131026);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer, 6);
            String label = $tile.getLabel();
            TextStyle bodyMedium = MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getBodyMedium();
            TextKt.m2693Text4IGK_g(label, RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, bodyMedium, $composer, 196992, 0, 65496);
            if ($isRevealed) {
                composer.startReplaceGroup(1896292178);
                ComposerKt.sourceInformation(composer, "427@15829L258");
                IconKt.m2150Iconww6aTOc(CheckCircleKt.getCheckCircle(Icons.INSTANCE.getDefault()), "Správná odpověď", SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), Color.INSTANCE.m4196getWhite0d7_KjU(), composer, 3504, 0);
                composer = composer;
            } else {
                composer.startReplaceGroup(1880603202);
            }
            composer.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$49$lambda$44$lambda$43(MutableIntState $currentQuestionIndex$delegate, MutableState $selectedShape$delegate, MutableState $detectedShape$delegate) {
        if (QuizSandbox$lambda$1($currentQuestionIndex$delegate) > 0) {
            $currentQuestionIndex$delegate.setIntValue(QuizSandbox$lambda$1($currentQuestionIndex$delegate) - 1);
            $selectedShape$delegate.setValue(null);
            $detectedShape$delegate.setValue(null);
        }
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$49$lambda$46$lambda$45(MutableState $selectedShape$delegate, MutableState $detectedShape$delegate) {
        $selectedShape$delegate.setValue(null);
        $detectedShape$delegate.setValue(null);
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$51$lambda$50$lambda$49$lambda$48$lambda$47(MutableIntState $currentQuestionIndex$delegate, MutableState $selectedShape$delegate, MutableState $detectedShape$delegate) {
        if (QuizSandbox$lambda$1($currentQuestionIndex$delegate) < SampleQuizQuestions.size() - 1) {
            $currentQuestionIndex$delegate.setIntValue(QuizSandbox$lambda$1($currentQuestionIndex$delegate) + 1);
            $selectedShape$delegate.setValue(null);
            $detectedShape$delegate.setValue(null);
        }
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$55(final MutableState $customQuestionText$delegate, ColumnScope Card, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C491@17991L1163:QuizSandbox.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1021124683, $changed, -1, "com.example.ui.QuizSandbox.<anonymous>.<anonymous>.<anonymous> (QuizSandbox.kt:491)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(18));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                $composer.createNode(constructor);
            } else {
                $composer.useNode();
            }
            Composer composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i2 = (i >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            int i3 = ((6 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -11501390, "C494@18140L10,492@18048L172,497@18233L40,500@18410L10,501@18468L11,498@18286L224,503@18523L41,513@19054L74,506@18668L27,504@18577L565:QuizSandbox.kt#naom5h");
            TextKt.m2693Text4IGK_g("Zadejte jakoukoliv otázku", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleMedium(), $composer, 196614, 0, 65502);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), $composer, 6);
            TextKt.m2693Text4IGK_g("Napište nebo vložte text otázky a klikněte na bod v rohu.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodySmall(), $composer, 6, 0, 65530);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), $composer, 6);
            String strQuizSandbox$lambda$7 = QuizSandbox$lambda$7($customQuestionText$delegate);
            Modifier modifierTestTag = TestTagKt.testTag(SizeKt.m701height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(140)), "custom_question_input");
            RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12));
            TextFieldColors textFieldColorsM2343colors0hiis_0 = OutlinedTextFieldDefaults.INSTANCE.m2343colors0hiis_0(0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, null, ColorKt.getIndigoPrimary(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, $composer, 0, 48, 0, 0, 3072, 2147481599, 4095);
            ComposerKt.sourceInformationMarkerStart($composer, 1800763078, "CC(remember):QuizSandbox.kt#9igjgp");
            Object objRememberedValue = $composer.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function1() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda12
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return QuizSandboxKt.QuizSandbox$lambda$69$lambda$59$lambda$55$lambda$54$lambda$53$lambda$52($customQuestionText$delegate, (String) obj);
                    }
                };
                $composer.updateRememberedValue(objRememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd($composer);
            OutlinedTextFieldKt.OutlinedTextField(strQuizSandbox$lambda$7, (Function1<? super String, Unit>) objRememberedValue, modifierTestTag, false, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$QuizSandboxKt.INSTANCE.m6944getLambda$940983452$app(), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, false, (VisualTransformation) null, (KeyboardOptions) null, (KeyboardActions) null, false, 0, 0, (MutableInteractionSource) null, (Shape) roundedCornerShapeM953RoundedCornerShape0680j_4, textFieldColorsM2343colors0hiis_0, $composer, 12583344, 0, 0, 2097016);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$55$lambda$54$lambda$53$lambda$52(MutableState $customQuestionText$delegate, String it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $customQuestionText$delegate.setValue(it);
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$57$lambda$56(CoroutineScope $scope, MutableState $isAnalyzing$delegate, MutableState $isCustomMode$delegate, MutableState $customQuestionText$delegate, QuizOptionQuestion $currentQuestion, AppPreferences $preferences, GeminiService $geminiService, MutableState $answerResult$delegate, MutableState $detectedShape$delegate) {
        QuizSandbox$triggerCornerScan($scope, $isAnalyzing$delegate, $isCustomMode$delegate, $customQuestionText$delegate, $currentQuestion, $preferences, $geminiService, $answerResult$delegate, $detectedShape$delegate);
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$59$lambda$58(MutableState $isAnalyzing$delegate, RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C534@19585L57,535@19651L39,536@19699L164:QuizSandbox.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-211234033, $changed, -1, "com.example.ui.QuizSandbox.<anonymous>.<anonymous>.<anonymous> (QuizSandbox.kt:534)");
            }
            IconKt.m2150Iconww6aTOc(PsychologyKt.getPsychology(Icons.INSTANCE.getDefault()), (String) null, (Modifier) null, 0L, $composer, 48, 12);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), $composer, 6);
            TextKt.m2693Text4IGK_g(QuizSandbox$lambda$13($isAnalyzing$delegate) ? "Zjišťuji správnou možnost..." : "Zjistit odpověď (nebo klepněte do rohu)", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 0, 131038);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$68$lambda$67$lambda$61$lambda$60(MutableState $detectedShape$delegate, MutableState $answerResult$delegate) {
        $detectedShape$delegate.setValue(null);
        $answerResult$delegate.setValue(null);
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$68$lambda$67$lambda$63$lambda$62(OptionShape $activeShape, MutableState $detectedShape$delegate, MutableState $answerResult$delegate, CoroutineScope $scope, MutableState $isAnalyzing$delegate, MutableState $isCustomMode$delegate, MutableState $customQuestionText$delegate, QuizOptionQuestion $currentQuestion, AppPreferences $preferences, GeminiService $geminiService) {
        if ($activeShape == null) {
            QuizSandbox$triggerCornerScan($scope, $isAnalyzing$delegate, $isCustomMode$delegate, $customQuestionText$delegate, $currentQuestion, $preferences, $geminiService, $answerResult$delegate, $detectedShape$delegate);
        } else {
            $detectedShape$delegate.setValue(null);
            $answerResult$delegate.setValue(null);
        }
        return Unit.INSTANCE;
    }

    static final Unit QuizSandbox$lambda$69$lambda$68$lambda$67$lambda$66$lambda$65(MutableState $detectedShape$delegate, MutableState $answerResult$delegate) {
        $detectedShape$delegate.setValue(null);
        $answerResult$delegate.setValue(null);
        return Unit.INSTANCE;
    }

    private static final void SandboxAnswerCard(final AnswerResult answer, CornerPosition cornerPos, Function0<Unit> function0, Composer $composer, final int $changed) {
        Object objMutableFloatStateOf;
        Object objMutableFloatStateOf2;
        Object obj;
        final CornerPosition cornerPosition;
        QuizSandboxKt$SandboxAnswerCard$2$1 quizSandboxKt$SandboxAnswerCard$2$1;
        final Function0<Unit> function1 = function0;
        Composer $composer2 = $composer.startRestartGroup(2035111657);
        ComposerKt.sourceInformation($composer2, "C(SandboxAnswerCard)649@23394L36,650@23448L36,653@23520L46,658@23746L72,659@23845L964,685@24858L1616,652@23488L2986:QuizSandbox.kt#naom5h");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer2.changedInstance(answer) ? 4 : 2;
        }
        if (($changed & 48) == 0) {
            $dirty |= $composer2.changed(cornerPos.ordinal()) ? 32 : 16;
        }
        if (($changed & 384) == 0) {
            $dirty |= $composer2.changedInstance(function1) ? 256 : 128;
        }
        if (($dirty & 147) == 146 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
            cornerPosition = cornerPos;
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2035111657, $dirty, -1, "com.example.ui.SandboxAnswerCard (QuizSandbox.kt:648)");
            }
            ComposerKt.sourceInformationMarkerStart($composer2, 1532187245, "CC(remember):QuizSandbox.kt#9igjgp");
            Object objRememberedValue = $composer2.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objMutableFloatStateOf = PrimitiveSnapshotStateKt.mutableFloatStateOf(0.0f);
                $composer2.updateRememberedValue(objMutableFloatStateOf);
            } else {
                objMutableFloatStateOf = objRememberedValue;
            }
            final MutableFloatState offsetX$delegate = (MutableFloatState) objMutableFloatStateOf;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, 1532188973, "CC(remember):QuizSandbox.kt#9igjgp");
            Object objRememberedValue2 = $composer2.rememberedValue();
            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                objMutableFloatStateOf2 = PrimitiveSnapshotStateKt.mutableFloatStateOf(0.0f);
                $composer2.updateRememberedValue(objMutableFloatStateOf2);
            } else {
                objMutableFloatStateOf2 = objRememberedValue2;
            }
            final MutableFloatState offsetY$delegate = (MutableFloatState) objMutableFloatStateOf2;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            CardColors cardColorsM1829cardColorsro_MJ88 = CardDefaults.INSTANCE.m1829cardColorsro_MJ88(androidx.compose.ui.graphics.ColorKt.Color(4279179050L), 0L, 0L, 0L, $composer2, (CardDefaults.$stable << 12) | 6, 14);
            $composer2 = $composer2;
            RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(16));
            BorderStroke borderStrokeM252BorderStrokecXLIe8U = BorderStrokeKt.m252BorderStrokecXLIe8U(Dp.m6622constructorimpl(1), androidx.compose.ui.graphics.ColorKt.Color(4282595530L));
            Modifier modifierM720width3ABfNKs = SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(280));
            ComposerKt.sourceInformationMarkerStart($composer2, 1532198545, "CC(remember):QuizSandbox.kt#9igjgp");
            Object objRememberedValue3 = $composer2.rememberedValue();
            if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                obj = new Function1() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda8
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return QuizSandboxKt.SandboxAnswerCard$lambda$78$lambda$77(offsetX$delegate, offsetY$delegate, (Density) obj2);
                    }
                };
                $composer2.updateRememberedValue(obj);
            } else {
                obj = objRememberedValue3;
            }
            ComposerKt.sourceInformationMarkerEnd($composer2);
            Modifier modifierOffset = OffsetKt.offset(modifierM720width3ABfNKs, (Function1) obj);
            Unit unit = Unit.INSTANCE;
            ComposerKt.sourceInformationMarkerStart($composer2, 1532202605, "CC(remember):QuizSandbox.kt#9igjgp");
            boolean z = (($dirty & 112) == 32) | (($dirty & 896) == 256);
            Object objRememberedValue4 = $composer2.rememberedValue();
            if (z || objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                cornerPosition = cornerPos;
                function1 = function0;
                quizSandboxKt$SandboxAnswerCard$2$1 = new QuizSandboxKt$SandboxAnswerCard$2$1(cornerPosition, function1, offsetX$delegate, offsetY$delegate, null);
                $composer2.updateRememberedValue(quizSandboxKt$SandboxAnswerCard$2$1);
            } else {
                cornerPosition = cornerPos;
                function1 = function0;
                quizSandboxKt$SandboxAnswerCard$2$1 = objRememberedValue4;
            }
            ComposerKt.sourceInformationMarkerEnd($composer2);
            CardKt.Card(TestTagKt.testTag(SuspendingPointerInputFilterKt.pointerInput(modifierOffset, unit, (Function2<? super PointerInputScope, ? super Continuation<? super Unit>, ? extends Object>) quizSandboxKt$SandboxAnswerCard$2$1), "sandbox_answer_popup_card"), roundedCornerShapeM953RoundedCornerShape0680j_4, cardColorsM1829cardColorsro_MJ88, null, borderStrokeM252BorderStrokecXLIe8U, ComposableLambdaKt.rememberComposableLambda(1382660827, true, new Function3() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda9
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return QuizSandboxKt.SandboxAnswerCard$lambda$82(answer, function1, (ColumnScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                }
            }, $composer2, 54), $composer2, 221184, 8);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.QuizSandboxKt$$ExternalSyntheticLambda10
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return QuizSandboxKt.SandboxAnswerCard$lambda$83(answer, cornerPosition, function1, $changed, (Composer) obj2, ((Integer) obj3).intValue());
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float SandboxAnswerCard$lambda$72(MutableFloatState $offsetX$delegate) {
        return $offsetX$delegate.getFloatValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final float SandboxAnswerCard$lambda$75(MutableFloatState $offsetY$delegate) {
        return $offsetY$delegate.getFloatValue();
    }

    static final IntOffset SandboxAnswerCard$lambda$78$lambda$77(MutableFloatState $offsetX$delegate, MutableFloatState $offsetY$delegate, Density offset) {
        Intrinsics.checkNotNullParameter(offset, "$this$offset");
        return IntOffset.m6741boximpl(IntOffsetKt.IntOffset((int) SandboxAnswerCard$lambda$72($offsetX$delegate), (int) SandboxAnswerCard$lambda$75($offsetY$delegate)));
    }

    static final Unit SandboxAnswerCard$lambda$82(AnswerResult $answer, Function0 $onDismiss, ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        Function0<ComposeUiNode> function1;
        String str;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C686@24864L1606:QuizSandbox.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1382660827, $changed, -1, "com.example.ui.SandboxAnswerCard.<anonymous> (QuizSandbox.kt:686)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor;
                $composer.createNode(function0);
            } else {
                function0 = constructor;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i2 = (i >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            int i3 = ((6 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, 312252581, "C687@24915L664,711@25587L40,713@25635L147:QuizSandbox.kt#naom5h");
            Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap2 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i4 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function1 = constructor2;
                $composer.createNode(function1);
            } else {
                function1 = constructor2;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl2 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
            }
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            int i5 = (i4 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            int i6 = ((438 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, 1821021586, "C692@25095L175,698@25279L292:QuizSandbox.kt#naom5h");
            TextKt.m2693Text4IGK_g("SPRÁVNÁ ODPOVĚĎ (Potažením schovat)", (Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4287931320L), TextUnitKt.getSp(10), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 200070, 0, 131026);
            IconButtonKt.IconButton($onDismiss, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), false, null, null, ComposableSingletons$QuizSandboxKt.INSTANCE.m6942getLambda$1943980846$app(), $composer, 196656, 28);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(4)), $composer, 6);
            TextKt.m2693Text4IGK_g($answer.getDirectAnswer(), (Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4281652121L), TextUnitKt.getSp(16), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 200064, 0, 131026);
            if (StringsKt.isBlank($answer.getExplanation())) {
                $composer.startReplaceGroup(287487889);
            } else {
                $composer.startReplaceGroup(313115868);
                ComposerKt.sourceInformation($composer, "721@25837L40,722@25886L146");
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(4)), $composer, 6);
                TextKt.m2693Text4IGK_g($answer.getExplanation(), (Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4293060848L), TextUnitKt.getSp(12), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, TextUnitKt.getSp(16), 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3456, 6, 130034);
            }
            $composer.endReplaceGroup();
            if (StringsKt.isBlank($answer.getModelUsed())) {
                $composer.startReplaceGroup(287487889);
            } else {
                $composer.startReplaceGroup(313375028);
                ComposerKt.sourceInformation($composer, "731@26093L40,733@26281L175");
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), $composer, 6);
                if ($answer.getDurationMs() > 0) {
                    StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
                    String str2 = String.format(Locale.US, "%.1fs", Arrays.copyOf(new Object[]{Double.valueOf($answer.getDurationMs() / 1000.0d)}, 1));
                    Intrinsics.checkNotNullExpressionValue(str2, "format(...)");
                    str = " • " + str2;
                } else {
                    str = "";
                }
                TextKt.m2693Text4IGK_g("⚡ " + $answer.getModelUsed() + str, (Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4281652121L), TextUnitKt.getSp(10), (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 200064, 0, 131026);
            }
            $composer.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
