package com.example.model;

import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Models.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u001c\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B[\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n\u0012\u0006\u0010\f\u001a\u00020\r\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u000f\u001a\u00020\r¢\u0006\u0004\b\u0010\u0010\u0011J\t\u0010\u001f\u001a\u00020\u0003HÆ\u0003J\t\u0010 \u001a\u00020\u0005HÆ\u0003J\t\u0010!\u001a\u00020\u0003HÆ\u0003J\t\u0010\"\u001a\u00020\u0003HÆ\u0003J\t\u0010#\u001a\u00020\u0003HÆ\u0003J\u000f\u0010$\u001a\b\u0012\u0004\u0012\u00020\u000b0\nHÆ\u0003J\t\u0010%\u001a\u00020\rHÆ\u0003J\t\u0010&\u001a\u00020\u0003HÆ\u0003J\t\u0010'\u001a\u00020\rHÆ\u0003Ji\u0010(\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\u000e\b\u0002\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n2\b\b\u0002\u0010\f\u001a\u00020\r2\b\b\u0002\u0010\u000e\u001a\u00020\u00032\b\b\u0002\u0010\u000f\u001a\u00020\rHÆ\u0001J\u0013\u0010)\u001a\u00020*2\b\u0010+\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010,\u001a\u00020-HÖ\u0001J\t\u0010.\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0013R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0013R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0013R\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\f\u001a\u00020\r¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0011\u0010\u000e\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0013R\u0011\u0010\u000f\u001a\u00020\r¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001c¨\u0006/"}, d2 = {"Lcom/example/model/ScanHistoryItem;", "", "id", "", "optionShape", "Lcom/example/model/OptionShape;", "directAnswer", "explanation", "questionSummary", "sources", "", "Lcom/example/model/SearchSource;", "timestamp", "", "modelUsed", "durationMs", "<init>", "(Ljava/lang/String;Lcom/example/model/OptionShape;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;JLjava/lang/String;J)V", "getId", "()Ljava/lang/String;", "getOptionShape", "()Lcom/example/model/OptionShape;", "getDirectAnswer", "getExplanation", "getQuestionSummary", "getSources", "()Ljava/util/List;", "getTimestamp", "()J", "getModelUsed", "getDurationMs", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "", "other", "hashCode", "", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final /* data */ class ScanHistoryItem {
    public static final int $stable = 8;
    private final String directAnswer;
    private final long durationMs;
    private final String explanation;
    private final String id;
    private final String modelUsed;
    private final OptionShape optionShape;
    private final String questionSummary;
    private final List<SearchSource> sources;
    private final long timestamp;

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ ScanHistoryItem copy$default(ScanHistoryItem scanHistoryItem, String str, OptionShape optionShape, String str2, String str3, String str4, List list, long j, String str5, long j2, int i, Object obj) {
        if ((i & 1) != 0) {
            str = scanHistoryItem.id;
        }
        if ((i & 2) != 0) {
            optionShape = scanHistoryItem.optionShape;
        }
        if ((i & 4) != 0) {
            str2 = scanHistoryItem.directAnswer;
        }
        if ((i & 8) != 0) {
            str3 = scanHistoryItem.explanation;
        }
        if ((i & 16) != 0) {
            str4 = scanHistoryItem.questionSummary;
        }
        if ((i & 32) != 0) {
            list = scanHistoryItem.sources;
        }
        if ((i & 64) != 0) {
            j = scanHistoryItem.timestamp;
        }
        if ((i & 128) != 0) {
            str5 = scanHistoryItem.modelUsed;
        }
        if ((i & 256) != 0) {
            j2 = scanHistoryItem.durationMs;
        }
        String str6 = str5;
        long j3 = j;
        String str7 = str4;
        List list2 = list;
        String str8 = str2;
        String str9 = str3;
        return scanHistoryItem.copy(str, optionShape, str8, str9, str7, list2, j3, str6, j2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getId() {
        return this.id;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final OptionShape getOptionShape() {
        return this.optionShape;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getDirectAnswer() {
        return this.directAnswer;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final String getExplanation() {
        return this.explanation;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final String getQuestionSummary() {
        return this.questionSummary;
    }

    public final List<SearchSource> component6() {
        return this.sources;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final long getTimestamp() {
        return this.timestamp;
    }

    /* JADX INFO: renamed from: component8, reason: from getter */
    public final String getModelUsed() {
        return this.modelUsed;
    }

    /* JADX INFO: renamed from: component9, reason: from getter */
    public final long getDurationMs() {
        return this.durationMs;
    }

    public final ScanHistoryItem copy(String id, OptionShape optionShape, String directAnswer, String explanation, String questionSummary, List<SearchSource> sources, long timestamp, String modelUsed, long durationMs) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(optionShape, "optionShape");
        Intrinsics.checkNotNullParameter(directAnswer, "directAnswer");
        Intrinsics.checkNotNullParameter(explanation, "explanation");
        Intrinsics.checkNotNullParameter(questionSummary, "questionSummary");
        Intrinsics.checkNotNullParameter(sources, "sources");
        Intrinsics.checkNotNullParameter(modelUsed, "modelUsed");
        return new ScanHistoryItem(id, optionShape, directAnswer, explanation, questionSummary, sources, timestamp, modelUsed, durationMs);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ScanHistoryItem)) {
            return false;
        }
        ScanHistoryItem scanHistoryItem = (ScanHistoryItem) other;
        return Intrinsics.areEqual(this.id, scanHistoryItem.id) && this.optionShape == scanHistoryItem.optionShape && Intrinsics.areEqual(this.directAnswer, scanHistoryItem.directAnswer) && Intrinsics.areEqual(this.explanation, scanHistoryItem.explanation) && Intrinsics.areEqual(this.questionSummary, scanHistoryItem.questionSummary) && Intrinsics.areEqual(this.sources, scanHistoryItem.sources) && this.timestamp == scanHistoryItem.timestamp && Intrinsics.areEqual(this.modelUsed, scanHistoryItem.modelUsed) && this.durationMs == scanHistoryItem.durationMs;
    }

    public int hashCode() {
        return (((((((((((((((this.id.hashCode() * 31) + this.optionShape.hashCode()) * 31) + this.directAnswer.hashCode()) * 31) + this.explanation.hashCode()) * 31) + this.questionSummary.hashCode()) * 31) + this.sources.hashCode()) * 31) + Long.hashCode(this.timestamp)) * 31) + this.modelUsed.hashCode()) * 31) + Long.hashCode(this.durationMs);
    }

    public String toString() {
        return "ScanHistoryItem(id=" + this.id + ", optionShape=" + this.optionShape + ", directAnswer=" + this.directAnswer + ", explanation=" + this.explanation + ", questionSummary=" + this.questionSummary + ", sources=" + this.sources + ", timestamp=" + this.timestamp + ", modelUsed=" + this.modelUsed + ", durationMs=" + this.durationMs + ")";
    }

    public ScanHistoryItem(String id, OptionShape optionShape, String directAnswer, String explanation, String questionSummary, List<SearchSource> sources, long timestamp, String modelUsed, long durationMs) {
        Intrinsics.checkNotNullParameter(id, "id");
        Intrinsics.checkNotNullParameter(optionShape, "optionShape");
        Intrinsics.checkNotNullParameter(directAnswer, "directAnswer");
        Intrinsics.checkNotNullParameter(explanation, "explanation");
        Intrinsics.checkNotNullParameter(questionSummary, "questionSummary");
        Intrinsics.checkNotNullParameter(sources, "sources");
        Intrinsics.checkNotNullParameter(modelUsed, "modelUsed");
        this.id = id;
        this.optionShape = optionShape;
        this.directAnswer = directAnswer;
        this.explanation = explanation;
        this.questionSummary = questionSummary;
        this.sources = sources;
        this.timestamp = timestamp;
        this.modelUsed = modelUsed;
        this.durationMs = durationMs;
    }

    public /* synthetic */ ScanHistoryItem(String str, OptionShape optionShape, String str2, String str3, String str4, List list, long j, String str5, long j2, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, (i & 2) != 0 ? OptionShape.UNKNOWN : optionShape, str2, str3, str4, list, j, (i & 128) != 0 ? "" : str5, (i & 256) != 0 ? 0L : j2);
    }

    public final String getId() {
        return this.id;
    }

    public final OptionShape getOptionShape() {
        return this.optionShape;
    }

    public final String getDirectAnswer() {
        return this.directAnswer;
    }

    public final String getExplanation() {
        return this.explanation;
    }

    public final String getQuestionSummary() {
        return this.questionSummary;
    }

    public final List<SearchSource> getSources() {
        return this.sources;
    }

    public final long getTimestamp() {
        return this.timestamp;
    }

    public final String getModelUsed() {
        return this.modelUsed;
    }

    public final long getDurationMs() {
        return this.durationMs;
    }
}
