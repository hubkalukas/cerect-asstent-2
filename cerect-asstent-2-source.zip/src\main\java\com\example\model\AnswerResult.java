package com.example.model;

import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Models.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u001a\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001BY\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\b\u0012\b\b\u0002\u0010\n\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u000b\u001a\u00020\f\u0012\b\b\u0002\u0010\r\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u000e\u001a\u00020\f¢\u0006\u0004\b\u000f\u0010\u0010J\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0005HÆ\u0003J\u000f\u0010 \u001a\b\u0012\u0004\u0012\u00020\t0\bHÆ\u0003J\t\u0010!\u001a\u00020\u0005HÆ\u0003J\t\u0010\"\u001a\u00020\fHÆ\u0003J\t\u0010#\u001a\u00020\u0005HÆ\u0003J\t\u0010$\u001a\u00020\fHÆ\u0003J_\u0010%\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\b2\b\b\u0002\u0010\n\u001a\u00020\u00052\b\b\u0002\u0010\u000b\u001a\u00020\f2\b\b\u0002\u0010\r\u001a\u00020\u00052\b\b\u0002\u0010\u000e\u001a\u00020\fHÆ\u0001J\u0013\u0010&\u001a\u00020'2\b\u0010(\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010)\u001a\u00020*HÖ\u0001J\t\u0010+\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0014R\u0017\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\b¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0014R\u0011\u0010\u000b\u001a\u00020\f¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\r\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0014R\u0011\u0010\u000e\u001a\u00020\f¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001a¨\u0006,"}, d2 = {"Lcom/example/model/AnswerResult;", "", "optionShape", "Lcom/example/model/OptionShape;", "directAnswer", "", "explanation", "searchSources", "", "Lcom/example/model/SearchSource;", "questionSummary", "timestamp", "", "modelUsed", "durationMs", "<init>", "(Lcom/example/model/OptionShape;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;JLjava/lang/String;J)V", "getOptionShape", "()Lcom/example/model/OptionShape;", "getDirectAnswer", "()Ljava/lang/String;", "getExplanation", "getSearchSources", "()Ljava/util/List;", "getQuestionSummary", "getTimestamp", "()J", "getModelUsed", "getDurationMs", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "", "other", "hashCode", "", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final /* data */ class AnswerResult {
    public static final int $stable = 8;
    private final String directAnswer;
    private final long durationMs;
    private final String explanation;
    private final String modelUsed;
    private final OptionShape optionShape;
    private final String questionSummary;
    private final List<SearchSource> searchSources;
    private final long timestamp;

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ AnswerResult copy$default(AnswerResult answerResult, OptionShape optionShape, String str, String str2, List list, String str3, long j, String str4, long j2, int i, Object obj) {
        if ((i & 1) != 0) {
            optionShape = answerResult.optionShape;
        }
        if ((i & 2) != 0) {
            str = answerResult.directAnswer;
        }
        if ((i & 4) != 0) {
            str2 = answerResult.explanation;
        }
        if ((i & 8) != 0) {
            list = answerResult.searchSources;
        }
        if ((i & 16) != 0) {
            str3 = answerResult.questionSummary;
        }
        if ((i & 32) != 0) {
            j = answerResult.timestamp;
        }
        if ((i & 64) != 0) {
            str4 = answerResult.modelUsed;
        }
        if ((i & 128) != 0) {
            j2 = answerResult.durationMs;
        }
        String str5 = str4;
        long j3 = j;
        List list2 = list;
        String str6 = str3;
        String str7 = str2;
        return answerResult.copy(optionShape, str, str7, list2, str6, j3, str5, j2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final OptionShape getOptionShape() {
        return this.optionShape;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getDirectAnswer() {
        return this.directAnswer;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getExplanation() {
        return this.explanation;
    }

    public final List<SearchSource> component4() {
        return this.searchSources;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final String getQuestionSummary() {
        return this.questionSummary;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final long getTimestamp() {
        return this.timestamp;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final String getModelUsed() {
        return this.modelUsed;
    }

    /* JADX INFO: renamed from: component8, reason: from getter */
    public final long getDurationMs() {
        return this.durationMs;
    }

    public final AnswerResult copy(OptionShape optionShape, String directAnswer, String explanation, List<SearchSource> searchSources, String questionSummary, long timestamp, String modelUsed, long durationMs) {
        Intrinsics.checkNotNullParameter(optionShape, "optionShape");
        Intrinsics.checkNotNullParameter(directAnswer, "directAnswer");
        Intrinsics.checkNotNullParameter(explanation, "explanation");
        Intrinsics.checkNotNullParameter(searchSources, "searchSources");
        Intrinsics.checkNotNullParameter(questionSummary, "questionSummary");
        Intrinsics.checkNotNullParameter(modelUsed, "modelUsed");
        return new AnswerResult(optionShape, directAnswer, explanation, searchSources, questionSummary, timestamp, modelUsed, durationMs);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof AnswerResult)) {
            return false;
        }
        AnswerResult answerResult = (AnswerResult) other;
        return this.optionShape == answerResult.optionShape && Intrinsics.areEqual(this.directAnswer, answerResult.directAnswer) && Intrinsics.areEqual(this.explanation, answerResult.explanation) && Intrinsics.areEqual(this.searchSources, answerResult.searchSources) && Intrinsics.areEqual(this.questionSummary, answerResult.questionSummary) && this.timestamp == answerResult.timestamp && Intrinsics.areEqual(this.modelUsed, answerResult.modelUsed) && this.durationMs == answerResult.durationMs;
    }

    public int hashCode() {
        return (((((((((((((this.optionShape.hashCode() * 31) + this.directAnswer.hashCode()) * 31) + this.explanation.hashCode()) * 31) + this.searchSources.hashCode()) * 31) + this.questionSummary.hashCode()) * 31) + Long.hashCode(this.timestamp)) * 31) + this.modelUsed.hashCode()) * 31) + Long.hashCode(this.durationMs);
    }

    public String toString() {
        return "AnswerResult(optionShape=" + this.optionShape + ", directAnswer=" + this.directAnswer + ", explanation=" + this.explanation + ", searchSources=" + this.searchSources + ", questionSummary=" + this.questionSummary + ", timestamp=" + this.timestamp + ", modelUsed=" + this.modelUsed + ", durationMs=" + this.durationMs + ")";
    }

    public AnswerResult(OptionShape optionShape, String directAnswer, String explanation, List<SearchSource> searchSources, String questionSummary, long timestamp, String modelUsed, long durationMs) {
        Intrinsics.checkNotNullParameter(optionShape, "optionShape");
        Intrinsics.checkNotNullParameter(directAnswer, "directAnswer");
        Intrinsics.checkNotNullParameter(explanation, "explanation");
        Intrinsics.checkNotNullParameter(searchSources, "searchSources");
        Intrinsics.checkNotNullParameter(questionSummary, "questionSummary");
        Intrinsics.checkNotNullParameter(modelUsed, "modelUsed");
        this.optionShape = optionShape;
        this.directAnswer = directAnswer;
        this.explanation = explanation;
        this.searchSources = searchSources;
        this.questionSummary = questionSummary;
        this.timestamp = timestamp;
        this.modelUsed = modelUsed;
        this.durationMs = durationMs;
    }

    public /* synthetic */ AnswerResult(OptionShape optionShape, String str, String str2, List list, String str3, long j, String str4, long j2, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? OptionShape.UNKNOWN : optionShape, str, str2, (i & 8) != 0 ? CollectionsKt.emptyList() : list, (i & 16) != 0 ? "" : str3, (i & 32) != 0 ? System.currentTimeMillis() : j, (i & 64) != 0 ? "" : str4, (i & 128) != 0 ? 0L : j2);
    }

    public final OptionShape getOptionShape() {
        return this.optionShape;
    }

    public final String getDirectAnswer() {
        return this.directAnswer;
    }

    public final String getExplanation() {
        return this.explanation;
    }

    public final List<SearchSource> getSearchSources() {
        return this.searchSources;
    }

    public final String getQuestionSummary() {
        return this.questionSummary;
    }

    public final long getTimestamp() {
        return this.timestamp;
    }

    public final String getModelUsed() {
        return this.modelUsed;
    }

    public final long getDurationMs() {
        return this.durationMs;
    }
}
