package com.example.data;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;

/* JADX INFO: compiled from: GeminiService.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@DebugMetadata(c = "com.example.data.GeminiService$analyzeScreen$2$2$modelResponse$1", f = "GeminiService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {})
final class GeminiService$analyzeScreen$2$2$modelResponse$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super String>, Object> {
    final /* synthetic */ String $apiKey;
    final /* synthetic */ String $model;
    final /* synthetic */ String $requestBodyString;
    int label;
    final /* synthetic */ GeminiService this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    GeminiService$analyzeScreen$2$2$modelResponse$1(GeminiService geminiService, String str, String str2, String str3, Continuation<? super GeminiService$analyzeScreen$2$2$modelResponse$1> continuation) {
        super(2, continuation);
        this.this$0 = geminiService;
        this.$model = str;
        this.$apiKey = str2;
        this.$requestBodyString = str3;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        return new GeminiService$analyzeScreen$2$2$modelResponse$1(this.this$0, this.$model, this.$apiKey, this.$requestBodyString, continuation);
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super String> continuation) {
        return ((GeminiService$analyzeScreen$2$2$modelResponse$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object $result) {
        IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                return this.this$0.executeModelRequest(this.$model, this.$apiKey, this.$requestBodyString);
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
    }
}
