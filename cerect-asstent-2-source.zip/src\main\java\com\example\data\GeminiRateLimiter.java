package com.example.data;

import android.content.Context;
import android.content.SharedPreferences;
import com.example.model.ModelQuotaInfo;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;

/* JADX INFO: compiled from: GeminiRateLimiter.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0007\b\u0007\u0018\u0000 *2\u00020\u0001:\u0002*+B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\b\u0010\u0013\u001a\u00020\u0014H\u0002J\b\u0010\u0015\u001a\u00020\u0016H\u0002J\u0006\u0010\u0017\u001a\u00020\u0016J\f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00140\tJ\u000e\u0010\u0019\u001a\u00020\u00162\u0006\u0010\u001a\u001a\u00020\u0014J\u000e\u0010\u001b\u001a\u00020\u00162\u0006\u0010\u001a\u001a\u00020\u0014J\u000e\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001a\u001a\u00020\u0014J\u000e\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u001a\u001a\u00020\u0014J\u0016\u0010\u001f\u001a\u00020\u00162\u0006\u0010\u001a\u001a\u00020\u00142\u0006\u0010 \u001a\u00020\u001dJ\u000e\u0010!\u001a\u00020\"2\u0006\u0010\u001a\u001a\u00020\u0014J\u000e\u0010#\u001a\u00020\"2\u0006\u0010\u001a\u001a\u00020\u0014J\u001e\u0010$\u001a\b\u0012\u0004\u0012\u00020%0\t2\u0006\u0010\u001a\u001a\u00020\u00142\u0006\u0010&\u001a\u00020%H\u0002J\u0006\u0010'\u001a\u00020\u0016J\u0006\u0010(\u001a\u00020\u000eJ\b\u0010)\u001a\u00020\u000eH\u0002R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u000e0\u0010¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012¨\u0006,"}, d2 = {"Lcom/example/data/GeminiRateLimiter;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "prefs", "Landroid/content/SharedPreferences;", "primaryModelConfigs", "", "Lcom/example/data/GeminiRateLimiter$ModelConfig;", "emergencyModelConfigs", "_overviewFlow", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/example/data/RateLimiterOverview;", "overviewFlow", "Lkotlinx/coroutines/flow/StateFlow;", "getOverviewFlow", "()Lkotlinx/coroutines/flow/StateFlow;", "getTodayDateString", "", "ensureInitialized", "", "checkDailyReset", "getCandidateModels", "recordCall", "modelId", "markExhausted", "isExhaustedToday", "", "isBlocked", "setBlocked", "blocked", "getCallsToday", "", "getCallsThisMinute", "getValidTimestamps", "", "now", "resetAllCounters", "getOverview", "buildOverview", "Companion", "ModelConfig", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class GeminiRateLimiter {
    private static final String KEY_BLOCKED_PREFIX = "rl_blocked_";
    private static final String KEY_CALLS_TODAY_PREFIX = "rl_calls_today_";
    private static final String KEY_EXHAUSTED_DATE_PREFIX = "rl_exhausted_date_";
    private static final String KEY_INIT_DONE = "rl_init_done_v1";
    private static final String KEY_LAST_DATE = "rl_last_date";
    private static final String KEY_TIMESTAMPS_PREFIX = "rl_timestamps_";
    public static final String MODEL_20_FLASH = "gemini-2.0-flash";
    public static final String MODEL_25_FLASH = "gemini-2.5-flash";
    public static final String MODEL_30_FLASH = "gemini-3-flash";
    public static final String MODEL_31_FLASH_LITE = "gemini-3.1-flash-lite-preview";
    public static final String MODEL_31_FLASH_LITE_STABLE = "gemini-3.1-flash-lite";
    public static final String MODEL_35_FLASH = "gemini-3.5-flash";
    public static final String MODEL_35_FLASH_LITE = "gemini-3.5-flash-lite";
    public static final String MODEL_37_FLASH = "gemini-3.7-flash";
    public static final String MODEL_38_FLASH = "gemini-3.8-flash";
    private final MutableStateFlow<RateLimiterOverview> _overviewFlow;
    private final List<ModelConfig> emergencyModelConfigs;
    private final StateFlow<RateLimiterOverview> overviewFlow;
    private final SharedPreferences prefs;
    private final List<ModelConfig> primaryModelConfigs;
    public static final int $stable = 8;

    /* JADX WARN: Multi-variable type inference failed */
    public GeminiRateLimiter(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        SharedPreferences sharedPreferences = context.getSharedPreferences("gemini_rate_limiter_prefs_v2", 0);
        Intrinsics.checkNotNullExpressionValue(sharedPreferences, "getSharedPreferences(...)");
        this.prefs = sharedPreferences;
        this.primaryModelConfigs = CollectionsKt.listOf((Object[]) new ModelConfig[]{new ModelConfig(MODEL_35_FLASH_LITE, "Gemini 3.5 Flash Lite", true, 500, 480, 15, 14, false, 0, 384, null), new ModelConfig(MODEL_31_FLASH_LITE, "Gemini 3.1 Flash Lite", true, 500, 480, 15, 14, 0 == true ? 1 : 0, 0, 384, null)});
        this.emergencyModelConfigs = CollectionsKt.listOf((Object[]) new ModelConfig[]{new ModelConfig(MODEL_35_FLASH, "Gemini 3.5 Flash", false, 20, 18, 5, 4, true, 22), new ModelConfig(MODEL_25_FLASH, "Gemini 2.5 Flash", false, 20, 18, 5, 4, false, 0, 384, null), new ModelConfig(MODEL_38_FLASH, "Gemini 3.8 Flash", false, 20, 18, 5, 4, 0 == true ? 1 : 0, 0, 384, null), new ModelConfig(MODEL_37_FLASH, "Gemini 3.7 Flash", false, 20, 18, 5, 4, 0 == true ? 1 : 0, 0, 384, null), new ModelConfig(MODEL_30_FLASH, "Gemini 3.0 Flash", false, 20, 18, 5, 4, 0 == true ? 1 : 0, 0, 384, null), new ModelConfig(MODEL_20_FLASH, "Gemini 2.0 Flash", false, 20, 18, 5, 4, 0 == true ? 1 : 0, 0, 384, null)});
        this._overviewFlow = StateFlowKt.MutableStateFlow(buildOverview());
        this.overviewFlow = FlowKt.asStateFlow(this._overviewFlow);
        ensureInitialized();
        checkDailyReset();
        this._overviewFlow.setValue(buildOverview());
    }

    public final StateFlow<RateLimiterOverview> getOverviewFlow() {
        return this.overviewFlow;
    }

    private final String getTodayDateString() {
        String str = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        Intrinsics.checkNotNullExpressionValue(str, "format(...)");
        return str;
    }

    private final void ensureInitialized() {
        if (!this.prefs.getBoolean(KEY_INIT_DONE, false)) {
            SharedPreferences.Editor editor = this.prefs.edit();
            editor.putString(KEY_LAST_DATE, getTodayDateString());
            editor.putBoolean("rl_blocked_gemini-3.5-flash", true);
            editor.putInt("rl_calls_today_gemini-3.5-flash", 22);
            editor.putBoolean(KEY_INIT_DONE, true);
            editor.apply();
        }
    }

    public final synchronized void checkDailyReset() {
        String today = getTodayDateString();
        String lastDate = this.prefs.getString(KEY_LAST_DATE, "");
        if (lastDate == null) {
            lastDate = "";
        }
        if (!Intrinsics.areEqual(lastDate, today)) {
            SharedPreferences.Editor editor = this.prefs.edit();
            editor.putString(KEY_LAST_DATE, today);
            for (ModelConfig cfg : CollectionsKt.plus((Collection) this.primaryModelConfigs, (Iterable) this.emergencyModelConfigs)) {
                if (!Intrinsics.areEqual(cfg.getId(), MODEL_35_FLASH)) {
                    editor.putInt(KEY_CALLS_TODAY_PREFIX + cfg.getId(), 0);
                    editor.remove(KEY_EXHAUSTED_DATE_PREFIX + cfg.getId());
                }
            }
            editor.apply();
        }
    }

    public final synchronized List<String> getCandidateModels() {
        List candidates;
        checkDailyReset();
        candidates = new ArrayList();
        int lite35Calls = getCallsToday(MODEL_35_FLASH_LITE);
        int lite35Rpm = getCallsThisMinute(MODEL_35_FLASH_LITE);
        boolean lite35Exhausted = isExhaustedToday(MODEL_35_FLASH_LITE);
        int lite31Calls = getCallsToday(MODEL_31_FLASH_LITE);
        int lite31Rpm = getCallsThisMinute(MODEL_31_FLASH_LITE);
        boolean lite31Exhausted = isExhaustedToday(MODEL_31_FLASH_LITE);
        boolean lite35Eligible = lite35Calls < 480 && lite35Rpm < 14 && !lite35Exhausted;
        boolean lite31Eligible = lite31Calls < 480 && lite31Rpm < 14 && !lite31Exhausted;
        if (lite35Eligible) {
            candidates.add(MODEL_35_FLASH_LITE);
            if (lite31Eligible) {
                candidates.add(MODEL_31_FLASH_LITE);
                candidates.add(MODEL_31_FLASH_LITE_STABLE);
            }
        } else if (lite31Eligible) {
            candidates.add(MODEL_31_FLASH_LITE);
            candidates.add(MODEL_31_FLASH_LITE_STABLE);
            if (!lite35Exhausted && lite35Calls < 500) {
                candidates.add(MODEL_35_FLASH_LITE);
            }
        } else {
            if (!lite35Exhausted && lite35Calls < 500) {
                candidates.add(MODEL_35_FLASH_LITE);
            }
            if (!lite31Exhausted && lite31Calls < 500) {
                candidates.add(MODEL_31_FLASH_LITE);
                candidates.add(MODEL_31_FLASH_LITE_STABLE);
            }
        }
        List<String> emergencyOrder = CollectionsKt.listOf((Object[]) new String[]{MODEL_25_FLASH, MODEL_38_FLASH, MODEL_37_FLASH, MODEL_30_FLASH, MODEL_20_FLASH});
        for (String emId : emergencyOrder) {
            int calls = getCallsToday(emId);
            int rpm = getCallsThisMinute(emId);
            boolean exhausted = isExhaustedToday(emId);
            boolean blocked = isBlocked(emId);
            if (!blocked && !exhausted && calls < 18 && rpm < 4) {
                candidates.add(emId);
            }
        }
        return CollectionsKt.distinct(candidates);
    }

    public final synchronized void recordCall(String modelId) {
        Intrinsics.checkNotNullParameter(modelId, "modelId");
        checkDailyReset();
        long now = System.currentTimeMillis();
        int todayCalls = getCallsToday(modelId) + 1;
        SharedPreferences.Editor editor = this.prefs.edit();
        editor.putInt(KEY_CALLS_TODAY_PREFIX + modelId, todayCalls);
        List existingTimestamps = CollectionsKt.toMutableList((Collection) getValidTimestamps(modelId, now));
        existingTimestamps.add(Long.valueOf(now));
        editor.putString(KEY_TIMESTAMPS_PREFIX + modelId, CollectionsKt.joinToString$default(existingTimestamps, ",", null, null, 0, null, null, 62, null));
        editor.apply();
        this._overviewFlow.setValue(buildOverview());
    }

    public final synchronized void markExhausted(String modelId) {
        Intrinsics.checkNotNullParameter(modelId, "modelId");
        String today = getTodayDateString();
        this.prefs.edit().putString(KEY_EXHAUSTED_DATE_PREFIX + modelId, today).apply();
        this._overviewFlow.setValue(buildOverview());
    }

    public final boolean isExhaustedToday(String modelId) {
        Intrinsics.checkNotNullParameter(modelId, "modelId");
        String today = getTodayDateString();
        String date = this.prefs.getString(KEY_EXHAUSTED_DATE_PREFIX + modelId, "");
        return Intrinsics.areEqual(date, today);
    }

    public final boolean isBlocked(String modelId) {
        Intrinsics.checkNotNullParameter(modelId, "modelId");
        return this.prefs.getBoolean(KEY_BLOCKED_PREFIX + modelId, false);
    }

    public final void setBlocked(String modelId, boolean blocked) {
        Intrinsics.checkNotNullParameter(modelId, "modelId");
        this.prefs.edit().putBoolean(KEY_BLOCKED_PREFIX + modelId, blocked).apply();
        this._overviewFlow.setValue(buildOverview());
    }

    public final int getCallsToday(String modelId) {
        Intrinsics.checkNotNullParameter(modelId, "modelId");
        checkDailyReset();
        return this.prefs.getInt(KEY_CALLS_TODAY_PREFIX + modelId, 0);
    }

    public final int getCallsThisMinute(String modelId) {
        Intrinsics.checkNotNullParameter(modelId, "modelId");
        long now = System.currentTimeMillis();
        return getValidTimestamps(modelId, now).size();
    }

    private final List<Long> getValidTimestamps(String modelId, long now) {
        String string = this.prefs.getString(KEY_TIMESTAMPS_PREFIX + modelId, "");
        String raw = string != null ? string : "";
        if (StringsKt.isBlank(raw)) {
            return CollectionsKt.emptyList();
        }
        Iterable iterableSplit$default = StringsKt.split$default((CharSequence) raw, new String[]{","}, false, 0, 6, (Object) null);
        Collection arrayList = new ArrayList();
        Iterator it = iterableSplit$default.iterator();
        while (it.hasNext()) {
            Long longOrNull = StringsKt.toLongOrNull(StringsKt.trim((CharSequence) it.next()).toString());
            if (longOrNull != null) {
                arrayList.add(longOrNull);
            }
        }
        List list = (List) arrayList;
        Collection arrayList2 = new ArrayList();
        for (Object obj : list) {
            long jLongValue = now - ((Number) obj).longValue();
            if (0 <= jLongValue && jLongValue < 60001) {
                arrayList2.add(obj);
            }
        }
        List filtered = (List) arrayList2;
        if (filtered.size() != list.size()) {
            this.prefs.edit().putString(KEY_TIMESTAMPS_PREFIX + modelId, CollectionsKt.joinToString$default(filtered, ",", null, null, 0, null, null, 62, null)).apply();
        }
        return filtered;
    }

    public final synchronized void resetAllCounters() {
        SharedPreferences.Editor editor = this.prefs.edit();
        String today = getTodayDateString();
        editor.putString(KEY_LAST_DATE, today);
        for (ModelConfig cfg : CollectionsKt.plus((Collection) this.primaryModelConfigs, (Iterable) this.emergencyModelConfigs)) {
            editor.putInt(KEY_CALLS_TODAY_PREFIX + cfg.getId(), 0);
            editor.remove(KEY_TIMESTAMPS_PREFIX + cfg.getId());
            editor.remove(KEY_EXHAUSTED_DATE_PREFIX + cfg.getId());
        }
        editor.putBoolean("rl_blocked_gemini-3.5-flash", true);
        editor.putInt("rl_calls_today_gemini-3.5-flash", 22);
        editor.apply();
        this._overviewFlow.setValue(buildOverview());
    }

    public final RateLimiterOverview getOverview() {
        return buildOverview();
    }

    private final RateLimiterOverview buildOverview() {
        long now = System.currentTimeMillis();
        Iterable<ModelConfig> iterable = this.primaryModelConfigs;
        Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
        for (ModelConfig modelConfig : iterable) {
            arrayList.add(new ModelQuotaInfo(modelConfig.getId(), modelConfig.getDisplayName(), true, modelConfig.getDailyLimit(), modelConfig.getSafetyCutoff(), modelConfig.getMinuteLimit(), this.prefs.getInt(KEY_CALLS_TODAY_PREFIX + modelConfig.getId(), 0), getValidTimestamps(modelConfig.getId(), now).size(), isExhaustedToday(modelConfig.getId()), isBlocked(modelConfig.getId())));
        }
        List primaryInfos = (List) arrayList;
        Iterable<ModelConfig> iterable2 = this.emergencyModelConfigs;
        Collection arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable2, 10));
        for (ModelConfig modelConfig2 : iterable2) {
            Iterable iterable3 = iterable2;
            arrayList2.add(new ModelQuotaInfo(modelConfig2.getId(), modelConfig2.getDisplayName(), false, modelConfig2.getDailyLimit(), modelConfig2.getSafetyCutoff(), modelConfig2.getMinuteLimit(), this.prefs.getInt(KEY_CALLS_TODAY_PREFIX + modelConfig2.getId(), Intrinsics.areEqual(modelConfig2.getId(), MODEL_35_FLASH) ? 22 : 0), getValidTimestamps(modelConfig2.getId(), now).size(), isExhaustedToday(modelConfig2.getId()), isBlocked(modelConfig2.getId()) || (Intrinsics.areEqual(modelConfig2.getId(), MODEL_35_FLASH) && this.prefs.getBoolean("rl_blocked_gemini-3.5-flash", true))));
            iterable2 = iterable3;
        }
        List emergencyInfos = (List) arrayList2;
        Iterator it = primaryInfos.iterator();
        int callsToday = 0;
        while (it.hasNext()) {
            callsToday += ((ModelQuotaInfo) it.next()).getCallsToday();
        }
        int totalLiteCalls = callsToday;
        Iterator it2 = primaryInfos.iterator();
        int totalLiteRpm = 0;
        while (it2.hasNext()) {
            totalLiteRpm += ((ModelQuotaInfo) it2.next()).getCallsThisMinute();
        }
        int totalLiteRemaining = RangesKt.coerceAtLeast(1000 - totalLiteCalls, 0);
        return new RateLimiterOverview(totalLiteRemaining, totalLiteCalls, totalLiteRpm, primaryInfos, emergencyInfos);
    }

    /* JADX INFO: compiled from: GeminiRateLimiter.kt */
    @Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b!\b\u0082\b\u0018\u00002\u00020\u0001BS\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\b\u0012\u0006\u0010\n\u001a\u00020\b\u0012\u0006\u0010\u000b\u001a\u00020\b\u0012\b\b\u0002\u0010\f\u001a\u00020\u0006\u0012\b\b\u0002\u0010\r\u001a\u00020\b¢\u0006\u0004\b\u000e\u0010\u000fJ\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0006HÆ\u0003J\t\u0010\u001e\u001a\u00020\bHÆ\u0003J\t\u0010\u001f\u001a\u00020\bHÆ\u0003J\t\u0010 \u001a\u00020\bHÆ\u0003J\t\u0010!\u001a\u00020\bHÆ\u0003J\t\u0010\"\u001a\u00020\u0006HÆ\u0003J\t\u0010#\u001a\u00020\bHÆ\u0003Jc\u0010$\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\b2\b\b\u0002\u0010\n\u001a\u00020\b2\b\b\u0002\u0010\u000b\u001a\u00020\b2\b\b\u0002\u0010\f\u001a\u00020\u00062\b\b\u0002\u0010\r\u001a\u00020\bHÆ\u0001J\u0013\u0010%\u001a\u00020\u00062\b\u0010&\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010'\u001a\u00020\bHÖ\u0001J\t\u0010(\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0011R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0013R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\t\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0015R\u0011\u0010\n\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0015R\u0011\u0010\u000b\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0015R\u0011\u0010\f\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0013R\u0011\u0010\r\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0015¨\u0006)"}, d2 = {"Lcom/example/data/GeminiRateLimiter$ModelConfig;", "", "id", "", "displayName", "isLite", "", "dailyLimit", "", "safetyCutoff", "minuteLimit", "safetyMinuteCutoff", "defaultBlocked", "initialCalls", "<init>", "(Ljava/lang/String;Ljava/lang/String;ZIIIIZI)V", "getId", "()Ljava/lang/String;", "getDisplayName", "()Z", "getDailyLimit", "()I", "getSafetyCutoff", "getMinuteLimit", "getSafetyMinuteCutoff", "getDefaultBlocked", "getInitialCalls", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    private static final /* data */ class ModelConfig {
        private final int dailyLimit;
        private final boolean defaultBlocked;
        private final String displayName;
        private final String id;
        private final int initialCalls;
        private final boolean isLite;
        private final int minuteLimit;
        private final int safetyCutoff;
        private final int safetyMinuteCutoff;

        public static /* synthetic */ ModelConfig copy$default(ModelConfig modelConfig, String str, String str2, boolean z, int i, int i2, int i3, int i4, boolean z2, int i5, int i6, Object obj) {
            if ((i6 & 1) != 0) {
                str = modelConfig.id;
            }
            if ((i6 & 2) != 0) {
                str2 = modelConfig.displayName;
            }
            if ((i6 & 4) != 0) {
                z = modelConfig.isLite;
            }
            if ((i6 & 8) != 0) {
                i = modelConfig.dailyLimit;
            }
            if ((i6 & 16) != 0) {
                i2 = modelConfig.safetyCutoff;
            }
            if ((i6 & 32) != 0) {
                i3 = modelConfig.minuteLimit;
            }
            if ((i6 & 64) != 0) {
                i4 = modelConfig.safetyMinuteCutoff;
            }
            if ((i6 & 128) != 0) {
                z2 = modelConfig.defaultBlocked;
            }
            if ((i6 & 256) != 0) {
                i5 = modelConfig.initialCalls;
            }
            boolean z3 = z2;
            int i7 = i5;
            int i8 = i3;
            int i9 = i4;
            int i10 = i2;
            boolean z4 = z;
            return modelConfig.copy(str, str2, z4, i, i10, i8, i9, z3, i7);
        }

        /* JADX INFO: renamed from: component1, reason: from getter */
        public final String getId() {
            return this.id;
        }

        /* JADX INFO: renamed from: component2, reason: from getter */
        public final String getDisplayName() {
            return this.displayName;
        }

        /* JADX INFO: renamed from: component3, reason: from getter */
        public final boolean getIsLite() {
            return this.isLite;
        }

        /* JADX INFO: renamed from: component4, reason: from getter */
        public final int getDailyLimit() {
            return this.dailyLimit;
        }

        /* JADX INFO: renamed from: component5, reason: from getter */
        public final int getSafetyCutoff() {
            return this.safetyCutoff;
        }

        /* JADX INFO: renamed from: component6, reason: from getter */
        public final int getMinuteLimit() {
            return this.minuteLimit;
        }

        /* JADX INFO: renamed from: component7, reason: from getter */
        public final int getSafetyMinuteCutoff() {
            return this.safetyMinuteCutoff;
        }

        /* JADX INFO: renamed from: component8, reason: from getter */
        public final boolean getDefaultBlocked() {
            return this.defaultBlocked;
        }

        /* JADX INFO: renamed from: component9, reason: from getter */
        public final int getInitialCalls() {
            return this.initialCalls;
        }

        public final ModelConfig copy(String id, String displayName, boolean isLite, int dailyLimit, int safetyCutoff, int minuteLimit, int safetyMinuteCutoff, boolean defaultBlocked, int initialCalls) {
            Intrinsics.checkNotNullParameter(id, "id");
            Intrinsics.checkNotNullParameter(displayName, "displayName");
            return new ModelConfig(id, displayName, isLite, dailyLimit, safetyCutoff, minuteLimit, safetyMinuteCutoff, defaultBlocked, initialCalls);
        }

        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof ModelConfig)) {
                return false;
            }
            ModelConfig modelConfig = (ModelConfig) other;
            return Intrinsics.areEqual(this.id, modelConfig.id) && Intrinsics.areEqual(this.displayName, modelConfig.displayName) && this.isLite == modelConfig.isLite && this.dailyLimit == modelConfig.dailyLimit && this.safetyCutoff == modelConfig.safetyCutoff && this.minuteLimit == modelConfig.minuteLimit && this.safetyMinuteCutoff == modelConfig.safetyMinuteCutoff && this.defaultBlocked == modelConfig.defaultBlocked && this.initialCalls == modelConfig.initialCalls;
        }

        public int hashCode() {
            return (((((((((((((((this.id.hashCode() * 31) + this.displayName.hashCode()) * 31) + Boolean.hashCode(this.isLite)) * 31) + Integer.hashCode(this.dailyLimit)) * 31) + Integer.hashCode(this.safetyCutoff)) * 31) + Integer.hashCode(this.minuteLimit)) * 31) + Integer.hashCode(this.safetyMinuteCutoff)) * 31) + Boolean.hashCode(this.defaultBlocked)) * 31) + Integer.hashCode(this.initialCalls);
        }

        public String toString() {
            return "ModelConfig(id=" + this.id + ", displayName=" + this.displayName + ", isLite=" + this.isLite + ", dailyLimit=" + this.dailyLimit + ", safetyCutoff=" + this.safetyCutoff + ", minuteLimit=" + this.minuteLimit + ", safetyMinuteCutoff=" + this.safetyMinuteCutoff + ", defaultBlocked=" + this.defaultBlocked + ", initialCalls=" + this.initialCalls + ")";
        }

        public ModelConfig(String id, String displayName, boolean isLite, int dailyLimit, int safetyCutoff, int minuteLimit, int safetyMinuteCutoff, boolean defaultBlocked, int initialCalls) {
            Intrinsics.checkNotNullParameter(id, "id");
            Intrinsics.checkNotNullParameter(displayName, "displayName");
            this.id = id;
            this.displayName = displayName;
            this.isLite = isLite;
            this.dailyLimit = dailyLimit;
            this.safetyCutoff = safetyCutoff;
            this.minuteLimit = minuteLimit;
            this.safetyMinuteCutoff = safetyMinuteCutoff;
            this.defaultBlocked = defaultBlocked;
            this.initialCalls = initialCalls;
        }

        /* JADX WARN: Illegal instructions before constructor call */
        public /* synthetic */ ModelConfig(String str, String str2, boolean z, int i, int i2, int i3, int i4, boolean z2, int i5, int i6, DefaultConstructorMarker defaultConstructorMarker) {
            int i7;
            z2 = (i6 & 128) != 0 ? false : z2;
            if ((i6 & 256) == 0) {
                i7 = i5;
            } else {
                i7 = 0;
            }
            this(str, str2, z, i, i2, i3, i4, z2, i7);
        }

        public final String getId() {
            return this.id;
        }

        public final String getDisplayName() {
            return this.displayName;
        }

        public final boolean isLite() {
            return this.isLite;
        }

        public final int getDailyLimit() {
            return this.dailyLimit;
        }

        public final int getSafetyCutoff() {
            return this.safetyCutoff;
        }

        public final int getMinuteLimit() {
            return this.minuteLimit;
        }

        public final int getSafetyMinuteCutoff() {
            return this.safetyMinuteCutoff;
        }

        public final boolean getDefaultBlocked() {
            return this.defaultBlocked;
        }

        public final int getInitialCalls() {
            return this.initialCalls;
        }
    }
}
