package com.example.service;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import java.nio.ByteBuffer;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: ScreenCaptureManager.kt */
/* JADX INFO: loaded from: classes5.dex */
@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0007\u0018\u0000 \u001d2\u00020\u0001:\u0001\u001dB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J.\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u00132\u0006\u0010\u0017\u001a\u00020\u00132\u0006\u0010\u0018\u001a\u00020\u0013J\b\u0010\u0019\u001a\u0004\u0018\u00010\u001aJ\u0006\u0010\u001b\u001a\u00020\u001cR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0007X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u0004\u0018\u00010\tX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\n\u001a\u0004\u0018\u00010\u000bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u0004\u0018\u00010\u000fX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u001e"}, d2 = {"Lcom/example/service/ScreenCaptureManager;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "mediaProjection", "Landroid/media/projection/MediaProjection;", "virtualDisplay", "Landroid/hardware/display/VirtualDisplay;", "imageReader", "Landroid/media/ImageReader;", "handler", "Landroid/os/Handler;", "mediaProjectionCallback", "Landroid/media/projection/MediaProjection$Callback;", "initialize", "", "resultCode", "", "data", "Landroid/content/Intent;", "width", "height", "densityDpi", "captureScreen", "Landroid/graphics/Bitmap;", "release", "", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ScreenCaptureManager {
    private static final String TAG = "ScreenCaptureManager";
    private static final String VIRTUAL_DISPLAY_NAME = "CornerCaptureDisplay";
    private final Context context;
    private final Handler handler;
    private ImageReader imageReader;
    private MediaProjection mediaProjection;
    private MediaProjection.Callback mediaProjectionCallback;
    private VirtualDisplay virtualDisplay;
    public static final int $stable = 8;

    public ScreenCaptureManager(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        this.context = context;
        this.handler = new Handler(Looper.getMainLooper());
    }

    public final boolean initialize(int resultCode, Intent data, int width, int height, int densityDpi) {
        Intrinsics.checkNotNullParameter(data, "data");
        try {
            Object systemService = this.context.getSystemService("media_projection");
            Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.media.projection.MediaProjectionManager");
            try {
                this.mediaProjection = ((MediaProjectionManager) systemService).getMediaProjection(resultCode, data);
                this.mediaProjectionCallback = new MediaProjection.Callback() { // from class: com.example.service.ScreenCaptureManager.initialize.1
                    @Override // android.media.projection.MediaProjection.Callback
                    public void onStop() {
                        super.onStop();
                        Log.d(ScreenCaptureManager.TAG, "MediaProjection stopped by system");
                        ScreenCaptureManager.this.release();
                    }
                };
                MediaProjection mediaProjection = this.mediaProjection;
                if (mediaProjection != null) {
                    MediaProjection.Callback callback = this.mediaProjectionCallback;
                    Intrinsics.checkNotNull(callback);
                    mediaProjection.registerCallback(callback, this.handler);
                }
                int i = width > 0 ? width : 1080;
                int i2 = height > 0 ? height : 1920;
                int i3 = densityDpi > 0 ? densityDpi : 400;
                this.imageReader = ImageReader.newInstance(i, i2, 1, 2);
                MediaProjection mediaProjection2 = this.mediaProjection;
                VirtualDisplay virtualDisplayCreateVirtualDisplay = null;
                if (mediaProjection2 != null) {
                    ImageReader imageReader = this.imageReader;
                    virtualDisplayCreateVirtualDisplay = mediaProjection2.createVirtualDisplay(VIRTUAL_DISPLAY_NAME, i, i2, i3, 16, imageReader != null ? imageReader.getSurface() : null, null, this.handler);
                }
                this.virtualDisplay = virtualDisplayCreateVirtualDisplay;
                Log.d(TAG, "MediaProjection and VirtualDisplay successfully initialized (" + i + " x " + i2 + ")");
                return true;
            } catch (Exception e) {
                e = e;
                Log.e(TAG, "Failed to initialize screen capture", e);
                return false;
            }
        } catch (Exception e2) {
            e = e2;
        }
    }

    public final Bitmap captureScreen() {
        ImageReader reader = this.imageReader;
        if (reader == null) {
            return null;
        }
        Image image = null;
        try {
            try {
                Image imageAcquireLatestImage = reader.acquireLatestImage();
                if (imageAcquireLatestImage == null) {
                    return null;
                }
                image = imageAcquireLatestImage;
                Image.Plane[] planes = image.getPlanes();
                ByteBuffer buffer = planes[0].getBuffer();
                int pixelStride = planes[0].getPixelStride();
                int rowStride = planes[0].getRowStride();
                int rowPadding = rowStride - (image.getWidth() * pixelStride);
                Bitmap bitmap = Bitmap.createBitmap(image.getWidth() + (rowPadding / pixelStride), image.getHeight(), Bitmap.Config.ARGB_8888);
                Intrinsics.checkNotNullExpressionValue(bitmap, "createBitmap(...)");
                bitmap.copyPixelsFromBuffer(buffer);
                Bitmap bitmapCreateBitmap = rowPadding == 0 ? bitmap : Bitmap.createBitmap(bitmap, 0, 0, image.getWidth(), image.getHeight());
                image.close();
                return bitmapCreateBitmap;
            } catch (Exception e) {
                Log.e(TAG, "Failed to acquire screen capture image", e);
                if (image != null) {
                    image.close();
                }
                return null;
            }
        } catch (Throwable th) {
            if (image != null) {
                image.close();
            }
            throw th;
        }
    }

    public final void release() {
        try {
            VirtualDisplay virtualDisplay = this.virtualDisplay;
            if (virtualDisplay != null) {
                virtualDisplay.release();
            }
            this.virtualDisplay = null;
            ImageReader imageReader = this.imageReader;
            if (imageReader != null) {
                imageReader.close();
            }
            this.imageReader = null;
            MediaProjection.Callback callback = this.mediaProjectionCallback;
            if (callback != null) {
                try {
                    MediaProjection mediaProjection = this.mediaProjection;
                    if (mediaProjection != null) {
                        mediaProjection.unregisterCallback(callback);
                        Unit unit = Unit.INSTANCE;
                    }
                } catch (Exception e) {
                    Unit unit2 = Unit.INSTANCE;
                }
            }
            this.mediaProjectionCallback = null;
            MediaProjection mediaProjection2 = this.mediaProjection;
            if (mediaProjection2 != null) {
                mediaProjection2.stop();
            }
            this.mediaProjection = null;
        } catch (Exception e2) {
            Log.e(TAG, "Error releasing capture manager", e2);
        }
    }
}
