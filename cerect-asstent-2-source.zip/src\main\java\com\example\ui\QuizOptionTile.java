package com.example.ui;

import androidx.compose.ui.graphics.Color;
import com.example.model.OptionShape;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: QuizSandbox.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0005HÆ\u0003J\u0010\u0010\u0013\u001a\u00020\u0007HÆ\u0003¢\u0006\u0004\b\u0014\u0010\u000fJ.\u0010\u0015\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001¢\u0006\u0004\b\u0016\u0010\u0017J\u0013\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001b\u001a\u00020\u001cHÖ\u0001J\t\u0010\u001d\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0013\u0010\u0006\u001a\u00020\u0007¢\u0006\n\n\u0002\u0010\u0010\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001e"}, d2 = {"Lcom/example/ui/QuizOptionTile;", "", "shape", "Lcom/example/model/OptionShape;", "label", "", "color", "Landroidx/compose/ui/graphics/Color;", "<init>", "(Lcom/example/model/OptionShape;Ljava/lang/String;JLkotlin/jvm/internal/DefaultConstructorMarker;)V", "getShape", "()Lcom/example/model/OptionShape;", "getLabel", "()Ljava/lang/String;", "getColor-0d7_KjU", "()J", "J", "component1", "component2", "component3", "component3-0d7_KjU", "copy", "copy-mxwnekA", "(Lcom/example/model/OptionShape;Ljava/lang/String;J)Lcom/example/ui/QuizOptionTile;", "equals", "", "other", "hashCode", "", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final /* data */ class QuizOptionTile {
    public static final int $stable = 0;
    private final long color;
    private final String label;
    private final OptionShape shape;

    public /* synthetic */ QuizOptionTile(OptionShape optionShape, String str, long j, DefaultConstructorMarker defaultConstructorMarker) {
        this(optionShape, str, j);
    }

    /* JADX INFO: renamed from: copy-mxwnekA$default, reason: not valid java name */
    public static /* synthetic */ QuizOptionTile m6950copymxwnekA$default(QuizOptionTile quizOptionTile, OptionShape optionShape, String str, long j, int i, Object obj) {
        if ((i & 1) != 0) {
            optionShape = quizOptionTile.shape;
        }
        if ((i & 2) != 0) {
            str = quizOptionTile.label;
        }
        if ((i & 4) != 0) {
            j = quizOptionTile.color;
        }
        return quizOptionTile.m6952copymxwnekA(optionShape, str, j);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final OptionShape getShape() {
        return this.shape;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getLabel() {
        return this.label;
    }

    /* JADX INFO: renamed from: component3-0d7_KjU, reason: not valid java name and from getter */
    public final long getColor() {
        return this.color;
    }

    /* JADX INFO: renamed from: copy-mxwnekA, reason: not valid java name */
    public final QuizOptionTile m6952copymxwnekA(OptionShape shape, String label, long color) {
        Intrinsics.checkNotNullParameter(shape, "shape");
        Intrinsics.checkNotNullParameter(label, "label");
        return new QuizOptionTile(shape, label, color, null);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof QuizOptionTile)) {
            return false;
        }
        QuizOptionTile quizOptionTile = (QuizOptionTile) other;
        return this.shape == quizOptionTile.shape && Intrinsics.areEqual(this.label, quizOptionTile.label) && Color.m4160equalsimpl0(this.color, quizOptionTile.color);
    }

    public int hashCode() {
        return (((this.shape.hashCode() * 31) + this.label.hashCode()) * 31) + Color.m4166hashCodeimpl(this.color);
    }

    public String toString() {
        return "QuizOptionTile(shape=" + this.shape + ", label=" + this.label + ", color=" + Color.m4167toStringimpl(this.color) + ")";
    }

    private QuizOptionTile(OptionShape shape, String label, long color) {
        Intrinsics.checkNotNullParameter(shape, "shape");
        Intrinsics.checkNotNullParameter(label, "label");
        this.shape = shape;
        this.label = label;
        this.color = color;
    }

    public final OptionShape getShape() {
        return this.shape;
    }

    public final String getLabel() {
        return this.label;
    }

    /* JADX INFO: renamed from: getColor-0d7_KjU, reason: not valid java name */
    public final long m6953getColor0d7_KjU() {
        return this.color;
    }
}
