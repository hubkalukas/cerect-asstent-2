package com.example.ui;

import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.automirrored.filled.ArrowBackKt;
import androidx.compose.material.icons.automirrored.filled.ArrowForwardKt;
import androidx.compose.material.icons.filled.CloseKt;
import androidx.compose.material.icons.filled.RefreshKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.graphics.ColorKt;
import androidx.compose.ui.text.TextLayoutResult;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.TextUnitKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: QuizSandbox.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
public final class ComposableSingletons$QuizSandboxKt {
    public static final ComposableSingletons$QuizSandboxKt INSTANCE = new ComposableSingletons$QuizSandboxKt();

    /* JADX INFO: renamed from: lambda$-2084070797, reason: not valid java name */
    private static Function3<RowScope, Composer, Integer, Unit> f95lambda$2084070797 = ComposableLambdaKt.composableLambdaInstance(-2084070797, false, new Function3() { // from class: com.example.ui.ComposableSingletons$QuizSandboxKt$$ExternalSyntheticLambda0
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$QuizSandboxKt.lambda__2084070797$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function3<RowScope, Composer, Integer, Unit> lambda$1461881386 = ComposableLambdaKt.composableLambdaInstance(1461881386, false, new Function3() { // from class: com.example.ui.ComposableSingletons$QuizSandboxKt$$ExternalSyntheticLambda1
        @Override // kotlin.jvm.functions.Function3
        public final Object invoke(Object obj, Object obj2, Object obj3) {
            return ComposableSingletons$QuizSandboxKt.lambda_1461881386$lambda$1((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$1435506970 = ComposableLambdaKt.composableLambdaInstance(1435506970, false, new Function2() { // from class: com.example.ui.ComposableSingletons$QuizSandboxKt$$ExternalSyntheticLambda2
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$QuizSandboxKt.lambda_1435506970$lambda$2((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$1964883409 = ComposableLambdaKt.composableLambdaInstance(1964883409, false, new Function2() { // from class: com.example.ui.ComposableSingletons$QuizSandboxKt$$ExternalSyntheticLambda3
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$QuizSandboxKt.lambda_1964883409$lambda$3((Composer) obj, ((Integer) obj2).intValue());
        }
    });
    private static Function2<Composer, Integer, Unit> lambda$1983310162 = ComposableLambdaKt.composableLambdaInstance(1983310162, false, new Function2() { // from class: com.example.ui.ComposableSingletons$QuizSandboxKt$$ExternalSyntheticLambda4
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$QuizSandboxKt.lambda_1983310162$lambda$4((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-940983452, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f96lambda$940983452 = ComposableLambdaKt.composableLambdaInstance(-940983452, false, new Function2() { // from class: com.example.ui.ComposableSingletons$QuizSandboxKt$$ExternalSyntheticLambda5
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$QuizSandboxKt.lambda__940983452$lambda$5((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* JADX INFO: renamed from: lambda$-1943980846, reason: not valid java name */
    private static Function2<Composer, Integer, Unit> f94lambda$1943980846 = ComposableLambdaKt.composableLambdaInstance(-1943980846, false, new Function2() { // from class: com.example.ui.ComposableSingletons$QuizSandboxKt$$ExternalSyntheticLambda6
        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(Object obj, Object obj2) {
            return ComposableSingletons$QuizSandboxKt.lambda__1943980846$lambda$6((Composer) obj, ((Integer) obj2).intValue());
        }
    });

    /* JADX INFO: renamed from: getLambda$-1943980846$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m6942getLambda$1943980846$app() {
        return f94lambda$1943980846;
    }

    /* JADX INFO: renamed from: getLambda$-2084070797$app, reason: not valid java name */
    public final Function3<RowScope, Composer, Integer, Unit> m6943getLambda$2084070797$app() {
        return f95lambda$2084070797;
    }

    /* JADX INFO: renamed from: getLambda$-940983452$app, reason: not valid java name */
    public final Function2<Composer, Integer, Unit> m6944getLambda$940983452$app() {
        return f96lambda$940983452;
    }

    public final Function2<Composer, Integer, Unit> getLambda$1435506970$app() {
        return lambda$1435506970;
    }

    public final Function3<RowScope, Composer, Integer, Unit> getLambda$1461881386$app() {
        return lambda$1461881386;
    }

    public final Function2<Composer, Integer, Unit> getLambda$1964883409$app() {
        return lambda$1964883409;
    }

    public final Function2<Composer, Integer, Unit> getLambda$1983310162$app() {
        return lambda$1983310162;
    }

    static final Unit lambda__2084070797$lambda$0(RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C316@11384L40:QuizSandbox.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-2084070797, $changed, -1, "com.example.ui.ComposableSingletons$QuizSandboxKt.lambda$-2084070797.<anonymous> (QuizSandbox.kt:316)");
            }
            TextKt.m2693Text4IGK_g("Vzorové otázky", (Modifier) null, 0L, TextUnitKt.getSp(13), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3078, 0, 131062);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1461881386$lambda$1(RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C329@11890L38:QuizSandbox.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1461881386, $changed, -1, "com.example.ui.ComposableSingletons$QuizSandboxKt.lambda$1461881386.<anonymous> (QuizSandbox.kt:329)");
            }
            TextKt.m2693Text4IGK_g("Vlastní text", (Modifier) null, 0L, TextUnitKt.getSp(13), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3078, 0, 131062);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1435506970$lambda$2(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C456@16771L75:QuizSandbox.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1435506970, $changed, -1, "com.example.ui.ComposableSingletons$QuizSandboxKt.lambda$1435506970.<anonymous> (QuizSandbox.kt:456)");
            }
            IconKt.m2150Iconww6aTOc(ArrowBackKt.getArrowBack(Icons.AutoMirrored.Filled.INSTANCE), "Předchozí", (Modifier) null, 0L, $composer, 48, 12);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1964883409$lambda$3(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C465@17048L67:QuizSandbox.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1964883409, $changed, -1, "com.example.ui.ComposableSingletons$QuizSandboxKt.lambda$1964883409.<anonymous> (QuizSandbox.kt:465)");
            }
            IconKt.m2150Iconww6aTOc(RefreshKt.getRefresh(Icons.INSTANCE.getDefault()), "Resetovat výběr", (Modifier) null, 0L, $composer, 48, 12);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda_1983310162$lambda$4(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C478@17540L74:QuizSandbox.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1983310162, $changed, -1, "com.example.ui.ComposableSingletons$QuizSandboxKt.lambda$1983310162.<anonymous> (QuizSandbox.kt:478)");
            }
            IconKt.m2150Iconww6aTOc(ArrowForwardKt.getArrowForward(Icons.AutoMirrored.Filled.INSTANCE), "Další", (Modifier) null, 0L, $composer, 48, 12);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__940983452$lambda$5(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C507@18727L76:QuizSandbox.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-940983452, $changed, -1, "com.example.ui.ComposableSingletons$QuizSandboxKt.lambda$-940983452.<anonymous> (QuizSandbox.kt:507)");
            }
            TextKt.m2693Text4IGK_g("Např.: Kolik nohou má pavouk? Červená 6, Modrá 8, Žlutá 10, Zelená 4", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 6, 0, 131070);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit lambda__1943980846$lambda$6(Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C702@25386L175:QuizSandbox.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1943980846, $changed, -1, "com.example.ui.ComposableSingletons$QuizSandboxKt.lambda$-1943980846.<anonymous> (QuizSandbox.kt:702)");
            }
            IconKt.m2150Iconww6aTOc(CloseKt.getClose(Icons.INSTANCE.getDefault()), "Zavřít", SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), ColorKt.Color(4287931320L), $composer, 3504, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
