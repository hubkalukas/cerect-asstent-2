package com.example;

/* JADX INFO: loaded from: classes6.dex */
public final class BuildConfig {
    public static final String APPLICATION_ID = "com.aistudio.cornerassistant2.wfqz";
    public static final String BUILD_TYPE = "debug";
    public static final boolean DEBUG = Boolean.parseBoolean("true");
    public static final String GEMINI_API_KEY = "YOUR_GEMINI_API_KEY";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.0";
}
