package com.example.ui;

import androidx.compose.foundation.gestures.DragGestureDetectorKt;
import androidx.compose.runtime.MutableFloatState;
import androidx.compose.ui.geometry.Offset;
import androidx.compose.ui.input.pointer.PointerInputChange;
import androidx.compose.ui.input.pointer.PointerInputScope;
import com.example.model.CornerPosition;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SpillingKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;

/* JADX INFO: compiled from: QuizSandbox.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Landroidx/compose/ui/input/pointer/PointerInputScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
@DebugMetadata(c = "com.example.ui.QuizSandboxKt$SandboxAnswerCard$2$1", f = "QuizSandbox.kt", i = {0}, l = {661}, m = "invokeSuspend", n = {"$this$pointerInput"}, s = {"L$0"})
final class QuizSandboxKt$SandboxAnswerCard$2$1 extends SuspendLambda implements Function2<PointerInputScope, Continuation<? super Unit>, Object> {
    final /* synthetic */ CornerPosition $cornerPos;
    final /* synthetic */ MutableFloatState $offsetX$delegate;
    final /* synthetic */ MutableFloatState $offsetY$delegate;
    final /* synthetic */ Function0<Unit> $onDismiss;
    private /* synthetic */ Object L$0;
    int label;

    /* JADX INFO: compiled from: QuizSandbox.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[CornerPosition.values().length];
            try {
                iArr[CornerPosition.TOP_RIGHT.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[CornerPosition.TOP_LEFT.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[CornerPosition.BOTTOM_RIGHT.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                iArr[CornerPosition.BOTTOM_LEFT.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    QuizSandboxKt$SandboxAnswerCard$2$1(CornerPosition cornerPosition, Function0<Unit> function0, MutableFloatState mutableFloatState, MutableFloatState mutableFloatState2, Continuation<? super QuizSandboxKt$SandboxAnswerCard$2$1> continuation) {
        super(2, continuation);
        this.$cornerPos = cornerPosition;
        this.$onDismiss = function0;
        this.$offsetX$delegate = mutableFloatState;
        this.$offsetY$delegate = mutableFloatState2;
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
        QuizSandboxKt$SandboxAnswerCard$2$1 quizSandboxKt$SandboxAnswerCard$2$1 = new QuizSandboxKt$SandboxAnswerCard$2$1(this.$cornerPos, this.$onDismiss, this.$offsetX$delegate, this.$offsetY$delegate, continuation);
        quizSandboxKt$SandboxAnswerCard$2$1.L$0 = obj;
        return quizSandboxKt$SandboxAnswerCard$2$1;
    }

    @Override // kotlin.jvm.functions.Function2
    public final Object invoke(PointerInputScope pointerInputScope, Continuation<? super Unit> continuation) {
        return ((QuizSandboxKt$SandboxAnswerCard$2$1) create(pointerInputScope, continuation)).invokeSuspend(Unit.INSTANCE);
    }

    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object $result) {
        PointerInputScope $this$pointerInput = (PointerInputScope) this.L$0;
        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
        switch (this.label) {
            case 0:
                ResultKt.throwOnFailure($result);
                final CornerPosition cornerPosition = this.$cornerPos;
                final Function0<Unit> function0 = this.$onDismiss;
                final MutableFloatState mutableFloatState = this.$offsetX$delegate;
                final MutableFloatState mutableFloatState2 = this.$offsetY$delegate;
                Function0 function1 = new Function0() { // from class: com.example.ui.QuizSandboxKt$SandboxAnswerCard$2$1$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return QuizSandboxKt$SandboxAnswerCard$2$1.invokeSuspend$lambda$0(cornerPosition, function0, mutableFloatState, mutableFloatState2);
                    }
                };
                final MutableFloatState mutableFloatState3 = this.$offsetX$delegate;
                final MutableFloatState mutableFloatState4 = this.$offsetY$delegate;
                this.L$0 = SpillingKt.nullOutSpilledVariable($this$pointerInput);
                this.label = 1;
                if (DragGestureDetectorKt.detectDragGestures$default($this$pointerInput, null, function1, null, new Function2() { // from class: com.example.ui.QuizSandboxKt$SandboxAnswerCard$2$1$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return QuizSandboxKt$SandboxAnswerCard$2$1.invokeSuspend$lambda$1(mutableFloatState3, mutableFloatState4, (PointerInputChange) obj, (Offset) obj2);
                    }
                }, this, 5, null) == coroutine_suspended) {
                    return coroutine_suspended;
                }
                break;
            case 1:
                ResultKt.throwOnFailure($result);
                break;
            default:
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return Unit.INSTANCE;
    }

    static final Unit invokeSuspend$lambda$0(CornerPosition $cornerPos, Function0 $onDismiss, MutableFloatState $offsetX$delegate, MutableFloatState $offsetY$delegate) {
        boolean isSwipedToCorner = false;
        switch (WhenMappings.$EnumSwitchMapping$0[$cornerPos.ordinal()]) {
            case 1:
                if (QuizSandboxKt.SandboxAnswerCard$lambda$72($offsetX$delegate) > 70.0f || QuizSandboxKt.SandboxAnswerCard$lambda$75($offsetY$delegate) < (-70.0f)) {
                    isSwipedToCorner = true;
                }
                break;
            case 2:
                if (QuizSandboxKt.SandboxAnswerCard$lambda$72($offsetX$delegate) < (-70.0f) || QuizSandboxKt.SandboxAnswerCard$lambda$75($offsetY$delegate) < (-70.0f)) {
                    isSwipedToCorner = true;
                }
                break;
            case 3:
                if (QuizSandboxKt.SandboxAnswerCard$lambda$72($offsetX$delegate) > 70.0f || QuizSandboxKt.SandboxAnswerCard$lambda$75($offsetY$delegate) > 70.0f) {
                    isSwipedToCorner = true;
                }
                break;
            case 4:
                if (QuizSandboxKt.SandboxAnswerCard$lambda$72($offsetX$delegate) < (-70.0f) || QuizSandboxKt.SandboxAnswerCard$lambda$75($offsetY$delegate) > 70.0f) {
                    isSwipedToCorner = true;
                }
                break;
            default:
                throw new NoWhenBranchMatchedException();
        }
        if (isSwipedToCorner || Math.abs(QuizSandboxKt.SandboxAnswerCard$lambda$72($offsetX$delegate)) > 120.0f || Math.abs(QuizSandboxKt.SandboxAnswerCard$lambda$75($offsetY$delegate)) > 120.0f) {
            $onDismiss.invoke();
        } else {
            $offsetX$delegate.setFloatValue(0.0f);
            $offsetY$delegate.setFloatValue(0.0f);
        }
        return Unit.INSTANCE;
    }

    static final Unit invokeSuspend$lambda$1(MutableFloatState $offsetX$delegate, MutableFloatState $offsetY$delegate, PointerInputChange change, Offset dragAmount) {
        change.consume();
        $offsetX$delegate.setFloatValue(QuizSandboxKt.SandboxAnswerCard$lambda$72($offsetX$delegate) + Offset.m3918getXimpl(dragAmount.getPackedValue()));
        $offsetY$delegate.setFloatValue(QuizSandboxKt.SandboxAnswerCard$lambda$75($offsetY$delegate) + Offset.m3919getYimpl(dragAmount.getPackedValue()));
        return Unit.INSTANCE;
    }
}
