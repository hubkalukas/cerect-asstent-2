package com.example.ui;

import androidx.compose.foundation.ScrollKt;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.shape.RoundedCornerShape;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.foundation.text.KeyboardActions;
import androidx.compose.foundation.text.KeyboardOptions;
import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.filled.CloudQueueKt;
import androidx.compose.material.icons.filled.KeyKt;
import androidx.compose.material.icons.filled.LockKt;
import androidx.compose.material.icons.filled.SaveKt;
import androidx.compose.material3.ButtonColors;
import androidx.compose.material3.ButtonDefaults;
import androidx.compose.material3.ButtonKt;
import androidx.compose.material3.CardDefaults;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.OutlinedTextFieldDefaults;
import androidx.compose.material3.OutlinedTextFieldKt;
import androidx.compose.material3.ProgressIndicatorKt;
import androidx.compose.material3.SurfaceKt;
import androidx.compose.material3.TextFieldColors;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.TestTagKt;
import androidx.compose.ui.text.TextLayoutResult;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.input.PasswordVisualTransformation;
import androidx.compose.ui.text.input.VisualTransformation;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.profileinstaller.ProfileVerifier;
import com.example.BuildConfig;
import com.example.data.AppPreferences;
import com.example.data.EncryptedApiKeyVault;
import com.example.data.RateLimiterOverview;
import com.example.model.ModelHealthState;
import com.example.model.ModelQuotaInfo;
import com.example.ui.theme.ColorKt;
import java.util.Iterator;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Triple;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: SettingsScreen.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u00002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a\u001f\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0006\u001a\u0015\u0010\u0007\u001a\u00020\u00012\u0006\u0010\b\u001a\u00020\tH\u0003¢\u0006\u0002\u0010\n¨\u0006\u000b²\u0006\n\u0010\f\u001a\u00020\rX\u008a\u008e\u0002²\u0006\n\u0010\u000e\u001a\u00020\u000fX\u008a\u008e\u0002²\u0006\n\u0010\u0010\u001a\u00020\u0011X\u008a\u0084\u0002²\u0006\n\u0010\u0012\u001a\u00020\rX\u008a\u008e\u0002²\u0006\n\u0010\u0013\u001a\u00020\u000fX\u008a\u008e\u0002²\u0006\n\u0010\u0014\u001a\u00020\u000fX\u008a\u008e\u0002"}, d2 = {"SettingsScreen", "", "preferences", "Lcom/example/data/AppPreferences;", "modifier", "Landroidx/compose/ui/Modifier;", "(Lcom/example/data/AppPreferences;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "ModelQuotaRow", "info", "Lcom/example/model/ModelQuotaInfo;", "(Lcom/example/model/ModelQuotaInfo;Landroidx/compose/runtime/Composer;I)V", "app", "customApiKey", "", "savedConfirmation", "", "rateOverview", "Lcom/example/data/RateLimiterOverview;", "pinInput", "pinError", "pinSuccess"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class SettingsScreenKt {

    /* JADX INFO: compiled from: SettingsScreen.kt */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] iArr = new int[ModelHealthState.values().length];
            try {
                iArr[ModelHealthState.HEALTHY.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                iArr[ModelHealthState.APPROACHING.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                iArr[ModelHealthState.EXHAUSTED.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            $EnumSwitchMapping$0 = iArr;
        }
    }

    static final Unit ModelQuotaRow$lambda$56(ModelQuotaInfo modelQuotaInfo, int i, Composer composer, int i2) {
        ModelQuotaRow(modelQuotaInfo, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    static final Unit SettingsScreen$lambda$50(AppPreferences appPreferences, Modifier modifier, int i, int i2, Composer composer, int i3) {
        SettingsScreen(appPreferences, modifier, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    public static final void SettingsScreen(final AppPreferences preferences, Modifier modifier, Composer $composer, final int $changed, final int i) {
        final Modifier modifier2;
        Modifier.Companion modifier3;
        Object objMutableStateOf$default;
        int i2;
        Object objMutableStateOf$default2;
        Function0<ComposeUiNode> function0;
        Intrinsics.checkNotNullParameter(preferences, "preferences");
        Composer $composer2 = $composer.startRestartGroup(-1310602915);
        ComposerKt.sourceInformation($composer2, "C(SettingsScreen)P(1)66@2874L53,67@2955L34,74@3184L21,71@3109L16051:SettingsScreen.kt#naom5h");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer2.changedInstance(preferences) ? 4 : 2;
        }
        int i3 = i & 2;
        if (i3 != 0) {
            $dirty |= 48;
            modifier2 = modifier;
        } else if (($changed & 48) == 0) {
            modifier2 = modifier;
            $dirty |= $composer2.changed(modifier2) ? 32 : 16;
        } else {
            modifier2 = modifier;
        }
        if (($dirty & 19) == 18 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
        } else {
            if (i3 != 0) {
                modifier3 = Modifier.INSTANCE;
            } else {
                modifier3 = modifier2;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1310602915, $dirty, -1, "com.example.ui.SettingsScreen (SettingsScreen.kt:65)");
            }
            ComposerKt.sourceInformationMarkerStart($composer2, -1063979662, "CC(remember):SettingsScreen.kt#9igjgp");
            Object objRememberedValue = $composer2.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(preferences.getCustomApiKey(), null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default);
            } else {
                objMutableStateOf$default = objRememberedValue;
            }
            final MutableState customApiKey$delegate = (MutableState) objMutableStateOf$default;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, -1063977089, "CC(remember):SettingsScreen.kt#9igjgp");
            Object objRememberedValue2 = $composer2.rememberedValue();
            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                i2 = 0;
                objMutableStateOf$default2 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default2);
            } else {
                i2 = 0;
                objMutableStateOf$default2 = objRememberedValue2;
            }
            final MutableState savedConfirmation$delegate = (MutableState) objMutableStateOf$default2;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            final boolean hasDefaultKey = !StringsKt.isBlank(BuildConfig.GEMINI_API_KEY);
            int i4 = i2;
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(ScrollKt.verticalScroll$default(SizeKt.fillMaxSize$default(modifier3, 0.0f, 1, null), ScrollKt.rememberScrollState(i4, $composer2, i4, 1), false, null, false, 14, null), Dp.m6622constructorimpl(16));
            ComposerKt.sourceInformationMarkerStart($composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer2, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer2, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            Modifier modifier4 = modifier3;
            int i5 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer2.startReusableNode();
            if ($composer2.getInserting()) {
                function0 = constructor;
                $composer2.createNode(function0);
            } else {
                function0 = constructor;
                $composer2.useNode();
            }
            Composer composerM3652constructorimpl = Updater.m3652constructorimpl($composer2);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i6 = (i5 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            int i7 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer2, 1182725891, "C79@3314L10,77@3239L138,84@3472L10,85@3522L11,82@3382L174,88@3562L41,91@3723L16,93@3820L11,93@3778L62,95@3911L20,99@4033L4538,92@3744L4827,226@8577L41,230@8720L11,230@8678L62,232@8811L20,234@8880L8404,229@8644L8640,471@17290L41,475@17438L11,475@17396L88,474@17362L1747,518@19115L41:SettingsScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g("Nastavení AI & Integrace", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getTitleLarge(), $composer2, 196614, 0, 65502);
            TextKt.m2693Text4IGK_g("Konfigurace modelu Gemini a vyhledávání", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getBodySmall(), $composer2, 6, 0, 65530);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), $composer2, 6);
            final State stateCollectAsState = SnapshotStateKt.collectAsState(preferences.getRateLimiter().getOverviewFlow(), null, $composer2, 0, 1);
            CardKt.Card(TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "settings_api_limit_card"), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme($composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, $composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, $composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(2138255685, true, new Function3() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda7
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return SettingsScreenKt.SettingsScreen$lambda$49$lambda$19(stateCollectAsState, preferences, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, $composer2, 54), $composer2, 196614, 8);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), $composer2, 6);
            CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme($composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, $composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, $composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(1321652220, true, new Function3() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda8
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return SettingsScreenKt.SettingsScreen$lambda$49$lambda$48(hasDefaultKey, customApiKey$delegate, preferences, savedConfirmation$delegate, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, $composer2, 54), $composer2, 196614, 8);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), $composer2, 6);
            CardDefaults cardDefaults = CardDefaults.INSTANCE;
            long surfaceVariant = MaterialTheme.INSTANCE.getColorScheme($composer2, MaterialTheme.$stable).getSurfaceVariant();
            CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), cardDefaults.m1829cardColorsro_MJ88(Color.m4157copywmQWz5c(surfaceVariant, (14 & 1) != 0 ? Color.m4161getAlphaimpl(surfaceVariant) : 0.5f, (14 & 2) != 0 ? Color.m4165getRedimpl(surfaceVariant) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(surfaceVariant) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(surfaceVariant) : 0.0f), 0L, 0L, 0L, $composer2, CardDefaults.$stable << 12, 14), null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m6948getLambda$612554179$app(), $composer2, 196614, 24);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(80)), $composer2, 6);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            $composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            modifier2 = modifier4;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda9
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return SettingsScreenKt.SettingsScreen$lambda$50(preferences, modifier2, $changed, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    private static final String SettingsScreen$lambda$1(MutableState<String> mutableState) {
        return mutableState.getValue();
    }

    private static final boolean SettingsScreen$lambda$4(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void SettingsScreen$lambda$5(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    private static final RateLimiterOverview SettingsScreen$lambda$49$lambda$6(State<RateLimiterOverview> state) {
        return (RateLimiterOverview) state.getValue();
    }

    /* JADX WARN: Code duplicated, block: B:108:0x087a A[LOOP:0: B:106:0x0874->B:108:0x087a, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:111:0x09a4  */
    /* JADX WARN: Code duplicated, block: B:114:0x09b0  */
    /* JADX WARN: Code duplicated, block: B:115:0x09b6  */
    /* JADX WARN: Code duplicated, block: B:127:0x0a6b A[LOOP:1: B:125:0x0a65->B:127:0x0a6b, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:130:0x0b1a  */
    /* JADX WARN: Code duplicated, block: B:133:0x0b26  */
    /* JADX WARN: Code duplicated, block: B:134:0x0b2c  */
    /* JADX WARN: Code duplicated, block: B:145:0x0c41  */
    /* JADX WARN: Code duplicated, block: B:148:0x0c4c  */
    /* JADX WARN: Code duplicated, block: B:149:0x0c4f  */
    /* JADX WARN: Code duplicated, block: B:153:0x0cbe  */
    /* JADX WARN: Code duplicated, block: B:28:0x01d7  */
    /* JADX WARN: Code duplicated, block: B:31:0x01e3  */
    /* JADX WARN: Code duplicated, block: B:32:0x01e9  */
    /* JADX WARN: Code duplicated, block: B:43:0x02f6  */
    /* JADX WARN: Code duplicated, block: B:46:0x0302  */
    /* JADX WARN: Code duplicated, block: B:47:0x0308  */
    /* JADX WARN: Code duplicated, block: B:58:0x0457  */
    /* JADX WARN: Code duplicated, block: B:61:0x0463  */
    /* JADX WARN: Code duplicated, block: B:62:0x0469  */
    /* JADX WARN: Code duplicated, block: B:73:0x05a0  */
    /* JADX WARN: Code duplicated, block: B:74:0x05a5  */
    /* JADX WARN: Code duplicated, block: B:85:0x0692  */
    /* JADX WARN: Code duplicated, block: B:86:0x0699  */
    /* JADX WARN: Code duplicated, block: B:88:0x06a0  */
    /* JADX WARN: Code duplicated, block: B:89:0x06ac  */
    /* JADX WARN: Code duplicated, block: B:92:0x07b3  */
    /* JADX WARN: Code duplicated, block: B:95:0x07bf  */
    /* JADX WARN: Code duplicated, block: B:96:0x07c5  */
    static final Unit SettingsScreen$lambda$49$lambda$19(final State $rateOverview$delegate, final AppPreferences $preferences, ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        int i;
        Composer composer;
        Composer composer2;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function1;
        Composer composerM3652constructorimpl;
        int currentCompositeKeyHash2;
        Function0<ComposeUiNode> constructor2;
        Function0<ComposeUiNode> function2;
        Composer composerM3652constructorimpl2;
        int currentCompositeKeyHash3;
        Function0<ComposeUiNode> constructor3;
        Function0<ComposeUiNode> function3;
        Composer composerM3652constructorimpl3;
        long jColor;
        final float fCoerceIn;
        boolean zChanged;
        Object obj;
        long jColor2;
        int currentCompositeKeyHash4;
        Function0<ComposeUiNode> constructor4;
        Function0<ComposeUiNode> function4;
        Composer composerM3652constructorimpl4;
        Iterator<ModelQuotaInfo> it;
        int currentCompositeKeyHash5;
        Function0<ComposeUiNode> constructor5;
        Function0<ComposeUiNode> function5;
        Composer composerM3652constructorimpl5;
        Iterator<ModelQuotaInfo> it2;
        int currentCompositeKeyHash6;
        Function0<ComposeUiNode> constructor6;
        Function0<ComposeUiNode> function6;
        Composer composerM3652constructorimpl6;
        boolean zChangedInstance;
        Object objRememberedValue;
        Composer composer3;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C100@4041L4524:SettingsScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2138255685, $changed, -1, "com.example.ui.SettingsScreen.<anonymous>.<anonymous> (SettingsScreen.kt:100)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash7 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor7 = ComposeUiNode.INSTANCE.getConstructor();
            int i2 = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor7;
                $composer.createNode(function0);
            } else {
                function0 = constructor7;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl7 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl7, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl7, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl7.getInserting()) {
                i = 6;
                composer = $composer;
            } else {
                i = 6;
                composer = $composer;
                if (!Intrinsics.areEqual(composerM3652constructorimpl7.rememberedValue(), Integer.valueOf(currentCompositeKeyHash7))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl7, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i3 = (i2 >> 6) & 14;
                composer2 = composer;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i4 = ((i >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -1357081831, "C101@4094L1577,142@5681L41,147@5920L16,156@6241L11,146@5874L403,159@6287L41,162@6394L204,169@6607L40,171@6657L174,177@6841L41,180@6962L217,190@7366L11,187@7188L216,192@7413L40,194@7463L176,200@7649L41,202@7700L857:SettingsScreen.kt#naom5h");
                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap2 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i5 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function1 = constructor;
                    composer2.createNode(function1);
                } else {
                    function1 = constructor;
                    composer2.useNode();
                }
                composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                    composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash2);
                }
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i6 = (i5 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                int i7 = ((438 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -1785501885, "C106@4284L783,131@5287L374,128@5079L582:SettingsScreen.kt#naom5h");
                Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                Modifier modifier = Modifier.INSTANCE;
                MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically2, composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composer2, modifier);
                constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                int i8 = ((((384 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function2 = constructor2;
                    composer2.createNode(function2);
                } else {
                    function2 = constructor2;
                    composer2.useNode();
                }
                composerM3652constructorimpl2 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                    composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                    composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash3);
                }
                Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i9 = (i8 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                int i10 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 1094979263, "C107@4350L194,113@4557L40,114@4610L445:SettingsScreen.kt#naom5h");
                IconKt.m2150Iconww6aTOc(CloudQueueKt.getCloudQueue(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(22)), ColorKt.getIndigoLight(), composer2, 3504, 0);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer2, 6);
                ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                Modifier modifier2 = Modifier.INSTANCE;
                MeasurePolicy measurePolicyColumnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap4 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier(composer2, modifier2);
                constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                int i11 = ((((0 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function3 = constructor3;
                    composer2.createNode(function3);
                } else {
                    function3 = constructor3;
                    composer2.useNode();
                }
                composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyColumnMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl3.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                    composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                    composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash4);
                }
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                int i12 = (i11 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
                int i13 = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -1597947438, "C117@4731L10,115@4633L182,122@4937L10,123@4997L11,120@4830L211:SettingsScreen.kt#naom5h");
                TextKt.m2693Text4IGK_g("Správa limitů & Model Pools", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleMedium(), composer2, 196614, 0, 65502);
                TextKt.m2693Text4IGK_g("Failover bez chyb • Timeout 7s / 16s", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                if (SettingsScreen$lambda$49$lambda$6($rateOverview$delegate).getTotalLiteRemaining() > 100) {
                    jColor = ColorKt.getEmeraldSuccess();
                } else {
                    jColor = androidx.compose.ui.graphics.ColorKt.Color(4292617766L);
                }
                SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8)), Color.m4157copywmQWz5c(jColor, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jColor) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jColor) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jColor) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jColor) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(1615662010, true, new Function2() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda10
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj2, Object obj3) {
                        return SettingsScreenKt.SettingsScreen$lambda$49$lambda$19$lambda$18$lambda$10$lambda$9($rateOverview$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 12582912, 121);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer2, 6);
                fCoerceIn = RangesKt.coerceIn(SettingsScreen$lambda$49$lambda$6($rateOverview$delegate).getTotalLiteRemaining() / 1000.0f, 0.0f, 1.0f);
                ComposerKt.sourceInformationMarkerStart(composer2, -736459509, "CC(remember):SettingsScreen.kt#9igjgp");
                zChanged = composer2.changed(fCoerceIn);
                Object objRememberedValue2 = composer2.rememberedValue();
                if (!zChanged || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    obj = new Function0() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda11
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return Float.valueOf(SettingsScreenKt.SettingsScreen$lambda$49$lambda$19$lambda$18$lambda$12$lambda$11(fCoerceIn));
                        }
                    };
                    composer2.updateRememberedValue(obj);
                } else {
                    obj = objRememberedValue2;
                }
                Function0 function7 = (Function0) obj;
                ComposerKt.sourceInformationMarkerEnd(composer2);
                Modifier modifierM701height3ABfNKs = SizeKt.m701height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(8));
                if (fCoerceIn > 0.35f) {
                    jColor2 = ColorKt.getEmeraldSuccess();
                } else if (fCoerceIn > 0.15f) {
                    jColor2 = androidx.compose.ui.graphics.ColorKt.Color(4294286859L);
                } else {
                    jColor2 = androidx.compose.ui.graphics.ColorKt.Color(4292617766L);
                }
                ProgressIndicatorKt.m2371LinearProgressIndicatorGJbTh5U(function7, modifierM701height3ABfNKs, jColor2, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurfaceVariant(), 0, 0.0f, null, composer2, 48, 112);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14)), composer2, 6);
                TextKt.m2693Text4IGK_g("PRIORITNÍ FRONTÁ (PRIMARY LITE POOL)", (Modifier) null, ColorKt.getIndigoLight(), TextUnitKt.getSp(11), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, TextUnitKt.getSp(0.5d), (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 12782982, 0, 130898);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                Arrangement.Vertical verticalM550spacedBy0680j_4 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(6));
                ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                Modifier modifier3 = Modifier.INSTANCE;
                MeasurePolicy measurePolicyColumnMeasurePolicy3 = ColumnKt.columnMeasurePolicy(verticalM550spacedBy0680j_4, Alignment.INSTANCE.getStart(), composer2, ((48 >> 3) & 14) | ((48 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap5 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier(composer2, modifier3);
                constructor4 = ComposeUiNode.INSTANCE.getConstructor();
                int i14 = ((((48 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function4 = constructor4;
                    composer2.createNode(function4);
                } else {
                    function4 = constructor4;
                    composer2.useNode();
                }
                composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyColumnMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl4.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl4.rememberedValue(), Integer.valueOf(currentCompositeKeyHash4))) {
                    composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
                    composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash5);
                }
                Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
                int i15 = (i14 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance3 = ColumnScopeInstance.INSTANCE;
                int i16 = ((48 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -1026679757, "C:SettingsScreen.kt#naom5h");
                composer2.startReplaceGroup(2045091280);
                ComposerKt.sourceInformation(composer2, "*173@6782L27");
                for (it = SettingsScreen$lambda$49$lambda$6($rateOverview$delegate).getPrimaryModels().iterator(); it.hasNext(); it = it) {
                    ModelQuotaRow(it.next(), composer2, 0);
                }
                composer2.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14)), composer2, 6);
                TextKt.m2693Text4IGK_g("NOUZOVÝ POOL (EMERGENCY FLASH - MAX 18 RPD)", (Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4294286859L), TextUnitKt.getSp(11), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, TextUnitKt.getSp(0.5d), (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 12782982, 0, 130898);
                TextKt.m2693Text4IGK_g("Aktivuje se pouze při výpadku obou Lite modelů. Gemini 3.5 Flash je zablokován (22/20 RPD).", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3078, 0, 131058);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                Arrangement.Vertical verticalM550spacedBy0680j_5 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(6));
                ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                Modifier modifier4 = Modifier.INSTANCE;
                MeasurePolicy measurePolicyColumnMeasurePolicy4 = ColumnKt.columnMeasurePolicy(verticalM550spacedBy0680j_5, Alignment.INSTANCE.getStart(), composer2, ((48 >> 3) & 14) | ((48 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap6 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier6 = ComposedModifierKt.materializeModifier(composer2, modifier4);
                constructor5 = ComposeUiNode.INSTANCE.getConstructor();
                int i17 = ((((48 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function5 = constructor5;
                    composer2.createNode(function5);
                } else {
                    function5 = constructor5;
                    composer2.useNode();
                }
                composerM3652constructorimpl5 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl5, measurePolicyColumnMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl5, currentCompositionLocalMap6, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash6 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl5.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl5.rememberedValue(), Integer.valueOf(currentCompositeKeyHash5))) {
                    composerM3652constructorimpl5.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash5));
                    composerM3652constructorimpl5.apply(Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash6);
                }
                Updater.m3659setimpl(composerM3652constructorimpl5, modifierMaterializeModifier6, ComposeUiNode.INSTANCE.getSetModifier());
                int i18 = (i17 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance4 = ColumnScopeInstance.INSTANCE;
                int i19 = ((48 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 2110996634, "C:SettingsScreen.kt#naom5h");
                composer2.startReplaceGroup(-486092663);
                ComposerKt.sourceInformation(composer2, "*196@7590L27");
                for (it2 = SettingsScreen$lambda$49$lambda$6($rateOverview$delegate).getEmergencyModels().iterator(); it2.hasNext(); it2 = it2) {
                    ModelQuotaRow(it2.next(), composer2, 0);
                }
                composer2.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14)), composer2, 6);
                Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween2 = Arrangement.INSTANCE.getSpaceBetween();
                Alignment.Vertical centerVertically3 = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy3 = RowKt.rowMeasurePolicy(spaceBetween2, centerVertically3, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash6 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap7 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier7 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default2);
                constructor6 = ComposeUiNode.INSTANCE.getConstructor();
                int i20 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function6 = constructor6;
                    composer2.createNode(function6);
                } else {
                    function6 = constructor6;
                    composer2.useNode();
                }
                composerM3652constructorimpl6 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl6, measurePolicyRowMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl6, currentCompositionLocalMap7, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash7 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl6.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl6.rememberedValue(), Integer.valueOf(currentCompositeKeyHash6))) {
                    composerM3652constructorimpl6.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash6));
                    composerM3652constructorimpl6.apply(Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash7);
                }
                Updater.m3659setimpl(composerM3652constructorimpl6, modifierMaterializeModifier7, ComposeUiNode.INSTANCE.getSetModifier());
                int i21 = (i20 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                int i22 = ((438 >> 6) & 112) | 6;
                RowScope rowScope = RowScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composer2, -1305770052, "C210@8023L11,207@7890L217,214@8156L46,213@8118L429:SettingsScreen.kt#naom5h");
                TextKt.m2693Text4IGK_g("Reset RPD probíhá automaticky o půlnoci.", RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3078, 0, 131056);
                RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10));
                Modifier modifierTestTag = TestTagKt.testTag(Modifier.INSTANCE, "reset_rate_limits_button");
                ComposerKt.sourceInformationMarkerStart(composer2, 1759001604, "CC(remember):SettingsScreen.kt#9igjgp");
                zChangedInstance = composer2.changedInstance($preferences);
                objRememberedValue = composer2.rememberedValue();
                if (zChangedInstance) {
                    composer3 = composer2;
                } else {
                    composer3 = composer2;
                    if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    Composer composer4 = composer3;
                    ButtonKt.OutlinedButton((Function0) objRememberedValue, modifierTestTag, false, roundedCornerShapeM953RoundedCornerShape0680j_4, null, null, null, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m6945getLambda$1924913272$app(), composer4, 805306416, 500);
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                }
                objRememberedValue = new Function0() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda12
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return SettingsScreenKt.SettingsScreen$lambda$49$lambda$19$lambda$18$lambda$17$lambda$16$lambda$15($preferences);
                    }
                };
                composer2.updateRememberedValue(objRememberedValue);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                Composer composer5 = composer3;
                ButtonKt.OutlinedButton((Function0) objRememberedValue, modifierTestTag, false, roundedCornerShapeM953RoundedCornerShape0680j_4, null, null, null, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m6945getLambda$1924913272$app(), composer5, 805306416, 500);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composerM3652constructorimpl7.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash7));
            composerM3652constructorimpl7.apply(Integer.valueOf(currentCompositeKeyHash7), setCompositeKeyHash);
            Updater.m3659setimpl(composerM3652constructorimpl7, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i23 = (i2 >> 6) & 14;
            composer2 = composer;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance5 = ColumnScopeInstance.INSTANCE;
            int i24 = ((i >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -1357081831, "C101@4094L1577,142@5681L41,147@5920L16,156@6241L11,146@5874L403,159@6287L41,162@6394L204,169@6607L40,171@6657L174,177@6841L41,180@6962L217,190@7366L11,187@7188L216,192@7413L40,194@7463L176,200@7649L41,202@7700L857:SettingsScreen.kt#naom5h");
            Modifier modifierFillMaxWidth$default3 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween3 = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically4 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy4 = RowKt.rowMeasurePolicy(spaceBetween3, centerVertically4, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap8 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier8 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default3);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i25 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function1 = constructor;
                composer2.createNode(function1);
            } else {
                function1 = constructor;
                composer2.useNode();
            }
            composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap8, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash8 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl.getInserting()) {
            }
            composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash8);
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier8, ComposeUiNode.INSTANCE.getSetModifier());
            int i26 = (i25 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance3 = RowScopeInstance.INSTANCE;
            int i27 = ((438 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -1785501885, "C106@4284L783,131@5287L374,128@5079L582:SettingsScreen.kt#naom5h");
            Alignment.Vertical centerVertically5 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            Modifier modifier5 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy5 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically5, composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap9 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier9 = ComposedModifierKt.materializeModifier(composer2, modifier5);
            constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i28 = ((((384 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function2 = constructor2;
                composer2.createNode(function2);
            } else {
                function2 = constructor2;
                composer2.useNode();
            }
            composerM3652constructorimpl2 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy5, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap9, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash9 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl2.getInserting()) {
            }
            composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash9);
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier9, ComposeUiNode.INSTANCE.getSetModifier());
            int i29 = (i28 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance4 = RowScopeInstance.INSTANCE;
            int i110 = ((384 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 1094979263, "C107@4350L194,113@4557L40,114@4610L445:SettingsScreen.kt#naom5h");
            IconKt.m2150Iconww6aTOc(CloudQueueKt.getCloudQueue(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(22)), ColorKt.getIndigoLight(), composer2, 3504, 0);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer2, 6);
            ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            Modifier modifier6 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyColumnMeasurePolicy5 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap10 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier10 = ComposedModifierKt.materializeModifier(composer2, modifier6);
            constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            int i111 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function3 = constructor3;
                composer2.createNode(function3);
            } else {
                function3 = constructor3;
                composer2.useNode();
            }
            composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyColumnMeasurePolicy5, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap10, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash10 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl3.getInserting()) {
            }
            composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
            composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash10);
            Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier10, ComposeUiNode.INSTANCE.getSetModifier());
            int i112 = (i111 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance6 = ColumnScopeInstance.INSTANCE;
            int i113 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -1597947438, "C117@4731L10,115@4633L182,122@4937L10,123@4997L11,120@4830L211:SettingsScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g("Správa limitů & Model Pools", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleMedium(), composer2, 196614, 0, 65502);
            TextKt.m2693Text4IGK_g("Failover bez chyb • Timeout 7s / 16s", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            if (SettingsScreen$lambda$49$lambda$6($rateOverview$delegate).getTotalLiteRemaining() > 100) {
                jColor = ColorKt.getEmeraldSuccess();
            } else {
                jColor = androidx.compose.ui.graphics.ColorKt.Color(4292617766L);
            }
            SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8)), Color.m4157copywmQWz5c(jColor, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jColor) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jColor) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jColor) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jColor) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(1615662010, true, new Function2() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda10
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return SettingsScreenKt.SettingsScreen$lambda$49$lambda$19$lambda$18$lambda$10$lambda$9($rateOverview$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer2, 54), composer2, 12582912, 121);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer2, 6);
            fCoerceIn = RangesKt.coerceIn(SettingsScreen$lambda$49$lambda$6($rateOverview$delegate).getTotalLiteRemaining() / 1000.0f, 0.0f, 1.0f);
            ComposerKt.sourceInformationMarkerStart(composer2, -736459509, "CC(remember):SettingsScreen.kt#9igjgp");
            zChanged = composer2.changed(fCoerceIn);
            Object objRememberedValue3 = composer2.rememberedValue();
            if (zChanged) {
            }
            obj = new Function0() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda11
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return Float.valueOf(SettingsScreenKt.SettingsScreen$lambda$49$lambda$19$lambda$18$lambda$12$lambda$11(fCoerceIn));
                }
            };
            composer2.updateRememberedValue(obj);
            Function0 function8 = (Function0) obj;
            ComposerKt.sourceInformationMarkerEnd(composer2);
            Modifier modifierM701height3ABfNKs2 = SizeKt.m701height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(8));
            if (fCoerceIn > 0.35f) {
                jColor2 = ColorKt.getEmeraldSuccess();
            } else if (fCoerceIn > 0.15f) {
                jColor2 = androidx.compose.ui.graphics.ColorKt.Color(4294286859L);
            } else {
                jColor2 = androidx.compose.ui.graphics.ColorKt.Color(4292617766L);
            }
            ProgressIndicatorKt.m2371LinearProgressIndicatorGJbTh5U(function8, modifierM701height3ABfNKs2, jColor2, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurfaceVariant(), 0, 0.0f, null, composer2, 48, 112);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14)), composer2, 6);
            TextKt.m2693Text4IGK_g("PRIORITNÍ FRONTÁ (PRIMARY LITE POOL)", (Modifier) null, ColorKt.getIndigoLight(), TextUnitKt.getSp(11), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, TextUnitKt.getSp(0.5d), (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 12782982, 0, 130898);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
            Arrangement.Vertical verticalM550spacedBy0680j_6 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(6));
            ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            Modifier modifier7 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyColumnMeasurePolicy6 = ColumnKt.columnMeasurePolicy(verticalM550spacedBy0680j_6, Alignment.INSTANCE.getStart(), composer2, ((48 >> 3) & 14) | ((48 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap11 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier11 = ComposedModifierKt.materializeModifier(composer2, modifier7);
            constructor4 = ComposeUiNode.INSTANCE.getConstructor();
            int i114 = ((((48 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function4 = constructor4;
                composer2.createNode(function4);
            } else {
                function4 = constructor4;
                composer2.useNode();
            }
            composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyColumnMeasurePolicy6, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap11, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash11 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl4.getInserting()) {
            }
            composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
            composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash11);
            Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier11, ComposeUiNode.INSTANCE.getSetModifier());
            int i115 = (i114 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance7 = ColumnScopeInstance.INSTANCE;
            int i116 = ((48 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -1026679757, "C:SettingsScreen.kt#naom5h");
            composer2.startReplaceGroup(2045091280);
            ComposerKt.sourceInformation(composer2, "*173@6782L27");
            while (it.hasNext()) {
                ModelQuotaRow(it.next(), composer2, 0);
            }
            composer2.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14)), composer2, 6);
            TextKt.m2693Text4IGK_g("NOUZOVÝ POOL (EMERGENCY FLASH - MAX 18 RPD)", (Modifier) null, androidx.compose.ui.graphics.ColorKt.Color(4294286859L), TextUnitKt.getSp(11), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, TextUnitKt.getSp(0.5d), (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 12782982, 0, 130898);
            TextKt.m2693Text4IGK_g("Aktivuje se pouze při výpadku obou Lite modelů. Gemini 3.5 Flash je zablokován (22/20 RPD).", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3078, 0, 131058);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
            Arrangement.Vertical verticalM550spacedBy0680j_7 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(6));
            ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            Modifier modifier8 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyColumnMeasurePolicy7 = ColumnKt.columnMeasurePolicy(verticalM550spacedBy0680j_7, Alignment.INSTANCE.getStart(), composer2, ((48 >> 3) & 14) | ((48 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap12 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier12 = ComposedModifierKt.materializeModifier(composer2, modifier8);
            constructor5 = ComposeUiNode.INSTANCE.getConstructor();
            int i117 = ((((48 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function5 = constructor5;
                composer2.createNode(function5);
            } else {
                function5 = constructor5;
                composer2.useNode();
            }
            composerM3652constructorimpl5 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl5, measurePolicyColumnMeasurePolicy7, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl5, currentCompositionLocalMap12, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash12 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl5.getInserting()) {
            }
            composerM3652constructorimpl5.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash5));
            composerM3652constructorimpl5.apply(Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash12);
            Updater.m3659setimpl(composerM3652constructorimpl5, modifierMaterializeModifier12, ComposeUiNode.INSTANCE.getSetModifier());
            int i118 = (i117 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance8 = ColumnScopeInstance.INSTANCE;
            int i119 = ((48 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 2110996634, "C:SettingsScreen.kt#naom5h");
            composer2.startReplaceGroup(-486092663);
            ComposerKt.sourceInformation(composer2, "*196@7590L27");
            while (it2.hasNext()) {
                ModelQuotaRow(it2.next(), composer2, 0);
            }
            composer2.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14)), composer2, 6);
            Modifier modifierFillMaxWidth$default4 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween4 = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically6 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy6 = RowKt.rowMeasurePolicy(spaceBetween4, centerVertically6, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash6 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap13 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier13 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default4);
            constructor6 = ComposeUiNode.INSTANCE.getConstructor();
            int i210 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function6 = constructor6;
                composer2.createNode(function6);
            } else {
                function6 = constructor6;
                composer2.useNode();
            }
            composerM3652constructorimpl6 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl6, measurePolicyRowMeasurePolicy6, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl6, currentCompositionLocalMap13, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash13 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl6.getInserting()) {
            }
            composerM3652constructorimpl6.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash6));
            composerM3652constructorimpl6.apply(Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash13);
            Updater.m3659setimpl(composerM3652constructorimpl6, modifierMaterializeModifier13, ComposeUiNode.INSTANCE.getSetModifier());
            int i211 = (i210 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            int i212 = ((438 >> 6) & 112) | 6;
            RowScope rowScope2 = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer2, -1305770052, "C210@8023L11,207@7890L217,214@8156L46,213@8118L429:SettingsScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g("Reset RPD probíhá automaticky o půlnoci.", RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3078, 0, 131056);
            RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_5 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10));
            Modifier modifierTestTag2 = TestTagKt.testTag(Modifier.INSTANCE, "reset_rate_limits_button");
            ComposerKt.sourceInformationMarkerStart(composer2, 1759001604, "CC(remember):SettingsScreen.kt#9igjgp");
            zChangedInstance = composer2.changedInstance($preferences);
            objRememberedValue = composer2.rememberedValue();
            if (zChangedInstance) {
                composer3 = composer2;
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                }
                ComposerKt.sourceInformationMarkerEnd(composer3);
                Composer composer6 = composer3;
                ButtonKt.OutlinedButton((Function0) objRememberedValue, modifierTestTag2, false, roundedCornerShapeM953RoundedCornerShape0680j_5, null, null, null, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m6945getLambda$1924913272$app(), composer6, 805306416, 500);
                ComposerKt.sourceInformationMarkerEnd(composer6);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composer3 = composer2;
            }
            objRememberedValue = new Function0() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda12
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return SettingsScreenKt.SettingsScreen$lambda$49$lambda$19$lambda$18$lambda$17$lambda$16$lambda$15($preferences);
                }
            };
            composer2.updateRememberedValue(objRememberedValue);
            ComposerKt.sourceInformationMarkerEnd(composer3);
            Composer composer7 = composer3;
            ButtonKt.OutlinedButton((Function0) objRememberedValue, modifierTestTag2, false, roundedCornerShapeM953RoundedCornerShape0680j_5, null, null, null, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m6945getLambda$1924913272$app(), composer7, 805306416, 500);
            ComposerKt.sourceInformationMarkerEnd(composer7);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit SettingsScreen$lambda$49$lambda$19$lambda$18$lambda$10$lambda$9(State $rateOverview$delegate, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C132@5301L348:SettingsScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1615662010, $changed, -1, "com.example.ui.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:132)");
            }
            TextKt.m2693Text4IGK_g(SettingsScreen$lambda$49$lambda$6($rateOverview$delegate).getTotalLiteRemaining() + " / 1 000 RPD", PaddingKt.m671paddingVpY3zN4(Modifier.INSTANCE, Dp.m6622constructorimpl(8), Dp.m6622constructorimpl(4)), SettingsScreen$lambda$49$lambda$6($rateOverview$delegate).getTotalLiteRemaining() > 100 ? ColorKt.getEmeraldSuccess() : androidx.compose.ui.graphics.ColorKt.Color(4292617766L), TextUnitKt.getSp(12), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 199728, 0, 131024);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final float SettingsScreen$lambda$49$lambda$19$lambda$18$lambda$12$lambda$11(float $liteFraction) {
        return $liteFraction;
    }

    static final Unit SettingsScreen$lambda$49$lambda$19$lambda$18$lambda$17$lambda$16$lambda$15(AppPreferences $preferences) {
        $preferences.getRateLimiter().resetAllCounters();
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:86:0x082b  */
    /* JADX WARN: Code duplicated, block: B:95:0x089c  */
    /* JADX WARN: Code duplicated, block: B:98:0x0937  */
    static final Unit SettingsScreen$lambda$49$lambda$48(boolean $hasDefaultKey, final MutableState $customApiKey$delegate, final AppPreferences $preferences, final MutableState $savedConfirmation$delegate, ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        Object objMutableStateOf$default;
        Object objMutableStateOf$default2;
        Object objMutableStateOf$default3;
        Object obj;
        Function0<ComposeUiNode> function1;
        Composer composer;
        Composer composer2;
        boolean zChangedInstance;
        Object objRememberedValue;
        boolean zChangedInstance2;
        Object obj2;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C235@8888L8390:SettingsScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1321652220, $changed, -1, "com.example.ui.SettingsScreen.<anonymous>.<anonymous> (SettingsScreen.kt:235)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                $composer.createNode(constructor);
            } else {
                $composer.useNode();
            }
            Composer composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i2 = (i >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            int i3 = ((6 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, 1613598376, "C236@8941L469,251@9420L41,281@10424L31,282@10480L34,283@10541L34,286@10626L11,289@10774L4157,285@10585L4346,398@14941L41,402@15089L10,403@15143L11,400@14992L189,406@15191L40,417@15587L66,410@15318L81,408@15241L526,425@15777L41,427@15828L1086,461@16924L40,464@17150L10,466@17232L11,462@16973L297:SettingsScreen.kt#naom5h");
            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            Modifier modifier = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically, $composer, ((384 >> 3) & 14) | ((384 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap2 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifier);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i4 = ((((384 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor2;
                $composer.createNode(function0);
            } else {
                function0 = constructor2;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl2 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
            }
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            int i5 = (i4 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
            int i6 = ((384 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -1986395966, "C237@9005L179,243@9195L40,246@9324L10,244@9246L154:SettingsScreen.kt#naom5h");
            IconKt.m2150Iconww6aTOc(KeyKt.getKey(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(22)), ColorKt.getIndigoPrimary(), $composer, 3504, 0);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), $composer, 6);
            TextKt.m2693Text4IGK_g("Gemini API Klíč", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleMedium(), $composer, 196614, 0, 65502);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), $composer, 6);
            if ($hasDefaultKey) {
                $composer.startReplaceGroup(1613911816);
                ComposerKt.sourceInformation($composer, "254@9502L798,277@10311L41");
                long emeraldSuccess = ColorKt.getEmeraldSuccess();
                SurfaceKt.m2543SurfaceT9BRK9s(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10)), Color.m4157copywmQWz5c(emeraldSuccess, (14 & 1) != 0 ? Color.m4161getAlphaimpl(emeraldSuccess) : 0.12f, (14 & 2) != 0 ? Color.m4165getRedimpl(emeraldSuccess) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(emeraldSuccess) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(emeraldSuccess) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableSingletons$SettingsScreenKt.INSTANCE.getLambda$117102760$app(), $composer, 12583302, 120);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), $composer, 6);
            } else {
                $composer.startReplaceGroup(1604469712);
            }
            $composer.endReplaceGroup();
            ComposerKt.sourceInformationMarkerStart($composer, -1471929935, "CC(remember):SettingsScreen.kt#9igjgp");
            Object objRememberedValue2 = $composer.rememberedValue();
            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
                $composer.updateRememberedValue(objMutableStateOf$default);
            } else {
                objMutableStateOf$default = objRememberedValue2;
            }
            final MutableState mutableState = (MutableState) objMutableStateOf$default;
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerStart($composer, -1471928140, "CC(remember):SettingsScreen.kt#9igjgp");
            Object objRememberedValue3 = $composer.rememberedValue();
            if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default2 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                $composer.updateRememberedValue(objMutableStateOf$default2);
            } else {
                objMutableStateOf$default2 = objRememberedValue3;
            }
            final MutableState mutableState2 = (MutableState) objMutableStateOf$default2;
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerStart($composer, -1471926188, "CC(remember):SettingsScreen.kt#9igjgp");
            Object objRememberedValue4 = $composer.rememberedValue();
            if (objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default3 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                $composer.updateRememberedValue(objMutableStateOf$default3);
            } else {
                objMutableStateOf$default3 = objRememberedValue4;
            }
            final MutableState mutableState3 = (MutableState) objMutableStateOf$default3;
            ComposerKt.sourceInformationMarkerEnd($composer);
            long surfaceVariant = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getSurfaceVariant();
            SurfaceKt.m2543SurfaceT9BRK9s(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(14)), Color.m4157copywmQWz5c(surfaceVariant, (14 & 1) != 0 ? Color.m4161getAlphaimpl(surfaceVariant) : 0.45f, (14 & 2) != 0 ? Color.m4165getRedimpl(surfaceVariant) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(surfaceVariant) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(surfaceVariant) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(-1201852915, true, new Function2() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda15
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj3, Object obj4) {
                    return SettingsScreenKt.SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$38(mutableState3, $customApiKey$delegate, $preferences, mutableState, mutableState2, $savedConfirmation$delegate, (Composer) obj3, ((Integer) obj4).intValue());
                }
            }, $composer, 54), $composer, 12582918, 120);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), $composer, 6);
            TextKt.m2693Text4IGK_g("Vlastní API klíč (volitelné přepsání):", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodySmall(), $composer, 6, 0, 65530);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), $composer, 6);
            String strSettingsScreen$lambda$1 = SettingsScreen$lambda$1($customApiKey$delegate);
            RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12));
            TextFieldColors textFieldColorsM2343colors0hiis_0 = OutlinedTextFieldDefaults.INSTANCE.m2343colors0hiis_0(0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, null, ColorKt.getIndigoPrimary(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, $composer, 0, 48, 0, 0, 3072, 2147481599, 4095);
            Modifier modifierTestTag = TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "custom_api_key_input");
            ComposerKt.sourceInformationMarkerStart($composer, -1471773277, "CC(remember):SettingsScreen.kt#9igjgp");
            Object objRememberedValue5 = $composer.rememberedValue();
            if (objRememberedValue5 == Composer.INSTANCE.getEmpty()) {
                obj = new Function1() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj3) {
                        return SettingsScreenKt.SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$40$lambda$39($customApiKey$delegate, $savedConfirmation$delegate, (String) obj3);
                    }
                };
                $composer.updateRememberedValue(obj);
            } else {
                obj = objRememberedValue5;
            }
            ComposerKt.sourceInformationMarkerEnd($composer);
            OutlinedTextFieldKt.OutlinedTextField(strSettingsScreen$lambda$1, (Function1<? super String, Unit>) obj, modifierTestTag, false, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$SettingsScreenKt.INSTANCE.getLambda$1732457515$app(), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, false, (VisualTransformation) null, (KeyboardOptions) null, (KeyboardActions) null, true, 0, 0, (MutableInteractionSource) null, (Shape) roundedCornerShapeM953RoundedCornerShape0680j_4, textFieldColorsM2343colors0hiis_0, $composer, 12583344, 12582912, 0, 1965944);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), $composer, 6);
            Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal horizontalM550spacedBy0680j_4 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(horizontalM550spacedBy0680j_4, Alignment.INSTANCE.getTop(), $composer, ((54 >> 3) & 14) | ((54 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap3 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default);
            Function0<ComposeUiNode> constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            int i7 = ((((54 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function1 = constructor3;
                $composer.createNode(function1);
            } else {
                function1 = constructor3;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl3 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl3.getInserting()) {
                composer = $composer;
            } else {
                composer = $composer;
                if (!Intrinsics.areEqual(composerM3652constructorimpl3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i8 = (i7 >> 6) & 14;
                composer2 = composer;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                int i9 = ((54 >> 6) & 112) | 6;
                RowScope rowScope = RowScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composer2, -504138648, "C436@16138L44,432@15992L108,441@16347L200,431@15962L585:SettingsScreen.kt#naom5h");
                ButtonColors buttonColorsM1809buttonColorsro_MJ88 = ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(ColorKt.getIndigoPrimary(), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14);
                RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_5 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12));
                Modifier modifierTestTag2 = TestTagKt.testTag(RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), "save_api_key_button");
                ComposerKt.sourceInformationMarkerStart(composer2, 122284921, "CC(remember):SettingsScreen.kt#9igjgp");
                zChangedInstance = composer2.changedInstance($preferences);
                objRememberedValue = composer2.rememberedValue();
                if (!zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new Function0() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda2
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return SettingsScreenKt.SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$46$lambda$42$lambda$41($preferences, $customApiKey$delegate, $savedConfirmation$delegate);
                        }
                    };
                    composer2.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ButtonKt.Button((Function0) objRememberedValue, modifierTestTag2, false, roundedCornerShapeM953RoundedCornerShape0680j_5, buttonColorsM1809buttonColorsro_MJ88, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-1478716163, true, new Function3() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj3, Object obj4, Object obj5) {
                        return SettingsScreenKt.SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$46$lambda$43($savedConfirmation$delegate, (RowScope) obj3, (Composer) obj4, ((Integer) obj5).intValue());
                    }
                }, composer2, 54), composer2, 805306368, 484);
                if (StringsKt.isBlank(SettingsScreen$lambda$1($customApiKey$delegate))) {
                    composer2.startReplaceGroup(-520003147);
                } else {
                    composer2.startReplaceGroup(-503535141);
                    ComposerKt.sourceInformation(composer2, "449@16644L139,448@16604L288");
                    ComposerKt.sourceInformationMarkerStart(composer2, 122305816, "CC(remember):SettingsScreen.kt#9igjgp");
                    zChangedInstance2 = composer2.changedInstance($preferences);
                    Object objRememberedValue6 = composer2.rememberedValue();
                    if (!zChangedInstance2 || objRememberedValue6 == Composer.INSTANCE.getEmpty()) {
                        obj2 = new Function0() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda4
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return SettingsScreenKt.SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$46$lambda$45$lambda$44($preferences, $customApiKey$delegate, $savedConfirmation$delegate);
                            }
                        };
                        composer2.updateRememberedValue(obj2);
                    } else {
                        obj2 = objRememberedValue6;
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ButtonKt.OutlinedButton((Function0) obj2, null, false, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)), null, null, null, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.getLambda$423725402$app(), composer2, 805306368, 502);
                }
                composer2.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), $composer, 6);
                TextKt.m2693Text4IGK_g("Tip: Pokud narazíte na limit bezplatné kvóty (429), zadejte zde svůj vlastní bezplatný API klíč z aistudio.google.com.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodySmall(), $composer, 3078, 0, 65522);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
            composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash3);
            Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
            int i10 = (i7 >> 6) & 14;
            composer2 = composer;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            int i11 = ((54 >> 6) & 112) | 6;
            RowScope rowScope2 = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer2, -504138648, "C436@16138L44,432@15992L108,441@16347L200,431@15962L585:SettingsScreen.kt#naom5h");
            ButtonColors buttonColorsM1809buttonColorsro_MJ89 = ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(ColorKt.getIndigoPrimary(), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14);
            RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_6 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12));
            Modifier modifierTestTag3 = TestTagKt.testTag(RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), "save_api_key_button");
            ComposerKt.sourceInformationMarkerStart(composer2, 122284921, "CC(remember):SettingsScreen.kt#9igjgp");
            zChangedInstance = composer2.changedInstance($preferences);
            objRememberedValue = composer2.rememberedValue();
            if (!zChangedInstance) {
            }
            objRememberedValue = new Function0() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return SettingsScreenKt.SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$46$lambda$42$lambda$41($preferences, $customApiKey$delegate, $savedConfirmation$delegate);
                }
            };
            composer2.updateRememberedValue(objRememberedValue);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ButtonKt.Button((Function0) objRememberedValue, modifierTestTag3, false, roundedCornerShapeM953RoundedCornerShape0680j_6, buttonColorsM1809buttonColorsro_MJ89, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-1478716163, true, new Function3() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj3, Object obj4, Object obj5) {
                    return SettingsScreenKt.SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$46$lambda$43($savedConfirmation$delegate, (RowScope) obj3, (Composer) obj4, ((Integer) obj5).intValue());
                }
            }, composer2, 54), composer2, 805306368, 484);
            if (StringsKt.isBlank(SettingsScreen$lambda$1($customApiKey$delegate))) {
                composer2.startReplaceGroup(-503535141);
                ComposerKt.sourceInformation(composer2, "449@16644L139,448@16604L288");
                ComposerKt.sourceInformationMarkerStart(composer2, 122305816, "CC(remember):SettingsScreen.kt#9igjgp");
                zChangedInstance2 = composer2.changedInstance($preferences);
                Object objRememberedValue7 = composer2.rememberedValue();
                if (zChangedInstance2) {
                }
                obj2 = new Function0() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return SettingsScreenKt.SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$46$lambda$45$lambda$44($preferences, $customApiKey$delegate, $savedConfirmation$delegate);
                    }
                };
                composer2.updateRememberedValue(obj2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ButtonKt.OutlinedButton((Function0) obj2, null, false, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)), null, null, null, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.getLambda$423725402$app(), composer2, 805306368, 502);
            } else {
                composer2.startReplaceGroup(-520003147);
            }
            composer2.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), $composer, 6);
            TextKt.m2693Text4IGK_g("Tip: Pokud narazíte na limit bezplatné kvóty (429), zadejte zde svůj vlastní bezplatný API klíč z aistudio.google.com.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodySmall(), $composer, 3078, 0, 65522);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    private static final String SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$22(MutableState<String> mutableState) {
        return mutableState.getValue();
    }

    private static final boolean SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$25(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$26(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    private static final boolean SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$28(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$29(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    /* JADX WARN: Code duplicated, block: B:100:0x08b7  */
    /* JADX WARN: Code duplicated, block: B:28:0x01d6  */
    /* JADX WARN: Code duplicated, block: B:31:0x01e2  */
    /* JADX WARN: Code duplicated, block: B:32:0x01e8  */
    /* JADX WARN: Code duplicated, block: B:43:0x02f4  */
    /* JADX WARN: Code duplicated, block: B:46:0x0300  */
    /* JADX WARN: Code duplicated, block: B:47:0x0306  */
    /* JADX WARN: Code duplicated, block: B:62:0x0459  */
    /* JADX WARN: Code duplicated, block: B:65:0x05a2  */
    /* JADX WARN: Code duplicated, block: B:68:0x05ae  */
    /* JADX WARN: Code duplicated, block: B:69:0x05b4  */
    /* JADX WARN: Code duplicated, block: B:80:0x06a4  */
    /* JADX WARN: Code duplicated, block: B:81:0x06bc  */
    /* JADX WARN: Code duplicated, block: B:84:0x0758  */
    /* JADX WARN: Code duplicated, block: B:87:0x0763  */
    /* JADX WARN: Code duplicated, block: B:88:0x0765  */
    /* JADX WARN: Code duplicated, block: B:92:0x07c4  */
    /* JADX WARN: Code duplicated, block: B:93:0x0829  */
    /* JADX WARN: Code duplicated, block: B:95:0x082f  */
    /* JADX WARN: Code duplicated, block: B:96:0x0891  */
    static final Unit SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$38(final MutableState $pinSuccess$delegate, final MutableState $customApiKey$delegate, final AppPreferences $preferences, final MutableState $pinInput$delegate, final MutableState $pinError$delegate, final MutableState $savedConfirmation$delegate, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        int i;
        Composer composer;
        Composer composer2;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function1;
        Composer composerM3652constructorimpl;
        int currentCompositeKeyHash2;
        Function0<ComposeUiNode> constructor2;
        Function0<ComposeUiNode> function2;
        Composer composerM3652constructorimpl2;
        Composer composer3;
        int currentCompositeKeyHash3;
        Function0<ComposeUiNode> constructor3;
        Function0<ComposeUiNode> function3;
        Composer composerM3652constructorimpl3;
        Object objRememberedValue;
        boolean zChangedInstance;
        Object objRememberedValue2;
        Composer composer4;
        Object obj;
        ComposerKt.sourceInformation($composer, "C290@10786L4135:SettingsScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1201852915, $changed, -1, "com.example.ui.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:290)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor4 = ComposeUiNode.INSTANCE.getConstructor();
            int i2 = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor4;
                $composer.createNode(function0);
            } else {
                function0 = constructor4;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl4 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl4.getInserting()) {
                i = 6;
                composer = $composer;
            } else {
                i = 6;
                composer = $composer;
                if (!Intrinsics.areEqual(composerM3652constructorimpl4.rememberedValue(), Integer.valueOf(currentCompositeKeyHash4))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i3 = (i2 >> 6) & 14;
                composer2 = composer;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i4 = ((i >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -1974484758, "C291@10843L1339,326@12196L40,329@12453L10,330@12511L11,327@12249L304,333@12567L41,335@12622L1641:SettingsScreen.kt#naom5h");
                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap2 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i5 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function1 = constructor;
                    composer2.createNode(function1);
                } else {
                    function1 = constructor;
                    composer2.useNode();
                }
                composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                    composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash2);
                }
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i6 = (i5 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                int i7 = ((438 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -1735410251, "C296@11053L561:SettingsScreen.kt#naom5h");
                Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                Modifier modifier = Modifier.INSTANCE;
                MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically2, composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composer2, modifier);
                constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                int i8 = ((((384 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function2 = constructor2;
                    composer2.createNode(function2);
                } else {
                    function2 = constructor2;
                    composer2.useNode();
                }
                composerM3652constructorimpl2 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                    composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                    composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash3);
                }
                Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i9 = (i8 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                int i10 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -1304804519, "C297@11123L208,303@11348L39,306@11511L10,304@11404L194:SettingsScreen.kt#naom5h");
                IconKt.m2150Iconww6aTOc(LockKt.getLock(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), ColorKt.getIndigoLight(), composer2, 3504, 0);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), composer2, 6);
                TextKt.m2693Text4IGK_g("Zašifrovaný trezor (heslo / PIN)", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, 196614, 0, 65502);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                if (SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$28($pinSuccess$delegate) && StringsKt.isBlank(SettingsScreen$lambda$1($customApiKey$delegate))) {
                    composer2.startReplaceGroup(-1746410385);
                    composer2.endReplaceGroup();
                    composer3 = composer2;
                } else {
                    composer2.startReplaceGroup(-1734813471);
                    ComposerKt.sourceInformation(composer2, "311@11692L460");
                    long emeraldSuccess = ColorKt.getEmeraldSuccess();
                    composer3 = composer2;
                    SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(6)), Color.m4157copywmQWz5c(emeraldSuccess, (14 & 1) != 0 ? Color.m4161getAlphaimpl(emeraldSuccess) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(emeraldSuccess) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(emeraldSuccess) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(emeraldSuccess) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m6949getLambda$899787907$app(), composer3, 12583296, 121);
                    composer3.endReplaceGroup();
                }
                ComposerKt.sourceInformationMarkerEnd(composer3);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                TextKt.m2693Text4IGK_g("Zadejte heslo 3011 pro automatické dešifrování chráněného API klíče. Klíč se trvale uloží a při dalším spuštění už heslo není vyžadováno.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer2, 6);
                Alignment.Vertical centerVertically3 = Alignment.INSTANCE.getCenterVertically();
                Arrangement.Horizontal horizontalM550spacedBy0680j_4 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
                Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy3 = RowKt.rowMeasurePolicy(horizontalM550spacedBy0680j_4, centerVertically3, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap4 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default2);
                constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                int i11 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function3 = constructor3;
                    composer2.createNode(function3);
                } else {
                    function3 = constructor3;
                    composer2.useNode();
                }
                composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl3.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                    composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                    composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash4);
                }
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                int i12 = (i11 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                int i13 = ((438 >> 6) & 112) | 6;
                RowScope rowScope = RowScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composer2, 848133440, "C342@12919L86,340@12834L558,371@14020L44,357@13442L536,356@13408L841:SettingsScreen.kt#naom5h");
                String strSettingsScreen$lambda$49$lambda$48$lambda$47$lambda$22 = SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$22($pinInput$delegate);
                PasswordVisualTransformation passwordVisualTransformation = new PasswordVisualTransformation((char) 0, 1, null);
                boolean zSettingsScreen$lambda$49$lambda$48$lambda$47$lambda$25 = SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$25($pinError$delegate);
                RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10));
                Modifier modifierTestTag = TestTagKt.testTag(RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), "pin_vault_input");
                ComposerKt.sourceInformationMarkerStart(composer2, -111186798, "CC(remember):SettingsScreen.kt#9igjgp");
                objRememberedValue = composer2.rememberedValue();
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    objRememberedValue = new Function1() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda5
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return SettingsScreenKt.SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$38$lambda$37$lambda$36$lambda$33$lambda$32($pinInput$delegate, $pinError$delegate, (String) obj2);
                        }
                    };
                    composer2.updateRememberedValue(objRememberedValue);
                }
                ComposerKt.sourceInformationMarkerEnd(r2);
                OutlinedTextFieldKt.OutlinedTextField(strSettingsScreen$lambda$49$lambda$48$lambda$47$lambda$22, (Function1<? super String, Unit>) objRememberedValue, modifierTestTag, false, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$SettingsScreenKt.INSTANCE.getLambda$1567105667$app(), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, zSettingsScreen$lambda$49$lambda$48$lambda$47$lambda$25, (VisualTransformation) passwordVisualTransformation, (KeyboardOptions) null, (KeyboardActions) null, true, 0, 0, (MutableInteractionSource) null, (Shape) roundedCornerShapeM953RoundedCornerShape0680j_4, (TextFieldColors) null, (Composer) r2, 12582960, 12582912, 0, 6135672);
                ButtonColors buttonColorsM1809buttonColorsro_MJ88 = ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(ColorKt.getIndigoPrimary(), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14);
                RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_5 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10));
                Modifier modifierTestTag2 = TestTagKt.testTag(Modifier.INSTANCE, "unlock_pin_button");
                ComposerKt.sourceInformationMarkerStart(composer2, -111169612, "CC(remember):SettingsScreen.kt#9igjgp");
                zChangedInstance = composer2.changedInstance($preferences);
                objRememberedValue2 = composer2.rememberedValue();
                if (zChangedInstance) {
                    composer4 = composer2;
                } else {
                    composer4 = composer2;
                    if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                        obj = objRememberedValue2;
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    ButtonKt.Button((Function0) obj, modifierTestTag2, false, roundedCornerShapeM953RoundedCornerShape0680j_5, buttonColorsM1809buttonColorsro_MJ88, null, null, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m6947getLambda$220087124$app(), composer4, 805306416, 484);
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    if (SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$25($pinError$delegate)) {
                        composer2.startReplaceGroup(-1971181895);
                        ComposerKt.sourceInformation(composer2, "380@14307L40,383@14458L11,384@14515L10,381@14362L189");
                        SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                        TextKt.m2693Text4IGK_g("Nesprávné heslo nebo PIN.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getError(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
                        composer2.endReplaceGroup();
                    } else {
                        if (SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$28($pinSuccess$delegate)) {
                            composer2.startReplaceGroup(-1970886775);
                            ComposerKt.sourceInformation(composer2, "387@14603L40,391@14809L10,388@14658L237");
                            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                            TextKt.m2693Text4IGK_g("Klíč byl úspěšně dešifrován a aktivován!", (Modifier) null, ColorKt.getEmeraldSuccess(), 0L, (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 196998, 0, 65498);
                        } else {
                            composer2.startReplaceGroup(-1985368053);
                        }
                        composer2.endReplaceGroup();
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                }
                obj = new Function0() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return SettingsScreenKt.SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$38$lambda$37$lambda$36$lambda$35$lambda$34($preferences, $pinInput$delegate, $customApiKey$delegate, $pinSuccess$delegate, $pinError$delegate, $savedConfirmation$delegate);
                    }
                };
                composer2.updateRememberedValue(obj);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ButtonKt.Button((Function0) obj, modifierTestTag2, false, roundedCornerShapeM953RoundedCornerShape0680j_5, buttonColorsM1809buttonColorsro_MJ88, null, null, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m6947getLambda$220087124$app(), composer4, 805306416, 484);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                if (SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$25($pinError$delegate)) {
                    composer2.startReplaceGroup(-1971181895);
                    ComposerKt.sourceInformation(composer2, "380@14307L40,383@14458L11,384@14515L10,381@14362L189");
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                    TextKt.m2693Text4IGK_g("Nesprávné heslo nebo PIN.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getError(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
                    composer2.endReplaceGroup();
                } else {
                    if (SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$28($pinSuccess$delegate)) {
                        composer2.startReplaceGroup(-1970886775);
                        ComposerKt.sourceInformation(composer2, "387@14603L40,391@14809L10,388@14658L237");
                        SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                        TextKt.m2693Text4IGK_g("Klíč byl úspěšně dešifrován a aktivován!", (Modifier) null, ColorKt.getEmeraldSuccess(), 0L, (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 196998, 0, 65498);
                    } else {
                        composer2.startReplaceGroup(-1985368053);
                    }
                    composer2.endReplaceGroup();
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
            composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash);
            Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i14 = (i2 >> 6) & 14;
            composer2 = composer;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
            int i15 = ((i >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -1974484758, "C291@10843L1339,326@12196L40,329@12453L10,330@12511L11,327@12249L304,333@12567L41,335@12622L1641:SettingsScreen.kt#naom5h");
            Alignment.Vertical centerVertically4 = Alignment.INSTANCE.getCenterVertically();
            Arrangement.Horizontal spaceBetween2 = Arrangement.INSTANCE.getSpaceBetween();
            Modifier modifierFillMaxWidth$default3 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy4 = RowKt.rowMeasurePolicy(spaceBetween2, centerVertically4, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap5 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default3);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i16 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function1 = constructor;
                composer2.createNode(function1);
            } else {
                function1 = constructor;
                composer2.useNode();
            }
            composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl.getInserting()) {
            }
            composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash5);
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
            int i17 = (i16 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance3 = RowScopeInstance.INSTANCE;
            int i18 = ((438 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -1735410251, "C296@11053L561:SettingsScreen.kt#naom5h");
            Alignment.Vertical centerVertically5 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            Modifier modifier2 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy5 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically5, composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap6 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier6 = ComposedModifierKt.materializeModifier(composer2, modifier2);
            constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i19 = ((((384 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function2 = constructor2;
                composer2.createNode(function2);
            } else {
                function2 = constructor2;
                composer2.useNode();
            }
            composerM3652constructorimpl2 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy5, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap6, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash6 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl2.getInserting()) {
            }
            composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash6);
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier6, ComposeUiNode.INSTANCE.getSetModifier());
            int i20 = (i19 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance4 = RowScopeInstance.INSTANCE;
            int i110 = ((384 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -1304804519, "C297@11123L208,303@11348L39,306@11511L10,304@11404L194:SettingsScreen.kt#naom5h");
            IconKt.m2150Iconww6aTOc(LockKt.getLock(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), ColorKt.getIndigoLight(), composer2, 3504, 0);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), composer2, 6);
            TextKt.m2693Text4IGK_g("Zašifrovaný trezor (heslo / PIN)", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, 196614, 0, 65502);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            if (SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$28($pinSuccess$delegate)) {
                composer2.startReplaceGroup(-1734813471);
                ComposerKt.sourceInformation(composer2, "311@11692L460");
                long emeraldSuccess2 = ColorKt.getEmeraldSuccess();
                composer3 = composer2;
                SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(6)), Color.m4157copywmQWz5c(emeraldSuccess2, (14 & 1) != 0 ? Color.m4161getAlphaimpl(emeraldSuccess2) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(emeraldSuccess2) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(emeraldSuccess2) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(emeraldSuccess2) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m6949getLambda$899787907$app(), composer3, 12583296, 121);
                composer3.endReplaceGroup();
            } else {
                composer2.startReplaceGroup(-1734813471);
                ComposerKt.sourceInformation(composer2, "311@11692L460");
                long emeraldSuccess3 = ColorKt.getEmeraldSuccess();
                composer3 = composer2;
                SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(6)), Color.m4157copywmQWz5c(emeraldSuccess3, (14 & 1) != 0 ? Color.m4161getAlphaimpl(emeraldSuccess3) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(emeraldSuccess3) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(emeraldSuccess3) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(emeraldSuccess3) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m6949getLambda$899787907$app(), composer3, 12583296, 121);
                composer3.endReplaceGroup();
            }
            ComposerKt.sourceInformationMarkerEnd(composer3);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
            TextKt.m2693Text4IGK_g("Zadejte heslo 3011 pro automatické dešifrování chráněného API klíče. Klíč se trvale uloží a při dalším spuštění už heslo není vyžadováno.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer2, 6);
            Alignment.Vertical centerVertically6 = Alignment.INSTANCE.getCenterVertically();
            Arrangement.Horizontal horizontalM550spacedBy0680j_5 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
            Modifier modifierFillMaxWidth$default4 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy6 = RowKt.rowMeasurePolicy(horizontalM550spacedBy0680j_5, centerVertically6, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap7 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier7 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default4);
            constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            int i111 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function3 = constructor3;
                composer2.createNode(function3);
            } else {
                function3 = constructor3;
                composer2.useNode();
            }
            composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy6, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap7, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash7 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl3.getInserting()) {
            }
            composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
            composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash7);
            Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier7, ComposeUiNode.INSTANCE.getSetModifier());
            int i112 = (i111 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            int i113 = ((438 >> 6) & 112) | 6;
            RowScope rowScope2 = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer2, 848133440, "C342@12919L86,340@12834L558,371@14020L44,357@13442L536,356@13408L841:SettingsScreen.kt#naom5h");
            String strSettingsScreen$lambda$49$lambda$48$lambda$47$lambda$23 = SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$22($pinInput$delegate);
            PasswordVisualTransformation passwordVisualTransformation2 = new PasswordVisualTransformation((char) 0, 1, null);
            boolean zSettingsScreen$lambda$49$lambda$48$lambda$47$lambda$26 = SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$25($pinError$delegate);
            RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_6 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10));
            Modifier modifierTestTag3 = TestTagKt.testTag(RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), "pin_vault_input");
            ComposerKt.sourceInformationMarkerStart(composer2, -111186798, "CC(remember):SettingsScreen.kt#9igjgp");
            objRememberedValue = composer2.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objRememberedValue = new Function1() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda5
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return SettingsScreenKt.SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$38$lambda$37$lambda$36$lambda$33$lambda$32($pinInput$delegate, $pinError$delegate, (String) obj2);
                    }
                };
                composer2.updateRememberedValue(objRememberedValue);
            }
            ComposerKt.sourceInformationMarkerEnd(r2);
            OutlinedTextFieldKt.OutlinedTextField(strSettingsScreen$lambda$49$lambda$48$lambda$47$lambda$23, (Function1<? super String, Unit>) objRememberedValue, modifierTestTag3, false, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$SettingsScreenKt.INSTANCE.getLambda$1567105667$app(), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, zSettingsScreen$lambda$49$lambda$48$lambda$47$lambda$26, (VisualTransformation) passwordVisualTransformation2, (KeyboardOptions) null, (KeyboardActions) null, true, 0, 0, (MutableInteractionSource) null, (Shape) roundedCornerShapeM953RoundedCornerShape0680j_6, (TextFieldColors) null, (Composer) r2, 12582960, 12582912, 0, 6135672);
            ButtonColors buttonColorsM1809buttonColorsro_MJ89 = ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(ColorKt.getIndigoPrimary(), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14);
            RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_7 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10));
            Modifier modifierTestTag4 = TestTagKt.testTag(Modifier.INSTANCE, "unlock_pin_button");
            ComposerKt.sourceInformationMarkerStart(composer2, -111169612, "CC(remember):SettingsScreen.kt#9igjgp");
            zChangedInstance = composer2.changedInstance($preferences);
            objRememberedValue2 = composer2.rememberedValue();
            if (zChangedInstance) {
                composer4 = composer2;
                if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    obj = objRememberedValue2;
                }
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ButtonKt.Button((Function0) obj, modifierTestTag4, false, roundedCornerShapeM953RoundedCornerShape0680j_7, buttonColorsM1809buttonColorsro_MJ89, null, null, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m6947getLambda$220087124$app(), composer4, 805306416, 484);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                if (SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$25($pinError$delegate)) {
                    composer2.startReplaceGroup(-1971181895);
                    ComposerKt.sourceInformation(composer2, "380@14307L40,383@14458L11,384@14515L10,381@14362L189");
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                    TextKt.m2693Text4IGK_g("Nesprávné heslo nebo PIN.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getError(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
                    composer2.endReplaceGroup();
                } else {
                    if (SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$28($pinSuccess$delegate)) {
                        composer2.startReplaceGroup(-1970886775);
                        ComposerKt.sourceInformation(composer2, "387@14603L40,391@14809L10,388@14658L237");
                        SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                        TextKt.m2693Text4IGK_g("Klíč byl úspěšně dešifrován a aktivován!", (Modifier) null, ColorKt.getEmeraldSuccess(), 0L, (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 196998, 0, 65498);
                    } else {
                        composer2.startReplaceGroup(-1985368053);
                    }
                    composer2.endReplaceGroup();
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composer4 = composer2;
            }
            obj = new Function0() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda6
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return SettingsScreenKt.SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$38$lambda$37$lambda$36$lambda$35$lambda$34($preferences, $pinInput$delegate, $customApiKey$delegate, $pinSuccess$delegate, $pinError$delegate, $savedConfirmation$delegate);
                }
            };
            composer2.updateRememberedValue(obj);
            ComposerKt.sourceInformationMarkerEnd(composer4);
            ButtonKt.Button((Function0) obj, modifierTestTag4, false, roundedCornerShapeM953RoundedCornerShape0680j_7, buttonColorsM1809buttonColorsro_MJ89, null, null, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m6947getLambda$220087124$app(), composer4, 805306416, 484);
            ComposerKt.sourceInformationMarkerEnd(composer4);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            if (SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$25($pinError$delegate)) {
                composer2.startReplaceGroup(-1971181895);
                ComposerKt.sourceInformation(composer2, "380@14307L40,383@14458L11,384@14515L10,381@14362L189");
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                TextKt.m2693Text4IGK_g("Nesprávné heslo nebo PIN.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getError(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
                composer2.endReplaceGroup();
            } else {
                if (SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$28($pinSuccess$delegate)) {
                    composer2.startReplaceGroup(-1970886775);
                    ComposerKt.sourceInformation(composer2, "387@14603L40,391@14809L10,388@14658L237");
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                    TextKt.m2693Text4IGK_g("Klíč byl úspěšně dešifrován a aktivován!", (Modifier) null, ColorKt.getEmeraldSuccess(), 0L, (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 196998, 0, 65498);
                } else {
                    composer2.startReplaceGroup(-1985368053);
                }
                composer2.endReplaceGroup();
            }
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$38$lambda$37$lambda$36$lambda$33$lambda$32(MutableState $pinInput$delegate, MutableState $pinError$delegate, String it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $pinInput$delegate.setValue(it);
        SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$26($pinError$delegate, false);
        return Unit.INSTANCE;
    }

    static final Unit SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$38$lambda$37$lambda$36$lambda$35$lambda$34(AppPreferences $preferences, MutableState $pinInput$delegate, MutableState $customApiKey$delegate, MutableState $pinSuccess$delegate, MutableState $pinError$delegate, MutableState $savedConfirmation$delegate) {
        String unlocked = EncryptedApiKeyVault.INSTANCE.unlock(StringsKt.trim((CharSequence) SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$22($pinInput$delegate)).toString());
        if (unlocked == null) {
            SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$26($pinError$delegate, true);
            SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$29($pinSuccess$delegate, false);
        } else {
            $customApiKey$delegate.setValue(unlocked);
            $preferences.setCustomApiKey(unlocked);
            $preferences.setVaultUnlocked(true);
            SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$29($pinSuccess$delegate, true);
            SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$26($pinError$delegate, false);
            SettingsScreen$lambda$5($savedConfirmation$delegate, true);
        }
        return Unit.INSTANCE;
    }

    static final Unit SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$40$lambda$39(MutableState $customApiKey$delegate, MutableState $savedConfirmation$delegate, String it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $customApiKey$delegate.setValue(it);
        SettingsScreen$lambda$5($savedConfirmation$delegate, false);
        return Unit.INSTANCE;
    }

    static final Unit SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$46$lambda$42$lambda$41(AppPreferences $preferences, MutableState $customApiKey$delegate, MutableState $savedConfirmation$delegate) {
        $preferences.setCustomApiKey(SettingsScreen$lambda$1($customApiKey$delegate));
        SettingsScreen$lambda$5($savedConfirmation$delegate, true);
        return Unit.INSTANCE;
    }

    static final Unit SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$46$lambda$43(MutableState $savedConfirmation$delegate, RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C442@16361L51,443@16425L39,444@16477L58:SettingsScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1478716163, $changed, -1, "com.example.ui.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:442)");
            }
            IconKt.m2150Iconww6aTOc(SaveKt.getSave(Icons.INSTANCE.getDefault()), (String) null, (Modifier) null, 0L, $composer, 48, 12);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), $composer, 6);
            TextKt.m2693Text4IGK_g(SettingsScreen$lambda$4($savedConfirmation$delegate) ? "Uloženo!" : "Uložit klíč", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 0, 0, 131070);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit SettingsScreen$lambda$49$lambda$48$lambda$47$lambda$46$lambda$45$lambda$44(AppPreferences $preferences, MutableState $customApiKey$delegate, MutableState $savedConfirmation$delegate) {
        $customApiKey$delegate.setValue("");
        $preferences.setCustomApiKey("");
        SettingsScreen$lambda$5($savedConfirmation$delegate, false);
        return Unit.INSTANCE;
    }

    private static final void ModelQuotaRow(final ModelQuotaInfo info, Composer $composer, final int $changed) {
        Composer $composer2 = $composer.startRestartGroup(-214791786);
        ComposerKt.sourceInformation($composer2, "C(ModelQuotaRow)527@19267L11,530@19397L2322,526@19232L2487:SettingsScreen.kt#naom5h");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer2.changed(info) ? 4 : 2;
        }
        if (($dirty & 3) == 2 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-214791786, $dirty, -1, "com.example.ui.ModelQuotaRow (SettingsScreen.kt:525)");
            }
            long surfaceVariant = MaterialTheme.INSTANCE.getColorScheme($composer2, MaterialTheme.$stable).getSurfaceVariant();
            SurfaceKt.m2543SurfaceT9BRK9s(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)), Color.m4157copywmQWz5c(surfaceVariant, (14 & 1) != 0 ? Color.m4161getAlphaimpl(surfaceVariant) : 0.35f, (14 & 2) != 0 ? Color.m4165getRedimpl(surfaceVariant) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(surfaceVariant) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(surfaceVariant) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(1493362801, true, new Function2() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda13
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return SettingsScreenKt.ModelQuotaRow$lambda$55(info, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, $composer2, 54), $composer2, 12582918, 120);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda14
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return SettingsScreenKt.ModelQuotaRow$lambda$56(info, $changed, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    /* JADX WARN: Code duplicated, block: B:58:0x03e5  */
    /* JADX WARN: Code duplicated, block: B:59:0x0446  */
    /* JADX WARN: Code duplicated, block: B:65:0x04b7  */
    /* JADX WARN: Code duplicated, block: B:67:0x04c1  */
    /* JADX WARN: Code duplicated, block: B:68:0x04c6  */
    /* JADX WARN: Code duplicated, block: B:72:0x0569  */
    /* JADX WARN: Code duplicated, block: B:74:0x056f  */
    /* JADX WARN: Code duplicated, block: B:75:0x059d  */
    /* JADX WARN: Code duplicated, block: B:76:0x05cb  */
    /* JADX WARN: Code duplicated, block: B:79:0x0661  */
    static final Unit ModelQuotaRow$lambda$55(ModelQuotaInfo $info, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        Function0<ComposeUiNode> function1;
        Function0<ComposeUiNode> function2;
        Composer composer;
        Composer composer2;
        int safetyCutoff;
        String str;
        Triple triple;
        ComposerKt.sourceInformation($composer, "C531@19403L2312:SettingsScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1493362801, $changed, -1, "com.example.ui.ModelQuotaRow.<anonymous> (SettingsScreen.kt:531)");
            }
            Modifier modifierM671paddingVpY3zN4 = PaddingKt.m671paddingVpY3zN4(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(12), Dp.m6622constructorimpl(10));
            Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM671paddingVpY3zN4);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor;
                $composer.createNode(function0);
            } else {
                function0 = constructor;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i2 = (i >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            int i3 = ((438 >> 6) & 112) | 6;
            RowScope rowScope = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart($composer, 1961590590, "C538@19637L1324,583@21474L235,580@21390L319:SettingsScreen.kt#naom5h");
            Modifier modifierWeight$default = RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null);
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap2 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifierWeight$default);
            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i4 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function1 = constructor2;
                $composer.createNode(function1);
            } else {
                function1 = constructor2;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl2 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash2);
            }
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            int i5 = (i4 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            int i6 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -1060351239, "C539@19686L743,561@20438L40,570@20915L11,567@20821L132:SettingsScreen.kt#naom5h");
            Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            Modifier modifier = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically2, $composer, ((384 >> 3) & 14) | ((384 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap3 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier($composer, modifier);
            Function0<ComposeUiNode> constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            int i7 = ((((384 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function2 = constructor3;
                $composer.createNode(function2);
            } else {
                function2 = constructor3;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl3 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl3.getInserting()) {
                composer = $composer;
            } else {
                composer = $composer;
                if (!Intrinsics.areEqual(composerM3652constructorimpl3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i8 = (i7 >> 6) & 14;
                composer2 = composer;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                int i9 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 1184434355, "C542@19827L10,540@19750L152:SettingsScreen.kt#naom5h");
                TextKt.m2693Text4IGK_g($info.getDisplayName(), (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 0, 65502);
                if ($info.isLite()) {
                    composer2.startReplaceGroup(1184607334);
                    ComposerKt.sourceInformation(composer2, "546@19944L39,547@19996L411");
                    SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                    long indigoLight = ColorKt.getIndigoLight();
                    SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(4)), Color.m4157copywmQWz5c(indigoLight, (14 & 1) != 0 ? Color.m4161getAlphaimpl(indigoLight) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(indigoLight) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(indigoLight) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(indigoLight) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m6946getLambda$217806595$app(), composer2, 12583296, 121);
                } else {
                    composer2.startReplaceGroup(1164820623);
                }
                composer2.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(2)), $composer, 6);
                if ($info.isBlocked() || $info.getCallsToday() < 20) {
                    int callsToday = $info.getCallsToday();
                    if ($info.isLite()) {
                        safetyCutoff = $info.getDailyLimit();
                    } else {
                        safetyCutoff = $info.getSafetyCutoff();
                    }
                    str = "Dnes: " + callsToday + "/" + safetyCutoff + " RPD • Minuta: " + $info.getCallsThisMinute() + "/" + $info.getMinuteLimit() + " RPM";
                } else {
                    str = "Dnes: " + $info.getCallsToday() + "/" + $info.getDailyLimit() + " RPD • Okamžitá stopka";
                }
                TextKt.m2693Text4IGK_g(str, (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3072, 0, 131058);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                switch (WhenMappings.$EnumSwitchMapping$0[$info.getHealthState().ordinal()]) {
                    case 1:
                        Color colorM4149boximpl = Color.m4149boximpl(ColorKt.getEmeraldSuccess());
                        long emeraldSuccess = ColorKt.getEmeraldSuccess();
                        triple = new Triple(colorM4149boximpl, Color.m4149boximpl(Color.m4157copywmQWz5c(emeraldSuccess, (14 & 1) != 0 ? Color.m4161getAlphaimpl(emeraldSuccess) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(emeraldSuccess) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(emeraldSuccess) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(emeraldSuccess) : 0.0f)), "🟢 OK");
                        break;
                    case 2:
                        Color colorM4149boximpl2 = Color.m4149boximpl(androidx.compose.ui.graphics.ColorKt.Color(4294286859L));
                        long jColor = androidx.compose.ui.graphics.ColorKt.Color(4294286859L);
                        triple = new Triple(colorM4149boximpl2, Color.m4149boximpl(Color.m4157copywmQWz5c(jColor, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jColor) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jColor) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jColor) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jColor) : 0.0f)), "🟠 Strop");
                        break;
                    case 3:
                        Color colorM4149boximpl3 = Color.m4149boximpl(androidx.compose.ui.graphics.ColorKt.Color(4292617766L));
                        long jColor2 = androidx.compose.ui.graphics.ColorKt.Color(4292617766L);
                        triple = new Triple(colorM4149boximpl3, Color.m4149boximpl(Color.m4157copywmQWz5c(jColor2, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jColor2) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jColor2) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jColor2) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jColor2) : 0.0f)), "🔴 Vyřazen");
                        break;
                    default:
                        throw new NoWhenBranchMatchedException();
                }
                final long jM4169unboximpl = ((Color) triple.component1()).m4169unboximpl();
                long jM4169unboximpl2 = ((Color) triple.component2()).m4169unboximpl();
                final String str2 = (String) triple.component3();
                SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8)), jM4169unboximpl2, 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(1237534290, true, new Function2() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return SettingsScreenKt.ModelQuotaRow$lambda$55$lambda$54$lambda$53(str2, jM4169unboximpl, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, $composer, 54), $composer, 12582912, 121);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
            composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash3);
            Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
            int i10 = (i7 >> 6) & 14;
            composer2 = composer;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
            int i11 = ((384 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 1184434355, "C542@19827L10,540@19750L152:SettingsScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g($info.getDisplayName(), (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_CANT_WRITE_PROFILE_VERIFICATION_RESULT_CACHE_FILE, 0, 65502);
            if ($info.isLite()) {
                composer2.startReplaceGroup(1184607334);
                ComposerKt.sourceInformation(composer2, "546@19944L39,547@19996L411");
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                long indigoLight2 = ColorKt.getIndigoLight();
                SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(4)), Color.m4157copywmQWz5c(indigoLight2, (14 & 1) != 0 ? Color.m4161getAlphaimpl(indigoLight2) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(indigoLight2) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(indigoLight2) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(indigoLight2) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m6946getLambda$217806595$app(), composer2, 12583296, 121);
            } else {
                composer2.startReplaceGroup(1164820623);
            }
            composer2.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(2)), $composer, 6);
            if ($info.isBlocked()) {
                int callsToday2 = $info.getCallsToday();
                if ($info.isLite()) {
                    safetyCutoff = $info.getDailyLimit();
                } else {
                    safetyCutoff = $info.getSafetyCutoff();
                }
                str = "Dnes: " + callsToday2 + "/" + safetyCutoff + " RPD • Minuta: " + $info.getCallsThisMinute() + "/" + $info.getMinuteLimit() + " RPM";
            } else {
                int callsToday3 = $info.getCallsToday();
                if ($info.isLite()) {
                    safetyCutoff = $info.getDailyLimit();
                } else {
                    safetyCutoff = $info.getSafetyCutoff();
                }
                str = "Dnes: " + callsToday3 + "/" + safetyCutoff + " RPD • Minuta: " + $info.getCallsThisMinute() + "/" + $info.getMinuteLimit() + " RPM";
            }
            TextKt.m2693Text4IGK_g(str, (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(11), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3072, 0, 131058);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            switch (WhenMappings.$EnumSwitchMapping$0[$info.getHealthState().ordinal()]) {
                case 1:
                    Color colorM4149boximpl4 = Color.m4149boximpl(ColorKt.getEmeraldSuccess());
                    long emeraldSuccess2 = ColorKt.getEmeraldSuccess();
                    triple = new Triple(colorM4149boximpl4, Color.m4149boximpl(Color.m4157copywmQWz5c(emeraldSuccess2, (14 & 1) != 0 ? Color.m4161getAlphaimpl(emeraldSuccess2) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(emeraldSuccess2) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(emeraldSuccess2) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(emeraldSuccess2) : 0.0f)), "🟢 OK");
                    break;
                case 2:
                    Color colorM4149boximpl5 = Color.m4149boximpl(androidx.compose.ui.graphics.ColorKt.Color(4294286859L));
                    long jColor3 = androidx.compose.ui.graphics.ColorKt.Color(4294286859L);
                    triple = new Triple(colorM4149boximpl5, Color.m4149boximpl(Color.m4157copywmQWz5c(jColor3, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jColor3) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jColor3) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jColor3) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jColor3) : 0.0f)), "🟠 Strop");
                    break;
                case 3:
                    Color colorM4149boximpl6 = Color.m4149boximpl(androidx.compose.ui.graphics.ColorKt.Color(4292617766L));
                    long jColor4 = androidx.compose.ui.graphics.ColorKt.Color(4292617766L);
                    triple = new Triple(colorM4149boximpl6, Color.m4149boximpl(Color.m4157copywmQWz5c(jColor4, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jColor4) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jColor4) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jColor4) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jColor4) : 0.0f)), "🔴 Vyřazen");
                    break;
                default:
                    throw new NoWhenBranchMatchedException();
            }
            final long jM4169unboximpl3 = ((Color) triple.component1()).m4169unboximpl();
            long jM4169unboximpl4 = ((Color) triple.component2()).m4169unboximpl();
            final String str3 = (String) triple.component3();
            SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8)), jM4169unboximpl4, 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(1237534290, true, new Function2() { // from class: com.example.ui.SettingsScreenKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return SettingsScreenKt.ModelQuotaRow$lambda$55$lambda$54$lambda$53(str3, jM4169unboximpl3, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, $composer, 54), $composer, 12582912, 121);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit ModelQuotaRow$lambda$55$lambda$54$lambda$53(String $statusText, long $statusColor, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C584@21484L217:SettingsScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1237534290, $changed, -1, "com.example.ui.ModelQuotaRow.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:584)");
            }
            TextKt.m2693Text4IGK_g($statusText, PaddingKt.m671paddingVpY3zN4(Modifier.INSTANCE, Dp.m6622constructorimpl(8), Dp.m6622constructorimpl(4)), $statusColor, TextUnitKt.getSp(11), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 199728, 0, 131024);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
