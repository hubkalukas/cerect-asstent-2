package com.example.ui;

import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.shape.RoundedCornerShape;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.foundation.text.KeyboardActions;
import androidx.compose.foundation.text.KeyboardOptions;
import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.filled.HistoryKt;
import androidx.compose.material.icons.filled.LayersKt;
import androidx.compose.material.icons.filled.PsychologyKt;
import androidx.compose.material.icons.filled.SettingsKt;
import androidx.compose.material3.AndroidAlertDialog_androidKt;
import androidx.compose.material3.ButtonColors;
import androidx.compose.material3.ButtonDefaults;
import androidx.compose.material3.ButtonKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.NavigationBarItemColors;
import androidx.compose.material3.NavigationBarItemDefaults;
import androidx.compose.material3.NavigationBarKt;
import androidx.compose.material3.OutlinedTextFieldKt;
import androidx.compose.material3.ScaffoldKt;
import androidx.compose.material3.TextFieldColors;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.MutableIntState;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotIntStateKt;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.TestTagKt;
import androidx.compose.ui.text.TextLayoutResult;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.input.PasswordVisualTransformation;
import androidx.compose.ui.text.input.VisualTransformation;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.TextUnitKt;
import com.example.data.AppPreferences;
import com.example.data.EncryptedApiKeyVault;
import com.example.data.GeminiService;
import com.example.ui.theme.ColorKt;
import java.util.List;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: MainScreen.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u00000\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\u001aA\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00010\t2\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00010\tH\u0007¢\u0006\u0002\u0010\u000b¨\u0006\f²\u0006\n\u0010\r\u001a\u00020\u000eX\u008a\u008e\u0002²\u0006\n\u0010\u000f\u001a\u00020\u0003X\u008a\u008e\u0002²\u0006\n\u0010\u0010\u001a\u00020\u0011X\u008a\u008e\u0002²\u0006\n\u0010\u0012\u001a\u00020\u0003X\u008a\u008e\u0002"}, d2 = {"MainScreen", "", "isServiceRunning", "", "preferences", "Lcom/example/data/AppPreferences;", "geminiService", "Lcom/example/data/GeminiService;", "onRequestCaptureAndStart", "Lkotlin/Function0;", "onStopService", "(ZLcom/example/data/AppPreferences;Lcom/example/data/GeminiService;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V", "app", "selectedTab", "", "showFirstLaunchDialog", "pinInput", "", "pinError"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class MainScreenKt {
    static final Unit MainScreen$lambda$33(boolean z, AppPreferences appPreferences, GeminiService geminiService, Function0 function0, Function0 function1, int i, Composer composer, int i2) {
        MainScreen(z, appPreferences, geminiService, function0, function1, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
        return Unit.INSTANCE;
    }

    public static final void MainScreen(final boolean isServiceRunning, final AppPreferences preferences, final GeminiService geminiService, final Function0<Unit> onRequestCaptureAndStart, final Function0<Unit> onStopService, Composer $composer, final int $changed) {
        Object objMutableIntStateOf;
        Object objMutableStateOf$default;
        Object objMutableStateOf$default2;
        char c;
        Object objMutableStateOf$default3;
        Composer $composer2;
        int i;
        int i2;
        Composer $composer3;
        Object obj;
        Intrinsics.checkNotNullParameter(preferences, "preferences");
        Intrinsics.checkNotNullParameter(geminiService, "geminiService");
        Intrinsics.checkNotNullParameter(onRequestCaptureAndStart, "onRequestCaptureAndStart");
        Intrinsics.checkNotNullParameter(onStopService, "onStopService");
        Composer $composer4 = $composer.startRestartGroup(-1517116180);
        ComposerKt.sourceInformation($composer4, "C(MainScreen)P(1,4)60@2543L33,63@2699L101,66@2819L31,67@2869L34,174@6202L821,195@7028L653,158@5772L1909:MainScreen.kt#naom5h");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer4.changed(isServiceRunning) ? 4 : 2;
        }
        if (($changed & 48) == 0) {
            $dirty |= $composer4.changedInstance(preferences) ? 32 : 16;
        }
        if (($changed & 384) == 0) {
            $dirty |= $composer4.changedInstance(geminiService) ? 256 : 128;
        }
        if (($changed & 3072) == 0) {
            $dirty |= $composer4.changedInstance(onRequestCaptureAndStart) ? 2048 : 1024;
        }
        if (($changed & 24576) == 0) {
            $dirty |= $composer4.changedInstance(onStopService) ? 16384 : 8192;
        }
        if (($dirty & 9363) == 9362 && $composer4.getSkipping()) {
            $composer4.skipToGroupEnd();
            $composer3 = $composer4;
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1517116180, $dirty, -1, "com.example.ui.MainScreen (MainScreen.kt:59)");
            }
            ComposerKt.sourceInformationMarkerStart($composer4, -1954727507, "CC(remember):MainScreen.kt#9igjgp");
            Object objRememberedValue = $composer4.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objMutableIntStateOf = SnapshotIntStateKt.mutableIntStateOf(0);
                $composer4.updateRememberedValue(objMutableIntStateOf);
            } else {
                objMutableIntStateOf = objRememberedValue;
            }
            final MutableIntState selectedTab$delegate = (MutableIntState) objMutableIntStateOf;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            ComposerKt.sourceInformationMarkerStart($composer4, -1954722447, "CC(remember):MainScreen.kt#9igjgp");
            Object objRememberedValue2 = $composer4.rememberedValue();
            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(Boolean.valueOf(!preferences.isVaultUnlocked() && StringsKt.isBlank(preferences.getCustomApiKey())), null, 2, null);
                $composer4.updateRememberedValue(objMutableStateOf$default);
            } else {
                objMutableStateOf$default = objRememberedValue2;
            }
            final MutableState showFirstLaunchDialog$delegate = (MutableState) objMutableStateOf$default;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            ComposerKt.sourceInformationMarkerStart($composer4, -1954718677, "CC(remember):MainScreen.kt#9igjgp");
            Object objRememberedValue3 = $composer4.rememberedValue();
            if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default2 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
                $composer4.updateRememberedValue(objMutableStateOf$default2);
            } else {
                objMutableStateOf$default2 = objRememberedValue3;
            }
            final MutableState pinInput$delegate = (MutableState) objMutableStateOf$default2;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            ComposerKt.sourceInformationMarkerStart($composer4, -1954717074, "CC(remember):MainScreen.kt#9igjgp");
            Object objRememberedValue4 = $composer4.rememberedValue();
            if (objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                c = 2;
                objMutableStateOf$default3 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                $composer4.updateRememberedValue(objMutableStateOf$default3);
            } else {
                c = 2;
                objMutableStateOf$default3 = objRememberedValue4;
            }
            final MutableState pinError$delegate = (MutableState) objMutableStateOf$default3;
            ComposerKt.sourceInformationMarkerEnd($composer4);
            if (MainScreen$lambda$4(showFirstLaunchDialog$delegate)) {
                $composer4.startReplaceGroup(-466541944);
                ComposerKt.sourceInformation($composer4, "147@5543L11,71@2978L33,119@4623L630,138@5277L186,86@3356L1243,70@2940L2628");
                RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(20));
                long surface = MaterialTheme.INSTANCE.getColorScheme($composer4, MaterialTheme.$stable).getSurface();
                ComposerKt.sourceInformationMarkerStart($composer4, -1954713587, "CC(remember):MainScreen.kt#9igjgp");
                Object objRememberedValue5 = $composer4.rememberedValue();
                if (objRememberedValue5 == Composer.INSTANCE.getEmpty()) {
                    obj = new Function0() { // from class: com.example.ui.MainScreenKt$$ExternalSyntheticLambda5
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return MainScreenKt.MainScreen$lambda$13$lambda$12(showFirstLaunchDialog$delegate);
                        }
                    };
                    $composer4.updateRememberedValue(obj);
                } else {
                    obj = objRememberedValue5;
                }
                ComposerKt.sourceInformationMarkerEnd($composer4);
                i = 4;
                c = 2;
                i2 = 54;
                AndroidAlertDialog_androidKt.m1762AlertDialogOix01E0((Function0) obj, ComposableLambdaKt.rememberComposableLambda(-829920583, true, new Function2() { // from class: com.example.ui.MainScreenKt$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj2, Object obj3) {
                        return MainScreenKt.MainScreen$lambda$16(preferences, pinInput$delegate, showFirstLaunchDialog$delegate, pinError$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, $composer4, 54), null, ComposableLambdaKt.rememberComposableLambda(-403366085, true, new Function2() { // from class: com.example.ui.MainScreenKt$$ExternalSyntheticLambda7
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj2, Object obj3) {
                        return MainScreenKt.MainScreen$lambda$19(showFirstLaunchDialog$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, $composer4, 54), ComposableSingletons$MainScreenKt.INSTANCE.getLambda$1957394812$app(), ComposableSingletons$MainScreenKt.INSTANCE.getLambda$23188413$app(), ComposableLambdaKt.rememberComposableLambda(-1911017986, true, new Function2() { // from class: com.example.ui.MainScreenKt$$ExternalSyntheticLambda8
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj2, Object obj3) {
                        return MainScreenKt.MainScreen$lambda$23(pinInput$delegate, pinError$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, $composer4, 54), roundedCornerShapeM953RoundedCornerShape0680j_4, surface, 0L, 0L, 0L, 0.0f, null, $composer4, 1797174, 0, 15876);
                $composer2 = $composer4;
            } else {
                $composer2 = $composer4;
                i = 4;
                i2 = 54;
                $composer2.startReplaceGroup(-469535242);
            }
            $composer2.endReplaceGroup();
            Pair[] pairArr = new Pair[i];
            pairArr[0] = TuplesKt.to("Překrytí", LayersKt.getLayers(Icons.INSTANCE.getDefault()));
            pairArr[1] = TuplesKt.to("Cvičný kvíz", PsychologyKt.getPsychology(Icons.INSTANCE.getDefault()));
            pairArr[c] = TuplesKt.to("Historie", HistoryKt.getHistory(Icons.INSTANCE.getDefault()));
            pairArr[3] = TuplesKt.to("Nastavení", SettingsKt.getSettings(Icons.INSTANCE.getDefault()));
            final List tabs = CollectionsKt.listOf((Object[]) pairArr);
            $composer3 = $composer2;
            ScaffoldKt.m2408ScaffoldTvnljyQ(null, ComposableSingletons$MainScreenKt.INSTANCE.getLambda$1992941736$app(), ComposableLambdaKt.rememberComposableLambda(183038151, true, new Function2() { // from class: com.example.ui.MainScreenKt$$ExternalSyntheticLambda9
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return MainScreenKt.MainScreen$lambda$30(tabs, selectedTab$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, $composer2, i2), null, null, 0, 0L, 0L, null, ComposableLambdaKt.rememberComposableLambda(918857021, true, new Function3() { // from class: com.example.ui.MainScreenKt$$ExternalSyntheticLambda10
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    return MainScreenKt.MainScreen$lambda$32(isServiceRunning, preferences, onRequestCaptureAndStart, onStopService, geminiService, selectedTab$delegate, (PaddingValues) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                }
            }, $composer2, i2), $composer3, 805306800, 505);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer3.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.MainScreenKt$$ExternalSyntheticLambda11
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return MainScreenKt.MainScreen$lambda$33(isServiceRunning, preferences, geminiService, onRequestCaptureAndStart, onStopService, $changed, (Composer) obj2, ((Integer) obj3).intValue());
                }
            });
        }
    }

    private static final int MainScreen$lambda$1(MutableIntState $selectedTab$delegate) {
        return $selectedTab$delegate.getIntValue();
    }

    private static final boolean MainScreen$lambda$4(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void MainScreen$lambda$5(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    private static final String MainScreen$lambda$7(MutableState<String> mutableState) {
        return mutableState.getValue();
    }

    private static final boolean MainScreen$lambda$10(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void MainScreen$lambda$11(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    static final Unit MainScreen$lambda$13$lambda$12(MutableState $showFirstLaunchDialog$delegate) {
        MainScreen$lambda$5($showFirstLaunchDialog$delegate, false);
        return Unit.INSTANCE;
    }

    static final Unit MainScreen$lambda$23(final MutableState $pinInput$delegate, MutableState $pinError$delegate, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        final MutableState mutableState;
        Object obj;
        Composer composer;
        ComposerKt.sourceInformation($composer, "C87@3366L1225:MainScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1911017986, $changed, -1, "com.example.ui.MainScreen.<anonymous> (MainScreen.kt:87)");
            }
            Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor;
                $composer.createNode(function0);
            } else {
                function0 = constructor;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i2 = (i >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            int i3 = ((6 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -520471801, "C90@3623L10,91@3680L11,88@3421L299,93@3731L41,96@3860L74,94@3783L513:MainScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g("Zadejte heslo 3011 pro odemčení a trvalé uložení API klíče. Aplikace si klíč zapamatuje a při dalších spuštěních už heslo nebude vyžadovat.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodyMedium(), $composer, 6, 0, 65530);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14)), $composer, 6);
            String strMainScreen$lambda$7 = MainScreen$lambda$7($pinInput$delegate);
            PasswordVisualTransformation passwordVisualTransformation = new PasswordVisualTransformation((char) 0, 1, null);
            boolean zMainScreen$lambda$10 = MainScreen$lambda$10($pinError$delegate);
            RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12));
            Modifier modifierTestTag = TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "first_launch_pin_input");
            ComposerKt.sourceInformationMarkerStart($composer, 1091602206, "CC(remember):MainScreen.kt#9igjgp");
            Object objRememberedValue = $composer.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                mutableState = $pinError$delegate;
                obj = new Function1() { // from class: com.example.ui.MainScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return MainScreenKt.MainScreen$lambda$23$lambda$22$lambda$21$lambda$20($pinInput$delegate, mutableState, (String) obj2);
                    }
                };
                $composer.updateRememberedValue(obj);
            } else {
                mutableState = $pinError$delegate;
                obj = objRememberedValue;
            }
            ComposerKt.sourceInformationMarkerEnd(r2);
            OutlinedTextFieldKt.OutlinedTextField(strMainScreen$lambda$7, (Function1<? super String, Unit>) obj, modifierTestTag, false, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$MainScreenKt.INSTANCE.getLambda$19492653$app(), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, zMainScreen$lambda$10, (VisualTransformation) passwordVisualTransformation, (KeyboardOptions) null, (KeyboardActions) null, true, 0, 0, (MutableInteractionSource) null, (Shape) roundedCornerShapeM953RoundedCornerShape0680j_4, (TextFieldColors) null, $composer, 12583344, 12582912, 0, 6135672);
            if (MainScreen$lambda$10(mutableState)) {
                $composer.startReplaceGroup(-519606902);
                ComposerKt.sourceInformation($composer, "110@4335L40,113@4480L11,114@4535L10,111@4388L181");
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), $composer, 6);
                TextKt.m2693Text4IGK_g("Nesprávné heslo nebo PIN.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getError(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodySmall(), $composer, 6, 0, 65530);
                composer = $composer;
            } else {
                composer = $composer;
                composer.startReplaceGroup(-523902386);
            }
            composer.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit MainScreen$lambda$23$lambda$22$lambda$21$lambda$20(MutableState $pinInput$delegate, MutableState $pinError$delegate, String it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $pinInput$delegate.setValue(it);
        MainScreen$lambda$11($pinError$delegate, false);
        return Unit.INSTANCE;
    }

    static final Unit MainScreen$lambda$16(final AppPreferences $preferences, final MutableState $pinInput$delegate, final MutableState $showFirstLaunchDialog$delegate, final MutableState $pinError$delegate, Composer $composer, int $changed) {
        Object obj;
        ComposerKt.sourceInformation($composer, "C131@5026L44,121@4661L329,120@4633L612:MainScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-829920583, $changed, -1, "com.example.ui.MainScreen.<anonymous> (MainScreen.kt:120)");
            }
            ButtonColors buttonColorsM1809buttonColorsro_MJ88 = ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(ColorKt.getIndigoPrimary(), 0L, 0L, 0L, $composer, (ButtonDefaults.$stable << 12) | 6, 14);
            RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10));
            Modifier modifierTestTag = TestTagKt.testTag(Modifier.INSTANCE, "first_launch_unlock_btn");
            ComposerKt.sourceInformationMarkerStart($composer, 1310238338, "CC(remember):MainScreen.kt#9igjgp");
            boolean zChangedInstance = $composer.changedInstance($preferences);
            Object objRememberedValue = $composer.rememberedValue();
            if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                obj = new Function0() { // from class: com.example.ui.MainScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return MainScreenKt.MainScreen$lambda$16$lambda$15$lambda$14($preferences, $pinInput$delegate, $showFirstLaunchDialog$delegate, $pinError$delegate);
                    }
                };
                $composer.updateRememberedValue(obj);
            } else {
                obj = objRememberedValue;
            }
            ComposerKt.sourceInformationMarkerEnd($composer);
            ButtonKt.Button((Function0) obj, modifierTestTag, false, roundedCornerShapeM953RoundedCornerShape0680j_4, buttonColorsM1809buttonColorsro_MJ88, null, null, null, null, ComposableSingletons$MainScreenKt.INSTANCE.m6939getLambda$705719639$app(), $composer, 805306416, 484);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit MainScreen$lambda$16$lambda$15$lambda$14(AppPreferences $preferences, MutableState $pinInput$delegate, MutableState $showFirstLaunchDialog$delegate, MutableState $pinError$delegate) {
        String unlocked = EncryptedApiKeyVault.INSTANCE.unlock(StringsKt.trim((CharSequence) MainScreen$lambda$7($pinInput$delegate)).toString());
        if (unlocked != null) {
            $preferences.setCustomApiKey(unlocked);
            $preferences.setVaultUnlocked(true);
            MainScreen$lambda$5($showFirstLaunchDialog$delegate, false);
        } else {
            MainScreen$lambda$11($pinError$delegate, true);
        }
        return Unit.INSTANCE;
    }

    static final Unit MainScreen$lambda$19(final MutableState $showFirstLaunchDialog$delegate, Composer $composer, int $changed) {
        Object obj;
        ComposerKt.sourceInformation($composer, "C140@5323L33,139@5287L168:MainScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-403366085, $changed, -1, "com.example.ui.MainScreen.<anonymous> (MainScreen.kt:139)");
            }
            ComposerKt.sourceInformationMarkerStart($composer, -1087749540, "CC(remember):MainScreen.kt#9igjgp");
            Object objRememberedValue = $composer.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                obj = new Function0() { // from class: com.example.ui.MainScreenKt$$ExternalSyntheticLambda12
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return MainScreenKt.MainScreen$lambda$19$lambda$18$lambda$17($showFirstLaunchDialog$delegate);
                    }
                };
                $composer.updateRememberedValue(obj);
            } else {
                obj = objRememberedValue;
            }
            ComposerKt.sourceInformationMarkerEnd($composer);
            ButtonKt.OutlinedButton((Function0) obj, null, false, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10)), null, null, null, null, null, ComposableSingletons$MainScreenKt.INSTANCE.m6938getLambda$681639251$app(), $composer, 805306374, 502);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit MainScreen$lambda$19$lambda$18$lambda$17(MutableState $showFirstLaunchDialog$delegate) {
        MainScreen$lambda$5($showFirstLaunchDialog$delegate, false);
        return Unit.INSTANCE;
    }

    static final Unit MainScreen$lambda$30(final List $tabs, final MutableIntState $selectedTab$delegate, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C176@6264L11,178@6323L694,175@6210L807:MainScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(183038151, $changed, -1, "com.example.ui.MainScreen.<anonymous> (MainScreen.kt:175)");
            }
            NavigationBarKt.m2273NavigationBarHsRjFd4(null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getSurface(), 0L, Dp.m6622constructorimpl(8), null, ComposableLambdaKt.rememberComposableLambda(903346112, true, new Function3() { // from class: com.example.ui.MainScreenKt$$ExternalSyntheticLambda13
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return MainScreenKt.MainScreen$lambda$30$lambda$29($tabs, $selectedTab$delegate, (RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, $composer, 54), $composer, 199680, 21);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit MainScreen$lambda$30$lambda$29(List $tabs, final MutableIntState $selectedTab$delegate, RowScope NavigationBar, Composer $composer, int $changed) {
        Object obj;
        Intrinsics.checkNotNullParameter(NavigationBar, "$this$NavigationBar");
        ComposerKt.sourceInformation($composer, "C*185@6744L184,182@6475L23,183@6519L42,184@6583L112,180@6389L610:MainScreen.kt#naom5h");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer.changed(NavigationBar) ? 4 : 2;
        }
        if (($dirty & 19) == 18 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(903346112, $dirty, -1, "com.example.ui.MainScreen.<anonymous>.<anonymous> (MainScreen.kt:179)");
            }
            int i = 0;
            for (Object obj2 : $tabs) {
                int i2 = i + 1;
                if (i < 0) {
                    CollectionsKt.throwIndexOverflow();
                }
                Pair pair = (Pair) obj2;
                final String str = (String) pair.component1();
                final ImageVector imageVector = (ImageVector) pair.component2();
                boolean z = MainScreen$lambda$1($selectedTab$delegate) == i;
                int $dirty2 = $dirty;
                NavigationBarItemDefaults navigationBarItemDefaults = NavigationBarItemDefaults.INSTANCE;
                final int i3 = i;
                long indigoPrimary = ColorKt.getIndigoPrimary();
                long indigoPrimary2 = ColorKt.getIndigoPrimary();
                long indigoPrimary3 = ColorKt.getIndigoPrimary();
                NavigationBarItemColors navigationBarItemColorsM2271colors69fazGs = navigationBarItemDefaults.m2271colors69fazGs(indigoPrimary, indigoPrimary2, Color.m4157copywmQWz5c(indigoPrimary3, (14 & 1) != 0 ? Color.m4161getAlphaimpl(indigoPrimary3) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(indigoPrimary3) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(indigoPrimary3) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(indigoPrimary3) : 0.0f), 0L, 0L, 0L, 0L, $composer, (NavigationBarItemDefaults.$stable << 21) | 438, 120);
                Modifier modifierTestTag = TestTagKt.testTag(Modifier.INSTANCE, "nav_tab_" + i3);
                ComposerKt.sourceInformationMarkerStart($composer, -143618182, "CC(remember):MainScreen.kt#9igjgp");
                boolean zChanged = $composer.changed(i3);
                Object objRememberedValue = $composer.rememberedValue();
                if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    obj = new Function0() { // from class: com.example.ui.MainScreenKt$$ExternalSyntheticLambda2
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return MainScreenKt.MainScreen$lambda$30$lambda$29$lambda$28$lambda$25$lambda$24(i3, $selectedTab$delegate);
                        }
                    };
                    $composer.updateRememberedValue(obj);
                } else {
                    obj = objRememberedValue;
                }
                ComposerKt.sourceInformationMarkerEnd($composer);
                NavigationBarKt.NavigationBarItem(NavigationBar, z, (Function0) obj, ComposableLambdaKt.rememberComposableLambda(534796894, true, new Function2() { // from class: com.example.ui.MainScreenKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj3, Object obj4) {
                        return MainScreenKt.MainScreen$lambda$30$lambda$29$lambda$28$lambda$26(imageVector, str, (Composer) obj3, ((Integer) obj4).intValue());
                    }
                }, $composer, 54), modifierTestTag, false, ComposableLambdaKt.rememberComposableLambda(1879143649, true, new Function2() { // from class: com.example.ui.MainScreenKt$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj3, Object obj4) {
                        return MainScreenKt.MainScreen$lambda$30$lambda$29$lambda$28$lambda$27(str, i3, $selectedTab$delegate, (Composer) obj3, ((Integer) obj4).intValue());
                    }
                }, $composer, 54), false, navigationBarItemColorsM2271colors69fazGs, null, $composer, ($dirty2 & 14) | 1575936, 336);
                i = i2;
                $dirty = $dirty2;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit MainScreen$lambda$30$lambda$29$lambda$28$lambda$25$lambda$24(int $index, MutableIntState $selectedTab$delegate) {
        $selectedTab$delegate.setIntValue($index);
        return Unit.INSTANCE;
    }

    static final Unit MainScreen$lambda$30$lambda$29$lambda$28$lambda$26(ImageVector $icon, String $title, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C183@6521L38:MainScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(534796894, $changed, -1, "com.example.ui.MainScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (MainScreen.kt:183)");
            }
            IconKt.m2150Iconww6aTOc($icon, $title, (Modifier) null, 0L, $composer, 0, 12);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit MainScreen$lambda$30$lambda$29$lambda$28$lambda$27(String $title, int $index, MutableIntState $selectedTab$delegate, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C184@6585L108:MainScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1879143649, $changed, -1, "com.example.ui.MainScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (MainScreen.kt:184)");
            }
            TextKt.m2693Text4IGK_g($title, (Modifier) null, 0L, TextUnitKt.getSp(11), (FontStyle) null, MainScreen$lambda$1($selectedTab$delegate) == $index ? FontWeight.INSTANCE.getBold() : FontWeight.INSTANCE.getNormal(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3072, 0, 131030);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit MainScreen$lambda$32(boolean $isServiceRunning, AppPreferences $preferences, Function0 $onRequestCaptureAndStart, Function0 $onStopService, GeminiService $geminiService, MutableIntState $selectedTab$delegate, PaddingValues innerPadding, Composer $composer, int $changed) {
        Composer composer;
        Intrinsics.checkNotNullParameter(innerPadding, "innerPadding");
        ComposerKt.sourceInformation($composer, "C196@7050L627:MainScreen.kt#naom5h");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer.changed(innerPadding) ? 4 : 2;
        }
        int $dirty2 = $dirty;
        if (($dirty2 & 19) == 18 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(918857021, $dirty2, -1, "com.example.ui.MainScreen.<anonymous> (MainScreen.kt:196)");
            }
            Modifier modifierPadding = PaddingKt.padding(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), innerPadding);
            ComposerKt.sourceInformationMarkerStart($composer, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.INSTANCE.getTopStart(), false);
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierPadding);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                $composer.createNode(constructor);
            } else {
                $composer.useNode();
            }
            Composer composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i2 = (i >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
            BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
            int i3 = ((0 >> 6) & 112) | 6;
            Composer composer2 = $composer;
            ComposerKt.sourceInformationMarkerStart(composer2, 1674308886, "C:MainScreen.kt#naom5h");
            switch (MainScreen$lambda$1($selectedTab$delegate)) {
                case 0:
                    composer = $composer;
                    composer2.startReplaceGroup(1162389405);
                    ComposerKt.sourceInformation(composer2, "202@7183L218");
                    OverlayControlScreenKt.OverlayControlScreen($isServiceRunning, $preferences, $onRequestCaptureAndStart, $onStopService, null, composer2, 0, 16);
                    composer2 = composer2;
                    composer2.endReplaceGroup();
                    break;
                case 1:
                    composer2.startReplaceGroup(1162396710);
                    ComposerKt.sourceInformation(composer2, "208@7415L99");
                    composer = $composer;
                    QuizSandboxKt.QuizSandbox($preferences, $geminiService, null, composer2, 0, 4);
                    composer2.endReplaceGroup();
                    break;
                case 2:
                    composer2.startReplaceGroup(1162400287);
                    ComposerKt.sourceInformation(composer2, "212@7528L60");
                    HistoryScreenKt.HistoryScreen($preferences, null, composer2, 0, 2);
                    composer2.endReplaceGroup();
                    composer = $composer;
                    break;
                case 3:
                    composer2.startReplaceGroup(1162402656);
                    ComposerKt.sourceInformation(composer2, "215@7602L61");
                    SettingsScreenKt.SettingsScreen($preferences, null, composer2, 0, 2);
                    composer2.endReplaceGroup();
                    composer = $composer;
                    break;
                default:
                    composer = $composer;
                    composer2.startReplaceGroup(1667199903);
                    composer2.endReplaceGroup();
                    break;
            }
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
