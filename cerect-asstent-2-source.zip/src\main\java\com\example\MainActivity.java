package com.example;

import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;
import androidx.activity.ComponentActivity;
import androidx.activity.EdgeToEdge;
import androidx.activity.compose.ComponentActivityKt;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import com.example.data.AppPreferences;
import com.example.data.GeminiService;
import com.example.service.CornerOverlayService;
import com.example.ui.MainScreenKt;
import com.example.ui.theme.ThemeKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: MainActivity.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010H\u0014R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082.¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\f0\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0011²\u0006\n\u0010\u0012\u001a\u00020\u0013X\u008a\u0084\u0002"}, d2 = {"Lcom/example/MainActivity;", "Landroidx/activity/ComponentActivity;", "<init>", "()V", "preferences", "Lcom/example/data/AppPreferences;", "geminiService", "Lcom/example/data/GeminiService;", "screenCaptureLauncher", "Landroidx/activity/result/ActivityResultLauncher;", "Landroid/content/Intent;", "notificationPermissionLauncher", "", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "app", "isServiceRunning", ""}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class MainActivity extends ComponentActivity {
    public static final int $stable = 8;
    private AppPreferences preferences;
    private final GeminiService geminiService = new GeminiService();
    private final ActivityResultLauncher<Intent> screenCaptureLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback() { // from class: com.example.MainActivity$$ExternalSyntheticLambda4
        @Override // androidx.activity.result.ActivityResultCallback
        public final void onActivityResult(Object obj) {
            MainActivity.screenCaptureLauncher$lambda$0(this.f$0, (ActivityResult) obj);
        }
    });
    private final ActivityResultLauncher<String> notificationPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), new ActivityResultCallback() { // from class: com.example.MainActivity$$ExternalSyntheticLambda5
        @Override // androidx.activity.result.ActivityResultCallback
        public final void onActivityResult(Object obj) {
            MainActivity.notificationPermissionLauncher$lambda$1(((Boolean) obj).booleanValue());
        }
    });

    static final void screenCaptureLauncher$lambda$0(MainActivity this$0, ActivityResult result) {
        Intrinsics.checkNotNullParameter(result, "result");
        if (result.getResultCode() == -1 && result.getData() != null) {
            int resultCode = result.getResultCode();
            Intent data = result.getData();
            Intrinsics.checkNotNull(data);
            CornerOverlayService.INSTANCE.start(this$0, resultCode, data);
            Toast.makeText(this$0, "Corner Assistant spuštěn!", 0).show();
            return;
        }
        Toast.makeText(this$0, "Snímání obrazovky bylo zrušeno", 0).show();
    }

    static final void notificationPermissionLauncher$lambda$1(boolean it) {
    }

    @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable$default(this, null, null, 3, null);
        this.preferences = new AppPreferences(this);
        if (Build.VERSION.SDK_INT >= 33) {
            this.notificationPermissionLauncher.launch("android.permission.POST_NOTIFICATIONS");
        }
        ComponentActivityKt.setContent$default(this, null, ComposableLambdaKt.composableLambdaInstance(-601144069, true, new Function2() { // from class: com.example.MainActivity$$ExternalSyntheticLambda1
            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(Object obj, Object obj2) {
                return MainActivity.onCreate$lambda$8(this.f$0, (Composer) obj, ((Integer) obj2).intValue());
            }
        }), 1, null);
    }

    static final Unit onCreate$lambda$8(final MainActivity this$0, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C59@2184L702,59@2165L721:MainActivity.kt#to5c3");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-601144069, $changed, -1, "com.example.MainActivity.onCreate.<anonymous> (MainActivity.kt:59)");
            }
            ThemeKt.MyApplicationTheme(false, false, ComposableLambdaKt.rememberComposableLambda(434770631, true, new Function2() { // from class: com.example.MainActivity$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return MainActivity.onCreate$lambda$8$lambda$7(this.f$0, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, $composer, 54), $composer, 384, 3);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit onCreate$lambda$8$lambda$7(final MainActivity this$0, Composer $composer, int $changed) {
        AppPreferences appPreferences;
        Object obj;
        Object obj2;
        ComposerKt.sourceInformation($composer, "C60@2256L16,66@2456L238,71@2722L146,62@2282L596:MainActivity.kt#to5c3");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(434770631, $changed, -1, "com.example.MainActivity.onCreate.<anonymous>.<anonymous> (MainActivity.kt:60)");
            }
            State isServiceRunning$delegate = SnapshotStateKt.collectAsState(CornerOverlayService.INSTANCE.isServiceRunning(), null, $composer, 0, 1);
            boolean zOnCreate$lambda$8$lambda$7$lambda$2 = onCreate$lambda$8$lambda$7$lambda$2(isServiceRunning$delegate);
            AppPreferences appPreferences2 = this$0.preferences;
            if (appPreferences2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("preferences");
                appPreferences = null;
            } else {
                appPreferences = appPreferences2;
            }
            GeminiService geminiService = this$0.geminiService;
            ComposerKt.sourceInformationMarkerStart($composer, 1202757621, "CC(remember):MainActivity.kt#9igjgp");
            boolean zChangedInstance = $composer.changedInstance(this$0);
            Object objRememberedValue = $composer.rememberedValue();
            if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                obj = new Function0() { // from class: com.example.MainActivity$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return MainActivity.onCreate$lambda$8$lambda$7$lambda$4$lambda$3(this.f$0);
                    }
                };
                $composer.updateRememberedValue(obj);
            } else {
                obj = objRememberedValue;
            }
            Function0 function0 = (Function0) obj;
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerStart($composer, 1202766041, "CC(remember):MainActivity.kt#9igjgp");
            boolean zChangedInstance2 = $composer.changedInstance(this$0);
            Object objRememberedValue2 = $composer.rememberedValue();
            if (zChangedInstance2 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                obj2 = new Function0() { // from class: com.example.MainActivity$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return MainActivity.onCreate$lambda$8$lambda$7$lambda$6$lambda$5(this.f$0);
                    }
                };
                $composer.updateRememberedValue(obj2);
            } else {
                obj2 = objRememberedValue2;
            }
            ComposerKt.sourceInformationMarkerEnd($composer);
            MainScreenKt.MainScreen(zOnCreate$lambda$8$lambda$7$lambda$2, appPreferences, geminiService, function0, (Function0) obj2, $composer, 0);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    private static final boolean onCreate$lambda$8$lambda$7$lambda$2(State<Boolean> state) {
        return ((Boolean) state.getValue()).booleanValue();
    }

    static final Unit onCreate$lambda$8$lambda$7$lambda$4$lambda$3(MainActivity this$0) {
        Object systemService = this$0.getSystemService("media_projection");
        Intrinsics.checkNotNull(systemService, "null cannot be cast to non-null type android.media.projection.MediaProjectionManager");
        MediaProjectionManager mediaProjectionManager = (MediaProjectionManager) systemService;
        ActivityResultLauncher<Intent> activityResultLauncher = this$0.screenCaptureLauncher;
        Intent intentCreateScreenCaptureIntent = mediaProjectionManager.createScreenCaptureIntent();
        Intrinsics.checkNotNullExpressionValue(intentCreateScreenCaptureIntent, "createScreenCaptureIntent(...)");
        activityResultLauncher.launch(intentCreateScreenCaptureIntent);
        return Unit.INSTANCE;
    }

    static final Unit onCreate$lambda$8$lambda$7$lambda$6$lambda$5(MainActivity this$0) {
        CornerOverlayService.INSTANCE.stop(this$0);
        Toast.makeText(this$0, "Corner Assistant zastaven", 0).show();
        return Unit.INSTANCE;
    }
}
