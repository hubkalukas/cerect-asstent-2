package com.example.data;

import android.content.Context;
import android.content.SharedPreferences;
import com.example.model.CornerPosition;
import com.example.model.OptionShape;
import com.example.model.ScanHistoryItem;
import com.example.model.SearchSource;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.ImagesContract;
import io.ktor.http.LinkHeader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import kotlinx.coroutines.flow.FlowKt;
import kotlinx.coroutines.flow.MutableStateFlow;
import kotlinx.coroutines.flow.StateFlow;
import kotlinx.coroutines.flow.StateFlowKt;
import okhttp3.HttpUrl;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* JADX INFO: compiled from: AppPreferences.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000x\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010!\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0002\b\t\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u000e\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0007\u0018\u0000 K2\u00020\u0001:\u0001KB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0006\u0010A\u001a\u00020BJ\u0006\u0010C\u001a\u00020\u0017J\u0006\u0010D\u001a\u00020BJ\f\u0010E\u001a\b\u0012\u0004\u0012\u00020G0FJ\u000e\u0010H\u001a\u00020B2\u0006\u0010I\u001a\u00020GJ\u0006\u0010J\u001a\u00020BR\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000f\u001a\u00020\u0010X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0014\u0010\u0013\u001a\u00020\u0010X\u0086D¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0012R\u0014\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00170\u0016X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00170\u0019¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR$\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u001c\u001a\u00020\u001d8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\u001f\u0010 \"\u0004\b!\u0010\"R$\u0010$\u001a\u00020#2\u0006\u0010\u001c\u001a\u00020#8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b%\u0010&\"\u0004\b'\u0010(R$\u0010)\u001a\u00020\u00102\u0006\u0010\u001c\u001a\u00020\u00108F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b*\u0010\u0012\"\u0004\b+\u0010,R$\u0010.\u001a\u00020-2\u0006\u0010\u001c\u001a\u00020-8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b/\u00100\"\u0004\b1\u00102R$\u00104\u001a\u0002032\u0006\u0010\u001c\u001a\u0002038F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b4\u00105\"\u0004\b6\u00107R$\u00108\u001a\u0002032\u0006\u0010\u001c\u001a\u0002038F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b8\u00105\"\u0004\b9\u00107R$\u0010:\u001a\u0002032\u0006\u0010\u001c\u001a\u0002038F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b:\u00105\"\u0004\b;\u00107R$\u0010<\u001a\u0002032\u0006\u0010\u001c\u001a\u0002038F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b<\u00105\"\u0004\b=\u00107R$\u0010>\u001a\u00020\u00102\u0006\u0010\u001c\u001a\u00020\u00108F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b?\u0010\u0012\"\u0004\b@\u0010,¨\u0006L"}, d2 = {"Lcom/example/data/AppPreferences;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "prefs", "Landroid/content/SharedPreferences;", "rateLimiter", "Lcom/example/data/GeminiRateLimiter;", "getRateLimiter", "()Lcom/example/data/GeminiRateLimiter;", "recentCallTimestamps", "", "", "defaultDailyLimit", "", "getDefaultDailyLimit", "()I", "defaultMinuteLimit", "getDefaultMinuteLimit", "_apiUsageFlow", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/example/data/ApiUsageStats;", "apiUsageFlow", "Lkotlinx/coroutines/flow/StateFlow;", "getApiUsageFlow", "()Lkotlinx/coroutines/flow/StateFlow;", "value", "Lcom/example/model/CornerPosition;", "cornerPosition", "getCornerPosition", "()Lcom/example/model/CornerPosition;", "setCornerPosition", "(Lcom/example/model/CornerPosition;)V", "", "cornerOpacity", "getCornerOpacity", "()F", "setCornerOpacity", "(F)V", "autoDismissSeconds", "getAutoDismissSeconds", "setAutoDismissSeconds", "(I)V", "", "customApiKey", "getCustomApiKey", "()Ljava/lang/String;", "setCustomApiKey", "(Ljava/lang/String;)V", "", "isVaultUnlocked", "()Z", "setVaultUnlocked", "(Z)V", "isVibrationEnabled", "setVibrationEnabled", "isStealthBadgeMode", "setStealthBadgeMode", "isPopupCardDisabled", "setPopupCardDisabled", "dailyApiLimit", "getDailyApiLimit", "setDailyApiLimit", "recordApiCall", "", "getApiUsageStats", "resetTodayApiUsage", "getHistory", "", "Lcom/example/model/ScanHistoryItem;", "addHistoryItem", "item", "clearHistory", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class AppPreferences {
    private static final String KEY_API_DAILY_LIMIT = "key_api_daily_limit";
    private static final String KEY_API_USAGE_DATE = "key_api_usage_date";
    private static final String KEY_API_USAGE_TODAY = "key_api_usage_today";
    private static final String KEY_AUTO_DISMISS = "key_auto_dismiss";
    private static final String KEY_CORNER_OPACITY = "key_corner_opacity";
    private static final String KEY_CORNER_POSITION = "key_corner_position";
    private static final String KEY_CUSTOM_API_KEY = "key_custom_api_key_v2";
    private static final String KEY_DISABLE_POPUP_CARD = "key_disable_popup_card";
    private static final String KEY_HISTORY = "key_history";
    private static final String KEY_STEALTH_BADGE = "key_stealth_badge";
    private static final String KEY_VAULT_UNLOCKED = "key_vault_unlocked";
    private static final String KEY_VIBRATION = "key_vibration";
    private final MutableStateFlow<ApiUsageStats> _apiUsageFlow;
    private final StateFlow<ApiUsageStats> apiUsageFlow;
    private final int defaultDailyLimit;
    private final int defaultMinuteLimit;
    private final SharedPreferences prefs;
    private final GeminiRateLimiter rateLimiter;
    private final List<Long> recentCallTimestamps;
    public static final int $stable = 8;

    public AppPreferences(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        SharedPreferences sharedPreferences = context.getSharedPreferences("corner_assistant_prefs", 0);
        Intrinsics.checkNotNullExpressionValue(sharedPreferences, "getSharedPreferences(...)");
        this.prefs = sharedPreferences;
        this.rateLimiter = new GeminiRateLimiter(context);
        this.recentCallTimestamps = new ArrayList();
        this.defaultDailyLimit = ConnectionResult.DRIVE_EXTERNAL_STORAGE_REQUIRED;
        this.defaultMinuteLimit = 15;
        this._apiUsageFlow = StateFlowKt.MutableStateFlow(getApiUsageStats());
        this.apiUsageFlow = FlowKt.asStateFlow(this._apiUsageFlow);
    }

    public final GeminiRateLimiter getRateLimiter() {
        return this.rateLimiter;
    }

    public final int getDefaultDailyLimit() {
        return this.defaultDailyLimit;
    }

    public final int getDefaultMinuteLimit() {
        return this.defaultMinuteLimit;
    }

    public final StateFlow<ApiUsageStats> getApiUsageFlow() {
        return this.apiUsageFlow;
    }

    public final CornerPosition getCornerPosition() {
        return CornerPosition.INSTANCE.fromName(this.prefs.getString(KEY_CORNER_POSITION, "TOP_RIGHT"));
    }

    public final void setCornerPosition(CornerPosition value) {
        Intrinsics.checkNotNullParameter(value, "value");
        this.prefs.edit().putString(KEY_CORNER_POSITION, value.name()).apply();
    }

    public final float getCornerOpacity() {
        return this.prefs.getFloat(KEY_CORNER_OPACITY, 0.15f);
    }

    public final void setCornerOpacity(float value) {
        this.prefs.edit().putFloat(KEY_CORNER_OPACITY, value).apply();
    }

    public final int getAutoDismissSeconds() {
        return this.prefs.getInt(KEY_AUTO_DISMISS, 3);
    }

    public final void setAutoDismissSeconds(int value) {
        this.prefs.edit().putInt(KEY_AUTO_DISMISS, value).apply();
    }

    public final String getCustomApiKey() {
        String string = this.prefs.getString(KEY_CUSTOM_API_KEY, "YOUR_GEMINI_API_KEY");
        return (string == null || StringsKt.isBlank(string)) ? "YOUR_GEMINI_API_KEY" : string;
    }

    public final void setCustomApiKey(String value) {
        Intrinsics.checkNotNullParameter(value, "value");
        this.prefs.edit().putString(KEY_CUSTOM_API_KEY, value).apply();
    }

    public final boolean isVaultUnlocked() {
        return this.prefs.getBoolean(KEY_VAULT_UNLOCKED, false) || !StringsKt.isBlank(getCustomApiKey());
    }

    public final void setVaultUnlocked(boolean value) {
        this.prefs.edit().putBoolean(KEY_VAULT_UNLOCKED, value).apply();
    }

    public final boolean isVibrationEnabled() {
        return this.prefs.getBoolean(KEY_VIBRATION, true);
    }

    public final void setVibrationEnabled(boolean value) {
        this.prefs.edit().putBoolean(KEY_VIBRATION, value).apply();
    }

    public final boolean isStealthBadgeMode() {
        return this.prefs.getBoolean(KEY_STEALTH_BADGE, true);
    }

    public final void setStealthBadgeMode(boolean value) {
        this.prefs.edit().putBoolean(KEY_STEALTH_BADGE, value).apply();
    }

    public final boolean isPopupCardDisabled() {
        return this.prefs.getBoolean(KEY_DISABLE_POPUP_CARD, true);
    }

    public final void setPopupCardDisabled(boolean value) {
        this.prefs.edit().putBoolean(KEY_DISABLE_POPUP_CARD, value).apply();
    }

    public final int getDailyApiLimit() {
        return this.prefs.getInt(KEY_API_DAILY_LIMIT, this.defaultDailyLimit);
    }

    public final void setDailyApiLimit(int value) {
        this.prefs.edit().putInt(KEY_API_DAILY_LIMIT, value).apply();
        this._apiUsageFlow.setValue(getApiUsageStats());
    }

    public final void recordApiCall() {
        final long now = System.currentTimeMillis();
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(now));
        String savedDate = this.prefs.getString(KEY_API_USAGE_DATE, "");
        if (savedDate == null) {
            savedDate = "";
        }
        int currentCount = Intrinsics.areEqual(savedDate, today) ? this.prefs.getInt(KEY_API_USAGE_TODAY, 0) : 0;
        int newCount = currentCount + 1;
        this.prefs.edit().putString(KEY_API_USAGE_DATE, today).putInt(KEY_API_USAGE_TODAY, newCount).apply();
        synchronized (this.recentCallTimestamps) {
            this.recentCallTimestamps.add(Long.valueOf(now));
            CollectionsKt.removeAll((List) this.recentCallTimestamps, new Function1() { // from class: com.example.data.AppPreferences$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return Boolean.valueOf(AppPreferences.recordApiCall$lambda$1$lambda$0(now, ((Long) obj).longValue()));
                }
            });
        }
        this._apiUsageFlow.setValue(getApiUsageStats());
    }

    static final boolean recordApiCall$lambda$1$lambda$0(long $now, long it) {
        return $now - it > 60000;
    }

    public final ApiUsageStats getApiUsageStats() {
        int usedToday;
        int usedThisMinute;
        final long now = System.currentTimeMillis();
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(now));
        String string = this.prefs.getString(KEY_API_USAGE_DATE, "");
        if (string == null) {
            string = "";
        }
        String savedDate = string;
        if (Intrinsics.areEqual(savedDate, today)) {
            usedToday = this.prefs.getInt(KEY_API_USAGE_TODAY, 0);
        } else {
            usedToday = 0;
        }
        int dailyLimit = this.prefs.getInt(KEY_API_DAILY_LIMIT, this.defaultDailyLimit);
        int remainingToday = RangesKt.coerceAtLeast(dailyLimit - usedToday, 0);
        synchronized (this.recentCallTimestamps) {
            CollectionsKt.removeAll((List) this.recentCallTimestamps, new Function1() { // from class: com.example.data.AppPreferences$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return Boolean.valueOf(AppPreferences.getApiUsageStats$lambda$3$lambda$2(now, ((Long) obj).longValue()));
                }
            });
            usedThisMinute = this.recentCallTimestamps.size();
            Unit unit = Unit.INSTANCE;
        }
        int remainingMinute = RangesKt.coerceAtLeast(this.defaultMinuteLimit - usedThisMinute, 0);
        int i = this.defaultMinuteLimit;
        Intrinsics.checkNotNull(today);
        return new ApiUsageStats(usedToday, dailyLimit, remainingToday, usedThisMinute, i, remainingMinute, today);
    }

    static final boolean getApiUsageStats$lambda$3$lambda$2(long $now, long it) {
        return $now - it > 60000;
    }

    public final void resetTodayApiUsage() {
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        this.prefs.edit().putString(KEY_API_USAGE_DATE, today).putInt(KEY_API_USAGE_TODAY, 0).apply();
        synchronized (this.recentCallTimestamps) {
            this.recentCallTimestamps.clear();
            Unit unit = Unit.INSTANCE;
        }
        this._apiUsageFlow.setValue(getApiUsageStats());
    }

    public final List<ScanHistoryItem> getHistory() {
        OptionShape shape;
        String str = "optString(...)";
        String str2 = "";
        SharedPreferences sharedPreferences = this.prefs;
        String jsonStr = HttpUrl.PATH_SEGMENT_ENCODE_SET_URI;
        String string = sharedPreferences.getString(KEY_HISTORY, HttpUrl.PATH_SEGMENT_ENCODE_SET_URI);
        if (string != null) {
            jsonStr = string;
        }
        List list = new ArrayList();
        try {
            JSONArray array = new JSONArray(jsonStr);
            int length = array.length();
            int i = 0;
            while (i < length) {
                JSONObject obj = array.getJSONObject(i);
                List sources = new ArrayList();
                JSONArray sourcesArr = obj.optJSONArray("sources");
                if (sourcesArr != null) {
                    int j = 0;
                    int length2 = sourcesArr.length();
                    while (j < length2) {
                        JSONObject sObj = sourcesArr.getJSONObject(j);
                        int j2 = j;
                        String string2 = sObj.getString(LinkHeader.Parameters.Title);
                        Intrinsics.checkNotNullExpressionValue(string2, "getString(...)");
                        String string3 = sObj.getString(ImagesContract.URL);
                        Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
                        sources.add(new SearchSource(string2, string3));
                        j = j2 + 1;
                    }
                }
                String shapeName = obj.optString("optionShape", "UNKNOWN");
                try {
                    Intrinsics.checkNotNull(shapeName);
                    shape = OptionShape.valueOf(shapeName);
                } catch (Exception e) {
                    shape = OptionShape.UNKNOWN;
                }
                String string4 = obj.getString("id");
                Intrinsics.checkNotNullExpressionValue(string4, "getString(...)");
                String string5 = obj.getString("directAnswer");
                Intrinsics.checkNotNullExpressionValue(string5, "getString(...)");
                String string6 = obj.getString("explanation");
                Intrinsics.checkNotNullExpressionValue(string6, "getString(...)");
                String strOptString = obj.optString("questionSummary", str2);
                Intrinsics.checkNotNullExpressionValue(strOptString, str);
                OptionShape shape2 = shape;
                long j3 = obj.getLong("timestamp");
                String strOptString2 = obj.optString("modelUsed", str2);
                Intrinsics.checkNotNullExpressionValue(strOptString2, str);
                String str3 = str;
                String str4 = str2;
                list.add(new ScanHistoryItem(string4, shape2, string5, string6, strOptString, sources, j3, strOptString2, obj.optLong("durationMs", 0L)));
                i++;
                str = str3;
                str2 = str4;
            }
        } catch (Exception e2) {
        }
        return list;
    }

    public final void addHistoryItem(ScanHistoryItem item) throws JSONException {
        Intrinsics.checkNotNullParameter(item, "item");
        List current = CollectionsKt.toMutableList((Collection) getHistory());
        current.add(0, item);
        List<ScanHistoryItem> trimmed = CollectionsKt.take(current, 30);
        JSONArray jSONArray = new JSONArray();
        for (ScanHistoryItem entry : trimmed) {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("id", entry.getId());
            jSONObject.put("optionShape", entry.getOptionShape().name());
            jSONObject.put("directAnswer", entry.getDirectAnswer());
            jSONObject.put("explanation", entry.getExplanation());
            jSONObject.put("questionSummary", entry.getQuestionSummary());
            jSONObject.put("timestamp", entry.getTimestamp());
            jSONObject.put("modelUsed", entry.getModelUsed());
            jSONObject.put("durationMs", entry.getDurationMs());
            JSONArray jSONArray2 = new JSONArray();
            for (SearchSource searchSource : entry.getSources()) {
                JSONObject jSONObject2 = new JSONObject();
                jSONObject2.put(LinkHeader.Parameters.Title, searchSource.getTitle());
                jSONObject2.put(ImagesContract.URL, searchSource.getUrl());
                jSONArray2.put(jSONObject2);
            }
            jSONObject.put("sources", jSONArray2);
            jSONArray.put(jSONObject);
        }
        this.prefs.edit().putString(KEY_HISTORY, jSONArray.toString()).apply();
    }

    public final void clearHistory() {
        this.prefs.edit().remove(KEY_HISTORY).apply();
    }
}
