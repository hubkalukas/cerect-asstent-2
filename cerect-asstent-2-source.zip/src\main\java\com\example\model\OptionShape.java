package com.example.model;

import java.util.Locale;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

/* JADX INFO: compiled from: Models.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000f\b\u0086\u0081\u0002\u0018\u0000 \u00112\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u0011B!\b\u0002\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003¢\u0006\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\tR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\tj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010¨\u0006\u0012"}, d2 = {"Lcom/example/model/OptionShape;", "", "symbol", "", "czechName", "colorHex", "<init>", "(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getSymbol", "()Ljava/lang/String;", "getCzechName", "getColorHex", "RED_TRIANGLE", "BLUE_DIAMOND", "YELLOW_CIRCLE", "GREEN_SQUARE", "UNKNOWN", "Companion", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public enum OptionShape {
    RED_TRIANGLE("▲", "Červená", "#E21B3C"),
    BLUE_DIAMOND("◆", "Modrá", "#1368CE"),
    YELLOW_CIRCLE("●", "Žlutá", "#D89E00"),
    GREEN_SQUARE("■", "Zelená", "#26890C"),
    UNKNOWN("✦", "Neznámé", "#4F46E5");

    private final String colorHex;
    private final String czechName;
    private final String symbol;
    private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

    /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
    public static final Companion INSTANCE = new Companion(null);

    public static EnumEntries<OptionShape> getEntries() {
        return $ENTRIES;
    }

    OptionShape(String symbol, String czechName, String colorHex) {
        this.symbol = symbol;
        this.czechName = czechName;
        this.colorHex = colorHex;
    }

    public final String getSymbol() {
        return this.symbol;
    }

    public final String getCzechName() {
        return this.czechName;
    }

    public final String getColorHex() {
        return this.colorHex;
    }

    /* JADX INFO: compiled from: Models.kt */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007¨\u0006\b"}, d2 = {"Lcom/example/model/OptionShape$Companion;", "", "<init>", "()V", "fromText", "Lcom/example/model/OptionShape;", "text", "", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }

        public final OptionShape fromText(String text) {
            Intrinsics.checkNotNullParameter(text, "text");
            String upper = text.toUpperCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(upper, "toUpperCase(...)");
            if (StringsKt.contains$default((CharSequence) upper, (CharSequence) "RED", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "ČERVEN", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "TRIANGLE", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "TROJÚHEL", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) text, (CharSequence) "▲", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "OPTION_A", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "OPTION 1", false, 2, (Object) null)) {
                return OptionShape.RED_TRIANGLE;
            }
            if (StringsKt.contains$default((CharSequence) upper, (CharSequence) "BLUE", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "MODR", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "DIAMOND", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "KOSOČT", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) text, (CharSequence) "◆", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) text, (CharSequence) "♦", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "OPTION_B", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "OPTION 2", false, 2, (Object) null)) {
                return OptionShape.BLUE_DIAMOND;
            }
            if (StringsKt.contains$default((CharSequence) upper, (CharSequence) "YELLOW", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "ŽLUT", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "CIRCLE", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "KRUH", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "KOLEČ", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) text, (CharSequence) "●", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "OPTION_C", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "OPTION 3", false, 2, (Object) null)) {
                return OptionShape.YELLOW_CIRCLE;
            }
            if (StringsKt.contains$default((CharSequence) upper, (CharSequence) "GREEN", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "ZELEN", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "SQUARE", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "ČTVER", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) text, (CharSequence) "■", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) text, (CharSequence) "█", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "OPTION_D", false, 2, (Object) null) || StringsKt.contains$default((CharSequence) upper, (CharSequence) "OPTION 4", false, 2, (Object) null)) {
                return OptionShape.GREEN_SQUARE;
            }
            return OptionShape.UNKNOWN;
        }
    }
}
