package com.example.ui;

import com.example.model.OptionShape;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: QuizSandbox.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0017\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001BG\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0005\u0012\u0006\u0010\t\u001a\u00020\u0005\u0012\u0006\u0010\n\u001a\u00020\u0005\u0012\u0006\u0010\u000b\u001a\u00020\f¢\u0006\u0004\b\r\u0010\u000eJ\t\u0010\u001a\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0005HÆ\u0003J\t\u0010 \u001a\u00020\u0005HÆ\u0003J\t\u0010!\u001a\u00020\fHÆ\u0003JY\u0010\"\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u00052\b\b\u0002\u0010\t\u001a\u00020\u00052\b\b\u0002\u0010\n\u001a\u00020\u00052\b\b\u0002\u0010\u000b\u001a\u00020\fHÆ\u0001J\u0013\u0010#\u001a\u00020$2\b\u0010%\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010&\u001a\u00020\u0003HÖ\u0001J\t\u0010'\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0012R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0012R\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0012R\u0011\u0010\t\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0012R\u0011\u0010\n\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0012R\u0011\u0010\u000b\u001a\u00020\f¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019¨\u0006("}, d2 = {"Lcom/example/ui/QuizOptionQuestion;", "", "id", "", "category", "", "question", "redOption", "blueOption", "yellowOption", "greenOption", "correctShape", "Lcom/example/model/OptionShape;", "<init>", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/example/model/OptionShape;)V", "getId", "()I", "getCategory", "()Ljava/lang/String;", "getQuestion", "getRedOption", "getBlueOption", "getYellowOption", "getGreenOption", "getCorrectShape", "()Lcom/example/model/OptionShape;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final /* data */ class QuizOptionQuestion {
    public static final int $stable = 0;
    private final String blueOption;
    private final String category;
    private final OptionShape correctShape;
    private final String greenOption;
    private final int id;
    private final String question;
    private final String redOption;
    private final String yellowOption;

    public static /* synthetic */ QuizOptionQuestion copy$default(QuizOptionQuestion quizOptionQuestion, int i, String str, String str2, String str3, String str4, String str5, String str6, OptionShape optionShape, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            i = quizOptionQuestion.id;
        }
        if ((i2 & 2) != 0) {
            str = quizOptionQuestion.category;
        }
        if ((i2 & 4) != 0) {
            str2 = quizOptionQuestion.question;
        }
        if ((i2 & 8) != 0) {
            str3 = quizOptionQuestion.redOption;
        }
        if ((i2 & 16) != 0) {
            str4 = quizOptionQuestion.blueOption;
        }
        if ((i2 & 32) != 0) {
            str5 = quizOptionQuestion.yellowOption;
        }
        if ((i2 & 64) != 0) {
            str6 = quizOptionQuestion.greenOption;
        }
        if ((i2 & 128) != 0) {
            optionShape = quizOptionQuestion.correctShape;
        }
        String str7 = str6;
        OptionShape optionShape2 = optionShape;
        String str8 = str4;
        String str9 = str5;
        return quizOptionQuestion.copy(i, str, str2, str3, str8, str9, str7, optionShape2);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final int getId() {
        return this.id;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getCategory() {
        return this.category;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final String getQuestion() {
        return this.question;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final String getRedOption() {
        return this.redOption;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final String getBlueOption() {
        return this.blueOption;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final String getYellowOption() {
        return this.yellowOption;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final String getGreenOption() {
        return this.greenOption;
    }

    /* JADX INFO: renamed from: component8, reason: from getter */
    public final OptionShape getCorrectShape() {
        return this.correctShape;
    }

    public final QuizOptionQuestion copy(int id, String category, String question, String redOption, String blueOption, String yellowOption, String greenOption, OptionShape correctShape) {
        Intrinsics.checkNotNullParameter(category, "category");
        Intrinsics.checkNotNullParameter(question, "question");
        Intrinsics.checkNotNullParameter(redOption, "redOption");
        Intrinsics.checkNotNullParameter(blueOption, "blueOption");
        Intrinsics.checkNotNullParameter(yellowOption, "yellowOption");
        Intrinsics.checkNotNullParameter(greenOption, "greenOption");
        Intrinsics.checkNotNullParameter(correctShape, "correctShape");
        return new QuizOptionQuestion(id, category, question, redOption, blueOption, yellowOption, greenOption, correctShape);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof QuizOptionQuestion)) {
            return false;
        }
        QuizOptionQuestion quizOptionQuestion = (QuizOptionQuestion) other;
        return this.id == quizOptionQuestion.id && Intrinsics.areEqual(this.category, quizOptionQuestion.category) && Intrinsics.areEqual(this.question, quizOptionQuestion.question) && Intrinsics.areEqual(this.redOption, quizOptionQuestion.redOption) && Intrinsics.areEqual(this.blueOption, quizOptionQuestion.blueOption) && Intrinsics.areEqual(this.yellowOption, quizOptionQuestion.yellowOption) && Intrinsics.areEqual(this.greenOption, quizOptionQuestion.greenOption) && this.correctShape == quizOptionQuestion.correctShape;
    }

    public int hashCode() {
        return (((((((((((((Integer.hashCode(this.id) * 31) + this.category.hashCode()) * 31) + this.question.hashCode()) * 31) + this.redOption.hashCode()) * 31) + this.blueOption.hashCode()) * 31) + this.yellowOption.hashCode()) * 31) + this.greenOption.hashCode()) * 31) + this.correctShape.hashCode();
    }

    public String toString() {
        return "QuizOptionQuestion(id=" + this.id + ", category=" + this.category + ", question=" + this.question + ", redOption=" + this.redOption + ", blueOption=" + this.blueOption + ", yellowOption=" + this.yellowOption + ", greenOption=" + this.greenOption + ", correctShape=" + this.correctShape + ")";
    }

    public QuizOptionQuestion(int id, String category, String question, String redOption, String blueOption, String yellowOption, String greenOption, OptionShape correctShape) {
        Intrinsics.checkNotNullParameter(category, "category");
        Intrinsics.checkNotNullParameter(question, "question");
        Intrinsics.checkNotNullParameter(redOption, "redOption");
        Intrinsics.checkNotNullParameter(blueOption, "blueOption");
        Intrinsics.checkNotNullParameter(yellowOption, "yellowOption");
        Intrinsics.checkNotNullParameter(greenOption, "greenOption");
        Intrinsics.checkNotNullParameter(correctShape, "correctShape");
        this.id = id;
        this.category = category;
        this.question = question;
        this.redOption = redOption;
        this.blueOption = blueOption;
        this.yellowOption = yellowOption;
        this.greenOption = greenOption;
        this.correctShape = correctShape;
    }

    public final int getId() {
        return this.id;
    }

    public final String getCategory() {
        return this.category;
    }

    public final String getQuestion() {
        return this.question;
    }

    public final String getRedOption() {
        return this.redOption;
    }

    public final String getBlueOption() {
        return this.blueOption;
    }

    public final String getYellowOption() {
        return this.yellowOption;
    }

    public final String getGreenOption() {
        return this.greenOption;
    }

    public final OptionShape getCorrectShape() {
        return this.correctShape;
    }
}
