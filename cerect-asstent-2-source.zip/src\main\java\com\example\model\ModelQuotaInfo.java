package com.example.model;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: Models.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0015\n\u0002\u0018\u0002\n\u0002\b\u0012\b\u0087\b\u0018\u00002\u00020\u0001BW\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\b\u0012\u0006\u0010\n\u001a\u00020\b\u0012\u0006\u0010\u000b\u001a\u00020\b\u0012\u0006\u0010\f\u001a\u00020\b\u0012\u0006\u0010\r\u001a\u00020\u0006\u0012\u0006\u0010\u000e\u001a\u00020\u0006¢\u0006\u0004\b\u000f\u0010\u0010J\t\u0010!\u001a\u00020\u0003HÆ\u0003J\t\u0010\"\u001a\u00020\u0003HÆ\u0003J\t\u0010#\u001a\u00020\u0006HÆ\u0003J\t\u0010$\u001a\u00020\bHÆ\u0003J\t\u0010%\u001a\u00020\bHÆ\u0003J\t\u0010&\u001a\u00020\bHÆ\u0003J\t\u0010'\u001a\u00020\bHÆ\u0003J\t\u0010(\u001a\u00020\bHÆ\u0003J\t\u0010)\u001a\u00020\u0006HÆ\u0003J\t\u0010*\u001a\u00020\u0006HÆ\u0003Jm\u0010+\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\b2\b\b\u0002\u0010\n\u001a\u00020\b2\b\b\u0002\u0010\u000b\u001a\u00020\b2\b\b\u0002\u0010\f\u001a\u00020\b2\b\b\u0002\u0010\r\u001a\u00020\u00062\b\b\u0002\u0010\u000e\u001a\u00020\u0006HÆ\u0001J\u0013\u0010,\u001a\u00020\u00062\b\u0010-\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010.\u001a\u00020\bHÖ\u0001J\t\u0010/\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0012R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0014R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0011\u0010\t\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0016R\u0011\u0010\n\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0016R\u0011\u0010\u000b\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0016R\u0011\u0010\f\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0016R\u0011\u0010\r\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u0014R\u0011\u0010\u000e\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u0014R\u0011\u0010\u001b\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0016R\u0011\u0010\u001d\u001a\u00020\u001e8F¢\u0006\u0006\u001a\u0004\b\u001f\u0010 ¨\u00060"}, d2 = {"Lcom/example/model/ModelQuotaInfo;", "", "modelId", "", "displayName", "isLite", "", "dailyLimit", "", "safetyCutoff", "minuteLimit", "callsToday", "callsThisMinute", "isExhaustedToday", "isBlocked", "<init>", "(Ljava/lang/String;Ljava/lang/String;ZIIIIIZZ)V", "getModelId", "()Ljava/lang/String;", "getDisplayName", "()Z", "getDailyLimit", "()I", "getSafetyCutoff", "getMinuteLimit", "getCallsToday", "getCallsThisMinute", "remainingToday", "getRemainingToday", "healthState", "Lcom/example/model/ModelHealthState;", "getHealthState", "()Lcom/example/model/ModelHealthState;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "copy", "equals", "other", "hashCode", "toString", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final /* data */ class ModelQuotaInfo {
    public static final int $stable = 0;
    private final int callsThisMinute;
    private final int callsToday;
    private final int dailyLimit;
    private final String displayName;
    private final boolean isBlocked;
    private final boolean isExhaustedToday;
    private final boolean isLite;
    private final int minuteLimit;
    private final String modelId;
    private final int remainingToday;
    private final int safetyCutoff;

    public static /* synthetic */ ModelQuotaInfo copy$default(ModelQuotaInfo modelQuotaInfo, String str, String str2, boolean z, int i, int i2, int i3, int i4, int i5, boolean z2, boolean z3, int i6, Object obj) {
        if ((i6 & 1) != 0) {
            str = modelQuotaInfo.modelId;
        }
        if ((i6 & 2) != 0) {
            str2 = modelQuotaInfo.displayName;
        }
        if ((i6 & 4) != 0) {
            z = modelQuotaInfo.isLite;
        }
        if ((i6 & 8) != 0) {
            i = modelQuotaInfo.dailyLimit;
        }
        if ((i6 & 16) != 0) {
            i2 = modelQuotaInfo.safetyCutoff;
        }
        if ((i6 & 32) != 0) {
            i3 = modelQuotaInfo.minuteLimit;
        }
        if ((i6 & 64) != 0) {
            i4 = modelQuotaInfo.callsToday;
        }
        if ((i6 & 128) != 0) {
            i5 = modelQuotaInfo.callsThisMinute;
        }
        if ((i6 & 256) != 0) {
            z2 = modelQuotaInfo.isExhaustedToday;
        }
        if ((i6 & 512) != 0) {
            z3 = modelQuotaInfo.isBlocked;
        }
        boolean z4 = z2;
        boolean z5 = z3;
        int i7 = i4;
        int i8 = i5;
        int i9 = i2;
        int i10 = i3;
        return modelQuotaInfo.copy(str, str2, z, i, i9, i10, i7, i8, z4, z5);
    }

    /* JADX INFO: renamed from: component1, reason: from getter */
    public final String getModelId() {
        return this.modelId;
    }

    /* JADX INFO: renamed from: component10, reason: from getter */
    public final boolean getIsBlocked() {
        return this.isBlocked;
    }

    /* JADX INFO: renamed from: component2, reason: from getter */
    public final String getDisplayName() {
        return this.displayName;
    }

    /* JADX INFO: renamed from: component3, reason: from getter */
    public final boolean getIsLite() {
        return this.isLite;
    }

    /* JADX INFO: renamed from: component4, reason: from getter */
    public final int getDailyLimit() {
        return this.dailyLimit;
    }

    /* JADX INFO: renamed from: component5, reason: from getter */
    public final int getSafetyCutoff() {
        return this.safetyCutoff;
    }

    /* JADX INFO: renamed from: component6, reason: from getter */
    public final int getMinuteLimit() {
        return this.minuteLimit;
    }

    /* JADX INFO: renamed from: component7, reason: from getter */
    public final int getCallsToday() {
        return this.callsToday;
    }

    /* JADX INFO: renamed from: component8, reason: from getter */
    public final int getCallsThisMinute() {
        return this.callsThisMinute;
    }

    /* JADX INFO: renamed from: component9, reason: from getter */
    public final boolean getIsExhaustedToday() {
        return this.isExhaustedToday;
    }

    public final ModelQuotaInfo copy(String modelId, String displayName, boolean isLite, int dailyLimit, int safetyCutoff, int minuteLimit, int callsToday, int callsThisMinute, boolean isExhaustedToday, boolean isBlocked) {
        Intrinsics.checkNotNullParameter(modelId, "modelId");
        Intrinsics.checkNotNullParameter(displayName, "displayName");
        return new ModelQuotaInfo(modelId, displayName, isLite, dailyLimit, safetyCutoff, minuteLimit, callsToday, callsThisMinute, isExhaustedToday, isBlocked);
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ModelQuotaInfo)) {
            return false;
        }
        ModelQuotaInfo modelQuotaInfo = (ModelQuotaInfo) other;
        return Intrinsics.areEqual(this.modelId, modelQuotaInfo.modelId) && Intrinsics.areEqual(this.displayName, modelQuotaInfo.displayName) && this.isLite == modelQuotaInfo.isLite && this.dailyLimit == modelQuotaInfo.dailyLimit && this.safetyCutoff == modelQuotaInfo.safetyCutoff && this.minuteLimit == modelQuotaInfo.minuteLimit && this.callsToday == modelQuotaInfo.callsToday && this.callsThisMinute == modelQuotaInfo.callsThisMinute && this.isExhaustedToday == modelQuotaInfo.isExhaustedToday && this.isBlocked == modelQuotaInfo.isBlocked;
    }

    public int hashCode() {
        return (((((((((((((((((this.modelId.hashCode() * 31) + this.displayName.hashCode()) * 31) + Boolean.hashCode(this.isLite)) * 31) + Integer.hashCode(this.dailyLimit)) * 31) + Integer.hashCode(this.safetyCutoff)) * 31) + Integer.hashCode(this.minuteLimit)) * 31) + Integer.hashCode(this.callsToday)) * 31) + Integer.hashCode(this.callsThisMinute)) * 31) + Boolean.hashCode(this.isExhaustedToday)) * 31) + Boolean.hashCode(this.isBlocked);
    }

    public String toString() {
        return "ModelQuotaInfo(modelId=" + this.modelId + ", displayName=" + this.displayName + ", isLite=" + this.isLite + ", dailyLimit=" + this.dailyLimit + ", safetyCutoff=" + this.safetyCutoff + ", minuteLimit=" + this.minuteLimit + ", callsToday=" + this.callsToday + ", callsThisMinute=" + this.callsThisMinute + ", isExhaustedToday=" + this.isExhaustedToday + ", isBlocked=" + this.isBlocked + ")";
    }

    public ModelQuotaInfo(String modelId, String displayName, boolean isLite, int dailyLimit, int safetyCutoff, int minuteLimit, int callsToday, int callsThisMinute, boolean isExhaustedToday, boolean isBlocked) {
        Intrinsics.checkNotNullParameter(modelId, "modelId");
        Intrinsics.checkNotNullParameter(displayName, "displayName");
        this.modelId = modelId;
        this.displayName = displayName;
        this.isLite = isLite;
        this.dailyLimit = dailyLimit;
        this.safetyCutoff = safetyCutoff;
        this.minuteLimit = minuteLimit;
        this.callsToday = callsToday;
        this.callsThisMinute = callsThisMinute;
        this.isExhaustedToday = isExhaustedToday;
        this.isBlocked = isBlocked;
        this.remainingToday = RangesKt.coerceAtLeast(this.safetyCutoff - this.callsToday, 0);
    }

    public final String getModelId() {
        return this.modelId;
    }

    public final String getDisplayName() {
        return this.displayName;
    }

    public final boolean isLite() {
        return this.isLite;
    }

    public final int getDailyLimit() {
        return this.dailyLimit;
    }

    public final int getSafetyCutoff() {
        return this.safetyCutoff;
    }

    public final int getMinuteLimit() {
        return this.minuteLimit;
    }

    public final int getCallsToday() {
        return this.callsToday;
    }

    public final int getCallsThisMinute() {
        return this.callsThisMinute;
    }

    public final boolean isExhaustedToday() {
        return this.isExhaustedToday;
    }

    public final boolean isBlocked() {
        return this.isBlocked;
    }

    public final int getRemainingToday() {
        return this.remainingToday;
    }

    public final ModelHealthState getHealthState() {
        if (this.isBlocked || this.isExhaustedToday || this.callsToday >= this.safetyCutoff) {
            return ModelHealthState.EXHAUSTED;
        }
        if (this.callsToday >= ((int) (this.safetyCutoff * 0.85f)) || this.callsThisMinute >= this.minuteLimit - 1) {
            return ModelHealthState.APPROACHING;
        }
        return ModelHealthState.HEALTHY;
    }
}
