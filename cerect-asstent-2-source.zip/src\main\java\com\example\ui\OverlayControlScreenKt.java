package com.example.ui;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import androidx.compose.foundation.BackgroundKt;
import androidx.compose.foundation.BorderKt;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.foundation.BorderStrokeKt;
import androidx.compose.foundation.ScrollKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScope;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.shape.RoundedCornerShape;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.material.icons.automirrored.filled.ScreenShareKt;
import androidx.compose.material.icons.filled.CheckCircleKt;
import androidx.compose.material.icons.filled.CloudQueueKt;
import androidx.compose.material.icons.filled.PlayArrowKt;
import androidx.compose.material.icons.filled.VibrationKt;
import androidx.compose.material.icons.filled.WarningKt;
import androidx.compose.material3.ButtonColors;
import androidx.compose.material3.ButtonDefaults;
import androidx.compose.material3.ButtonKt;
import androidx.compose.material3.CardDefaults;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.ChipKt;
import androidx.compose.material3.DividerKt;
import androidx.compose.material3.FilterChipDefaults;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.ProgressIndicatorKt;
import androidx.compose.material3.SliderColors;
import androidx.compose.material3.SliderDefaults;
import androidx.compose.material3.SliderKt;
import androidx.compose.material3.SurfaceKt;
import androidx.compose.material3.SwitchColors;
import androidx.compose.material3.SwitchDefaults;
import androidx.compose.material3.SwitchKt;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Applier;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.MutableFloatState;
import androidx.compose.runtime.MutableIntState;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.PrimitiveSnapshotStateKt;
import androidx.compose.runtime.ProvidableCompositionLocal;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.SnapshotIntStateKt;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Updater;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.draw.AlphaKt;
import androidx.compose.ui.draw.ClipKt;
import androidx.compose.ui.geometry.Offset;
import androidx.compose.ui.graphics.Brush;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.ColorKt;
import androidx.compose.ui.graphics.TileMode;
import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.compose.ui.platform.TestTagKt;
import androidx.compose.ui.text.TextLayoutResult;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.core.view.PointerIconCompat;
import com.example.data.ApiUsageStats;
import com.example.data.AppPreferences;
import com.example.model.CornerPosition;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.Triple;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.ClosedFloatingPointRange;
import kotlin.ranges.RangesKt;

/* JADX INFO: compiled from: OverlayControlScreen.kt */
/* JADX INFO: loaded from: classes6.dex */
@Metadata(d1 = {"\u0000F\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0007\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\u001aC\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00010\u00072\b\b\u0002\u0010\t\u001a\u00020\nH\u0007¢\u0006\u0002\u0010\u000b\u001a;\u0010\f\u001a\u00020\u00012\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00032\u0012\u0010\u0010\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u00010\u00112\b\b\u0002\u0010\t\u001a\u00020\nH\u0007¢\u0006\u0002\u0010\u0012¨\u0006\u0013²\u0006\n\u0010\u0014\u001a\u00020\u0003X\u008a\u008e\u0002²\u0006\n\u0010\u0015\u001a\u00020\u000eX\u008a\u008e\u0002²\u0006\n\u0010\u0016\u001a\u00020\u0017X\u008a\u008e\u0002²\u0006\n\u0010\u0018\u001a\u00020\u0019X\u008a\u008e\u0002²\u0006\n\u0010\u001a\u001a\u00020\u0003X\u008a\u008e\u0002²\u0006\n\u0010\u001b\u001a\u00020\u0003X\u008a\u008e\u0002²\u0006\n\u0010\u001c\u001a\u00020\u0003X\u008a\u008e\u0002²\u0006\n\u0010\u001d\u001a\u00020\u001eX\u008a\u0084\u0002"}, d2 = {"OverlayControlScreen", "", "isServiceRunning", "", "preferences", "Lcom/example/data/AppPreferences;", "onRequestCaptureAndStart", "Lkotlin/Function0;", "onStopService", "modifier", "Landroidx/compose/ui/Modifier;", "(ZLcom/example/data/AppPreferences;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "CornerPickerChip", "position", "Lcom/example/model/CornerPosition;", "isSelected", "onSelect", "Lkotlin/Function1;", "(Lcom/example/model/CornerPosition;ZLkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app", "hasOverlayPermission", "currentPosition", "currentOpacity", "", "autoDismiss", "", "vibrationEnabled", "stealthBadgeMode", "isPopupCardDisabled", "apiUsage", "Lcom/example/data/ApiUsageStats;"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class OverlayControlScreenKt {
    static final Unit CornerPickerChip$lambda$101(CornerPosition cornerPosition, boolean z, Function1 function1, Modifier modifier, int i, int i2, Composer composer, int i3) {
        CornerPickerChip(cornerPosition, z, function1, modifier, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$97(boolean z, AppPreferences appPreferences, Function0 function0, Function0 function1, Modifier modifier, int i, int i2, Composer composer, int i3) {
        OverlayControlScreen(z, appPreferences, function0, function1, modifier, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:101:0x070e  */
    /* JADX WARN: Code duplicated, block: B:97:0x038e  */
    /* JADX WARN: Code duplicated, block: B:98:0x0394  */
    public static final void OverlayControlScreen(final boolean isServiceRunning, final AppPreferences preferences, final Function0<Unit> onRequestCaptureAndStart, final Function0<Unit> onStopService, Modifier modifier, Composer $composer, final int $changed, final int i) {
        Modifier modifier2;
        Object objMutableStateOf$default;
        Object objMutableStateOf$default2;
        Object objMutableFloatStateOf;
        Object objMutableIntStateOf;
        Object objMutableStateOf$default3;
        Object objMutableStateOf$default4;
        Object objMutableStateOf$default5;
        Function0<ComposeUiNode> function0;
        Composer composer;
        long j;
        final Modifier modifier3;
        Intrinsics.checkNotNullParameter(preferences, "preferences");
        Intrinsics.checkNotNullParameter(onRequestCaptureAndStart, "onRequestCaptureAndStart");
        Intrinsics.checkNotNullParameter(onStopService, "onStopService");
        Composer $composer2 = $composer.startRestartGroup(810458565);
        ComposerKt.sourceInformation($composer2, "C(OverlayControlScreen)P(!1,4,2,3)89@3893L7,90@3931L62,91@4019L55,92@4099L59,93@4180L62,94@4269L59,95@4355L59,96@4444L60,101@4583L21,98@4508L24470:OverlayControlScreen.kt#naom5h");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer2.changed(isServiceRunning) ? 4 : 2;
        }
        if (($changed & 48) == 0) {
            $dirty |= $composer2.changedInstance(preferences) ? 32 : 16;
        }
        if (($changed & 384) == 0) {
            $dirty |= $composer2.changedInstance(onRequestCaptureAndStart) ? 256 : 128;
        }
        if (($changed & 3072) == 0) {
            $dirty |= $composer2.changedInstance(onStopService) ? 2048 : 1024;
        }
        int i2 = i & 16;
        if (i2 != 0) {
            $dirty |= 24576;
            modifier2 = modifier;
        } else if (($changed & 24576) == 0) {
            modifier2 = modifier;
            $dirty |= $composer2.changed(modifier2) ? 16384 : 8192;
        } else {
            modifier2 = modifier;
        }
        int $dirty2 = $dirty;
        if (($dirty2 & 9363) == 9362 && $composer2.getSkipping()) {
            $composer2.skipToGroupEnd();
            modifier3 = modifier2;
        } else {
            if (i2 != 0) {
                modifier2 = Modifier.INSTANCE;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(810458565, $dirty2, -1, "com.example.ui.OverlayControlScreen (OverlayControlScreen.kt:88)");
            }
            ProvidableCompositionLocal<Context> localContext = AndroidCompositionLocals_androidKt.getLocalContext();
            ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "CC:CompositionLocal.kt#9igjgp");
            Object objConsume = $composer2.consume(localContext);
            ComposerKt.sourceInformationMarkerEnd($composer2);
            final Context context = (Context) objConsume;
            ComposerKt.sourceInformationMarkerStart($composer2, 1461609091, "CC(remember):OverlayControlScreen.kt#9igjgp");
            Object objRememberedValue = $composer2.rememberedValue();
            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(Boolean.valueOf(Settings.canDrawOverlays(context)), null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default);
            } else {
                objMutableStateOf$default = objRememberedValue;
            }
            final MutableState hasOverlayPermission$delegate = (MutableState) objMutableStateOf$default;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, 1461611900, "CC(remember):OverlayControlScreen.kt#9igjgp");
            Object objRememberedValue2 = $composer2.rememberedValue();
            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default2 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(preferences.getCornerPosition(), null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default2);
            } else {
                objMutableStateOf$default2 = objRememberedValue2;
            }
            final MutableState currentPosition$delegate = (MutableState) objMutableStateOf$default2;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, 1461614464, "CC(remember):OverlayControlScreen.kt#9igjgp");
            Object objRememberedValue3 = $composer2.rememberedValue();
            if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                objMutableFloatStateOf = PrimitiveSnapshotStateKt.mutableFloatStateOf(preferences.getCornerOpacity());
                $composer2.updateRememberedValue(objMutableFloatStateOf);
            } else {
                objMutableFloatStateOf = objRememberedValue3;
            }
            final MutableFloatState currentOpacity$delegate = (MutableFloatState) objMutableFloatStateOf;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, 1461617059, "CC(remember):OverlayControlScreen.kt#9igjgp");
            Object objRememberedValue4 = $composer2.rememberedValue();
            if (objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                objMutableIntStateOf = SnapshotIntStateKt.mutableIntStateOf(preferences.getAutoDismissSeconds());
                $composer2.updateRememberedValue(objMutableIntStateOf);
            } else {
                objMutableIntStateOf = objRememberedValue4;
            }
            final MutableIntState autoDismiss$delegate = (MutableIntState) objMutableIntStateOf;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, 1461619904, "CC(remember):OverlayControlScreen.kt#9igjgp");
            Object objRememberedValue5 = $composer2.rememberedValue();
            if (objRememberedValue5 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default3 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(Boolean.valueOf(preferences.isVibrationEnabled()), null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default3);
            } else {
                objMutableStateOf$default3 = objRememberedValue5;
            }
            final MutableState vibrationEnabled$delegate = (MutableState) objMutableStateOf$default3;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, 1461622656, "CC(remember):OverlayControlScreen.kt#9igjgp");
            Object objRememberedValue6 = $composer2.rememberedValue();
            if (objRememberedValue6 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default4 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(Boolean.valueOf(preferences.isStealthBadgeMode()), null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default4);
            } else {
                objMutableStateOf$default4 = objRememberedValue6;
            }
            final MutableState stealthBadgeMode$delegate = (MutableState) objMutableStateOf$default4;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            ComposerKt.sourceInformationMarkerStart($composer2, 1461625505, "CC(remember):OverlayControlScreen.kt#9igjgp");
            Object objRememberedValue7 = $composer2.rememberedValue();
            if (objRememberedValue7 == Composer.INSTANCE.getEmpty()) {
                objMutableStateOf$default5 = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(Boolean.valueOf(preferences.isPopupCardDisabled()), null, 2, null);
                $composer2.updateRememberedValue(objMutableStateOf$default5);
            } else {
                objMutableStateOf$default5 = objRememberedValue7;
            }
            final MutableState isPopupCardDisabled$delegate = (MutableState) objMutableStateOf$default5;
            ComposerKt.sourceInformationMarkerEnd($composer2);
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(ScrollKt.verticalScroll$default(SizeKt.fillMaxSize$default(modifier2, 0.0f, 1, null), ScrollKt.rememberScrollState(0, $composer2, 0, 1), false, null, false, 14, null), Dp.m6622constructorimpl(16));
            ComposerKt.sourceInformationMarkerStart($composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer2, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer2, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            Modifier modifier4 = modifier2;
            int i3 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer2.startReusableNode();
            if ($composer2.getInserting()) {
                function0 = constructor;
                $composer2.createNode(function0);
            } else {
                function0 = constructor;
                $composer2.useNode();
            }
            Composer composerM3652constructorimpl = Updater.m3652constructorimpl($composer2);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting()) {
                composer = $composer2;
            } else {
                composer = $composer2;
                if (!Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i4 = (i3 >> 6) & 14;
                Composer composer2 = composer;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i5 = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 1896168500, "C106@4700L107,111@4897L3694,105@4666L3925,214@8597L41,217@8715L16,219@8812L11,219@8770L62,221@8903L20,225@9023L2662,218@8736L2949,298@11691L41,302@11843L11,302@11801L62,304@11934L20,306@12003L2894,301@11767L3130,389@14903L41,393@15055L11,393@15013L62,395@15146L20,397@15215L2944,392@14979L3180,486@18165L41,490@18321L11,490@18279L62,492@18412L20,494@18481L2934,489@18245L3170,582@21421L41,586@21584L11,586@21542L62,588@21675L20,590@21744L4644,585@21508L4880,720@26394L41,724@26549L11,724@26507L62,726@26640L20,728@26709L2218,723@26473L2454,797@28933L41:OverlayControlScreen.kt#naom5h");
                CardDefaults cardDefaults = CardDefaults.INSTANCE;
                if (isServiceRunning) {
                    j = 4278603323L;
                } else {
                    j = 4280163147L;
                }
                CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(22)), cardDefaults.m1829cardColorsro_MJ88(ColorKt.Color(j), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, null, ComposableLambdaKt.rememberComposableLambda(995360173, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda10
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28(isServiceRunning, context, onRequestCaptureAndStart, onStopService, currentPosition$delegate, hasOverlayPermission$delegate, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 196614, 24);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                final State stateCollectAsState = SnapshotStateKt.collectAsState(preferences.getApiUsageFlow(), null, composer2, 0, 1);
                CardKt.Card(TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "api_limit_status_card"), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(1555061092, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda12
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$37(stateCollectAsState, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 196614, 8);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), composer2, 6);
                CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(2133827237, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda13
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$46(context, hasOverlayPermission$delegate, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 196614, 8);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), composer2, 6);
                CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(-1582373914, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda14
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58(preferences, currentPosition$delegate, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 196614, 8);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), composer2, 6);
                CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(-1003607769, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda15
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70(currentOpacity$delegate, preferences, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 196614, 8);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), composer2, 6);
                CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(-424841624, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda16
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$84(preferences, stealthBadgeMode$delegate, isPopupCardDisabled$delegate, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 196614, 8);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), composer2, 6);
                CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer2, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer2, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(153924521, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda17
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95(preferences, autoDismiss$delegate, vibrationEnabled$delegate, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 196614, 8);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(80)), composer2, 6);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
                modifier3 = modifier4;
            }
            composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i6 = (i3 >> 6) & 14;
            Composer composer3 = composer;
            ComposerKt.sourceInformationMarkerStart(composer3, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
            int i7 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer3, 1896168500, "C106@4700L107,111@4897L3694,105@4666L3925,214@8597L41,217@8715L16,219@8812L11,219@8770L62,221@8903L20,225@9023L2662,218@8736L2949,298@11691L41,302@11843L11,302@11801L62,304@11934L20,306@12003L2894,301@11767L3130,389@14903L41,393@15055L11,393@15013L62,395@15146L20,397@15215L2944,392@14979L3180,486@18165L41,490@18321L11,490@18279L62,492@18412L20,494@18481L2934,489@18245L3170,582@21421L41,586@21584L11,586@21542L62,588@21675L20,590@21744L4644,585@21508L4880,720@26394L41,724@26549L11,724@26507L62,726@26640L20,728@26709L2218,723@26473L2454,797@28933L41:OverlayControlScreen.kt#naom5h");
            CardDefaults cardDefaults2 = CardDefaults.INSTANCE;
            if (isServiceRunning) {
                j = 4278603323L;
            } else {
                j = 4280163147L;
            }
            CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(22)), cardDefaults2.m1829cardColorsro_MJ88(ColorKt.Color(j), 0L, 0L, 0L, composer3, CardDefaults.$stable << 12, 14), null, null, ComposableLambdaKt.rememberComposableLambda(995360173, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda10
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28(isServiceRunning, context, onRequestCaptureAndStart, onStopService, currentPosition$delegate, hasOverlayPermission$delegate, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer3, 54), composer3, 196614, 24);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer3, 6);
            final State stateCollectAsState2 = SnapshotStateKt.collectAsState(preferences.getApiUsageFlow(), null, composer3, 0, 1);
            CardKt.Card(TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "api_limit_status_card"), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer3, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer3, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(1555061092, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda12
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$37(stateCollectAsState2, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer3, 54), composer3, 196614, 8);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), composer3, 6);
            CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer3, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer3, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(2133827237, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda13
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$46(context, hasOverlayPermission$delegate, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer3, 54), composer3, 196614, 8);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), composer3, 6);
            CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer3, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer3, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(-1582373914, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda14
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58(preferences, currentPosition$delegate, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer3, 54), composer3, 196614, 8);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), composer3, 6);
            CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer3, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer3, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(-1003607769, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda15
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70(currentOpacity$delegate, preferences, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer3, 54), composer3, 196614, 8);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), composer3, 6);
            CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer3, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer3, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(-424841624, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda16
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$84(preferences, stealthBadgeMode$delegate, isPopupCardDisabled$delegate, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer3, 54), composer3, 196614, 8);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), composer3, 6);
            CardKt.Card(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(18)), CardDefaults.INSTANCE.m1829cardColorsro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getSurface(), 0L, 0L, 0L, composer3, CardDefaults.$stable << 12, 14), null, CardDefaults.INSTANCE.outlinedCardBorder(false, composer3, CardDefaults.$stable << 3, 1), ComposableLambdaKt.rememberComposableLambda(153924521, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda17
                @Override // kotlin.jvm.functions.Function3
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95(preferences, autoDismiss$delegate, vibrationEnabled$delegate, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer3, 54), composer3, 196614, 8);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(80)), composer3, 6);
            ComposerKt.sourceInformationMarkerEnd(composer3);
            ComposerKt.sourceInformationMarkerEnd(composer3);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            modifier3 = modifier4;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda18
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$97(isServiceRunning, preferences, onRequestCaptureAndStart, onStopService, modifier3, $changed, i, (Composer) obj, ((Integer) obj2).intValue());
                }
            });
        }
    }

    private static final boolean OverlayControlScreen$lambda$1(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void OverlayControlScreen$lambda$2(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    private static final CornerPosition OverlayControlScreen$lambda$4(MutableState<CornerPosition> mutableState) {
        return mutableState.getValue();
    }

    private static final float OverlayControlScreen$lambda$7(MutableFloatState $currentOpacity$delegate) {
        return $currentOpacity$delegate.getFloatValue();
    }

    private static final int OverlayControlScreen$lambda$10(MutableIntState $autoDismiss$delegate) {
        return $autoDismiss$delegate.getIntValue();
    }

    private static final boolean OverlayControlScreen$lambda$13(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void OverlayControlScreen$lambda$14(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    private static final boolean OverlayControlScreen$lambda$16(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void OverlayControlScreen$lambda$17(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    private static final boolean OverlayControlScreen$lambda$19(MutableState<Boolean> mutableState) {
        return mutableState.getValue().booleanValue();
    }

    private static final void OverlayControlScreen$lambda$20(MutableState<Boolean> mutableState, boolean z) {
        mutableState.setValue(Boolean.valueOf(z));
    }

    /* JADX WARN: Code duplicated, block: B:28:0x01e1  */
    /* JADX WARN: Code duplicated, block: B:31:0x01ed  */
    /* JADX WARN: Code duplicated, block: B:32:0x01f3  */
    /* JADX WARN: Code duplicated, block: B:43:0x02fe  */
    /* JADX WARN: Code duplicated, block: B:46:0x030a  */
    /* JADX WARN: Code duplicated, block: B:47:0x0310  */
    /* JADX WARN: Code duplicated, block: B:50:0x0341  */
    /* JADX WARN: Code duplicated, block: B:53:0x0354  */
    /* JADX WARN: Code duplicated, block: B:54:0x0357  */
    /* JADX WARN: Code duplicated, block: B:58:0x03b9  */
    /* JADX WARN: Code duplicated, block: B:59:0x03be  */
    /* JADX WARN: Code duplicated, block: B:62:0x03f4  */
    /* JADX WARN: Code duplicated, block: B:63:0x03f7  */
    /* JADX WARN: Code duplicated, block: B:66:0x04d3  */
    /* JADX WARN: Code duplicated, block: B:67:0x04d8  */
    /* JADX WARN: Code duplicated, block: B:70:0x0538  */
    /* JADX WARN: Code duplicated, block: B:72:0x0596  */
    /* JADX WARN: Code duplicated, block: B:76:0x05a1  */
    /* JADX WARN: Code duplicated, block: B:78:0x05e6  */
    /* JADX WARN: Code duplicated, block: B:81:0x0671  */
    static final Unit OverlayControlScreen$lambda$96$lambda$28(boolean $isServiceRunning, final Context $context, final Function0 $onRequestCaptureAndStart, Function0 $onStopService, final MutableState $currentPosition$delegate, final MutableState $hasOverlayPermission$delegate, ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        Composer composer;
        Composer composer2;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function1;
        Composer composerM3652constructorimpl;
        int currentCompositeKeyHash2;
        Function0<ComposeUiNode> constructor2;
        Function0<ComposeUiNode> function2;
        Composer composerM3652constructorimpl2;
        Composer composer3;
        long jColor;
        String str;
        String str2;
        boolean zChangedInstance;
        Object obj;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C112@4905L3680:OverlayControlScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(995360173, $changed, -1, "com.example.ui.OverlayControlScreen.<anonymous>.<anonymous> (OverlayControlScreen.kt:112)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor3;
                $composer.createNode(function0);
            } else {
                function0 = constructor3;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl3 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl3.getInserting()) {
                composer = $composer;
            } else {
                composer = $composer;
                if (!Intrinsics.areEqual(composerM3652constructorimpl3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i2 = (i >> 6) & 14;
                composer2 = composer;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i3 = ((6 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 406099325, "C113@4958L1254,150@6222L41,157@6645L10,152@6273L470,162@6753L41:OverlayControlScreen.kt#naom5h");
                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap2 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i4 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function1 = constructor;
                    composer2.createNode(function1);
                } else {
                    function1 = constructor;
                    composer2.useNode();
                }
                composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                    composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash2);
                }
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i5 = (i4 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                int i6 = ((438 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -750363458, "C118@5148L641,139@5921L281,136@5801L401:OverlayControlScreen.kt#naom5h");
                Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                Modifier modifier = Modifier.INSTANCE;
                MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically2, composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composer2, modifier);
                constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                int i7 = ((((384 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function2 = constructor2;
                    composer2.createNode(function2);
                } else {
                    function2 = constructor2;
                    composer2.useNode();
                }
                composerM3652constructorimpl2 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (composerM3652constructorimpl2.getInserting()) {
                    composer3 = composer2;
                } else {
                    composer3 = composer2;
                    if (!Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                    }
                    Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                    int i8 = (i7 >> 6) & 14;
                    Composer composer4 = composer3;
                    ComposerKt.sourceInformationMarkerStart(composer4, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                    RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                    int i9 = ((384 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer4, 955698725, "C119@5214L237,127@5464L40,130@5662L10,128@5517L260:OverlayControlScreen.kt#naom5h");
                    Modifier modifierM715size3ABfNKs = SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14));
                    if ($isServiceRunning) {
                        jColor = com.example.ui.theme.ColorKt.getEmeraldSuccess();
                    } else {
                        jColor = ColorKt.Color(4287931320L);
                    }
                    BoxKt.Box(BackgroundKt.m224backgroundbw27NRU(modifierM715size3ABfNKs, jColor, RoundedCornerShapeKt.getCircleShape()), composer4, 0);
                    SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer4, 6);
                    if ($isServiceRunning) {
                        str = "Služba v rohu je AKTIVNÍ";
                    } else {
                        str = "Služba v rohu je VYPNUTÁ";
                    }
                    TextKt.m2693Text4IGK_g(str, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer4, MaterialTheme.$stable).getTitleMedium(), composer4, 196992, 0, 65498);
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    composer3.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    long jM4196getWhite0d7_KjU = Color.INSTANCE.m4196getWhite0d7_KjU();
                    SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)), Color.m4157copywmQWz5c(jM4196getWhite0d7_KjU, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jM4196getWhite0d7_KjU) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jM4196getWhite0d7_KjU) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jM4196getWhite0d7_KjU) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jM4196getWhite0d7_KjU) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(956268322, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj2, Object obj3) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$23$lambda$22($currentPosition$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }, composer2, 54), composer2, 12583296, 121);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer2, 6);
                    if ($isServiceRunning) {
                        str2 = "Aplikace běží na pozadí přes ostatní aplikace. Stačí kliknout do zvoleného rohu pro okamžité vyřešení kvízu nebo otázky.";
                    } else {
                        str2 = "Spusťte plovoucí nápovědu. V rohu obrazovky se zobrazí nenápadný bod, který po klepnutí sejme obrazovku a ukáže správnou odpověď.";
                    }
                    TextKt.m2693Text4IGK_g(str2, (Modifier) null, ColorKt.Color(4293060848L), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, TextUnitKt.getSp(20), 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, 384, 6, 64506);
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(18)), composer2, 6);
                    if ($isServiceRunning) {
                        composer2.startReplaceGroup(408985207);
                        ComposerKt.sourceInformation(composer2, "196@8054L48,194@7973L594");
                        ButtonKt.Button($onStopService, TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "stop_overlay_service_button"), false, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(14)), ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(ColorKt.Color(4292617766L), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14), null, null, null, null, ComposableSingletons$OverlayControlScreenKt.INSTANCE.getLambda$795956791$app(), composer2, 805306416, 484);
                        composer2.endReplaceGroup();
                    } else {
                        composer2.startReplaceGroup(407904981);
                        ComposerKt.sourceInformation(composer2, "179@7372L44,167@6899L435,184@7594L351,166@6869L1076");
                        ButtonColors buttonColorsM1809buttonColorsro_MJ88 = ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14);
                        RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(14));
                        Modifier modifierTestTag = TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "start_overlay_service_button");
                        ComposerKt.sourceInformationMarkerStart(composer2, -125388426, "CC(remember):OverlayControlScreen.kt#9igjgp");
                        zChangedInstance = composer2.changedInstance($context) | composer2.changed($onRequestCaptureAndStart);
                        Object objRememberedValue = composer2.rememberedValue();
                        if (!zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                            obj = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda11
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$25$lambda$24($context, $onRequestCaptureAndStart, $hasOverlayPermission$delegate);
                                }
                            };
                            composer2.updateRememberedValue(obj);
                        } else {
                            obj = objRememberedValue;
                        }
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ButtonKt.Button((Function0) obj, modifierTestTag, false, roundedCornerShapeM953RoundedCornerShape0680j_4, buttonColorsM1809buttonColorsro_MJ88, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-1505438546, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda22
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj2, Object obj3, Object obj4) {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$26($hasOverlayPermission$delegate, (RowScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                            }
                        }, composer2, 54), composer2, 805306416, 484);
                        composer2.endReplaceGroup();
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                }
                composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash3);
                Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i10 = (i7 >> 6) & 14;
                Composer composer5 = composer3;
                ComposerKt.sourceInformationMarkerStart(composer5, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance3 = RowScopeInstance.INSTANCE;
                int i11 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer5, 955698725, "C119@5214L237,127@5464L40,130@5662L10,128@5517L260:OverlayControlScreen.kt#naom5h");
                Modifier modifierM715size3ABfNKs2 = SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14));
                if ($isServiceRunning) {
                    jColor = com.example.ui.theme.ColorKt.getEmeraldSuccess();
                } else {
                    jColor = ColorKt.Color(4287931320L);
                }
                BoxKt.Box(BackgroundKt.m224backgroundbw27NRU(modifierM715size3ABfNKs2, jColor, RoundedCornerShapeKt.getCircleShape()), composer5, 0);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer5, 6);
                if ($isServiceRunning) {
                    str = "Služba v rohu je AKTIVNÍ";
                } else {
                    str = "Služba v rohu je VYPNUTÁ";
                }
                TextKt.m2693Text4IGK_g(str, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer5, MaterialTheme.$stable).getTitleMedium(), composer5, 196992, 0, 65498);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                composer3.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer3);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                long jM4196getWhite0d7_KjU2 = Color.INSTANCE.m4196getWhite0d7_KjU();
                SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)), Color.m4157copywmQWz5c(jM4196getWhite0d7_KjU2, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jM4196getWhite0d7_KjU2) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jM4196getWhite0d7_KjU2) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jM4196getWhite0d7_KjU2) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jM4196getWhite0d7_KjU2) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(956268322, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj2, Object obj3) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$23$lambda$22($currentPosition$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 12583296, 121);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer2, 6);
                if ($isServiceRunning) {
                    str2 = "Aplikace běží na pozadí přes ostatní aplikace. Stačí kliknout do zvoleného rohu pro okamžité vyřešení kvízu nebo otázky.";
                } else {
                    str2 = "Spusťte plovoucí nápovědu. V rohu obrazovky se zobrazí nenápadný bod, který po klepnutí sejme obrazovku a ukáže správnou odpověď.";
                }
                TextKt.m2693Text4IGK_g(str2, (Modifier) null, ColorKt.Color(4293060848L), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, TextUnitKt.getSp(20), 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, 384, 6, 64506);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(18)), composer2, 6);
                if ($isServiceRunning) {
                    composer2.startReplaceGroup(407904981);
                    ComposerKt.sourceInformation(composer2, "179@7372L44,167@6899L435,184@7594L351,166@6869L1076");
                    ButtonColors buttonColorsM1809buttonColorsro_MJ89 = ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14);
                    RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_5 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(14));
                    Modifier modifierTestTag2 = TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "start_overlay_service_button");
                    ComposerKt.sourceInformationMarkerStart(composer2, -125388426, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance = composer2.changedInstance($context) | composer2.changed($onRequestCaptureAndStart);
                    Object objRememberedValue2 = composer2.rememberedValue();
                    if (zChangedInstance) {
                        obj = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda11
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$25$lambda$24($context, $onRequestCaptureAndStart, $hasOverlayPermission$delegate);
                            }
                        };
                        composer2.updateRememberedValue(obj);
                    } else {
                        obj = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda11
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$25$lambda$24($context, $onRequestCaptureAndStart, $hasOverlayPermission$delegate);
                            }
                        };
                        composer2.updateRememberedValue(obj);
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ButtonKt.Button((Function0) obj, modifierTestTag2, false, roundedCornerShapeM953RoundedCornerShape0680j_5, buttonColorsM1809buttonColorsro_MJ89, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-1505438546, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda22
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj2, Object obj3, Object obj4) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$26($hasOverlayPermission$delegate, (RowScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                        }
                    }, composer2, 54), composer2, 805306416, 484);
                    composer2.endReplaceGroup();
                } else {
                    composer2.startReplaceGroup(408985207);
                    ComposerKt.sourceInformation(composer2, "196@8054L48,194@7973L594");
                    ButtonKt.Button($onStopService, TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "stop_overlay_service_button"), false, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(14)), ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(ColorKt.Color(4292617766L), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14), null, null, null, null, ComposableSingletons$OverlayControlScreenKt.INSTANCE.getLambda$795956791$app(), composer2, 805306416, 484);
                    composer2.endReplaceGroup();
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
            composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash);
            Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i12 = (i >> 6) & 14;
            composer2 = composer;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
            int i13 = ((6 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 406099325, "C113@4958L1254,150@6222L41,157@6645L10,152@6273L470,162@6753L41:OverlayControlScreen.kt#naom5h");
            Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween2 = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically3 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy3 = RowKt.rowMeasurePolicy(spaceBetween2, centerVertically3, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap4 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default2);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i14 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function1 = constructor;
                composer2.createNode(function1);
            } else {
                function1 = constructor;
                composer2.useNode();
            }
            composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl.getInserting()) {
            }
            composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash4);
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
            int i15 = (i14 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance4 = RowScopeInstance.INSTANCE;
            int i16 = ((438 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -750363458, "C118@5148L641,139@5921L281,136@5801L401:OverlayControlScreen.kt#naom5h");
            Alignment.Vertical centerVertically4 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            Modifier modifier2 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy4 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically4, composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap5 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier(composer2, modifier2);
            constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i17 = ((((384 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function2 = constructor2;
                composer2.createNode(function2);
            } else {
                function2 = constructor2;
                composer2.useNode();
            }
            composerM3652constructorimpl2 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl2.getInserting()) {
                composer3 = composer2;
                if (!Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
                int i18 = (i17 >> 6) & 14;
                Composer composer6 = composer3;
                ComposerKt.sourceInformationMarkerStart(composer6, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance5 = RowScopeInstance.INSTANCE;
                int i19 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer6, 955698725, "C119@5214L237,127@5464L40,130@5662L10,128@5517L260:OverlayControlScreen.kt#naom5h");
                Modifier modifierM715size3ABfNKs3 = SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14));
                if ($isServiceRunning) {
                    jColor = com.example.ui.theme.ColorKt.getEmeraldSuccess();
                } else {
                    jColor = ColorKt.Color(4287931320L);
                }
                BoxKt.Box(BackgroundKt.m224backgroundbw27NRU(modifierM715size3ABfNKs3, jColor, RoundedCornerShapeKt.getCircleShape()), composer6, 0);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer6, 6);
                if ($isServiceRunning) {
                    str = "Služba v rohu je AKTIVNÍ";
                } else {
                    str = "Služba v rohu je VYPNUTÁ";
                }
                TextKt.m2693Text4IGK_g(str, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer6, MaterialTheme.$stable).getTitleMedium(), composer6, 196992, 0, 65498);
                ComposerKt.sourceInformationMarkerEnd(composer6);
                ComposerKt.sourceInformationMarkerEnd(composer6);
                composer3.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer3);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                long jM4196getWhite0d7_KjU3 = Color.INSTANCE.m4196getWhite0d7_KjU();
                SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)), Color.m4157copywmQWz5c(jM4196getWhite0d7_KjU3, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jM4196getWhite0d7_KjU3) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jM4196getWhite0d7_KjU3) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jM4196getWhite0d7_KjU3) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jM4196getWhite0d7_KjU3) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(956268322, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj2, Object obj3) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$23$lambda$22($currentPosition$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, composer2, 54), composer2, 12583296, 121);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer2, 6);
                if ($isServiceRunning) {
                    str2 = "Aplikace běží na pozadí přes ostatní aplikace. Stačí kliknout do zvoleného rohu pro okamžité vyřešení kvízu nebo otázky.";
                } else {
                    str2 = "Spusťte plovoucí nápovědu. V rohu obrazovky se zobrazí nenápadný bod, který po klepnutí sejme obrazovku a ukáže správnou odpověď.";
                }
                TextKt.m2693Text4IGK_g(str2, (Modifier) null, ColorKt.Color(4293060848L), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, TextUnitKt.getSp(20), 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, 384, 6, 64506);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(18)), composer2, 6);
                if ($isServiceRunning) {
                    composer2.startReplaceGroup(407904981);
                    ComposerKt.sourceInformation(composer2, "179@7372L44,167@6899L435,184@7594L351,166@6869L1076");
                    ButtonColors buttonColorsM1809buttonColorsro_MJ810 = ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14);
                    RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_6 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(14));
                    Modifier modifierTestTag3 = TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "start_overlay_service_button");
                    ComposerKt.sourceInformationMarkerStart(composer2, -125388426, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance = composer2.changedInstance($context) | composer2.changed($onRequestCaptureAndStart);
                    Object objRememberedValue3 = composer2.rememberedValue();
                    if (zChangedInstance) {
                        obj = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda11
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$25$lambda$24($context, $onRequestCaptureAndStart, $hasOverlayPermission$delegate);
                            }
                        };
                        composer2.updateRememberedValue(obj);
                    } else {
                        obj = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda11
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$25$lambda$24($context, $onRequestCaptureAndStart, $hasOverlayPermission$delegate);
                            }
                        };
                        composer2.updateRememberedValue(obj);
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ButtonKt.Button((Function0) obj, modifierTestTag3, false, roundedCornerShapeM953RoundedCornerShape0680j_6, buttonColorsM1809buttonColorsro_MJ810, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-1505438546, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda22
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj2, Object obj3, Object obj4) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$26($hasOverlayPermission$delegate, (RowScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                        }
                    }, composer2, 54), composer2, 805306416, 484);
                    composer2.endReplaceGroup();
                } else {
                    composer2.startReplaceGroup(408985207);
                    ComposerKt.sourceInformation(composer2, "196@8054L48,194@7973L594");
                    ButtonKt.Button($onStopService, TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "stop_overlay_service_button"), false, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(14)), ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(ColorKt.Color(4292617766L), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14), null, null, null, null, ComposableSingletons$OverlayControlScreenKt.INSTANCE.getLambda$795956791$app(), composer2, 805306416, 484);
                    composer2.endReplaceGroup();
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composer3 = composer2;
            }
            composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash5);
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
            int i110 = (i17 >> 6) & 14;
            Composer composer7 = composer3;
            ComposerKt.sourceInformationMarkerStart(composer7, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance6 = RowScopeInstance.INSTANCE;
            int i111 = ((384 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer7, 955698725, "C119@5214L237,127@5464L40,130@5662L10,128@5517L260:OverlayControlScreen.kt#naom5h");
            Modifier modifierM715size3ABfNKs4 = SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14));
            if ($isServiceRunning) {
                jColor = com.example.ui.theme.ColorKt.getEmeraldSuccess();
            } else {
                jColor = ColorKt.Color(4287931320L);
            }
            BoxKt.Box(BackgroundKt.m224backgroundbw27NRU(modifierM715size3ABfNKs4, jColor, RoundedCornerShapeKt.getCircleShape()), composer7, 0);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer7, 6);
            if ($isServiceRunning) {
                str = "Služba v rohu je AKTIVNÍ";
            } else {
                str = "Služba v rohu je VYPNUTÁ";
            }
            TextKt.m2693Text4IGK_g(str, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer7, MaterialTheme.$stable).getTitleMedium(), composer7, 196992, 0, 65498);
            ComposerKt.sourceInformationMarkerEnd(composer7);
            ComposerKt.sourceInformationMarkerEnd(composer7);
            composer3.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer3);
            ComposerKt.sourceInformationMarkerEnd(composer3);
            ComposerKt.sourceInformationMarkerEnd(composer3);
            long jM4196getWhite0d7_KjU4 = Color.INSTANCE.m4196getWhite0d7_KjU();
            SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(12)), Color.m4157copywmQWz5c(jM4196getWhite0d7_KjU4, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jM4196getWhite0d7_KjU4) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jM4196getWhite0d7_KjU4) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jM4196getWhite0d7_KjU4) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jM4196getWhite0d7_KjU4) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(956268322, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda0
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$23$lambda$22($currentPosition$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, composer2, 54), composer2, 12583296, 121);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer2, 6);
            if ($isServiceRunning) {
                str2 = "Aplikace běží na pozadí přes ostatní aplikace. Stačí kliknout do zvoleného rohu pro okamžité vyřešení kvízu nebo otázky.";
            } else {
                str2 = "Spusťte plovoucí nápovědu. V rohu obrazovky se zobrazí nenápadný bod, který po klepnutí sejme obrazovku a ukáže správnou odpověď.";
            }
            TextKt.m2693Text4IGK_g(str2, (Modifier) null, ColorKt.Color(4293060848L), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, TextUnitKt.getSp(20), 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, 384, 6, 64506);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(18)), composer2, 6);
            if ($isServiceRunning) {
                composer2.startReplaceGroup(407904981);
                ComposerKt.sourceInformation(composer2, "179@7372L44,167@6899L435,184@7594L351,166@6869L1076");
                ButtonColors buttonColorsM1809buttonColorsro_MJ811 = ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14);
                RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_7 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(14));
                Modifier modifierTestTag4 = TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "start_overlay_service_button");
                ComposerKt.sourceInformationMarkerStart(composer2, -125388426, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance = composer2.changedInstance($context) | composer2.changed($onRequestCaptureAndStart);
                Object objRememberedValue4 = composer2.rememberedValue();
                if (zChangedInstance) {
                    obj = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda11
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$25$lambda$24($context, $onRequestCaptureAndStart, $hasOverlayPermission$delegate);
                        }
                    };
                    composer2.updateRememberedValue(obj);
                } else {
                    obj = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda11
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$25$lambda$24($context, $onRequestCaptureAndStart, $hasOverlayPermission$delegate);
                        }
                    };
                    composer2.updateRememberedValue(obj);
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ButtonKt.Button((Function0) obj, modifierTestTag4, false, roundedCornerShapeM953RoundedCornerShape0680j_7, buttonColorsM1809buttonColorsro_MJ811, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-1505438546, true, new Function3() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda22
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj2, Object obj3, Object obj4) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$26($hasOverlayPermission$delegate, (RowScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                    }
                }, composer2, 54), composer2, 805306416, 484);
                composer2.endReplaceGroup();
            } else {
                composer2.startReplaceGroup(408985207);
                ComposerKt.sourceInformation(composer2, "196@8054L48,194@7973L594");
                ButtonKt.Button($onStopService, TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "stop_overlay_service_button"), false, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(14)), ButtonDefaults.INSTANCE.m1809buttonColorsro_MJ88(ColorKt.Color(4292617766L), 0L, 0L, 0L, composer2, (ButtonDefaults.$stable << 12) | 6, 14), null, null, null, null, ComposableSingletons$OverlayControlScreenKt.INSTANCE.getLambda$795956791$app(), composer2, 805306416, 484);
                composer2.endReplaceGroup();
            }
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$23$lambda$22(MutableState $currentPosition$delegate, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C140@5935L255:OverlayControlScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(956268322, $changed, -1, "com.example.ui.OverlayControlScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (OverlayControlScreen.kt:140)");
            }
            TextKt.m2693Text4IGK_g(OverlayControlScreen$lambda$4($currentPosition$delegate).getTitle(), PaddingKt.m671paddingVpY3zN4(Modifier.INSTANCE, Dp.m6622constructorimpl(10), Dp.m6622constructorimpl(4)), Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(12), (FontStyle) null, FontWeight.INSTANCE.getMedium(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 200112, 0, 131024);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$25$lambda$24(Context $context, Function0 $onRequestCaptureAndStart, MutableState $hasOverlayPermission$delegate) {
        OverlayControlScreen$lambda$2($hasOverlayPermission$delegate, Settings.canDrawOverlays($context));
        if (!OverlayControlScreen$lambda$1($hasOverlayPermission$delegate)) {
            Intent intent = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + $context.getPackageName()));
            $context.startActivity(intent);
        } else {
            $onRequestCaptureAndStart.invoke();
        }
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$28$lambda$27$lambda$26(MutableState $hasOverlayPermission$delegate, RowScope Button, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Button, "$this$Button");
        ComposerKt.sourceInformation($composer, "C185@7608L56,186@7677L39,187@7729L204:OverlayControlScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1505438546, $changed, -1, "com.example.ui.OverlayControlScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (OverlayControlScreen.kt:185)");
            }
            IconKt.m2150Iconww6aTOc(PlayArrowKt.getPlayArrow(Icons.INSTANCE.getDefault()), (String) null, (Modifier) null, 0L, $composer, 48, 12);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), $composer, 6);
            TextKt.m2693Text4IGK_g(!OverlayControlScreen$lambda$1($hasOverlayPermission$delegate) ? "Povolit překrytí a spustit" : "Spustit v rohu obrazovky", (Modifier) null, 0L, TextUnitKt.getSp(15), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 199680, 0, 131030);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    private static final ApiUsageStats OverlayControlScreen$lambda$96$lambda$29(State<ApiUsageStats> state) {
        return (ApiUsageStats) state.getValue();
    }

    /* JADX WARN: Code duplicated, block: B:28:0x01d6  */
    /* JADX WARN: Code duplicated, block: B:31:0x01e2  */
    /* JADX WARN: Code duplicated, block: B:32:0x01e8  */
    /* JADX WARN: Code duplicated, block: B:43:0x02f4  */
    /* JADX WARN: Code duplicated, block: B:46:0x0300  */
    /* JADX WARN: Code duplicated, block: B:47:0x0306  */
    /* JADX WARN: Code duplicated, block: B:58:0x044b  */
    /* JADX WARN: Code duplicated, block: B:59:0x0461  */
    /* JADX WARN: Code duplicated, block: B:70:0x0567  */
    /* JADX WARN: Code duplicated, block: B:71:0x056e  */
    /* JADX WARN: Code duplicated, block: B:73:0x0575  */
    /* JADX WARN: Code duplicated, block: B:74:0x0581  */
    /* JADX WARN: Code duplicated, block: B:77:0x0629  */
    /* JADX WARN: Code duplicated, block: B:80:0x0635  */
    /* JADX WARN: Code duplicated, block: B:81:0x063b  */
    /* JADX WARN: Code duplicated, block: B:92:0x07bc  */
    static final Unit OverlayControlScreen$lambda$96$lambda$37(final State $apiUsage$delegate, ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        int i;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function1;
        Composer composerM3652constructorimpl;
        int currentCompositeKeyHash2;
        Function0<ComposeUiNode> constructor2;
        Function0<ComposeUiNode> function2;
        Composer composerM3652constructorimpl2;
        long jM4157copywmQWz5c;
        final float fCoerceIn;
        boolean zChanged;
        Object obj;
        long jColor;
        int currentCompositeKeyHash3;
        Function0<ComposeUiNode> constructor3;
        Function0<ComposeUiNode> function3;
        Composer composerM3652constructorimpl3;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C226@9031L2648:OverlayControlScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1555061092, $changed, -1, "com.example.ui.OverlayControlScreen.<anonymous>.<anonymous> (OverlayControlScreen.kt:226)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor4 = ComposeUiNode.INSTANCE.getConstructor();
            int i2 = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor4;
                $composer.createNode(function0);
            } else {
                function0 = constructor4;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl4 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl4.getInserting()) {
                i = 6;
            } else {
                i = 6;
                if (!Intrinsics.areEqual(composerM3652constructorimpl4.rememberedValue(), Integer.valueOf(currentCompositeKeyHash4))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i3 = (i2 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i4 = ((i >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, 1652679406, "C227@9084L1301,261@10395L41,265@10608L20,275@10985L11,264@10562L459,278@11031L40,280@11081L590:OverlayControlScreen.kt#naom5h");
                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
                CompositionLocalMap currentCompositionLocalMap2 = $composer.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i5 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!($composer.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                $composer.startReusableNode();
                if ($composer.getInserting()) {
                    function1 = constructor;
                    $composer.createNode(function1);
                } else {
                    function1 = constructor;
                    $composer.useNode();
                }
                composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
                Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                    composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash2);
                }
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i6 = (i5 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                int i7 = ((438 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, -1532029480, "C232@9274L505,250@9991L384,247@9791L584:OverlayControlScreen.kt#naom5h");
                Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                Modifier modifier = Modifier.INSTANCE;
                MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically2, $composer, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
                CompositionLocalMap currentCompositionLocalMap3 = $composer.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier($composer, modifier);
                constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                int i8 = ((((384 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!($composer.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                $composer.startReusableNode();
                if ($composer.getInserting()) {
                    function2 = constructor2;
                    $composer.createNode(function2);
                } else {
                    function2 = constructor2;
                    $composer.useNode();
                }
                composerM3652constructorimpl2 = Updater.m3652constructorimpl($composer);
                Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                    composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                    composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash3);
                }
                Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i9 = (i8 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                int i10 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, 1623890454, "C233@9340L194,239@9547L39,242@9688L10,240@9599L168:OverlayControlScreen.kt#naom5h");
                IconKt.m2150Iconww6aTOc(CloudQueueKt.getCloudQueue(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), com.example.ui.theme.ColorKt.getIndigoLight(), $composer, 3504, 0);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), $composer, 6);
                TextKt.m2693Text4IGK_g("API Limit Gemini Flash", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleSmall(), $composer, 196614, 0, 65502);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                if (OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getRemainingToday() > 100) {
                    long emeraldSuccess = com.example.ui.theme.ColorKt.getEmeraldSuccess();
                    jM4157copywmQWz5c = Color.m4157copywmQWz5c(emeraldSuccess, (14 & 1) != 0 ? Color.m4161getAlphaimpl(emeraldSuccess) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(emeraldSuccess) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(emeraldSuccess) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(emeraldSuccess) : 0.0f);
                } else {
                    long jColor2 = ColorKt.Color(4292617766L);
                    jM4157copywmQWz5c = Color.m4157copywmQWz5c(jColor2, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jColor2) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jColor2) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jColor2) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jColor2) : 0.0f);
                }
                SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8)), jM4157copywmQWz5c, 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(-1652469351, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda26
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj2, Object obj3) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$37$lambda$36$lambda$32$lambda$31($apiUsage$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, $composer, 54), $composer, 12582912, 121);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), $composer, 6);
                fCoerceIn = RangesKt.coerceIn(OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getRemainingToday() / OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getDailyLimit(), 0.0f, 1.0f);
                ComposerKt.sourceInformationMarkerStart($composer, -1886304210, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChanged = $composer.changed(fCoerceIn);
                Object objRememberedValue = $composer.rememberedValue();
                if (!zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    obj = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda27
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return Float.valueOf(OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$37$lambda$36$lambda$34$lambda$33(fCoerceIn));
                        }
                    };
                    $composer.updateRememberedValue(obj);
                } else {
                    obj = objRememberedValue;
                }
                Function0 function4 = (Function0) obj;
                ComposerKt.sourceInformationMarkerEnd($composer);
                Modifier modifierClip = ClipKt.clip(SizeKt.m701height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(8)), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(4)));
                if (fCoerceIn > 0.35f) {
                    jColor = com.example.ui.theme.ColorKt.getEmeraldSuccess();
                } else if (fCoerceIn > 0.15f) {
                    jColor = ColorKt.Color(4294286859L);
                } else {
                    jColor = ColorKt.Color(4292617766L);
                }
                ProgressIndicatorKt.m2371LinearProgressIndicatorGJbTh5U(function4, modifierClip, jColor, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getSurfaceVariant(), 0, 0.0f, null, $composer, 0, 112);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), $composer, 6);
                Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween2 = Arrangement.INSTANCE.getSpaceBetween();
                ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy3 = RowKt.rowMeasurePolicy(spaceBetween2, Alignment.INSTANCE.getTop(), $composer, ((54 >> 3) & 14) | ((54 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
                CompositionLocalMap currentCompositionLocalMap4 = $composer.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default2);
                constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                int i11 = ((((54 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!($composer.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                $composer.startReusableNode();
                if ($composer.getInserting()) {
                    function3 = constructor3;
                    $composer.createNode(function3);
                } else {
                    function3 = constructor3;
                    $composer.useNode();
                }
                composerM3652constructorimpl3 = Updater.m3652constructorimpl($composer);
                Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl3.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                    composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                    composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash4);
                }
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                int i12 = (i11 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance3 = RowScopeInstance.INSTANCE;
                int i13 = ((54 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, 1173658414, "C286@11318L10,287@11374L11,284@11213L201,291@11565L10,292@11621L11,289@11425L236:OverlayControlScreen.kt#naom5h");
                TextKt.m2693Text4IGK_g("Dnes využito: " + OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getUsedToday() + " volání", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodySmall(), $composer, 0, 0, 65530);
                TextKt.m2693Text4IGK_g("Minutový limit: " + OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getRemainingThisMinute() + " / " + OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getMinuteLimit() + " RPM", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodySmall(), $composer, 0, 0, 65530);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
            composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash);
            Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i14 = (i2 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
            int i15 = ((i >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, 1652679406, "C227@9084L1301,261@10395L41,265@10608L20,275@10985L11,264@10562L459,278@11031L40,280@11081L590:OverlayControlScreen.kt#naom5h");
            Modifier modifierFillMaxWidth$default3 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween3 = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically3 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy4 = RowKt.rowMeasurePolicy(spaceBetween3, centerVertically3, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap5 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default3);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i16 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function1 = constructor;
                $composer.createNode(function1);
            } else {
                function1 = constructor;
                $composer.useNode();
            }
            composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl.getInserting()) {
            }
            composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash5);
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
            int i17 = (i16 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance4 = RowScopeInstance.INSTANCE;
            int i18 = ((438 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -1532029480, "C232@9274L505,250@9991L384,247@9791L584:OverlayControlScreen.kt#naom5h");
            Alignment.Vertical centerVertically4 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            Modifier modifier2 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy5 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically4, $composer, ((384 >> 3) & 14) | ((384 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap6 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier6 = ComposedModifierKt.materializeModifier($composer, modifier2);
            constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i19 = ((((384 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function2 = constructor2;
                $composer.createNode(function2);
            } else {
                function2 = constructor2;
                $composer.useNode();
            }
            composerM3652constructorimpl2 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy5, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap6, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash6 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl2.getInserting()) {
            }
            composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash6);
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier6, ComposeUiNode.INSTANCE.getSetModifier());
            int i20 = (i19 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance5 = RowScopeInstance.INSTANCE;
            int i110 = ((384 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, 1623890454, "C233@9340L194,239@9547L39,242@9688L10,240@9599L168:OverlayControlScreen.kt#naom5h");
            IconKt.m2150Iconww6aTOc(CloudQueueKt.getCloudQueue(Icons.INSTANCE.getDefault()), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), com.example.ui.theme.ColorKt.getIndigoLight(), $composer, 3504, 0);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), $composer, 6);
            TextKt.m2693Text4IGK_g("API Limit Gemini Flash", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleSmall(), $composer, 196614, 0, 65502);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getRemainingToday() > 100) {
                long emeraldSuccess2 = com.example.ui.theme.ColorKt.getEmeraldSuccess();
                jM4157copywmQWz5c = Color.m4157copywmQWz5c(emeraldSuccess2, (14 & 1) != 0 ? Color.m4161getAlphaimpl(emeraldSuccess2) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(emeraldSuccess2) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(emeraldSuccess2) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(emeraldSuccess2) : 0.0f);
            } else {
                long jColor3 = ColorKt.Color(4292617766L);
                jM4157copywmQWz5c = Color.m4157copywmQWz5c(jColor3, (14 & 1) != 0 ? Color.m4161getAlphaimpl(jColor3) : 0.15f, (14 & 2) != 0 ? Color.m4165getRedimpl(jColor3) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(jColor3) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(jColor3) : 0.0f);
            }
            SurfaceKt.m2543SurfaceT9BRK9s(null, RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8)), jM4157copywmQWz5c, 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(-1652469351, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda26
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$37$lambda$36$lambda$32$lambda$31($apiUsage$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, $composer, 54), $composer, 12582912, 121);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), $composer, 6);
            fCoerceIn = RangesKt.coerceIn(OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getRemainingToday() / OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getDailyLimit(), 0.0f, 1.0f);
            ComposerKt.sourceInformationMarkerStart($composer, -1886304210, "CC(remember):OverlayControlScreen.kt#9igjgp");
            zChanged = $composer.changed(fCoerceIn);
            Object objRememberedValue2 = $composer.rememberedValue();
            if (zChanged) {
            }
            obj = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda27
                @Override // kotlin.jvm.functions.Function0
                public final Object invoke() {
                    return Float.valueOf(OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$37$lambda$36$lambda$34$lambda$33(fCoerceIn));
                }
            };
            $composer.updateRememberedValue(obj);
            Function0 function5 = (Function0) obj;
            ComposerKt.sourceInformationMarkerEnd($composer);
            Modifier modifierClip2 = ClipKt.clip(SizeKt.m701height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(8)), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(4)));
            if (fCoerceIn > 0.35f) {
                jColor = com.example.ui.theme.ColorKt.getEmeraldSuccess();
            } else if (fCoerceIn > 0.15f) {
                jColor = ColorKt.Color(4294286859L);
            } else {
                jColor = ColorKt.Color(4292617766L);
            }
            ProgressIndicatorKt.m2371LinearProgressIndicatorGJbTh5U(function5, modifierClip2, jColor, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getSurfaceVariant(), 0, 0.0f, null, $composer, 0, 112);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(8)), $composer, 6);
            Modifier modifierFillMaxWidth$default4 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween4 = Arrangement.INSTANCE.getSpaceBetween();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy6 = RowKt.rowMeasurePolicy(spaceBetween4, Alignment.INSTANCE.getTop(), $composer, ((54 >> 3) & 14) | ((54 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap7 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier7 = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default4);
            constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            int i111 = ((((54 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function3 = constructor3;
                $composer.createNode(function3);
            } else {
                function3 = constructor3;
                $composer.useNode();
            }
            composerM3652constructorimpl3 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy6, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap7, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash7 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl3.getInserting()) {
            }
            composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
            composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash7);
            Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier7, ComposeUiNode.INSTANCE.getSetModifier());
            int i112 = (i111 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance6 = RowScopeInstance.INSTANCE;
            int i113 = ((54 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, 1173658414, "C286@11318L10,287@11374L11,284@11213L201,291@11565L10,292@11621L11,289@11425L236:OverlayControlScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g("Dnes využito: " + OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getUsedToday() + " volání", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodySmall(), $composer, 0, 0, 65530);
            TextKt.m2693Text4IGK_g("Minutový limit: " + OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getRemainingThisMinute() + " / " + OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getMinuteLimit() + " RPM", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodySmall(), $composer, 0, 0, 65530);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$37$lambda$36$lambda$32$lambda$31(State $apiUsage$delegate, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C251@10005L358:OverlayControlScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1652469351, $changed, -1, "com.example.ui.OverlayControlScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (OverlayControlScreen.kt:251)");
            }
            TextKt.m2693Text4IGK_g(OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getRemainingToday() + " / " + OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getDailyLimit() + " zbývá dnes", PaddingKt.m671paddingVpY3zN4(Modifier.INSTANCE, Dp.m6622constructorimpl(8), Dp.m6622constructorimpl(4)), OverlayControlScreen$lambda$96$lambda$29($apiUsage$delegate).getRemainingToday() > 100 ? com.example.ui.theme.ColorKt.getEmeraldSuccess() : ColorKt.Color(4292617766L), TextUnitKt.getSp(11.5d), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 199728, 0, 131024);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final float OverlayControlScreen$lambda$96$lambda$37$lambda$36$lambda$34$lambda$33(float $progressFraction) {
        return $progressFraction;
    }

    /* JADX WARN: Code duplicated, block: B:100:0x0766  */
    /* JADX WARN: Code duplicated, block: B:101:0x076c  */
    /* JADX WARN: Code duplicated, block: B:112:0x08b5  */
    /* JADX WARN: Code duplicated, block: B:115:0x08c1  */
    /* JADX WARN: Code duplicated, block: B:116:0x08c7  */
    /* JADX WARN: Code duplicated, block: B:127:0x0a0b  */
    /* JADX WARN: Code duplicated, block: B:28:0x0230  */
    /* JADX WARN: Code duplicated, block: B:31:0x023c  */
    /* JADX WARN: Code duplicated, block: B:32:0x0242  */
    /* JADX WARN: Code duplicated, block: B:43:0x0352  */
    /* JADX WARN: Code duplicated, block: B:46:0x035e  */
    /* JADX WARN: Code duplicated, block: B:47:0x0364  */
    /* JADX WARN: Code duplicated, block: B:58:0x0402  */
    /* JADX WARN: Code duplicated, block: B:59:0x040d  */
    /* JADX WARN: Code duplicated, block: B:62:0x041f  */
    /* JADX WARN: Code duplicated, block: B:63:0x0424  */
    /* JADX WARN: Code duplicated, block: B:66:0x04db  */
    /* JADX WARN: Code duplicated, block: B:69:0x04e7  */
    /* JADX WARN: Code duplicated, block: B:70:0x04ed  */
    /* JADX WARN: Code duplicated, block: B:81:0x05c9  */
    /* JADX WARN: Code duplicated, block: B:82:0x05cc  */
    /* JADX WARN: Code duplicated, block: B:85:0x0647  */
    /* JADX WARN: Code duplicated, block: B:94:0x06b5  */
    /* JADX WARN: Code duplicated, block: B:97:0x075a  */
    static final Unit OverlayControlScreen$lambda$96$lambda$46(final Context $context, MutableState $hasOverlayPermission$delegate, ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        int i;
        Composer composer;
        Composer composer2;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function1;
        Composer composerM3652constructorimpl;
        int currentCompositeKeyHash2;
        Function0<ComposeUiNode> constructor2;
        Function0<ComposeUiNode> function2;
        Composer composerM3652constructorimpl2;
        ImageVector warning;
        long jColor;
        int currentCompositeKeyHash3;
        Function0<ComposeUiNode> constructor3;
        Function0<ComposeUiNode> function3;
        Composer composerM3652constructorimpl3;
        String str;
        int currentCompositeKeyHash4;
        Function0<ComposeUiNode> constructor4;
        Function0<ComposeUiNode> function4;
        Composer composerM3652constructorimpl4;
        int currentCompositeKeyHash5;
        Function0<ComposeUiNode> constructor5;
        Function0<ComposeUiNode> function5;
        Composer composerM3652constructorimpl5;
        boolean zChangedInstance;
        Object obj;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C307@12011L2880:OverlayControlScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(2133827237, $changed, -1, "com.example.ui.OverlayControlScreen.<anonymous>.<anonymous> (OverlayControlScreen.kt:307)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash6 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor6 = ComposeUiNode.INSTANCE.getConstructor();
            int i2 = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor6;
                $composer.createNode(function0);
            } else {
                function0 = constructor6;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl6 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl6, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl6, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl6.getInserting()) {
                i = 6;
                composer = $composer;
            } else {
                i = 6;
                composer = $composer;
                if (!Intrinsics.areEqual(composerM3652constructorimpl6.rememberedValue(), Integer.valueOf(currentCompositeKeyHash6))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl6, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i3 = (i2 >> 6) & 14;
                composer2 = composer;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i4 = ((i >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -618781147, "C310@12145L10,308@12064L152,313@12225L41,316@12309L1639,359@13958L41,362@14038L845:OverlayControlScreen.kt#naom5h");
                TextKt.m2693Text4IGK_g("Stav oprávnění systému", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleSmall(), composer2, 196614, 0, 65502);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer2, 6);
                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap2 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i5 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function1 = constructor;
                    composer2.createNode(function1);
                } else {
                    function1 = constructor;
                    composer2.useNode();
                }
                composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                    composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash2);
                }
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i6 = (i5 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                int i7 = ((438 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 491480549, "C321@12499L937:OverlayControlScreen.kt#naom5h");
                Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                Modifier modifier = Modifier.INSTANCE;
                MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically2, composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composer2, modifier);
                constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                int i8 = ((((384 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function2 = constructor2;
                    composer2.createNode(function2);
                } else {
                    function2 = constructor2;
                    composer2.useNode();
                }
                composerM3652constructorimpl2 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                    composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                    composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash3);
                }
                Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i9 = (i8 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                int i10 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -647563899, "C322@12565L300,328@12878L40,329@12931L493:OverlayControlScreen.kt#naom5h");
                if (OverlayControlScreen$lambda$1($hasOverlayPermission$delegate)) {
                    warning = CheckCircleKt.getCheckCircle(Icons.INSTANCE.getDefault());
                } else {
                    warning = WarningKt.getWarning(Icons.INSTANCE.getDefault());
                }
                ImageVector imageVector = warning;
                if (OverlayControlScreen$lambda$1($hasOverlayPermission$delegate)) {
                    jColor = com.example.ui.theme.ColorKt.getEmeraldSuccess();
                } else {
                    jColor = ColorKt.Color(4294286859L);
                }
                IconKt.m2150Iconww6aTOc(imageVector, (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), jColor, composer2, 432, 0);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer2, 6);
                ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                Modifier modifier2 = Modifier.INSTANCE;
                MeasurePolicy measurePolicyColumnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap4 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier(composer2, modifier2);
                constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                int i11 = ((((0 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function3 = constructor3;
                    composer2.createNode(function3);
                } else {
                    function3 = constructor3;
                    composer2.useNode();
                }
                composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyColumnMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl3.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                    composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                    composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash4);
                }
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                int i12 = (i11 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
                int i13 = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 45834050, "C332@13056L10,330@12954L189,337@13306L10,338@13366L11,335@13158L252:OverlayControlScreen.kt#naom5h");
                TextKt.m2693Text4IGK_g("Zobrazení přes ostatní aplikace", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, 196614, 0, 65502);
                if (OverlayControlScreen$lambda$1($hasOverlayPermission$delegate)) {
                    str = "Povoleno v systému";
                } else {
                    str = "Nutné povolit v nastavení";
                }
                TextKt.m2693Text4IGK_g(str, (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 0, 0, 65530);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                if (OverlayControlScreen$lambda$1($hasOverlayPermission$delegate)) {
                    composer2.startReplaceGroup(479035939);
                } else {
                    composer2.startReplaceGroup(492418484);
                    ComposerKt.sourceInformation(composer2, "345@13529L241,344@13489L437");
                    ComposerKt.sourceInformationMarkerStart(composer2, -1231040016, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance = composer2.changedInstance($context);
                    Object objRememberedValue = composer2.rememberedValue();
                    if (!zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                        obj = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda28
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$46$lambda$45$lambda$42$lambda$41$lambda$40($context);
                            }
                        };
                        composer2.updateRememberedValue(obj);
                    } else {
                        obj = objRememberedValue;
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ButtonKt.OutlinedButton((Function0) obj, TestTagKt.testTag(Modifier.INSTANCE, "grant_overlay_permission_button"), false, null, null, null, null, null, null, ComposableSingletons$OverlayControlScreenKt.INSTANCE.m6941getLambda$568597236$app(), composer2, 805306416, 508);
                }
                composer2.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer2, 6);
                Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Alignment.Vertical centerVertically3 = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy3 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically3, composer2, ((390 >> 3) & 14) | ((390 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap5 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default2);
                constructor4 = ComposeUiNode.INSTANCE.getConstructor();
                int i14 = ((((390 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function4 = constructor4;
                    composer2.createNode(function4);
                } else {
                    function4 = constructor4;
                    composer2.useNode();
                }
                composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyRowMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl4.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl4.rememberedValue(), Integer.valueOf(currentCompositeKeyHash4))) {
                    composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
                    composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash5);
                }
                Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
                int i15 = (i14 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance3 = RowScopeInstance.INSTANCE;
                int i16 = ((390 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -1097801364, "C366@14168L197,372@14376L40,373@14427L446:OverlayControlScreen.kt#naom5h");
                IconKt.m2150Iconww6aTOc(ScreenShareKt.getScreenShare(Icons.AutoMirrored.Filled.INSTANCE), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), com.example.ui.theme.ColorKt.getIndigoLight(), composer2, 3504, 0);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer2, 6);
                ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                Modifier modifier3 = Modifier.INSTANCE;
                MeasurePolicy measurePolicyColumnMeasurePolicy3 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap6 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier6 = ComposedModifierKt.materializeModifier(composer2, modifier3);
                constructor5 = ComposeUiNode.INSTANCE.getConstructor();
                int i17 = ((((0 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function5 = constructor5;
                    composer2.createNode(function5);
                } else {
                    function5 = constructor5;
                    composer2.useNode();
                }
                composerM3652constructorimpl5 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl5, measurePolicyColumnMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl5, currentCompositionLocalMap6, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash6 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl5.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl5.rememberedValue(), Integer.valueOf(currentCompositeKeyHash5))) {
                    composerM3652constructorimpl5.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash5));
                    composerM3652constructorimpl5.apply(Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash6);
                }
                Updater.m3659setimpl(composerM3652constructorimpl5, modifierMaterializeModifier6, ComposeUiNode.INSTANCE.getSetModifier());
                int i18 = (i17 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance3 = ColumnScopeInstance.INSTANCE;
                int i19 = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 986537882, "C376@14550L10,374@14448L185,381@14761L10,382@14819L11,379@14646L215:OverlayControlScreen.kt#naom5h");
                TextKt.m2693Text4IGK_g("Snímání obrazovky (MediaProjection)", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, 196614, 0, 65502);
                TextKt.m2693Text4IGK_g("Dotaz se zobrazí automaticky při spuštění služby", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composerM3652constructorimpl6.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash6));
            composerM3652constructorimpl6.apply(Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash);
            Updater.m3659setimpl(composerM3652constructorimpl6, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i20 = (i2 >> 6) & 14;
            composer2 = composer;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance4 = ColumnScopeInstance.INSTANCE;
            int i21 = ((i >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -618781147, "C310@12145L10,308@12064L152,313@12225L41,316@12309L1639,359@13958L41,362@14038L845:OverlayControlScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g("Stav oprávnění systému", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleSmall(), composer2, 196614, 0, 65502);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer2, 6);
            Modifier modifierFillMaxWidth$default3 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Alignment.Vertical centerVertically4 = Alignment.INSTANCE.getCenterVertically();
            Arrangement.Horizontal spaceBetween2 = Arrangement.INSTANCE.getSpaceBetween();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy4 = RowKt.rowMeasurePolicy(spaceBetween2, centerVertically4, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap7 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier7 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default3);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i22 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function1 = constructor;
                composer2.createNode(function1);
            } else {
                function1 = constructor;
                composer2.useNode();
            }
            composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap7, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash7 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl.getInserting()) {
            }
            composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash7);
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier7, ComposeUiNode.INSTANCE.getSetModifier());
            int i23 = (i22 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance4 = RowScopeInstance.INSTANCE;
            int i24 = ((438 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 491480549, "C321@12499L937:OverlayControlScreen.kt#naom5h");
            Alignment.Vertical centerVertically5 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            Modifier modifier4 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy5 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically5, composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap8 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier8 = ComposedModifierKt.materializeModifier(composer2, modifier4);
            constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i25 = ((((384 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function2 = constructor2;
                composer2.createNode(function2);
            } else {
                function2 = constructor2;
                composer2.useNode();
            }
            composerM3652constructorimpl2 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy5, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap8, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash8 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl2.getInserting()) {
            }
            composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash8);
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier8, ComposeUiNode.INSTANCE.getSetModifier());
            int i26 = (i25 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance5 = RowScopeInstance.INSTANCE;
            int i110 = ((384 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -647563899, "C322@12565L300,328@12878L40,329@12931L493:OverlayControlScreen.kt#naom5h");
            if (OverlayControlScreen$lambda$1($hasOverlayPermission$delegate)) {
                warning = CheckCircleKt.getCheckCircle(Icons.INSTANCE.getDefault());
            } else {
                warning = WarningKt.getWarning(Icons.INSTANCE.getDefault());
            }
            ImageVector imageVector2 = warning;
            if (OverlayControlScreen$lambda$1($hasOverlayPermission$delegate)) {
                jColor = com.example.ui.theme.ColorKt.getEmeraldSuccess();
            } else {
                jColor = ColorKt.Color(4294286859L);
            }
            IconKt.m2150Iconww6aTOc(imageVector2, (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), jColor, composer2, 432, 0);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer2, 6);
            ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            Modifier modifier5 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyColumnMeasurePolicy4 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap9 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier9 = ComposedModifierKt.materializeModifier(composer2, modifier5);
            constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            int i111 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function3 = constructor3;
                composer2.createNode(function3);
            } else {
                function3 = constructor3;
                composer2.useNode();
            }
            composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyColumnMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap9, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash9 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl3.getInserting()) {
            }
            composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
            composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash9);
            Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier9, ComposeUiNode.INSTANCE.getSetModifier());
            int i112 = (i111 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance5 = ColumnScopeInstance.INSTANCE;
            int i113 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 45834050, "C332@13056L10,330@12954L189,337@13306L10,338@13366L11,335@13158L252:OverlayControlScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g("Zobrazení přes ostatní aplikace", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, 196614, 0, 65502);
            if (OverlayControlScreen$lambda$1($hasOverlayPermission$delegate)) {
                str = "Povoleno v systému";
            } else {
                str = "Nutné povolit v nastavení";
            }
            TextKt.m2693Text4IGK_g(str, (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 0, 0, 65530);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            if (OverlayControlScreen$lambda$1($hasOverlayPermission$delegate)) {
                composer2.startReplaceGroup(492418484);
                ComposerKt.sourceInformation(composer2, "345@13529L241,344@13489L437");
                ComposerKt.sourceInformationMarkerStart(composer2, -1231040016, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance = composer2.changedInstance($context);
                Object objRememberedValue2 = composer2.rememberedValue();
                if (zChangedInstance) {
                }
                obj = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda28
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$46$lambda$45$lambda$42$lambda$41$lambda$40($context);
                    }
                };
                composer2.updateRememberedValue(obj);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ButtonKt.OutlinedButton((Function0) obj, TestTagKt.testTag(Modifier.INSTANCE, "grant_overlay_permission_button"), false, null, null, null, null, null, null, ComposableSingletons$OverlayControlScreenKt.INSTANCE.m6941getLambda$568597236$app(), composer2, 805306416, 508);
            } else {
                composer2.startReplaceGroup(479035939);
            }
            composer2.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer2, 6);
            Modifier modifierFillMaxWidth$default4 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Alignment.Vertical centerVertically6 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy6 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically6, composer2, ((390 >> 3) & 14) | ((390 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap10 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier10 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default4);
            constructor4 = ComposeUiNode.INSTANCE.getConstructor();
            int i114 = ((((390 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function4 = constructor4;
                composer2.createNode(function4);
            } else {
                function4 = constructor4;
                composer2.useNode();
            }
            composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyRowMeasurePolicy6, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap10, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash10 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl4.getInserting()) {
            }
            composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
            composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash10);
            Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier10, ComposeUiNode.INSTANCE.getSetModifier());
            int i115 = (i114 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance6 = RowScopeInstance.INSTANCE;
            int i116 = ((390 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -1097801364, "C366@14168L197,372@14376L40,373@14427L446:OverlayControlScreen.kt#naom5h");
            IconKt.m2150Iconww6aTOc(ScreenShareKt.getScreenShare(Icons.AutoMirrored.Filled.INSTANCE), (String) null, SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(20)), com.example.ui.theme.ColorKt.getIndigoLight(), composer2, 3504, 0);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer2, 6);
            ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            Modifier modifier6 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyColumnMeasurePolicy5 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap11 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier11 = ComposedModifierKt.materializeModifier(composer2, modifier6);
            constructor5 = ComposeUiNode.INSTANCE.getConstructor();
            int i117 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function5 = constructor5;
                composer2.createNode(function5);
            } else {
                function5 = constructor5;
                composer2.useNode();
            }
            composerM3652constructorimpl5 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl5, measurePolicyColumnMeasurePolicy5, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl5, currentCompositionLocalMap11, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash11 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl5.getInserting()) {
            }
            composerM3652constructorimpl5.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash5));
            composerM3652constructorimpl5.apply(Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash11);
            Updater.m3659setimpl(composerM3652constructorimpl5, modifierMaterializeModifier11, ComposeUiNode.INSTANCE.getSetModifier());
            int i118 = (i117 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance6 = ColumnScopeInstance.INSTANCE;
            int i119 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 986537882, "C376@14550L10,374@14448L185,381@14761L10,382@14819L11,379@14646L215:OverlayControlScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g("Snímání obrazovky (MediaProjection)", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getSemiBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, 196614, 0, 65502);
            TextKt.m2693Text4IGK_g("Dotaz se zobrazí automaticky při spuštění služby", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$46$lambda$45$lambda$42$lambda$41$lambda$40(Context $context) {
        Intent intent = new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + $context.getPackageName()));
        $context.startActivity(intent);
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$58(final AppPreferences $preferences, final MutableState $currentPosition$delegate, ColumnScope Card, Composer $composer, int $changed) {
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C398@15223L2930:OverlayControlScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1582373914, $changed, -1, "com.example.ui.OverlayControlScreen.<anonymous>.<anonymous> (OverlayControlScreen.kt:398)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                $composer.createNode(constructor);
            } else {
                $composer.useNode();
            }
            Composer composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            }
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i2 = (i >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
            int i3 = ((6 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, 1404719954, "C401@15359L10,399@15276L154,406@15553L10,407@15607L11,404@15439L206,410@15655L41,414@15783L11,420@16009L2136,413@15742L2403:OverlayControlScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g("Umístění tlačítka v rohu", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleSmall(), $composer, 196614, 0, 65502);
            TextKt.m2693Text4IGK_g("Vyberte roh obrazovky, kde se má zobrazit ovládací bod.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodySmall(), $composer, 6, 0, 65530);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14)), $composer, 6);
            long surfaceVariant = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getSurfaceVariant();
            SurfaceKt.m2543SurfaceT9BRK9s(PaddingKt.m672paddingVpY3zN4$default(SizeKt.m701height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m6622constructorimpl(130)), 0.0f, Dp.m6622constructorimpl(4), 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(14)), Color.m4157copywmQWz5c(surfaceVariant, (14 & 1) != 0 ? Color.m4161getAlphaimpl(surfaceVariant) : 0.4f, (14 & 2) != 0 ? Color.m4165getRedimpl(surfaceVariant) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(surfaceVariant) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(surfaceVariant) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(1672617207, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda29
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj, Object obj2) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56($preferences, $currentPosition$delegate, (Composer) obj, ((Integer) obj2).intValue());
                }
            }, $composer, 54), $composer, 12582918, 120);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:28:0x013d  */
    /* JADX WARN: Code duplicated, block: B:29:0x0140  */
    /* JADX WARN: Code duplicated, block: B:32:0x017a  */
    /* JADX WARN: Code duplicated, block: B:35:0x0185  */
    /* JADX WARN: Code duplicated, block: B:36:0x0188  */
    /* JADX WARN: Code duplicated, block: B:40:0x01b6  */
    /* JADX WARN: Code duplicated, block: B:41:0x01b9  */
    /* JADX WARN: Code duplicated, block: B:44:0x01f0  */
    /* JADX WARN: Code duplicated, block: B:47:0x01fb  */
    /* JADX WARN: Code duplicated, block: B:48:0x01fe  */
    /* JADX WARN: Code duplicated, block: B:52:0x028d  */
    /* JADX WARN: Code duplicated, block: B:53:0x0290  */
    /* JADX WARN: Code duplicated, block: B:56:0x02c6  */
    /* JADX WARN: Code duplicated, block: B:59:0x02d1  */
    /* JADX WARN: Code duplicated, block: B:60:0x02d4  */
    /* JADX WARN: Code duplicated, block: B:64:0x0302  */
    /* JADX WARN: Code duplicated, block: B:65:0x0305  */
    /* JADX WARN: Code duplicated, block: B:68:0x0338  */
    /* JADX WARN: Code duplicated, block: B:72:0x0345 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:76:0x0384  */
    static final Unit OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56(final AppPreferences $preferences, final MutableState $currentPosition$delegate, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        int i;
        boolean z;
        boolean zChangedInstance;
        Object objRememberedValue;
        Composer composer;
        Composer composer2;
        boolean z2;
        boolean zChangedInstance2;
        Object objRememberedValue2;
        Composer composer3;
        Composer composer4;
        boolean z3;
        boolean zChangedInstance3;
        Object objRememberedValue3;
        Composer composer5;
        boolean z4;
        boolean zChangedInstance4;
        Object obj;
        ComposerKt.sourceInformation($composer, "C421@16021L2114:OverlayControlScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1672617207, $changed, -1, "com.example.ui.OverlayControlScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (OverlayControlScreen.kt:421)");
            }
            Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
            ComposerKt.sourceInformationMarkerStart($composer, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.INSTANCE.getTopStart(), false);
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierFillMaxSize$default);
            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i2 = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor;
                $composer.createNode(function0);
            } else {
                function0 = constructor;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl.getInserting()) {
                i = 6;
            } else {
                i = 6;
                if (!Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i3 = (i2 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                int i4 = ((i >> 6) & 112) | 6;
                BoxScope boxScope = BoxScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart($composer, -1272791767, "C429@16372L102,423@16098L390,442@16811L102,436@16537L390,451@17064L10,452@17122L11,449@16981L261,463@17566L102,457@17283L399,476@18007L102,470@17724L399:OverlayControlScreen.kt#naom5h");
                CornerPosition cornerPosition = CornerPosition.TOP_LEFT;
                if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.TOP_LEFT) {
                    z = true;
                } else {
                    z = false;
                }
                Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getTopStart()), Dp.m6622constructorimpl(10));
                ComposerKt.sourceInformationMarkerStart($composer, 1067327703, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance = $composer.changedInstance($preferences);
                objRememberedValue = $composer.rememberedValue();
                if (zChangedInstance) {
                    composer = $composer;
                } else {
                    composer = $composer;
                    if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    composer2 = composer;
                    CornerPickerChip(cornerPosition, z, (Function1) objRememberedValue, modifierM670padding3ABfNKs, composer2, 6, 0);
                    CornerPosition cornerPosition2 = CornerPosition.TOP_RIGHT;
                    if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.TOP_RIGHT) {
                        z2 = true;
                    } else {
                        z2 = false;
                    }
                    Modifier modifierM670padding3ABfNKs2 = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getTopEnd()), Dp.m6622constructorimpl(10));
                    ComposerKt.sourceInformationMarkerStart(composer2, 1067341751, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance2 = composer2.changedInstance($preferences);
                    objRememberedValue2 = composer2.rememberedValue();
                    if (zChangedInstance2) {
                        composer3 = composer2;
                    } else {
                        composer3 = composer2;
                        if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                        }
                        ComposerKt.sourceInformationMarkerEnd(composer3);
                        composer4 = composer3;
                        CornerPickerChip(cornerPosition2, z2, (Function1) objRememberedValue2, modifierM670padding3ABfNKs2, composer4, 6, 0);
                        TextStyle bodySmall = MaterialTheme.INSTANCE.getTypography(composer4, MaterialTheme.$stable).getBodySmall();
                        long onSurfaceVariant = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                        TextKt.m2693Text4IGK_g("Displej telefonu", boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getCenter()), Color.m4157copywmQWz5c(onSurfaceVariant, (14 & 1) != 0 ? Color.m4161getAlphaimpl(onSurfaceVariant) : 0.6f, (14 & 2) != 0 ? Color.m4165getRedimpl(onSurfaceVariant) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(onSurfaceVariant) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(onSurfaceVariant) : 0.0f), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, bodySmall, composer4, 6, 0, 65528);
                        CornerPosition cornerPosition3 = CornerPosition.BOTTOM_LEFT;
                        if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_LEFT) {
                            z3 = true;
                        } else {
                            z3 = false;
                        }
                        Modifier modifierM670padding3ABfNKs3 = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomStart()), Dp.m6622constructorimpl(10));
                        ComposerKt.sourceInformationMarkerStart(composer4, 1067365911, "CC(remember):OverlayControlScreen.kt#9igjgp");
                        zChangedInstance3 = composer4.changedInstance($preferences);
                        objRememberedValue3 = composer4.rememberedValue();
                        if (zChangedInstance3) {
                            composer5 = composer4;
                        } else {
                            composer5 = composer4;
                            if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                            }
                            ComposerKt.sourceInformationMarkerEnd(composer5);
                            Composer composer6 = composer5;
                            CornerPickerChip(cornerPosition3, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs3, composer6, 6, 0);
                            CornerPosition cornerPosition4 = CornerPosition.BOTTOM_RIGHT;
                            if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                                z4 = true;
                            } else {
                                z4 = false;
                            }
                            Modifier modifierM670padding3ABfNKs4 = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                            ComposerKt.sourceInformationMarkerStart(composer6, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                            zChangedInstance4 = composer6.changedInstance($preferences);
                            Object objRememberedValue4 = composer6.rememberedValue();
                            if (!zChangedInstance4 || objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                                obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                                    @Override // kotlin.jvm.functions.Function1
                                    public final Object invoke(Object obj2) {
                                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                                    }
                                };
                                composer6.updateRememberedValue(obj);
                            } else {
                                obj = objRememberedValue4;
                            }
                            ComposerKt.sourceInformationMarkerEnd(composer6);
                            CornerPickerChip(cornerPosition4, z4, (Function1) obj, modifierM670padding3ABfNKs4, composer6, 6, 0);
                            ComposerKt.sourceInformationMarkerEnd(composer6);
                            ComposerKt.sourceInformationMarkerEnd($composer);
                            $composer.endNode();
                            ComposerKt.sourceInformationMarkerEnd($composer);
                            ComposerKt.sourceInformationMarkerEnd($composer);
                            ComposerKt.sourceInformationMarkerEnd($composer);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        }
                        objRememberedValue3 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda3
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj2) {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$52$lambda$51($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                            }
                        };
                        composer4.updateRememberedValue(objRememberedValue3);
                        ComposerKt.sourceInformationMarkerEnd(composer5);
                        Composer composer7 = composer5;
                        CornerPickerChip(cornerPosition3, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs3, composer7, 6, 0);
                        CornerPosition cornerPosition5 = CornerPosition.BOTTOM_RIGHT;
                        if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                            z4 = true;
                        } else {
                            z4 = false;
                        }
                        Modifier modifierM670padding3ABfNKs5 = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                        ComposerKt.sourceInformationMarkerStart(composer7, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                        zChangedInstance4 = composer7.changedInstance($preferences);
                        Object objRememberedValue5 = composer7.rememberedValue();
                        if (zChangedInstance4) {
                        }
                        obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj2) {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                            }
                        };
                        composer7.updateRememberedValue(obj);
                        ComposerKt.sourceInformationMarkerEnd(composer7);
                        CornerPickerChip(cornerPosition5, z4, (Function1) obj, modifierM670padding3ABfNKs5, composer7, 6, 0);
                        ComposerKt.sourceInformationMarkerEnd(composer7);
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        $composer.endNode();
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
                    objRememberedValue2 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda2
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$50$lambda$49($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                        }
                    };
                    composer2.updateRememberedValue(objRememberedValue2);
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    composer4 = composer3;
                    CornerPickerChip(cornerPosition2, z2, (Function1) objRememberedValue2, modifierM670padding3ABfNKs2, composer4, 6, 0);
                    TextStyle bodySmall2 = MaterialTheme.INSTANCE.getTypography(composer4, MaterialTheme.$stable).getBodySmall();
                    long onSurfaceVariant2 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                    TextKt.m2693Text4IGK_g("Displej telefonu", boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getCenter()), Color.m4157copywmQWz5c(onSurfaceVariant2, (14 & 1) != 0 ? Color.m4161getAlphaimpl(onSurfaceVariant2) : 0.6f, (14 & 2) != 0 ? Color.m4165getRedimpl(onSurfaceVariant2) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(onSurfaceVariant2) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(onSurfaceVariant2) : 0.0f), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, bodySmall2, composer4, 6, 0, 65528);
                    CornerPosition cornerPosition6 = CornerPosition.BOTTOM_LEFT;
                    if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_LEFT) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                    Modifier modifierM670padding3ABfNKs6 = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomStart()), Dp.m6622constructorimpl(10));
                    ComposerKt.sourceInformationMarkerStart(composer4, 1067365911, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance3 = composer4.changedInstance($preferences);
                    objRememberedValue3 = composer4.rememberedValue();
                    if (zChangedInstance3) {
                        composer5 = composer4;
                        if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                        }
                        ComposerKt.sourceInformationMarkerEnd(composer5);
                        Composer composer8 = composer5;
                        CornerPickerChip(cornerPosition6, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs6, composer8, 6, 0);
                        CornerPosition cornerPosition7 = CornerPosition.BOTTOM_RIGHT;
                        if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                            z4 = true;
                        } else {
                            z4 = false;
                        }
                        Modifier modifierM670padding3ABfNKs7 = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                        ComposerKt.sourceInformationMarkerStart(composer8, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                        zChangedInstance4 = composer8.changedInstance($preferences);
                        Object objRememberedValue6 = composer8.rememberedValue();
                        if (zChangedInstance4) {
                        }
                        obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj2) {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                            }
                        };
                        composer8.updateRememberedValue(obj);
                        ComposerKt.sourceInformationMarkerEnd(composer8);
                        CornerPickerChip(cornerPosition7, z4, (Function1) obj, modifierM670padding3ABfNKs7, composer8, 6, 0);
                        ComposerKt.sourceInformationMarkerEnd(composer8);
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        $composer.endNode();
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        composer5 = composer4;
                    }
                    objRememberedValue3 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda3
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$52$lambda$51($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                        }
                    };
                    composer4.updateRememberedValue(objRememberedValue3);
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    Composer composer9 = composer5;
                    CornerPickerChip(cornerPosition6, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs6, composer9, 6, 0);
                    CornerPosition cornerPosition8 = CornerPosition.BOTTOM_RIGHT;
                    if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                        z4 = true;
                    } else {
                        z4 = false;
                    }
                    Modifier modifierM670padding3ABfNKs8 = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                    ComposerKt.sourceInformationMarkerStart(composer9, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance4 = composer9.changedInstance($preferences);
                    Object objRememberedValue7 = composer9.rememberedValue();
                    if (zChangedInstance4) {
                    }
                    obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                        }
                    };
                    composer9.updateRememberedValue(obj);
                    ComposerKt.sourceInformationMarkerEnd(composer9);
                    CornerPickerChip(cornerPosition8, z4, (Function1) obj, modifierM670padding3ABfNKs8, composer9, 6, 0);
                    ComposerKt.sourceInformationMarkerEnd(composer9);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    $composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                }
                objRememberedValue = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$48$lambda$47($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                    }
                };
                $composer.updateRememberedValue(objRememberedValue);
                ComposerKt.sourceInformationMarkerEnd(composer);
                composer2 = composer;
                CornerPickerChip(cornerPosition, z, (Function1) objRememberedValue, modifierM670padding3ABfNKs, composer2, 6, 0);
                CornerPosition cornerPosition9 = CornerPosition.TOP_RIGHT;
                if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.TOP_RIGHT) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                Modifier modifierM670padding3ABfNKs9 = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getTopEnd()), Dp.m6622constructorimpl(10));
                ComposerKt.sourceInformationMarkerStart(composer2, 1067341751, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance2 = composer2.changedInstance($preferences);
                objRememberedValue2 = composer2.rememberedValue();
                if (zChangedInstance2) {
                    composer3 = composer2;
                    if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    composer4 = composer3;
                    CornerPickerChip(cornerPosition9, z2, (Function1) objRememberedValue2, modifierM670padding3ABfNKs9, composer4, 6, 0);
                    TextStyle bodySmall3 = MaterialTheme.INSTANCE.getTypography(composer4, MaterialTheme.$stable).getBodySmall();
                    long onSurfaceVariant3 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                    TextKt.m2693Text4IGK_g("Displej telefonu", boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getCenter()), Color.m4157copywmQWz5c(onSurfaceVariant3, (14 & 1) != 0 ? Color.m4161getAlphaimpl(onSurfaceVariant3) : 0.6f, (14 & 2) != 0 ? Color.m4165getRedimpl(onSurfaceVariant3) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(onSurfaceVariant3) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(onSurfaceVariant3) : 0.0f), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, bodySmall3, composer4, 6, 0, 65528);
                    CornerPosition cornerPosition10 = CornerPosition.BOTTOM_LEFT;
                    if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_LEFT) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                    Modifier modifierM670padding3ABfNKs10 = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomStart()), Dp.m6622constructorimpl(10));
                    ComposerKt.sourceInformationMarkerStart(composer4, 1067365911, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance3 = composer4.changedInstance($preferences);
                    objRememberedValue3 = composer4.rememberedValue();
                    if (zChangedInstance3) {
                        composer5 = composer4;
                        if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                        }
                        ComposerKt.sourceInformationMarkerEnd(composer5);
                        Composer composer10 = composer5;
                        CornerPickerChip(cornerPosition10, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs10, composer10, 6, 0);
                        CornerPosition cornerPosition11 = CornerPosition.BOTTOM_RIGHT;
                        if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                            z4 = true;
                        } else {
                            z4 = false;
                        }
                        Modifier modifierM670padding3ABfNKs11 = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                        ComposerKt.sourceInformationMarkerStart(composer10, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                        zChangedInstance4 = composer10.changedInstance($preferences);
                        Object objRememberedValue8 = composer10.rememberedValue();
                        if (zChangedInstance4) {
                        }
                        obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj2) {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                            }
                        };
                        composer10.updateRememberedValue(obj);
                        ComposerKt.sourceInformationMarkerEnd(composer10);
                        CornerPickerChip(cornerPosition11, z4, (Function1) obj, modifierM670padding3ABfNKs11, composer10, 6, 0);
                        ComposerKt.sourceInformationMarkerEnd(composer10);
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        $composer.endNode();
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        composer5 = composer4;
                    }
                    objRememberedValue3 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda3
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$52$lambda$51($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                        }
                    };
                    composer4.updateRememberedValue(objRememberedValue3);
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    Composer composer11 = composer5;
                    CornerPickerChip(cornerPosition10, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs10, composer11, 6, 0);
                    CornerPosition cornerPosition12 = CornerPosition.BOTTOM_RIGHT;
                    if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                        z4 = true;
                    } else {
                        z4 = false;
                    }
                    Modifier modifierM670padding3ABfNKs12 = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                    ComposerKt.sourceInformationMarkerStart(composer11, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance4 = composer11.changedInstance($preferences);
                    Object objRememberedValue9 = composer11.rememberedValue();
                    if (zChangedInstance4) {
                    }
                    obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                        }
                    };
                    composer11.updateRememberedValue(obj);
                    ComposerKt.sourceInformationMarkerEnd(composer11);
                    CornerPickerChip(cornerPosition12, z4, (Function1) obj, modifierM670padding3ABfNKs12, composer11, 6, 0);
                    ComposerKt.sourceInformationMarkerEnd(composer11);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    $composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                } else {
                    composer3 = composer2;
                }
                objRememberedValue2 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$50$lambda$49($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                    }
                };
                composer2.updateRememberedValue(objRememberedValue2);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                composer4 = composer3;
                CornerPickerChip(cornerPosition9, z2, (Function1) objRememberedValue2, modifierM670padding3ABfNKs9, composer4, 6, 0);
                TextStyle bodySmall4 = MaterialTheme.INSTANCE.getTypography(composer4, MaterialTheme.$stable).getBodySmall();
                long onSurfaceVariant4 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                TextKt.m2693Text4IGK_g("Displej telefonu", boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getCenter()), Color.m4157copywmQWz5c(onSurfaceVariant4, (14 & 1) != 0 ? Color.m4161getAlphaimpl(onSurfaceVariant4) : 0.6f, (14 & 2) != 0 ? Color.m4165getRedimpl(onSurfaceVariant4) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(onSurfaceVariant4) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(onSurfaceVariant4) : 0.0f), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, bodySmall4, composer4, 6, 0, 65528);
                CornerPosition cornerPosition13 = CornerPosition.BOTTOM_LEFT;
                if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_LEFT) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                Modifier modifierM670padding3ABfNKs13 = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomStart()), Dp.m6622constructorimpl(10));
                ComposerKt.sourceInformationMarkerStart(composer4, 1067365911, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance3 = composer4.changedInstance($preferences);
                objRememberedValue3 = composer4.rememberedValue();
                if (zChangedInstance3) {
                    composer5 = composer4;
                    if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    Composer composer12 = composer5;
                    CornerPickerChip(cornerPosition13, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs13, composer12, 6, 0);
                    CornerPosition cornerPosition14 = CornerPosition.BOTTOM_RIGHT;
                    if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                        z4 = true;
                    } else {
                        z4 = false;
                    }
                    Modifier modifierM670padding3ABfNKs14 = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                    ComposerKt.sourceInformationMarkerStart(composer12, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance4 = composer12.changedInstance($preferences);
                    Object objRememberedValue10 = composer12.rememberedValue();
                    if (zChangedInstance4) {
                    }
                    obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                        }
                    };
                    composer12.updateRememberedValue(obj);
                    ComposerKt.sourceInformationMarkerEnd(composer12);
                    CornerPickerChip(cornerPosition14, z4, (Function1) obj, modifierM670padding3ABfNKs14, composer12, 6, 0);
                    ComposerKt.sourceInformationMarkerEnd(composer12);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    $composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                } else {
                    composer5 = composer4;
                }
                objRememberedValue3 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$52$lambda$51($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                    }
                };
                composer4.updateRememberedValue(objRememberedValue3);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                Composer composer13 = composer5;
                CornerPickerChip(cornerPosition13, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs13, composer13, 6, 0);
                CornerPosition cornerPosition15 = CornerPosition.BOTTOM_RIGHT;
                if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                    z4 = true;
                } else {
                    z4 = false;
                }
                Modifier modifierM670padding3ABfNKs15 = PaddingKt.m670padding3ABfNKs(boxScope.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                ComposerKt.sourceInformationMarkerStart(composer13, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance4 = composer13.changedInstance($preferences);
                Object objRememberedValue11 = composer13.rememberedValue();
                if (zChangedInstance4) {
                }
                obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                    }
                };
                composer13.updateRememberedValue(obj);
                ComposerKt.sourceInformationMarkerEnd(composer13);
                CornerPickerChip(cornerPosition15, z4, (Function1) obj, modifierM670padding3ABfNKs15, composer13, 6, 0);
                ComposerKt.sourceInformationMarkerEnd(composer13);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash);
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i5 = (i2 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
            int i6 = ((i >> 6) & 112) | 6;
            BoxScope boxScope2 = BoxScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart($composer, -1272791767, "C429@16372L102,423@16098L390,442@16811L102,436@16537L390,451@17064L10,452@17122L11,449@16981L261,463@17566L102,457@17283L399,476@18007L102,470@17724L399:OverlayControlScreen.kt#naom5h");
            CornerPosition cornerPosition16 = CornerPosition.TOP_LEFT;
            if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.TOP_LEFT) {
                z = true;
            } else {
                z = false;
            }
            Modifier modifierM670padding3ABfNKs16 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getTopStart()), Dp.m6622constructorimpl(10));
            ComposerKt.sourceInformationMarkerStart($composer, 1067327703, "CC(remember):OverlayControlScreen.kt#9igjgp");
            zChangedInstance = $composer.changedInstance($preferences);
            objRememberedValue = $composer.rememberedValue();
            if (zChangedInstance) {
                composer = $composer;
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                }
                ComposerKt.sourceInformationMarkerEnd(composer);
                composer2 = composer;
                CornerPickerChip(cornerPosition16, z, (Function1) objRememberedValue, modifierM670padding3ABfNKs16, composer2, 6, 0);
                CornerPosition cornerPosition17 = CornerPosition.TOP_RIGHT;
                if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.TOP_RIGHT) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                Modifier modifierM670padding3ABfNKs17 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getTopEnd()), Dp.m6622constructorimpl(10));
                ComposerKt.sourceInformationMarkerStart(composer2, 1067341751, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance2 = composer2.changedInstance($preferences);
                objRememberedValue2 = composer2.rememberedValue();
                if (zChangedInstance2) {
                    composer3 = composer2;
                    if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    composer4 = composer3;
                    CornerPickerChip(cornerPosition17, z2, (Function1) objRememberedValue2, modifierM670padding3ABfNKs17, composer4, 6, 0);
                    TextStyle bodySmall5 = MaterialTheme.INSTANCE.getTypography(composer4, MaterialTheme.$stable).getBodySmall();
                    long onSurfaceVariant5 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                    TextKt.m2693Text4IGK_g("Displej telefonu", boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getCenter()), Color.m4157copywmQWz5c(onSurfaceVariant5, (14 & 1) != 0 ? Color.m4161getAlphaimpl(onSurfaceVariant5) : 0.6f, (14 & 2) != 0 ? Color.m4165getRedimpl(onSurfaceVariant5) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(onSurfaceVariant5) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(onSurfaceVariant5) : 0.0f), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, bodySmall5, composer4, 6, 0, 65528);
                    CornerPosition cornerPosition18 = CornerPosition.BOTTOM_LEFT;
                    if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_LEFT) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                    Modifier modifierM670padding3ABfNKs18 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomStart()), Dp.m6622constructorimpl(10));
                    ComposerKt.sourceInformationMarkerStart(composer4, 1067365911, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance3 = composer4.changedInstance($preferences);
                    objRememberedValue3 = composer4.rememberedValue();
                    if (zChangedInstance3) {
                        composer5 = composer4;
                        if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                        }
                        ComposerKt.sourceInformationMarkerEnd(composer5);
                        Composer composer14 = composer5;
                        CornerPickerChip(cornerPosition18, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs18, composer14, 6, 0);
                        CornerPosition cornerPosition19 = CornerPosition.BOTTOM_RIGHT;
                        if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                            z4 = true;
                        } else {
                            z4 = false;
                        }
                        Modifier modifierM670padding3ABfNKs19 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                        ComposerKt.sourceInformationMarkerStart(composer14, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                        zChangedInstance4 = composer14.changedInstance($preferences);
                        Object objRememberedValue12 = composer14.rememberedValue();
                        if (zChangedInstance4) {
                        }
                        obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj2) {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                            }
                        };
                        composer14.updateRememberedValue(obj);
                        ComposerKt.sourceInformationMarkerEnd(composer14);
                        CornerPickerChip(cornerPosition19, z4, (Function1) obj, modifierM670padding3ABfNKs19, composer14, 6, 0);
                        ComposerKt.sourceInformationMarkerEnd(composer14);
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        $composer.endNode();
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        composer5 = composer4;
                    }
                    objRememberedValue3 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda3
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$52$lambda$51($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                        }
                    };
                    composer4.updateRememberedValue(objRememberedValue3);
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    Composer composer15 = composer5;
                    CornerPickerChip(cornerPosition18, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs18, composer15, 6, 0);
                    CornerPosition cornerPosition110 = CornerPosition.BOTTOM_RIGHT;
                    if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                        z4 = true;
                    } else {
                        z4 = false;
                    }
                    Modifier modifierM670padding3ABfNKs110 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                    ComposerKt.sourceInformationMarkerStart(composer15, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance4 = composer15.changedInstance($preferences);
                    Object objRememberedValue13 = composer15.rememberedValue();
                    if (zChangedInstance4) {
                    }
                    obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                        }
                    };
                    composer15.updateRememberedValue(obj);
                    ComposerKt.sourceInformationMarkerEnd(composer15);
                    CornerPickerChip(cornerPosition110, z4, (Function1) obj, modifierM670padding3ABfNKs110, composer15, 6, 0);
                    ComposerKt.sourceInformationMarkerEnd(composer15);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    $composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                } else {
                    composer3 = composer2;
                }
                objRememberedValue2 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$50$lambda$49($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                    }
                };
                composer2.updateRememberedValue(objRememberedValue2);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                composer4 = composer3;
                CornerPickerChip(cornerPosition17, z2, (Function1) objRememberedValue2, modifierM670padding3ABfNKs17, composer4, 6, 0);
                TextStyle bodySmall6 = MaterialTheme.INSTANCE.getTypography(composer4, MaterialTheme.$stable).getBodySmall();
                long onSurfaceVariant6 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                TextKt.m2693Text4IGK_g("Displej telefonu", boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getCenter()), Color.m4157copywmQWz5c(onSurfaceVariant6, (14 & 1) != 0 ? Color.m4161getAlphaimpl(onSurfaceVariant6) : 0.6f, (14 & 2) != 0 ? Color.m4165getRedimpl(onSurfaceVariant6) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(onSurfaceVariant6) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(onSurfaceVariant6) : 0.0f), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, bodySmall6, composer4, 6, 0, 65528);
                CornerPosition cornerPosition111 = CornerPosition.BOTTOM_LEFT;
                if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_LEFT) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                Modifier modifierM670padding3ABfNKs111 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomStart()), Dp.m6622constructorimpl(10));
                ComposerKt.sourceInformationMarkerStart(composer4, 1067365911, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance3 = composer4.changedInstance($preferences);
                objRememberedValue3 = composer4.rememberedValue();
                if (zChangedInstance3) {
                    composer5 = composer4;
                    if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    Composer composer16 = composer5;
                    CornerPickerChip(cornerPosition111, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs111, composer16, 6, 0);
                    CornerPosition cornerPosition112 = CornerPosition.BOTTOM_RIGHT;
                    if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                        z4 = true;
                    } else {
                        z4 = false;
                    }
                    Modifier modifierM670padding3ABfNKs112 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                    ComposerKt.sourceInformationMarkerStart(composer16, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance4 = composer16.changedInstance($preferences);
                    Object objRememberedValue14 = composer16.rememberedValue();
                    if (zChangedInstance4) {
                    }
                    obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                        }
                    };
                    composer16.updateRememberedValue(obj);
                    ComposerKt.sourceInformationMarkerEnd(composer16);
                    CornerPickerChip(cornerPosition112, z4, (Function1) obj, modifierM670padding3ABfNKs112, composer16, 6, 0);
                    ComposerKt.sourceInformationMarkerEnd(composer16);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    $composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                } else {
                    composer5 = composer4;
                }
                objRememberedValue3 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$52$lambda$51($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                    }
                };
                composer4.updateRememberedValue(objRememberedValue3);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                Composer composer17 = composer5;
                CornerPickerChip(cornerPosition111, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs111, composer17, 6, 0);
                CornerPosition cornerPosition113 = CornerPosition.BOTTOM_RIGHT;
                if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                    z4 = true;
                } else {
                    z4 = false;
                }
                Modifier modifierM670padding3ABfNKs113 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                ComposerKt.sourceInformationMarkerStart(composer17, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance4 = composer17.changedInstance($preferences);
                Object objRememberedValue15 = composer17.rememberedValue();
                if (zChangedInstance4) {
                }
                obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                    }
                };
                composer17.updateRememberedValue(obj);
                ComposerKt.sourceInformationMarkerEnd(composer17);
                CornerPickerChip(cornerPosition113, z4, (Function1) obj, modifierM670padding3ABfNKs113, composer17, 6, 0);
                ComposerKt.sourceInformationMarkerEnd(composer17);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composer = $composer;
            }
            objRememberedValue = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda1
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj2) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$48$lambda$47($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                }
            };
            $composer.updateRememberedValue(objRememberedValue);
            ComposerKt.sourceInformationMarkerEnd(composer);
            composer2 = composer;
            CornerPickerChip(cornerPosition16, z, (Function1) objRememberedValue, modifierM670padding3ABfNKs16, composer2, 6, 0);
            CornerPosition cornerPosition114 = CornerPosition.TOP_RIGHT;
            if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.TOP_RIGHT) {
                z2 = true;
            } else {
                z2 = false;
            }
            Modifier modifierM670padding3ABfNKs114 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getTopEnd()), Dp.m6622constructorimpl(10));
            ComposerKt.sourceInformationMarkerStart(composer2, 1067341751, "CC(remember):OverlayControlScreen.kt#9igjgp");
            zChangedInstance2 = composer2.changedInstance($preferences);
            objRememberedValue2 = composer2.rememberedValue();
            if (zChangedInstance2) {
                composer3 = composer2;
                if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                }
                ComposerKt.sourceInformationMarkerEnd(composer3);
                composer4 = composer3;
                CornerPickerChip(cornerPosition114, z2, (Function1) objRememberedValue2, modifierM670padding3ABfNKs114, composer4, 6, 0);
                TextStyle bodySmall7 = MaterialTheme.INSTANCE.getTypography(composer4, MaterialTheme.$stable).getBodySmall();
                long onSurfaceVariant7 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
                TextKt.m2693Text4IGK_g("Displej telefonu", boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getCenter()), Color.m4157copywmQWz5c(onSurfaceVariant7, (14 & 1) != 0 ? Color.m4161getAlphaimpl(onSurfaceVariant7) : 0.6f, (14 & 2) != 0 ? Color.m4165getRedimpl(onSurfaceVariant7) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(onSurfaceVariant7) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(onSurfaceVariant7) : 0.0f), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, bodySmall7, composer4, 6, 0, 65528);
                CornerPosition cornerPosition115 = CornerPosition.BOTTOM_LEFT;
                if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_LEFT) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                Modifier modifierM670padding3ABfNKs115 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomStart()), Dp.m6622constructorimpl(10));
                ComposerKt.sourceInformationMarkerStart(composer4, 1067365911, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance3 = composer4.changedInstance($preferences);
                objRememberedValue3 = composer4.rememberedValue();
                if (zChangedInstance3) {
                    composer5 = composer4;
                    if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer5);
                    Composer composer18 = composer5;
                    CornerPickerChip(cornerPosition115, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs115, composer18, 6, 0);
                    CornerPosition cornerPosition116 = CornerPosition.BOTTOM_RIGHT;
                    if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                        z4 = true;
                    } else {
                        z4 = false;
                    }
                    Modifier modifierM670padding3ABfNKs116 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                    ComposerKt.sourceInformationMarkerStart(composer18, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance4 = composer18.changedInstance($preferences);
                    Object objRememberedValue16 = composer18.rememberedValue();
                    if (zChangedInstance4) {
                    }
                    obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                        }
                    };
                    composer18.updateRememberedValue(obj);
                    ComposerKt.sourceInformationMarkerEnd(composer18);
                    CornerPickerChip(cornerPosition116, z4, (Function1) obj, modifierM670padding3ABfNKs116, composer18, 6, 0);
                    ComposerKt.sourceInformationMarkerEnd(composer18);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    $composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                } else {
                    composer5 = composer4;
                }
                objRememberedValue3 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$52$lambda$51($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                    }
                };
                composer4.updateRememberedValue(objRememberedValue3);
                ComposerKt.sourceInformationMarkerEnd(composer5);
                Composer composer19 = composer5;
                CornerPickerChip(cornerPosition115, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs115, composer19, 6, 0);
                CornerPosition cornerPosition117 = CornerPosition.BOTTOM_RIGHT;
                if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                    z4 = true;
                } else {
                    z4 = false;
                }
                Modifier modifierM670padding3ABfNKs117 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                ComposerKt.sourceInformationMarkerStart(composer19, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance4 = composer19.changedInstance($preferences);
                Object objRememberedValue17 = composer19.rememberedValue();
                if (zChangedInstance4) {
                }
                obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                    }
                };
                composer19.updateRememberedValue(obj);
                ComposerKt.sourceInformationMarkerEnd(composer19);
                CornerPickerChip(cornerPosition117, z4, (Function1) obj, modifierM670padding3ABfNKs117, composer19, 6, 0);
                ComposerKt.sourceInformationMarkerEnd(composer19);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composer3 = composer2;
            }
            objRememberedValue2 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda2
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj2) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$50$lambda$49($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                }
            };
            composer2.updateRememberedValue(objRememberedValue2);
            ComposerKt.sourceInformationMarkerEnd(composer3);
            composer4 = composer3;
            CornerPickerChip(cornerPosition114, z2, (Function1) objRememberedValue2, modifierM670padding3ABfNKs114, composer4, 6, 0);
            TextStyle bodySmall8 = MaterialTheme.INSTANCE.getTypography(composer4, MaterialTheme.$stable).getBodySmall();
            long onSurfaceVariant8 = MaterialTheme.INSTANCE.getColorScheme(composer4, MaterialTheme.$stable).getOnSurfaceVariant();
            TextKt.m2693Text4IGK_g("Displej telefonu", boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getCenter()), Color.m4157copywmQWz5c(onSurfaceVariant8, (14 & 1) != 0 ? Color.m4161getAlphaimpl(onSurfaceVariant8) : 0.6f, (14 & 2) != 0 ? Color.m4165getRedimpl(onSurfaceVariant8) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(onSurfaceVariant8) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(onSurfaceVariant8) : 0.0f), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, bodySmall8, composer4, 6, 0, 65528);
            CornerPosition cornerPosition118 = CornerPosition.BOTTOM_LEFT;
            if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_LEFT) {
                z3 = true;
            } else {
                z3 = false;
            }
            Modifier modifierM670padding3ABfNKs118 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomStart()), Dp.m6622constructorimpl(10));
            ComposerKt.sourceInformationMarkerStart(composer4, 1067365911, "CC(remember):OverlayControlScreen.kt#9igjgp");
            zChangedInstance3 = composer4.changedInstance($preferences);
            objRememberedValue3 = composer4.rememberedValue();
            if (zChangedInstance3) {
                composer5 = composer4;
                if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                }
                ComposerKt.sourceInformationMarkerEnd(composer5);
                Composer composer110 = composer5;
                CornerPickerChip(cornerPosition118, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs118, composer110, 6, 0);
                CornerPosition cornerPosition119 = CornerPosition.BOTTOM_RIGHT;
                if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                    z4 = true;
                } else {
                    z4 = false;
                }
                Modifier modifierM670padding3ABfNKs119 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
                ComposerKt.sourceInformationMarkerStart(composer110, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance4 = composer110.changedInstance($preferences);
                Object objRememberedValue18 = composer110.rememberedValue();
                if (zChangedInstance4) {
                }
                obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                    }
                };
                composer110.updateRememberedValue(obj);
                ComposerKt.sourceInformationMarkerEnd(composer110);
                CornerPickerChip(cornerPosition119, z4, (Function1) obj, modifierM670padding3ABfNKs119, composer110, 6, 0);
                ComposerKt.sourceInformationMarkerEnd(composer110);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composer5 = composer4;
            }
            objRememberedValue3 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda3
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj2) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$52$lambda$51($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                }
            };
            composer4.updateRememberedValue(objRememberedValue3);
            ComposerKt.sourceInformationMarkerEnd(composer5);
            Composer composer111 = composer5;
            CornerPickerChip(cornerPosition118, z3, (Function1) objRememberedValue3, modifierM670padding3ABfNKs118, composer111, 6, 0);
            CornerPosition cornerPosition1110 = CornerPosition.BOTTOM_RIGHT;
            if (OverlayControlScreen$lambda$4($currentPosition$delegate) == CornerPosition.BOTTOM_RIGHT) {
                z4 = true;
            } else {
                z4 = false;
            }
            Modifier modifierM670padding3ABfNKs1110 = PaddingKt.m670padding3ABfNKs(boxScope2.align(Modifier.INSTANCE, Alignment.INSTANCE.getBottomEnd()), Dp.m6622constructorimpl(10));
            ComposerKt.sourceInformationMarkerStart(composer111, 1067380023, "CC(remember):OverlayControlScreen.kt#9igjgp");
            zChangedInstance4 = composer111.changedInstance($preferences);
            Object objRememberedValue19 = composer111.rememberedValue();
            if (zChangedInstance4) {
            }
            obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda4
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj2) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53($preferences, $currentPosition$delegate, (CornerPosition) obj2);
                }
            };
            composer111.updateRememberedValue(obj);
            ComposerKt.sourceInformationMarkerEnd(composer111);
            CornerPickerChip(cornerPosition1110, z4, (Function1) obj, modifierM670padding3ABfNKs1110, composer111, 6, 0);
            ComposerKt.sourceInformationMarkerEnd(composer111);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$48$lambda$47(AppPreferences $preferences, MutableState $currentPosition$delegate, CornerPosition it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $currentPosition$delegate.setValue(it);
        $preferences.setCornerPosition(it);
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$50$lambda$49(AppPreferences $preferences, MutableState $currentPosition$delegate, CornerPosition it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $currentPosition$delegate.setValue(it);
        $preferences.setCornerPosition(it);
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$52$lambda$51(AppPreferences $preferences, MutableState $currentPosition$delegate, CornerPosition it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $currentPosition$delegate.setValue(it);
        $preferences.setCornerPosition(it);
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$58$lambda$57$lambda$56$lambda$55$lambda$54$lambda$53(AppPreferences $preferences, MutableState $currentPosition$delegate, CornerPosition it) {
        Intrinsics.checkNotNullParameter(it, "it");
        $currentPosition$delegate.setValue(it);
        $preferences.setCornerPosition(it);
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:100:0x08b8  */
    /* JADX WARN: Code duplicated, block: B:103:0x08da  */
    /* JADX WARN: Code duplicated, block: B:106:0x08e5  */
    /* JADX WARN: Code duplicated, block: B:107:0x08ea  */
    /* JADX WARN: Code duplicated, block: B:112:0x0a0e  */
    /* JADX WARN: Code duplicated, block: B:28:0x01dd  */
    /* JADX WARN: Code duplicated, block: B:31:0x01e9  */
    /* JADX WARN: Code duplicated, block: B:32:0x01ef  */
    /* JADX WARN: Code duplicated, block: B:43:0x03a9  */
    /* JADX WARN: Code duplicated, block: B:46:0x03b5  */
    /* JADX WARN: Code duplicated, block: B:47:0x03bb  */
    /* JADX WARN: Code duplicated, block: B:58:0x053e  */
    /* JADX WARN: Code duplicated, block: B:61:0x054a  */
    /* JADX WARN: Code duplicated, block: B:62:0x0550  */
    /* JADX WARN: Code duplicated, block: B:73:0x06ad  */
    /* JADX WARN: Code duplicated, block: B:76:0x06b8  */
    /* JADX WARN: Code duplicated, block: B:77:0x06bb  */
    /* JADX WARN: Code duplicated, block: B:81:0x077f  */
    /* JADX WARN: Code duplicated, block: B:84:0x078b  */
    /* JADX WARN: Code duplicated, block: B:85:0x0791  */
    /* JADX WARN: Code duplicated, block: B:88:0x07c2  */
    /* JADX WARN: Code duplicated, block: B:92:0x07d8 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:97:0x0884  */
    /* JADX WARN: Code duplicated, block: B:99:0x08b5  */
    static final Unit OverlayControlScreen$lambda$96$lambda$70(MutableFloatState $currentOpacity$delegate, AppPreferences $preferences, ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        int i;
        Composer composer;
        Composer composer2;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function1;
        Composer composerM3652constructorimpl;
        int currentCompositeKeyHash2;
        Function0<ComposeUiNode> constructor2;
        Function0<ComposeUiNode> function2;
        Composer composerM3652constructorimpl2;
        int currentCompositeKeyHash3;
        Function0<ComposeUiNode> constructor3;
        Function0<ComposeUiNode> function3;
        Composer composerM3652constructorimpl3;
        ClosedFloatingPointRange<Float> closedFloatingPointRangeRangeTo;
        boolean zChangedInstance;
        Object objRememberedValue;
        ClosedFloatingPointRange<Float> closedFloatingPointRange;
        int currentCompositeKeyHash4;
        Modifier modifierMaterializeModifier;
        Function0<ComposeUiNode> constructor4;
        Function0<ComposeUiNode> function4;
        Composer composerM3652constructorimpl4;
        Composer composer3;
        int i2;
        Iterable<Pair> iterableListOf;
        int i3;
        final float fFloatValue;
        boolean z;
        boolean zChanged;
        Object objRememberedValue2;
        Modifier modifier;
        final MutableFloatState mutableFloatState = $currentOpacity$delegate;
        final AppPreferences appPreferences = $preferences;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C495@18489L2920:OverlayControlScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1003607769, $changed, -1, "com.example.ui.OverlayControlScreen.<anonymous>.<anonymous> (OverlayControlScreen.kt:495)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor5 = ComposeUiNode.INSTANCE.getConstructor();
            int i4 = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor5;
                $composer.createNode(function0);
            } else {
                function0 = constructor5;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl5 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl5, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl5, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl5.getInserting()) {
                i = 6;
                composer = $composer;
            } else {
                i = 6;
                composer = $composer;
                if (!Intrinsics.areEqual(composerM3652constructorimpl5.rememberedValue(), Integer.valueOf(currentCompositeKeyHash5))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl5, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i5 = (i4 >> 6) & 14;
                composer2 = composer;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i6 = ((i >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -866748101, "C496@18542L586,514@19138L40,516@19188L1101,552@20299L750,572@21059L40,576@21309L10,577@21363L11,574@21109L292:OverlayControlScreen.kt#naom5h");
                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap2 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i7 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function1 = constructor;
                    composer2.createNode(function1);
                } else {
                    function1 = constructor;
                    composer2.useNode();
                }
                composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                    composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash2);
                }
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i8 = (i7 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                int i9 = ((438 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 243479712, "C503@18825L10,501@18732L168,508@19008L10,506@18911L207:OverlayControlScreen.kt#naom5h");
                TextKt.m2693Text4IGK_g("Nenápadnost rohu (Průhlednost)", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleSmall(), composer2, 196614, 0, 65502);
                TextKt.m2693Text4IGK_g(((int) (OverlayControlScreen$lambda$7(mutableFloatState) * 100.0f)) + "%", (Modifier) null, com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, 196992, 0, 65498);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
                Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically2, composer2, ((390 >> 3) & 14) | ((390 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default2);
                constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                int i10 = ((((390 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function2 = constructor2;
                    composer2.createNode(function2);
                } else {
                    function2 = constructor2;
                    composer2.useNode();
                }
                composerM3652constructorimpl2 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                    composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                    composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash3);
                }
                Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                int i11 = (i10 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                int i12 = ((390 >> 6) & 112) | 6;
                RowScope rowScope = RowScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composer2, -1345732792, "C521@19348L459,535@19819L40,544@20113L110,539@19943L94,537@19871L408:OverlayControlScreen.kt#naom5h");
                Modifier modifierM236borderxT4_qwU = BorderKt.m236borderxT4_qwU(BackgroundKt.background$default(AlphaKt.alpha(SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(36)), OverlayControlScreen$lambda$7(mutableFloatState)), Brush.INSTANCE.m4120linearGradientmHitzGk((List<Color>) CollectionsKt.listOf((Object[]) new Color[]{Color.m4149boximpl(ColorKt.Color(4283385573L)), Color.m4149boximpl(ColorKt.Color(4281413249L))}), (14 & 2) != 0 ? Offset.INSTANCE.m3934getZeroF1C5BW0() : 0L, (14 & 4) != 0 ? Offset.INSTANCE.m3932getInfiniteF1C5BW0() : 0L, (14 & 8) != 0 ? TileMode.INSTANCE.m4531getClamp3opZhB0() : 0), RoundedCornerShapeKt.getCircleShape(), 0.0f, 4, null), Dp.m6622constructorimpl((float) 1.5d), ColorKt.Color(4286680312L), RoundedCornerShapeKt.getCircleShape());
                Alignment center = Alignment.INSTANCE.getCenter();
                ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap4 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier(composer2, modifierM236borderxT4_qwU);
                constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                int i13 = ((((48 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function3 = constructor3;
                    composer2.createNode(function3);
                } else {
                    function3 = constructor3;
                    composer2.useNode();
                }
                composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl3.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                    composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                    composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash4);
                }
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
                int i14 = (i13 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                int i15 = ((48 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 1797999823, "C532@19741L54:OverlayControlScreen.kt#naom5h");
                TextKt.m2693Text4IGK_g("✦", (Modifier) null, ColorKt.Color(4294828103L), TextUnitKt.getSp(16), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3462, 0, 131058);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14)), composer2, 6);
                float fOverlayControlScreen$lambda$7 = OverlayControlScreen$lambda$7(mutableFloatState);
                closedFloatingPointRangeRangeTo = RangesKt.rangeTo(0.1f, 1.0f);
                SliderColors sliderColorsM2495colorsq0g_0yA = SliderDefaults.INSTANCE.m2495colorsq0g_0yA(com.example.ui.theme.ColorKt.getIndigoPrimary(), com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer2, 54, 6, PointerIconCompat.TYPE_GRAB);
                Modifier modifierWeight$default = RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null);
                ComposerKt.sourceInformationMarkerStart(composer2, -1844507850, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance = composer2.changedInstance(appPreferences);
                objRememberedValue = composer2.rememberedValue();
                if (zChangedInstance) {
                    closedFloatingPointRange = closedFloatingPointRangeRangeTo;
                } else {
                    closedFloatingPointRange = closedFloatingPointRangeRangeTo;
                    if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    SliderKt.Slider(fOverlayControlScreen$lambda$7, (Function1) objRememberedValue, modifierWeight$default, false, closedFloatingPointRange, 0, null, sliderColorsM2495colorsq0g_0yA, null, composer2, 0, 360);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    Modifier modifierFillMaxWidth$default3 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                    Arrangement.Horizontal horizontalM550spacedBy0680j_4 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
                    ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                    MeasurePolicy measurePolicyRowMeasurePolicy3 = RowKt.rowMeasurePolicy(horizontalM550spacedBy0680j_4, Alignment.INSTANCE.getTop(), composer2, ((54 >> 3) & 14) | ((54 >> 3) & 112));
                    ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                    CompositionLocalMap currentCompositionLocalMap5 = composer2.getCurrentCompositionLocalMap();
                    modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default3);
                    constructor4 = ComposeUiNode.INSTANCE.getConstructor();
                    int i16 = ((((54 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer2.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composer2.startReusableNode();
                    if (composer2.getInserting()) {
                        function4 = constructor4;
                        composer2.createNode(function4);
                    } else {
                        function4 = constructor4;
                        composer2.useNode();
                    }
                    composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer2);
                    Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyRowMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (!composerM3652constructorimpl4.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl4.rememberedValue(), Integer.valueOf(currentCompositeKeyHash4))) {
                        composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
                        composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash5);
                    }
                    Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                    int i17 = (i16 >> 6) & 14;
                    composer3 = composer2;
                    i2 = 0;
                    ComposerKt.sourceInformationMarkerStart(composer3, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                    RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                    int i18 = ((54 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer3, -1817770036, "C:OverlayControlScreen.kt#naom5h");
                    composer3.startReplaceGroup(-1998297820);
                    ComposerKt.sourceInformation(composer3, "*559@20666L106,563@20796L35,564@20875L138,557@20556L471");
                    iterableListOf = CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to(Float.valueOf(0.15f), "15% (Diskrétní)"), TuplesKt.to(Float.valueOf(0.25f), "25%"), TuplesKt.to(Float.valueOf(0.5f), "50%"), TuplesKt.to(Float.valueOf(0.8f), "80%")});
                    i3 = 0;
                    for (Pair pair : iterableListOf) {
                        Iterable iterable = iterableListOf;
                        fFloatValue = ((Number) pair.component1()).floatValue();
                        int i19 = i3;
                        final String str = (String) pair.component2();
                        if (Math.abs(OverlayControlScreen$lambda$7(mutableFloatState) - fFloatValue) < 0.03f) {
                            z = true;
                        } else {
                            z = false;
                        }
                        int i20 = i2;
                        ComposerKt.sourceInformationMarkerStart(composer3, 1132629564, "CC(remember):OverlayControlScreen.kt#9igjgp");
                        zChanged = composer3.changed(fFloatValue) | composer3.changedInstance(appPreferences);
                        Composer composer4 = composer3;
                        objRememberedValue2 = composer4.rememberedValue();
                        if (zChanged) {
                            modifier = modifierMaterializeModifier;
                        } else {
                            modifier = modifierMaterializeModifier;
                            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                            }
                            ComposerKt.sourceInformationMarkerEnd(composer3);
                            Composer composer5 = composer3;
                            ChipKt.FilterChip(z, (Function0) objRememberedValue2, ComposableLambdaKt.rememberComposableLambda(-1514859457, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda9
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj, Object obj2) {
                                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$68$lambda$67$lambda$66(str, (Composer) obj, ((Integer) obj2).intValue());
                                }
                            }, composer3, 54), null, false, null, null, null, FilterChipDefaults.INSTANCE.m2111filterChipColorsXqyqHi0(0L, 0L, 0L, 0L, 0L, 0L, 0L, com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, 0L, composer5, 817889280, FilterChipDefaults.$stable << 6, 3455), null, null, null, composer5, 384, 0, 3832);
                            mutableFloatState = $currentOpacity$delegate;
                            appPreferences = $preferences;
                            i2 = i20;
                            i3 = i19;
                            iterableListOf = iterable;
                            composer3 = composer5;
                            modifierMaterializeModifier = modifier;
                        }
                        objRememberedValue2 = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda8
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$68$lambda$67$lambda$65$lambda$64(fFloatValue, appPreferences, mutableFloatState);
                            }
                        };
                        composer4.updateRememberedValue(objRememberedValue2);
                        ComposerKt.sourceInformationMarkerEnd(composer3);
                        Composer composer6 = composer3;
                        ChipKt.FilterChip(z, (Function0) objRememberedValue2, ComposableLambdaKt.rememberComposableLambda(-1514859457, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda9
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$68$lambda$67$lambda$66(str, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        }, composer3, 54), null, false, null, null, null, FilterChipDefaults.INSTANCE.m2111filterChipColorsXqyqHi0(0L, 0L, 0L, 0L, 0L, 0L, 0L, com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, 0L, composer6, 817889280, FilterChipDefaults.$stable << 6, 3455), null, null, null, composer6, 384, 0, 3832);
                        mutableFloatState = $currentOpacity$delegate;
                        appPreferences = $preferences;
                        i2 = i20;
                        i3 = i19;
                        iterableListOf = iterable;
                        composer3 = composer6;
                        modifierMaterializeModifier = modifier;
                    }
                    Composer composer7 = composer3;
                    composer7.endReplaceGroup();
                    ComposerKt.sourceInformationMarkerEnd(composer7);
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                    TextKt.m2693Text4IGK_g("Při 15% je bod v rohu obrazovky i při přemýšlení téměř neviditelný pro okolí. Po zobrazení odpovědi se automaticky vrátí na tuto průhlednost.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                }
                objRememberedValue = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda7
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$63$lambda$62$lambda$61(appPreferences, mutableFloatState, ((Float) obj).floatValue());
                    }
                };
                composer2.updateRememberedValue(objRememberedValue);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SliderKt.Slider(fOverlayControlScreen$lambda$7, (Function1) objRememberedValue, modifierWeight$default, false, closedFloatingPointRange, 0, null, sliderColorsM2495colorsq0g_0yA, null, composer2, 0, 360);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                Modifier modifierFillMaxWidth$default4 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal horizontalM550spacedBy0680j_5 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy4 = RowKt.rowMeasurePolicy(horizontalM550spacedBy0680j_5, Alignment.INSTANCE.getTop(), composer2, ((54 >> 3) & 14) | ((54 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap6 = composer2.getCurrentCompositionLocalMap();
                modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default4);
                constructor4 = ComposeUiNode.INSTANCE.getConstructor();
                int i110 = ((((54 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function4 = constructor4;
                    composer2.createNode(function4);
                } else {
                    function4 = constructor4;
                    composer2.useNode();
                }
                composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyRowMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap6, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash6 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl4.getInserting()) {
                }
                composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
                composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash6);
                Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i111 = (i110 >> 6) & 14;
                composer3 = composer2;
                i2 = 0;
                ComposerKt.sourceInformationMarkerStart(composer3, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance3 = RowScopeInstance.INSTANCE;
                int i112 = ((54 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer3, -1817770036, "C:OverlayControlScreen.kt#naom5h");
                composer3.startReplaceGroup(-1998297820);
                ComposerKt.sourceInformation(composer3, "*559@20666L106,563@20796L35,564@20875L138,557@20556L471");
                iterableListOf = CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to(Float.valueOf(0.15f), "15% (Diskrétní)"), TuplesKt.to(Float.valueOf(0.25f), "25%"), TuplesKt.to(Float.valueOf(0.5f), "50%"), TuplesKt.to(Float.valueOf(0.8f), "80%")});
                i3 = 0;
                while (r46.hasNext()) {
                    Iterable iterable2 = iterableListOf;
                    fFloatValue = ((Number) pair.component1()).floatValue();
                    int i113 = i3;
                    final String str2 = (String) pair.component2();
                    if (Math.abs(OverlayControlScreen$lambda$7(mutableFloatState) - fFloatValue) < 0.03f) {
                        z = true;
                    } else {
                        z = false;
                    }
                    int i21 = i2;
                    ComposerKt.sourceInformationMarkerStart(composer3, 1132629564, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChanged = composer3.changed(fFloatValue) | composer3.changedInstance(appPreferences);
                    Composer composer8 = composer3;
                    objRememberedValue2 = composer8.rememberedValue();
                    if (zChanged) {
                        modifier = modifierMaterializeModifier;
                        if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                        }
                        ComposerKt.sourceInformationMarkerEnd(composer3);
                        Composer composer9 = composer3;
                        ChipKt.FilterChip(z, (Function0) objRememberedValue2, ComposableLambdaKt.rememberComposableLambda(-1514859457, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda9
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$68$lambda$67$lambda$66(str2, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        }, composer3, 54), null, false, null, null, null, FilterChipDefaults.INSTANCE.m2111filterChipColorsXqyqHi0(0L, 0L, 0L, 0L, 0L, 0L, 0L, com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, 0L, composer9, 817889280, FilterChipDefaults.$stable << 6, 3455), null, null, null, composer9, 384, 0, 3832);
                        mutableFloatState = $currentOpacity$delegate;
                        appPreferences = $preferences;
                        i2 = i21;
                        i3 = i113;
                        iterableListOf = iterable2;
                        composer3 = composer9;
                        modifierMaterializeModifier = modifier;
                    } else {
                        modifier = modifierMaterializeModifier;
                    }
                    objRememberedValue2 = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda8
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$68$lambda$67$lambda$65$lambda$64(fFloatValue, appPreferences, mutableFloatState);
                        }
                    };
                    composer8.updateRememberedValue(objRememberedValue2);
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    Composer composer10 = composer3;
                    ChipKt.FilterChip(z, (Function0) objRememberedValue2, ComposableLambdaKt.rememberComposableLambda(-1514859457, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda9
                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj, Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$68$lambda$67$lambda$66(str2, (Composer) obj, ((Integer) obj2).intValue());
                        }
                    }, composer3, 54), null, false, null, null, null, FilterChipDefaults.INSTANCE.m2111filterChipColorsXqyqHi0(0L, 0L, 0L, 0L, 0L, 0L, 0L, com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, 0L, composer10, 817889280, FilterChipDefaults.$stable << 6, 3455), null, null, null, composer10, 384, 0, 3832);
                    mutableFloatState = $currentOpacity$delegate;
                    appPreferences = $preferences;
                    i2 = i21;
                    i3 = i113;
                    iterableListOf = iterable2;
                    composer3 = composer10;
                    modifierMaterializeModifier = modifier;
                }
                Composer composer11 = composer3;
                composer11.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer11);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                TextKt.m2693Text4IGK_g("Při 15% je bod v rohu obrazovky i při přemýšlení téměř neviditelný pro okolí. Po zobrazení odpovědi se automaticky vrátí na tuto průhlednost.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composerM3652constructorimpl5.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash5));
            composerM3652constructorimpl5.apply(Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash);
            Updater.m3659setimpl(composerM3652constructorimpl5, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
            int i22 = (i4 >> 6) & 14;
            composer2 = composer;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
            int i23 = ((i >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -866748101, "C496@18542L586,514@19138L40,516@19188L1101,552@20299L750,572@21059L40,576@21309L10,577@21363L11,574@21109L292:OverlayControlScreen.kt#naom5h");
            Modifier modifierFillMaxWidth$default5 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween2 = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically3 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy5 = RowKt.rowMeasurePolicy(spaceBetween2, centerVertically3, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap7 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier6 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default5);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i24 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function1 = constructor;
                composer2.createNode(function1);
            } else {
                function1 = constructor;
                composer2.useNode();
            }
            composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy5, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap7, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash7 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl.getInserting()) {
            }
            composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash7);
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier6, ComposeUiNode.INSTANCE.getSetModifier());
            int i25 = (i24 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance4 = RowScopeInstance.INSTANCE;
            int i26 = ((438 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 243479712, "C503@18825L10,501@18732L168,508@19008L10,506@18911L207:OverlayControlScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g("Nenápadnost rohu (Průhlednost)", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleSmall(), composer2, 196614, 0, 65502);
            TextKt.m2693Text4IGK_g(((int) (OverlayControlScreen$lambda$7(mutableFloatState) * 100.0f)) + "%", (Modifier) null, com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, 196992, 0, 65498);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
            Alignment.Vertical centerVertically4 = Alignment.INSTANCE.getCenterVertically();
            Modifier modifierFillMaxWidth$default6 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy6 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically4, composer2, ((390 >> 3) & 14) | ((390 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap8 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier7 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default6);
            constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i114 = ((((390 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function2 = constructor2;
                composer2.createNode(function2);
            } else {
                function2 = constructor2;
                composer2.useNode();
            }
            composerM3652constructorimpl2 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy6, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap8, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash8 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl2.getInserting()) {
            }
            composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash8);
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier7, ComposeUiNode.INSTANCE.getSetModifier());
            int i115 = (i114 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            int i116 = ((390 >> 6) & 112) | 6;
            RowScope rowScope2 = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer2, -1345732792, "C521@19348L459,535@19819L40,544@20113L110,539@19943L94,537@19871L408:OverlayControlScreen.kt#naom5h");
            Modifier modifierM236borderxT4_qwU2 = BorderKt.m236borderxT4_qwU(BackgroundKt.background$default(AlphaKt.alpha(SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(36)), OverlayControlScreen$lambda$7(mutableFloatState)), Brush.INSTANCE.m4120linearGradientmHitzGk((List<Color>) CollectionsKt.listOf((Object[]) new Color[]{Color.m4149boximpl(ColorKt.Color(4283385573L)), Color.m4149boximpl(ColorKt.Color(4281413249L))}), (14 & 2) != 0 ? Offset.INSTANCE.m3934getZeroF1C5BW0() : 0L, (14 & 4) != 0 ? Offset.INSTANCE.m3932getInfiniteF1C5BW0() : 0L, (14 & 8) != 0 ? TileMode.INSTANCE.m4531getClamp3opZhB0() : 0), RoundedCornerShapeKt.getCircleShape(), 0.0f, 4, null), Dp.m6622constructorimpl((float) 1.5d), ColorKt.Color(4286680312L), RoundedCornerShapeKt.getCircleShape());
            Alignment center2 = Alignment.INSTANCE.getCenter();
            ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy2 = BoxKt.maybeCachedBoxMeasurePolicy(center2, false);
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap9 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier8 = ComposedModifierKt.materializeModifier(composer2, modifierM236borderxT4_qwU2);
            constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            int i117 = ((((48 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function3 = constructor3;
                composer2.createNode(function3);
            } else {
                function3 = constructor3;
                composer2.useNode();
            }
            composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyMaybeCachedBoxMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap9, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash9 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl3.getInserting()) {
            }
            composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
            composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash9);
            Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier8, ComposeUiNode.INSTANCE.getSetModifier());
            int i118 = (i117 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
            BoxScopeInstance boxScopeInstance2 = BoxScopeInstance.INSTANCE;
            int i119 = ((48 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 1797999823, "C532@19741L54:OverlayControlScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g("✦", (Modifier) null, ColorKt.Color(4294828103L), TextUnitKt.getSp(16), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3462, 0, 131058);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(14)), composer2, 6);
            float fOverlayControlScreen$lambda$8 = OverlayControlScreen$lambda$7(mutableFloatState);
            closedFloatingPointRangeRangeTo = RangesKt.rangeTo(0.1f, 1.0f);
            SliderColors sliderColorsM2495colorsq0g_0yA2 = SliderDefaults.INSTANCE.m2495colorsq0g_0yA(com.example.ui.theme.ColorKt.getIndigoPrimary(), com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer2, 54, 6, PointerIconCompat.TYPE_GRAB);
            Modifier modifierWeight$default2 = RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null);
            ComposerKt.sourceInformationMarkerStart(composer2, -1844507850, "CC(remember):OverlayControlScreen.kt#9igjgp");
            zChangedInstance = composer2.changedInstance(appPreferences);
            objRememberedValue = composer2.rememberedValue();
            if (zChangedInstance) {
                closedFloatingPointRange = closedFloatingPointRangeRangeTo;
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                }
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SliderKt.Slider(fOverlayControlScreen$lambda$8, (Function1) objRememberedValue, modifierWeight$default2, false, closedFloatingPointRange, 0, null, sliderColorsM2495colorsq0g_0yA2, null, composer2, 0, 360);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                Modifier modifierFillMaxWidth$default7 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal horizontalM550spacedBy0680j_6 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy7 = RowKt.rowMeasurePolicy(horizontalM550spacedBy0680j_6, Alignment.INSTANCE.getTop(), composer2, ((54 >> 3) & 14) | ((54 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap10 = composer2.getCurrentCompositionLocalMap();
                modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default7);
                constructor4 = ComposeUiNode.INSTANCE.getConstructor();
                int i1110 = ((((54 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function4 = constructor4;
                    composer2.createNode(function4);
                } else {
                    function4 = constructor4;
                    composer2.useNode();
                }
                composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyRowMeasurePolicy7, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap10, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash10 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl4.getInserting()) {
                }
                composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
                composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash10);
                Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i1111 = (i1110 >> 6) & 14;
                composer3 = composer2;
                i2 = 0;
                ComposerKt.sourceInformationMarkerStart(composer3, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance5 = RowScopeInstance.INSTANCE;
                int i1112 = ((54 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer3, -1817770036, "C:OverlayControlScreen.kt#naom5h");
                composer3.startReplaceGroup(-1998297820);
                ComposerKt.sourceInformation(composer3, "*559@20666L106,563@20796L35,564@20875L138,557@20556L471");
                iterableListOf = CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to(Float.valueOf(0.15f), "15% (Diskrétní)"), TuplesKt.to(Float.valueOf(0.25f), "25%"), TuplesKt.to(Float.valueOf(0.5f), "50%"), TuplesKt.to(Float.valueOf(0.8f), "80%")});
                i3 = 0;
                while (r46.hasNext()) {
                    Iterable iterable3 = iterableListOf;
                    fFloatValue = ((Number) pair.component1()).floatValue();
                    int i1113 = i3;
                    final String str3 = (String) pair.component2();
                    if (Math.abs(OverlayControlScreen$lambda$7(mutableFloatState) - fFloatValue) < 0.03f) {
                        z = true;
                    } else {
                        z = false;
                    }
                    int i27 = i2;
                    ComposerKt.sourceInformationMarkerStart(composer3, 1132629564, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChanged = composer3.changed(fFloatValue) | composer3.changedInstance(appPreferences);
                    Composer composer12 = composer3;
                    objRememberedValue2 = composer12.rememberedValue();
                    if (zChanged) {
                        modifier = modifierMaterializeModifier;
                        if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                        }
                        ComposerKt.sourceInformationMarkerEnd(composer3);
                        Composer composer13 = composer3;
                        ChipKt.FilterChip(z, (Function0) objRememberedValue2, ComposableLambdaKt.rememberComposableLambda(-1514859457, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda9
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$68$lambda$67$lambda$66(str3, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        }, composer3, 54), null, false, null, null, null, FilterChipDefaults.INSTANCE.m2111filterChipColorsXqyqHi0(0L, 0L, 0L, 0L, 0L, 0L, 0L, com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, 0L, composer13, 817889280, FilterChipDefaults.$stable << 6, 3455), null, null, null, composer13, 384, 0, 3832);
                        mutableFloatState = $currentOpacity$delegate;
                        appPreferences = $preferences;
                        i2 = i27;
                        i3 = i1113;
                        iterableListOf = iterable3;
                        composer3 = composer13;
                        modifierMaterializeModifier = modifier;
                    } else {
                        modifier = modifierMaterializeModifier;
                    }
                    objRememberedValue2 = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda8
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$68$lambda$67$lambda$65$lambda$64(fFloatValue, appPreferences, mutableFloatState);
                        }
                    };
                    composer12.updateRememberedValue(objRememberedValue2);
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    Composer composer14 = composer3;
                    ChipKt.FilterChip(z, (Function0) objRememberedValue2, ComposableLambdaKt.rememberComposableLambda(-1514859457, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda9
                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj, Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$68$lambda$67$lambda$66(str3, (Composer) obj, ((Integer) obj2).intValue());
                        }
                    }, composer3, 54), null, false, null, null, null, FilterChipDefaults.INSTANCE.m2111filterChipColorsXqyqHi0(0L, 0L, 0L, 0L, 0L, 0L, 0L, com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, 0L, composer14, 817889280, FilterChipDefaults.$stable << 6, 3455), null, null, null, composer14, 384, 0, 3832);
                    mutableFloatState = $currentOpacity$delegate;
                    appPreferences = $preferences;
                    i2 = i27;
                    i3 = i1113;
                    iterableListOf = iterable3;
                    composer3 = composer14;
                    modifierMaterializeModifier = modifier;
                }
                Composer composer15 = composer3;
                composer15.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer15);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
                TextKt.m2693Text4IGK_g("Při 15% je bod v rohu obrazovky i při přemýšlení téměř neviditelný pro okolí. Po zobrazení odpovědi se automaticky vrátí na tuto průhlednost.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                closedFloatingPointRange = closedFloatingPointRangeRangeTo;
            }
            objRememberedValue = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda7
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$63$lambda$62$lambda$61(appPreferences, mutableFloatState, ((Float) obj).floatValue());
                }
            };
            composer2.updateRememberedValue(objRememberedValue);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SliderKt.Slider(fOverlayControlScreen$lambda$8, (Function1) objRememberedValue, modifierWeight$default2, false, closedFloatingPointRange, 0, null, sliderColorsM2495colorsq0g_0yA2, null, composer2, 0, 360);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            Modifier modifierFillMaxWidth$default8 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal horizontalM550spacedBy0680j_7 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy8 = RowKt.rowMeasurePolicy(horizontalM550spacedBy0680j_7, Alignment.INSTANCE.getTop(), composer2, ((54 >> 3) & 14) | ((54 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap11 = composer2.getCurrentCompositionLocalMap();
            modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default8);
            constructor4 = ComposeUiNode.INSTANCE.getConstructor();
            int i1114 = ((((54 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function4 = constructor4;
                composer2.createNode(function4);
            } else {
                function4 = constructor4;
                composer2.useNode();
            }
            composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyRowMeasurePolicy8, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap11, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash11 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl4.getInserting()) {
            }
            composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
            composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash11);
            Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i1115 = (i1114 >> 6) & 14;
            composer3 = composer2;
            i2 = 0;
            ComposerKt.sourceInformationMarkerStart(composer3, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance6 = RowScopeInstance.INSTANCE;
            int i1116 = ((54 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer3, -1817770036, "C:OverlayControlScreen.kt#naom5h");
            composer3.startReplaceGroup(-1998297820);
            ComposerKt.sourceInformation(composer3, "*559@20666L106,563@20796L35,564@20875L138,557@20556L471");
            iterableListOf = CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to(Float.valueOf(0.15f), "15% (Diskrétní)"), TuplesKt.to(Float.valueOf(0.25f), "25%"), TuplesKt.to(Float.valueOf(0.5f), "50%"), TuplesKt.to(Float.valueOf(0.8f), "80%")});
            i3 = 0;
            while (r46.hasNext()) {
                Iterable iterable4 = iterableListOf;
                fFloatValue = ((Number) pair.component1()).floatValue();
                int i1117 = i3;
                final String str4 = (String) pair.component2();
                if (Math.abs(OverlayControlScreen$lambda$7(mutableFloatState) - fFloatValue) < 0.03f) {
                    z = true;
                } else {
                    z = false;
                }
                int i28 = i2;
                ComposerKt.sourceInformationMarkerStart(composer3, 1132629564, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChanged = composer3.changed(fFloatValue) | composer3.changedInstance(appPreferences);
                Composer composer16 = composer3;
                objRememberedValue2 = composer16.rememberedValue();
                if (zChanged) {
                    modifier = modifierMaterializeModifier;
                    if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    Composer composer17 = composer3;
                    ChipKt.FilterChip(z, (Function0) objRememberedValue2, ComposableLambdaKt.rememberComposableLambda(-1514859457, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda9
                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj, Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$68$lambda$67$lambda$66(str4, (Composer) obj, ((Integer) obj2).intValue());
                        }
                    }, composer3, 54), null, false, null, null, null, FilterChipDefaults.INSTANCE.m2111filterChipColorsXqyqHi0(0L, 0L, 0L, 0L, 0L, 0L, 0L, com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, 0L, composer17, 817889280, FilterChipDefaults.$stable << 6, 3455), null, null, null, composer17, 384, 0, 3832);
                    mutableFloatState = $currentOpacity$delegate;
                    appPreferences = $preferences;
                    i2 = i28;
                    i3 = i1117;
                    iterableListOf = iterable4;
                    composer3 = composer17;
                    modifierMaterializeModifier = modifier;
                } else {
                    modifier = modifierMaterializeModifier;
                }
                objRememberedValue2 = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda8
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$68$lambda$67$lambda$65$lambda$64(fFloatValue, appPreferences, mutableFloatState);
                    }
                };
                composer16.updateRememberedValue(objRememberedValue2);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                Composer composer18 = composer3;
                ChipKt.FilterChip(z, (Function0) objRememberedValue2, ComposableLambdaKt.rememberComposableLambda(-1514859457, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda9
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$68$lambda$67$lambda$66(str4, (Composer) obj, ((Integer) obj2).intValue());
                    }
                }, composer3, 54), null, false, null, null, null, FilterChipDefaults.INSTANCE.m2111filterChipColorsXqyqHi0(0L, 0L, 0L, 0L, 0L, 0L, 0L, com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, 0L, composer18, 817889280, FilterChipDefaults.$stable << 6, 3455), null, null, null, composer18, 384, 0, 3832);
                mutableFloatState = $currentOpacity$delegate;
                appPreferences = $preferences;
                i2 = i28;
                i3 = i1117;
                iterableListOf = iterable4;
                composer3 = composer18;
                modifierMaterializeModifier = modifier;
            }
            Composer composer19 = composer3;
            composer19.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer19);
            ComposerKt.sourceInformationMarkerEnd(composer3);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), composer2, 6);
            TextKt.m2693Text4IGK_g("Při 15% je bod v rohu obrazovky i při přemýšlení téměř neviditelný pro okolí. Po zobrazení odpovědi se automaticky vrátí na tuto průhlednost.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$63$lambda$62$lambda$61(AppPreferences $preferences, MutableFloatState $currentOpacity$delegate, float it) {
        $currentOpacity$delegate.setFloatValue(it);
        $preferences.setCornerOpacity(it);
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$68$lambda$67$lambda$65$lambda$64(float $opVal, AppPreferences $preferences, MutableFloatState $currentOpacity$delegate) {
        $currentOpacity$delegate.setFloatValue($opVal);
        $preferences.setCornerOpacity($opVal);
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$70$lambda$69$lambda$68$lambda$67$lambda$66(String $label, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C563@20798L31:OverlayControlScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-1514859457, $changed, -1, "com.example.ui.OverlayControlScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (OverlayControlScreen.kt:563)");
            }
            TextKt.m2693Text4IGK_g($label, (Modifier) null, 0L, TextUnitKt.getSp(11.5d), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3072, 0, 131062);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:100:0x0867 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:104:0x0991  */
    /* JADX WARN: Code duplicated, block: B:107:0x099d  */
    /* JADX WARN: Code duplicated, block: B:108:0x09a3  */
    /* JADX WARN: Code duplicated, block: B:111:0x09d4  */
    /* JADX WARN: Code duplicated, block: B:115:0x09ea A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:120:0x0ac5  */
    /* JADX WARN: Code duplicated, block: B:122:0x0b62  */
    /* JADX WARN: Code duplicated, block: B:125:0x0b6e  */
    /* JADX WARN: Code duplicated, block: B:126:0x0b74  */
    /* JADX WARN: Code duplicated, block: B:129:0x0ba7  */
    /* JADX WARN: Code duplicated, block: B:133:0x0bbd A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:137:0x0c9d  */
    /* JADX WARN: Code duplicated, block: B:140:0x0ca9  */
    /* JADX WARN: Code duplicated, block: B:141:0x0caf  */
    /* JADX WARN: Code duplicated, block: B:144:0x0ce2  */
    /* JADX WARN: Code duplicated, block: B:147:0x0cf5  */
    /* JADX WARN: Code duplicated, block: B:148:0x0cf8  */
    /* JADX WARN: Code duplicated, block: B:153:0x0e47  */
    /* JADX WARN: Code duplicated, block: B:28:0x01d9  */
    /* JADX WARN: Code duplicated, block: B:31:0x01e5  */
    /* JADX WARN: Code duplicated, block: B:32:0x01eb  */
    /* JADX WARN: Code duplicated, block: B:43:0x0306  */
    /* JADX WARN: Code duplicated, block: B:46:0x0312  */
    /* JADX WARN: Code duplicated, block: B:47:0x0318  */
    /* JADX WARN: Code duplicated, block: B:58:0x0488  */
    /* JADX WARN: Code duplicated, block: B:61:0x0493  */
    /* JADX WARN: Code duplicated, block: B:62:0x0498  */
    /* JADX WARN: Code duplicated, block: B:66:0x05a3  */
    /* JADX WARN: Code duplicated, block: B:69:0x05af  */
    /* JADX WARN: Code duplicated, block: B:70:0x05b5  */
    /* JADX WARN: Code duplicated, block: B:73:0x05e8  */
    /* JADX WARN: Code duplicated, block: B:77:0x05fe A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:81:0x06d3  */
    /* JADX WARN: Code duplicated, block: B:84:0x06df  */
    /* JADX WARN: Code duplicated, block: B:85:0x06e5  */
    /* JADX WARN: Code duplicated, block: B:88:0x0718  */
    /* JADX WARN: Code duplicated, block: B:92:0x072e A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:96:0x0857  */
    static final Unit OverlayControlScreen$lambda$96$lambda$84(final AppPreferences $preferences, final MutableState $stealthBadgeMode$delegate, final MutableState $isPopupCardDisabled$delegate, ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        int i;
        Composer composer;
        Composer composer2;
        String str;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function1;
        Composer composerM3652constructorimpl;
        int currentCompositeKeyHash2;
        Function0<ComposeUiNode> constructor2;
        Function0<ComposeUiNode> function2;
        Composer composerM3652constructorimpl2;
        boolean zChangedInstance;
        Object objRememberedValue;
        Composer composer3;
        int currentCompositeKeyHash3;
        Function0<ComposeUiNode> constructor3;
        Function0<ComposeUiNode> function3;
        Composer composerM3652constructorimpl3;
        int currentCompositeKeyHash4;
        Function0<ComposeUiNode> constructor4;
        Function0<ComposeUiNode> function4;
        Composer composerM3652constructorimpl4;
        boolean zChangedInstance2;
        Object objRememberedValue2;
        int currentCompositeKeyHash5;
        Function0<ComposeUiNode> constructor5;
        Function0<ComposeUiNode> function5;
        Composer composerM3652constructorimpl5;
        int i2;
        Iterable iterableListOf;
        int i3;
        Iterator it;
        int currentCompositeKeyHash6;
        Function0<ComposeUiNode> constructor6;
        Function0<ComposeUiNode> function6;
        Composer composerM3652constructorimpl6;
        int currentCompositeKeyHash7;
        Function0<ComposeUiNode> constructor7;
        Function0<ComposeUiNode> function7;
        Composer composerM3652constructorimpl7;
        Composer composer4;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C591@21752L4630:OverlayControlScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-424841624, $changed, -1, "com.example.ui.OverlayControlScreen.<anonymous>.<anonymous> (OverlayControlScreen.kt:591)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash8 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor8 = ComposeUiNode.INSTANCE.getConstructor();
            int i4 = ((((6 << 3) & 112) << 6) & 896) | 6;
            String str2 = "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp";
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor8;
                $composer.createNode(function0);
            } else {
                function0 = constructor8;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl8 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl8, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl8, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl8.getInserting()) {
                i = 6;
                composer = $composer;
            } else {
                i = 6;
                composer = $composer;
                if (!Intrinsics.areEqual(composerM3652constructorimpl8.rememberedValue(), Integer.valueOf(currentCompositeKeyHash8))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl8, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i5 = (i4 >> 6) & 14;
                composer2 = composer;
                str = "C87@4365L9:Column.kt#2w3rfo";
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i6 = ((i >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 1156804460, "C592@21805L1129,624@22944L41,626@23035L11,626@22995L86,628@23091L41,631@23190L1161,663@24361L41,665@24412L848,689@25270L41,692@25354L1020:OverlayControlScreen.kt#naom5h");
                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap2 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i7 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function1 = constructor;
                    composer2.createNode(function1);
                } else {
                    function1 = constructor;
                    composer2.useNode();
                }
                composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                    composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash2);
                }
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i8 = (i7 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                int i9 = ((438 >> 6) & 112) | 6;
                RowScope rowScope = RowScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composer2, -2027971200, "C597@21995L507,616@22731L116,612@22592L101,610@22514L410:OverlayControlScreen.kt#naom5h");
                Modifier modifierWeight$default = RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null);
                ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                MeasurePolicy measurePolicyColumnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier(composer2, modifierWeight$default);
                constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                int i10 = ((((0 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function2 = constructor2;
                    composer2.createNode(function2);
                } else {
                    function2 = constructor2;
                    composer2.useNode();
                }
                composerM3652constructorimpl2 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyColumnMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                    composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                    composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash3);
                }
                Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i11 = (i10 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
                int i12 = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 611053201, "C600@22147L10,598@22048L178,605@22390L10,606@22448L11,603@22239L251:OverlayControlScreen.kt#naom5h");
                TextKt.m2693Text4IGK_g("Diskrétní rohový režim (Stealth)", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleSmall(), composer2, 196614, 0, 65502);
                TextKt.m2693Text4IGK_g("Ukázat POUZE maličký symbol a barvu v rohu (▲ ◆ ● ■) bez jakéhokoliv textového okna.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                boolean zOverlayControlScreen$lambda$16 = OverlayControlScreen$lambda$16($stealthBadgeMode$delegate);
                SwitchColors switchColorsM2575colorsV1nXRL4 = SwitchDefaults.INSTANCE.m2575colorsV1nXRL4(Color.INSTANCE.m4196getWhite0d7_KjU(), com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer2, 54, SwitchDefaults.$stable << 18, 65532);
                Modifier modifierTestTag = TestTagKt.testTag(Modifier.INSTANCE, "stealth_badge_switch");
                ComposerKt.sourceInformationMarkerStart(composer2, 904431175, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance = composer2.changedInstance($preferences);
                objRememberedValue = composer2.rememberedValue();
                if (zChangedInstance) {
                    composer3 = composer2;
                } else {
                    composer3 = composer2;
                    if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    SwitchKt.Switch(zOverlayControlScreen$lambda$16, (Function1) objRememberedValue, modifierTestTag, null, false, switchColorsM2575colorsV1nXRL4, null, composer3, 384, 88);
                    ComposerKt.sourceInformationMarkerEnd(composer3);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                    long outlineVariant = MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOutlineVariant();
                    DividerKt.m2072HorizontalDivider9IZ8Weo(null, 0.0f, Color.m4157copywmQWz5c(outlineVariant, (14 & 1) != 0 ? Color.m4161getAlphaimpl(outlineVariant) : 0.5f, (14 & 2) != 0 ? Color.m4165getRedimpl(outlineVariant) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(outlineVariant) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(outlineVariant) : 0.0f), composer2, 0, 3);
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                    Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                    Arrangement.Horizontal spaceBetween2 = Arrangement.INSTANCE.getSpaceBetween();
                    Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
                    ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                    MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(spaceBetween2, centerVertically2, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                    ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                    CompositionLocalMap currentCompositionLocalMap4 = composer2.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default2);
                    constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                    int i13 = ((((438 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer2.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composer2.startReusableNode();
                    if (composer2.getInserting()) {
                        function3 = constructor3;
                        composer2.createNode(function3);
                    } else {
                        function3 = constructor3;
                        composer2.useNode();
                    }
                    composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer2);
                    Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (!composerM3652constructorimpl3.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                        composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                        composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash4);
                    }
                    Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                    int i14 = (i13 >> 6) & 14;
                    ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                    int i15 = ((438 >> 6) & 112) | 6;
                    RowScope rowScope2 = RowScopeInstance.INSTANCE;
                    ComposerKt.sourceInformationMarkerStart(composer2, 677737929, "C636@23380L527,655@24143L116,651@24000L105,649@23919L422:OverlayControlScreen.kt#naom5h");
                    Modifier modifierWeight$default2 = RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null);
                    ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                    MeasurePolicy measurePolicyColumnMeasurePolicy3 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                    ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                    CompositionLocalMap currentCompositionLocalMap5 = composer2.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier(composer2, modifierWeight$default2);
                    constructor4 = ComposeUiNode.INSTANCE.getConstructor();
                    int i16 = ((((0 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer2.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composer2.startReusableNode();
                    if (composer2.getInserting()) {
                        function4 = constructor4;
                        composer2.createNode(function4);
                    } else {
                        function4 = constructor4;
                        composer2.useNode();
                    }
                    composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer2);
                    Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyColumnMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (!composerM3652constructorimpl4.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl4.rememberedValue(), Integer.valueOf(currentCompositeKeyHash4))) {
                        composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
                        composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash5);
                    }
                    Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
                    int i17 = (i16 >> 6) & 14;
                    ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                    ColumnScopeInstance columnScopeInstance3 = ColumnScopeInstance.INSTANCE;
                    int i18 = ((0 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer2, -1532896538, "C639@23524L10,637@23433L170,644@23795L10,645@23853L11,642@23616L279:OverlayControlScreen.kt#naom5h");
                    TextKt.m2693Text4IGK_g("Zakázat vyskakovací okno", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleSmall(), composer2, 196614, 0, 65502);
                    TextKt.m2693Text4IGK_g("Nikdy nezobrazovat velké vyskakovací okno s textem odpovědi. Výsledek se zobrazí pouze jako symbol přímo v rohu.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    boolean zOverlayControlScreen$lambda$19 = OverlayControlScreen$lambda$19($isPopupCardDisabled$delegate);
                    SwitchColors switchColorsM2575colorsV1nXRL5 = SwitchDefaults.INSTANCE.m2575colorsV1nXRL4(Color.INSTANCE.m4196getWhite0d7_KjU(), com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer2, 54, SwitchDefaults.$stable << 18, 65532);
                    Modifier modifierTestTag2 = TestTagKt.testTag(Modifier.INSTANCE, "disable_popup_card_switch");
                    ComposerKt.sourceInformationMarkerStart(composer2, 298976162, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance2 = composer2.changedInstance($preferences);
                    objRememberedValue2 = composer2.rememberedValue();
                    if (!zChangedInstance2 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                        objRememberedValue2 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda6
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj) {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$84$lambda$83$lambda$78$lambda$77$lambda$76($preferences, $isPopupCardDisabled$delegate, ((Boolean) obj).booleanValue());
                            }
                        };
                        composer2.updateRememberedValue(objRememberedValue2);
                    }
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    SwitchKt.Switch(zOverlayControlScreen$lambda$19, (Function1) objRememberedValue2, modifierTestTag2, null, false, switchColorsM2575colorsV1nXRL5, null, composer2, 384, 88);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer2, 6);
                    long indigoPrimary = com.example.ui.theme.ColorKt.getIndigoPrimary();
                    SurfaceKt.m2543SurfaceT9BRK9s(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10)), Color.m4157copywmQWz5c(indigoPrimary, (14 & 1) != 0 ? Color.m4161getAlphaimpl(indigoPrimary) : 0.08f, (14 & 2) != 0 ? Color.m4165getRedimpl(indigoPrimary) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(indigoPrimary) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(indigoPrimary) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableSingletons$OverlayControlScreenKt.INSTANCE.m6940getLambda$1464817799$app(), composer2, 12583302, 120);
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                    Modifier modifierFillMaxWidth$default3 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                    Arrangement.Horizontal spaceEvenly = Arrangement.INSTANCE.getSpaceEvenly();
                    ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                    MeasurePolicy measurePolicyRowMeasurePolicy3 = RowKt.rowMeasurePolicy(spaceEvenly, Alignment.INSTANCE.getTop(), composer2, ((54 >> 3) & 14) | ((54 >> 3) & 112));
                    ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                    CompositionLocalMap currentCompositionLocalMap6 = composer2.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier6 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default3);
                    constructor5 = ComposeUiNode.INSTANCE.getConstructor();
                    int i19 = ((((54 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                    if (!(composer2.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composer2.startReusableNode();
                    if (composer2.getInserting()) {
                        function5 = constructor5;
                        composer2.createNode(function5);
                    } else {
                        function5 = constructor5;
                        composer2.useNode();
                    }
                    composerM3652constructorimpl5 = Updater.m3652constructorimpl(composer2);
                    Updater.m3659setimpl(composerM3652constructorimpl5, measurePolicyRowMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m3659setimpl(composerM3652constructorimpl5, currentCompositionLocalMap6, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash6 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (!composerM3652constructorimpl5.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl5.rememberedValue(), Integer.valueOf(currentCompositeKeyHash5))) {
                        composerM3652constructorimpl5.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash5));
                        composerM3652constructorimpl5.apply(Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash6);
                    }
                    Updater.m3659setimpl(composerM3652constructorimpl5, modifierMaterializeModifier6, ComposeUiNode.INSTANCE.getSetModifier());
                    int i20 = (i19 >> 6) & 14;
                    i2 = 0;
                    ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                    RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                    int i21 = ((54 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer2, 205737978, "C:OverlayControlScreen.kt#naom5h");
                    composer2.startReplaceGroup(145191295);
                    ComposerKt.sourceInformation(composer2, "*702@25761L591");
                    iterableListOf = CollectionsKt.listOf((Object[]) new Triple[]{new Triple("▲", Color.m4149boximpl(ColorKt.Color(4293008188L)), "Červená"), new Triple("◆", Color.m4149boximpl(ColorKt.Color(4279462094L)), "Modrá"), new Triple("●", Color.m4149boximpl(ColorKt.Color(4292386304L)), "Žlutá"), new Triple("■", Color.m4149boximpl(ColorKt.Color(4280715532L)), "Zelená")});
                    i3 = 0;
                    it = iterableListOf.iterator();
                    while (it.hasNext()) {
                        Triple triple = (Triple) it.next();
                        String str3 = (String) triple.component1();
                        long jM4169unboximpl = ((Color) triple.component2()).m4169unboximpl();
                        String str4 = (String) triple.component3();
                        Iterable iterable = iterableListOf;
                        Alignment.Horizontal centerHorizontally = Alignment.INSTANCE.getCenterHorizontally();
                        int i22 = i3;
                        Iterator it2 = it;
                        ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                        Modifier modifier = Modifier.INSTANCE;
                        int i23 = i2;
                        MeasurePolicy measurePolicyColumnMeasurePolicy4 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), centerHorizontally, composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                        ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                        currentCompositeKeyHash6 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                        CompositionLocalMap currentCompositionLocalMap7 = composer2.getCurrentCompositionLocalMap();
                        Modifier modifierMaterializeModifier7 = ComposedModifierKt.materializeModifier(composer2, modifier);
                        constructor6 = ComposeUiNode.INSTANCE.getConstructor();
                        int i24 = ((((384 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart(composer2, -692256719, str2);
                        if (!(composer2.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
                        composer2.startReusableNode();
                        if (composer2.getInserting()) {
                            function6 = constructor6;
                            composer2.createNode(function6);
                        } else {
                            function6 = constructor6;
                            composer2.useNode();
                        }
                        composerM3652constructorimpl6 = Updater.m3652constructorimpl(composer2);
                        Updater.m3659setimpl(composerM3652constructorimpl6, measurePolicyColumnMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        Updater.m3659setimpl(composerM3652constructorimpl6, currentCompositionLocalMap7, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                        Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash7 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                        if (!composerM3652constructorimpl6.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl6.rememberedValue(), Integer.valueOf(currentCompositeKeyHash6))) {
                            composerM3652constructorimpl6.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash6));
                            composerM3652constructorimpl6.apply(Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash7);
                        }
                        Updater.m3659setimpl(composerM3652constructorimpl6, modifierMaterializeModifier7, ComposeUiNode.INSTANCE.getSetModifier());
                        int i25 = (i24 >> 6) & 14;
                        ComposerKt.sourceInformationMarkerStart(composer2, -384862393, str);
                        ColumnScopeInstance columnScopeInstance4 = ColumnScopeInstance.INSTANCE;
                        int i26 = ((384 >> 6) & 112) | 6;
                        String str5 = str;
                        ComposerKt.sourceInformationMarkerStart(composer2, 1357180620, "C703@25836L345,712@26196L40,713@26309L11,713@26251L87:OverlayControlScreen.kt#naom5h");
                        Modifier modifierM225backgroundbw27NRU$default = BackgroundKt.m225backgroundbw27NRU$default(ClipKt.clip(SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(36)), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8))), jM4169unboximpl, null, 2, null);
                        Alignment center = Alignment.INSTANCE.getCenter();
                        ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                        MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(center, false);
                        ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                        currentCompositeKeyHash7 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                        CompositionLocalMap currentCompositionLocalMap8 = composer2.getCurrentCompositionLocalMap();
                        Modifier modifierMaterializeModifier8 = ComposedModifierKt.materializeModifier(composer2, modifierM225backgroundbw27NRU$default);
                        constructor7 = ComposeUiNode.INSTANCE.getConstructor();
                        int i27 = ((((48 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart(composer2, -692256719, str2);
                        if (!(composer2.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
                        composer2.startReusableNode();
                        if (composer2.getInserting()) {
                            function7 = constructor7;
                            composer2.createNode(function7);
                        } else {
                            function7 = constructor7;
                            composer2.useNode();
                        }
                        composerM3652constructorimpl7 = Updater.m3652constructorimpl(composer2);
                        String str6 = str2;
                        Updater.m3659setimpl(composerM3652constructorimpl7, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                        Updater.m3659setimpl(composerM3652constructorimpl7, currentCompositionLocalMap8, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                        Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash8 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                        if (composerM3652constructorimpl7.getInserting()) {
                            composer4 = composer2;
                        } else {
                            composer4 = composer2;
                            if (!Intrinsics.areEqual(composerM3652constructorimpl7.rememberedValue(), Integer.valueOf(currentCompositeKeyHash7))) {
                            }
                            Updater.m3659setimpl(composerM3652constructorimpl7, modifierMaterializeModifier8, ComposeUiNode.INSTANCE.getSetModifier());
                            int i28 = (i27 >> 6) & 14;
                            Composer composer5 = composer4;
                            ComposerKt.sourceInformationMarkerStart(composer5, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                            BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                            int i29 = ((48 >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart(composer5, 625702291, "C710@26080L85:OverlayControlScreen.kt#naom5h");
                            TextKt.m2693Text4IGK_g(str3, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(18), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer5, 200064, 0, 131026);
                            ComposerKt.sourceInformationMarkerEnd(composer5);
                            ComposerKt.sourceInformationMarkerEnd(composer5);
                            composer4.endNode();
                            ComposerKt.sourceInformationMarkerEnd(composer4);
                            ComposerKt.sourceInformationMarkerEnd(composer4);
                            ComposerKt.sourceInformationMarkerEnd(composer4);
                            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(4)), composer2, 6);
                            TextKt.m2693Text4IGK_g(str4, (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(10), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3072, 0, 131058);
                            ComposerKt.sourceInformationMarkerEnd(composer2);
                            ComposerKt.sourceInformationMarkerEnd(composer2);
                            composer2.endNode();
                            ComposerKt.sourceInformationMarkerEnd(composer2);
                            ComposerKt.sourceInformationMarkerEnd(composer2);
                            ComposerKt.sourceInformationMarkerEnd(composer2);
                            it = it2;
                            iterableListOf = iterable;
                            i3 = i22;
                            i2 = i23;
                            str = str5;
                            str2 = str6;
                        }
                        composerM3652constructorimpl7.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash7));
                        composerM3652constructorimpl7.apply(Integer.valueOf(currentCompositeKeyHash7), setCompositeKeyHash8);
                        Updater.m3659setimpl(composerM3652constructorimpl7, modifierMaterializeModifier8, ComposeUiNode.INSTANCE.getSetModifier());
                        int i210 = (i27 >> 6) & 14;
                        Composer composer6 = composer4;
                        ComposerKt.sourceInformationMarkerStart(composer6, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                        BoxScopeInstance boxScopeInstance2 = BoxScopeInstance.INSTANCE;
                        int i211 = ((48 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart(composer6, 625702291, "C710@26080L85:OverlayControlScreen.kt#naom5h");
                        TextKt.m2693Text4IGK_g(str3, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(18), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer6, 200064, 0, 131026);
                        ComposerKt.sourceInformationMarkerEnd(composer6);
                        ComposerKt.sourceInformationMarkerEnd(composer6);
                        composer4.endNode();
                        ComposerKt.sourceInformationMarkerEnd(composer4);
                        ComposerKt.sourceInformationMarkerEnd(composer4);
                        ComposerKt.sourceInformationMarkerEnd(composer4);
                        SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(4)), composer2, 6);
                        TextKt.m2693Text4IGK_g(str4, (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(10), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3072, 0, 131058);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        composer2.endNode();
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        it = it2;
                        iterableListOf = iterable;
                        i3 = i22;
                        i2 = i23;
                        str = str5;
                        str2 = str6;
                    }
                    composer2.endReplaceGroup();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                }
                objRememberedValue = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda5
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$84$lambda$83$lambda$74$lambda$73$lambda$72($preferences, $stealthBadgeMode$delegate, ((Boolean) obj).booleanValue());
                    }
                };
                composer2.updateRememberedValue(objRememberedValue);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                SwitchKt.Switch(zOverlayControlScreen$lambda$16, (Function1) objRememberedValue, modifierTestTag, null, false, switchColorsM2575colorsV1nXRL4, null, composer3, 384, 88);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                long outlineVariant2 = MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOutlineVariant();
                DividerKt.m2072HorizontalDivider9IZ8Weo(null, 0.0f, Color.m4157copywmQWz5c(outlineVariant2, (14 & 1) != 0 ? Color.m4161getAlphaimpl(outlineVariant2) : 0.5f, (14 & 2) != 0 ? Color.m4165getRedimpl(outlineVariant2) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(outlineVariant2) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(outlineVariant2) : 0.0f), composer2, 0, 3);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                Modifier modifierFillMaxWidth$default4 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween3 = Arrangement.INSTANCE.getSpaceBetween();
                Alignment.Vertical centerVertically3 = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy4 = RowKt.rowMeasurePolicy(spaceBetween3, centerVertically3, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap9 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier9 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default4);
                constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                int i110 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function3 = constructor3;
                    composer2.createNode(function3);
                } else {
                    function3 = constructor3;
                    composer2.useNode();
                }
                composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap9, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash9 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl3.getInserting()) {
                }
                composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash9);
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier9, ComposeUiNode.INSTANCE.getSetModifier());
                int i111 = (i110 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                int i112 = ((438 >> 6) & 112) | 6;
                RowScope rowScope3 = RowScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composer2, 677737929, "C636@23380L527,655@24143L116,651@24000L105,649@23919L422:OverlayControlScreen.kt#naom5h");
                Modifier modifierWeight$default3 = RowScope.weight$default(rowScope3, Modifier.INSTANCE, 1.0f, false, 2, null);
                ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                MeasurePolicy measurePolicyColumnMeasurePolicy5 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap10 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier10 = ComposedModifierKt.materializeModifier(composer2, modifierWeight$default3);
                constructor4 = ComposeUiNode.INSTANCE.getConstructor();
                int i113 = ((((0 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function4 = constructor4;
                    composer2.createNode(function4);
                } else {
                    function4 = constructor4;
                    composer2.useNode();
                }
                composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyColumnMeasurePolicy5, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap10, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash10 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl4.getInserting()) {
                }
                composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
                composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash10);
                Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier10, ComposeUiNode.INSTANCE.getSetModifier());
                int i114 = (i113 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance5 = ColumnScopeInstance.INSTANCE;
                int i115 = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -1532896538, "C639@23524L10,637@23433L170,644@23795L10,645@23853L11,642@23616L279:OverlayControlScreen.kt#naom5h");
                TextKt.m2693Text4IGK_g("Zakázat vyskakovací okno", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleSmall(), composer2, 196614, 0, 65502);
                TextKt.m2693Text4IGK_g("Nikdy nezobrazovat velké vyskakovací okno s textem odpovědi. Výsledek se zobrazí pouze jako symbol přímo v rohu.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                boolean zOverlayControlScreen$lambda$110 = OverlayControlScreen$lambda$19($isPopupCardDisabled$delegate);
                SwitchColors switchColorsM2575colorsV1nXRL6 = SwitchDefaults.INSTANCE.m2575colorsV1nXRL4(Color.INSTANCE.m4196getWhite0d7_KjU(), com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer2, 54, SwitchDefaults.$stable << 18, 65532);
                Modifier modifierTestTag3 = TestTagKt.testTag(Modifier.INSTANCE, "disable_popup_card_switch");
                ComposerKt.sourceInformationMarkerStart(composer2, 298976162, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance2 = composer2.changedInstance($preferences);
                objRememberedValue2 = composer2.rememberedValue();
                if (!zChangedInstance2) {
                }
                objRememberedValue2 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$84$lambda$83$lambda$78$lambda$77$lambda$76($preferences, $isPopupCardDisabled$delegate, ((Boolean) obj).booleanValue());
                    }
                };
                composer2.updateRememberedValue(objRememberedValue2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SwitchKt.Switch(zOverlayControlScreen$lambda$110, (Function1) objRememberedValue2, modifierTestTag3, null, false, switchColorsM2575colorsV1nXRL6, null, composer2, 384, 88);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer2, 6);
                long indigoPrimary2 = com.example.ui.theme.ColorKt.getIndigoPrimary();
                SurfaceKt.m2543SurfaceT9BRK9s(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10)), Color.m4157copywmQWz5c(indigoPrimary2, (14 & 1) != 0 ? Color.m4161getAlphaimpl(indigoPrimary2) : 0.08f, (14 & 2) != 0 ? Color.m4165getRedimpl(indigoPrimary2) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(indigoPrimary2) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(indigoPrimary2) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableSingletons$OverlayControlScreenKt.INSTANCE.m6940getLambda$1464817799$app(), composer2, 12583302, 120);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                Modifier modifierFillMaxWidth$default5 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceEvenly2 = Arrangement.INSTANCE.getSpaceEvenly();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy5 = RowKt.rowMeasurePolicy(spaceEvenly2, Alignment.INSTANCE.getTop(), composer2, ((54 >> 3) & 14) | ((54 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap11 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier11 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default5);
                constructor5 = ComposeUiNode.INSTANCE.getConstructor();
                int i116 = ((((54 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function5 = constructor5;
                    composer2.createNode(function5);
                } else {
                    function5 = constructor5;
                    composer2.useNode();
                }
                composerM3652constructorimpl5 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl5, measurePolicyRowMeasurePolicy5, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl5, currentCompositionLocalMap11, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash11 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl5.getInserting()) {
                }
                composerM3652constructorimpl5.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash5));
                composerM3652constructorimpl5.apply(Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash11);
                Updater.m3659setimpl(composerM3652constructorimpl5, modifierMaterializeModifier11, ComposeUiNode.INSTANCE.getSetModifier());
                int i212 = (i116 >> 6) & 14;
                i2 = 0;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                int i213 = ((54 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 205737978, "C:OverlayControlScreen.kt#naom5h");
                composer2.startReplaceGroup(145191295);
                ComposerKt.sourceInformation(composer2, "*702@25761L591");
                iterableListOf = CollectionsKt.listOf((Object[]) new Triple[]{new Triple("▲", Color.m4149boximpl(ColorKt.Color(4293008188L)), "Červená"), new Triple("◆", Color.m4149boximpl(ColorKt.Color(4279462094L)), "Modrá"), new Triple("●", Color.m4149boximpl(ColorKt.Color(4292386304L)), "Žlutá"), new Triple("■", Color.m4149boximpl(ColorKt.Color(4280715532L)), "Zelená")});
                i3 = 0;
                it = iterableListOf.iterator();
                while (it.hasNext()) {
                    Triple triple2 = (Triple) it.next();
                    String str7 = (String) triple2.component1();
                    long jM4169unboximpl2 = ((Color) triple2.component2()).m4169unboximpl();
                    String str8 = (String) triple2.component3();
                    Iterable iterable2 = iterableListOf;
                    Alignment.Horizontal centerHorizontally2 = Alignment.INSTANCE.getCenterHorizontally();
                    int i214 = i3;
                    Iterator it3 = it;
                    ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                    Modifier modifier2 = Modifier.INSTANCE;
                    int i215 = i2;
                    MeasurePolicy measurePolicyColumnMeasurePolicy6 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), centerHorizontally2, composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                    ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash6 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                    CompositionLocalMap currentCompositionLocalMap12 = composer2.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier12 = ComposedModifierKt.materializeModifier(composer2, modifier2);
                    constructor6 = ComposeUiNode.INSTANCE.getConstructor();
                    int i216 = ((((384 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer2, -692256719, str2);
                    if (!(composer2.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composer2.startReusableNode();
                    if (composer2.getInserting()) {
                        function6 = constructor6;
                        composer2.createNode(function6);
                    } else {
                        function6 = constructor6;
                        composer2.useNode();
                    }
                    composerM3652constructorimpl6 = Updater.m3652constructorimpl(composer2);
                    Updater.m3659setimpl(composerM3652constructorimpl6, measurePolicyColumnMeasurePolicy6, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m3659setimpl(composerM3652constructorimpl6, currentCompositionLocalMap12, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash12 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (!composerM3652constructorimpl6.getInserting()) {
                    }
                    composerM3652constructorimpl6.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash6));
                    composerM3652constructorimpl6.apply(Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash12);
                    Updater.m3659setimpl(composerM3652constructorimpl6, modifierMaterializeModifier12, ComposeUiNode.INSTANCE.getSetModifier());
                    int i217 = (i216 >> 6) & 14;
                    ComposerKt.sourceInformationMarkerStart(composer2, -384862393, str);
                    ColumnScopeInstance columnScopeInstance6 = ColumnScopeInstance.INSTANCE;
                    int i218 = ((384 >> 6) & 112) | 6;
                    String str9 = str;
                    ComposerKt.sourceInformationMarkerStart(composer2, 1357180620, "C703@25836L345,712@26196L40,713@26309L11,713@26251L87:OverlayControlScreen.kt#naom5h");
                    Modifier modifierM225backgroundbw27NRU$default2 = BackgroundKt.m225backgroundbw27NRU$default(ClipKt.clip(SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(36)), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8))), jM4169unboximpl2, null, 2, null);
                    Alignment center2 = Alignment.INSTANCE.getCenter();
                    ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                    MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy2 = BoxKt.maybeCachedBoxMeasurePolicy(center2, false);
                    ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash7 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                    CompositionLocalMap currentCompositionLocalMap13 = composer2.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier13 = ComposedModifierKt.materializeModifier(composer2, modifierM225backgroundbw27NRU$default2);
                    constructor7 = ComposeUiNode.INSTANCE.getConstructor();
                    int i219 = ((((48 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer2, -692256719, str2);
                    if (!(composer2.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composer2.startReusableNode();
                    if (composer2.getInserting()) {
                        function7 = constructor7;
                        composer2.createNode(function7);
                    } else {
                        function7 = constructor7;
                        composer2.useNode();
                    }
                    composerM3652constructorimpl7 = Updater.m3652constructorimpl(composer2);
                    String str10 = str2;
                    Updater.m3659setimpl(composerM3652constructorimpl7, measurePolicyMaybeCachedBoxMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m3659setimpl(composerM3652constructorimpl7, currentCompositionLocalMap13, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash13 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (composerM3652constructorimpl7.getInserting()) {
                        composer4 = composer2;
                        if (!Intrinsics.areEqual(composerM3652constructorimpl7.rememberedValue(), Integer.valueOf(currentCompositeKeyHash7))) {
                        }
                        Updater.m3659setimpl(composerM3652constructorimpl7, modifierMaterializeModifier13, ComposeUiNode.INSTANCE.getSetModifier());
                        int i2110 = (i219 >> 6) & 14;
                        Composer composer7 = composer4;
                        ComposerKt.sourceInformationMarkerStart(composer7, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                        BoxScopeInstance boxScopeInstance3 = BoxScopeInstance.INSTANCE;
                        int i2111 = ((48 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart(composer7, 625702291, "C710@26080L85:OverlayControlScreen.kt#naom5h");
                        TextKt.m2693Text4IGK_g(str7, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(18), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer7, 200064, 0, 131026);
                        ComposerKt.sourceInformationMarkerEnd(composer7);
                        ComposerKt.sourceInformationMarkerEnd(composer7);
                        composer4.endNode();
                        ComposerKt.sourceInformationMarkerEnd(composer4);
                        ComposerKt.sourceInformationMarkerEnd(composer4);
                        ComposerKt.sourceInformationMarkerEnd(composer4);
                        SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(4)), composer2, 6);
                        TextKt.m2693Text4IGK_g(str8, (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(10), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3072, 0, 131058);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        composer2.endNode();
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        it = it3;
                        iterableListOf = iterable2;
                        i3 = i214;
                        i2 = i215;
                        str = str9;
                        str2 = str10;
                    } else {
                        composer4 = composer2;
                    }
                    composerM3652constructorimpl7.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash7));
                    composerM3652constructorimpl7.apply(Integer.valueOf(currentCompositeKeyHash7), setCompositeKeyHash13);
                    Updater.m3659setimpl(composerM3652constructorimpl7, modifierMaterializeModifier13, ComposeUiNode.INSTANCE.getSetModifier());
                    int i2112 = (i219 >> 6) & 14;
                    Composer composer8 = composer4;
                    ComposerKt.sourceInformationMarkerStart(composer8, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                    BoxScopeInstance boxScopeInstance4 = BoxScopeInstance.INSTANCE;
                    int i2113 = ((48 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer8, 625702291, "C710@26080L85:OverlayControlScreen.kt#naom5h");
                    TextKt.m2693Text4IGK_g(str7, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(18), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer8, 200064, 0, 131026);
                    ComposerKt.sourceInformationMarkerEnd(composer8);
                    ComposerKt.sourceInformationMarkerEnd(composer8);
                    composer4.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(4)), composer2, 6);
                    TextKt.m2693Text4IGK_g(str8, (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(10), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3072, 0, 131058);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    it = it3;
                    iterableListOf = iterable2;
                    i3 = i214;
                    i2 = i215;
                    str = str9;
                    str2 = str10;
                }
                composer2.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composerM3652constructorimpl8.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash8));
            composerM3652constructorimpl8.apply(Integer.valueOf(currentCompositeKeyHash8), setCompositeKeyHash);
            Updater.m3659setimpl(composerM3652constructorimpl8, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i30 = (i4 >> 6) & 14;
            composer2 = composer;
            str = "C87@4365L9:Column.kt#2w3rfo";
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance7 = ColumnScopeInstance.INSTANCE;
            int i31 = ((i >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 1156804460, "C592@21805L1129,624@22944L41,626@23035L11,626@22995L86,628@23091L41,631@23190L1161,663@24361L41,665@24412L848,689@25270L41,692@25354L1020:OverlayControlScreen.kt#naom5h");
            Modifier modifierFillMaxWidth$default6 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween4 = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically4 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy6 = RowKt.rowMeasurePolicy(spaceBetween4, centerVertically4, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap14 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier14 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default6);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i32 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function1 = constructor;
                composer2.createNode(function1);
            } else {
                function1 = constructor;
                composer2.useNode();
            }
            composerM3652constructorimpl = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy6, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap14, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash14 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl.getInserting()) {
            }
            composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash14);
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier14, ComposeUiNode.INSTANCE.getSetModifier());
            int i33 = (i32 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            int i34 = ((438 >> 6) & 112) | 6;
            RowScope rowScope4 = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer2, -2027971200, "C597@21995L507,616@22731L116,612@22592L101,610@22514L410:OverlayControlScreen.kt#naom5h");
            Modifier modifierWeight$default4 = RowScope.weight$default(rowScope4, Modifier.INSTANCE, 1.0f, false, 2, null);
            ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy7 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap15 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier15 = ComposedModifierKt.materializeModifier(composer2, modifierWeight$default4);
            constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i117 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function2 = constructor2;
                composer2.createNode(function2);
            } else {
                function2 = constructor2;
                composer2.useNode();
            }
            composerM3652constructorimpl2 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyColumnMeasurePolicy7, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap15, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash15 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl2.getInserting()) {
            }
            composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash15);
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier15, ComposeUiNode.INSTANCE.getSetModifier());
            int i118 = (i117 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance8 = ColumnScopeInstance.INSTANCE;
            int i119 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 611053201, "C600@22147L10,598@22048L178,605@22390L10,606@22448L11,603@22239L251:OverlayControlScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g("Diskrétní rohový režim (Stealth)", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleSmall(), composer2, 196614, 0, 65502);
            TextKt.m2693Text4IGK_g("Ukázat POUZE maličký symbol a barvu v rohu (▲ ◆ ● ■) bez jakéhokoliv textového okna.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            boolean zOverlayControlScreen$lambda$17 = OverlayControlScreen$lambda$16($stealthBadgeMode$delegate);
            SwitchColors switchColorsM2575colorsV1nXRL7 = SwitchDefaults.INSTANCE.m2575colorsV1nXRL4(Color.INSTANCE.m4196getWhite0d7_KjU(), com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer2, 54, SwitchDefaults.$stable << 18, 65532);
            Modifier modifierTestTag4 = TestTagKt.testTag(Modifier.INSTANCE, "stealth_badge_switch");
            ComposerKt.sourceInformationMarkerStart(composer2, 904431175, "CC(remember):OverlayControlScreen.kt#9igjgp");
            zChangedInstance = composer2.changedInstance($preferences);
            objRememberedValue = composer2.rememberedValue();
            if (zChangedInstance) {
                composer3 = composer2;
                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                }
                ComposerKt.sourceInformationMarkerEnd(composer3);
                SwitchKt.Switch(zOverlayControlScreen$lambda$17, (Function1) objRememberedValue, modifierTestTag4, null, false, switchColorsM2575colorsV1nXRL7, null, composer3, 384, 88);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                long outlineVariant3 = MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOutlineVariant();
                DividerKt.m2072HorizontalDivider9IZ8Weo(null, 0.0f, Color.m4157copywmQWz5c(outlineVariant3, (14 & 1) != 0 ? Color.m4161getAlphaimpl(outlineVariant3) : 0.5f, (14 & 2) != 0 ? Color.m4165getRedimpl(outlineVariant3) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(outlineVariant3) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(outlineVariant3) : 0.0f), composer2, 0, 3);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                Modifier modifierFillMaxWidth$default7 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween5 = Arrangement.INSTANCE.getSpaceBetween();
                Alignment.Vertical centerVertically5 = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy7 = RowKt.rowMeasurePolicy(spaceBetween5, centerVertically5, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap16 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier16 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default7);
                constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                int i1110 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function3 = constructor3;
                    composer2.createNode(function3);
                } else {
                    function3 = constructor3;
                    composer2.useNode();
                }
                composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy7, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap16, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash16 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl3.getInserting()) {
                }
                composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash16);
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier16, ComposeUiNode.INSTANCE.getSetModifier());
                int i1111 = (i1110 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                int i1112 = ((438 >> 6) & 112) | 6;
                RowScope rowScope5 = RowScopeInstance.INSTANCE;
                ComposerKt.sourceInformationMarkerStart(composer2, 677737929, "C636@23380L527,655@24143L116,651@24000L105,649@23919L422:OverlayControlScreen.kt#naom5h");
                Modifier modifierWeight$default5 = RowScope.weight$default(rowScope5, Modifier.INSTANCE, 1.0f, false, 2, null);
                ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                MeasurePolicy measurePolicyColumnMeasurePolicy8 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap17 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier17 = ComposedModifierKt.materializeModifier(composer2, modifierWeight$default5);
                constructor4 = ComposeUiNode.INSTANCE.getConstructor();
                int i1113 = ((((0 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function4 = constructor4;
                    composer2.createNode(function4);
                } else {
                    function4 = constructor4;
                    composer2.useNode();
                }
                composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyColumnMeasurePolicy8, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap17, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash17 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl4.getInserting()) {
                }
                composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
                composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash17);
                Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier17, ComposeUiNode.INSTANCE.getSetModifier());
                int i1114 = (i1113 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance9 = ColumnScopeInstance.INSTANCE;
                int i1115 = ((0 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -1532896538, "C639@23524L10,637@23433L170,644@23795L10,645@23853L11,642@23616L279:OverlayControlScreen.kt#naom5h");
                TextKt.m2693Text4IGK_g("Zakázat vyskakovací okno", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleSmall(), composer2, 196614, 0, 65502);
                TextKt.m2693Text4IGK_g("Nikdy nezobrazovat velké vyskakovací okno s textem odpovědi. Výsledek se zobrazí pouze jako symbol přímo v rohu.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                boolean zOverlayControlScreen$lambda$111 = OverlayControlScreen$lambda$19($isPopupCardDisabled$delegate);
                SwitchColors switchColorsM2575colorsV1nXRL8 = SwitchDefaults.INSTANCE.m2575colorsV1nXRL4(Color.INSTANCE.m4196getWhite0d7_KjU(), com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer2, 54, SwitchDefaults.$stable << 18, 65532);
                Modifier modifierTestTag5 = TestTagKt.testTag(Modifier.INSTANCE, "disable_popup_card_switch");
                ComposerKt.sourceInformationMarkerStart(composer2, 298976162, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance2 = composer2.changedInstance($preferences);
                objRememberedValue2 = composer2.rememberedValue();
                if (!zChangedInstance2) {
                }
                objRememberedValue2 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$84$lambda$83$lambda$78$lambda$77$lambda$76($preferences, $isPopupCardDisabled$delegate, ((Boolean) obj).booleanValue());
                    }
                };
                composer2.updateRememberedValue(objRememberedValue2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SwitchKt.Switch(zOverlayControlScreen$lambda$111, (Function1) objRememberedValue2, modifierTestTag5, null, false, switchColorsM2575colorsV1nXRL8, null, composer2, 384, 88);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer2, 6);
                long indigoPrimary3 = com.example.ui.theme.ColorKt.getIndigoPrimary();
                SurfaceKt.m2543SurfaceT9BRK9s(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10)), Color.m4157copywmQWz5c(indigoPrimary3, (14 & 1) != 0 ? Color.m4161getAlphaimpl(indigoPrimary3) : 0.08f, (14 & 2) != 0 ? Color.m4165getRedimpl(indigoPrimary3) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(indigoPrimary3) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(indigoPrimary3) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableSingletons$OverlayControlScreenKt.INSTANCE.m6940getLambda$1464817799$app(), composer2, 12583302, 120);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
                Modifier modifierFillMaxWidth$default8 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceEvenly3 = Arrangement.INSTANCE.getSpaceEvenly();
                ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy8 = RowKt.rowMeasurePolicy(spaceEvenly3, Alignment.INSTANCE.getTop(), composer2, ((54 >> 3) & 14) | ((54 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap18 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier18 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default8);
                constructor5 = ComposeUiNode.INSTANCE.getConstructor();
                int i1116 = ((((54 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function5 = constructor5;
                    composer2.createNode(function5);
                } else {
                    function5 = constructor5;
                    composer2.useNode();
                }
                composerM3652constructorimpl5 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl5, measurePolicyRowMeasurePolicy8, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl5, currentCompositionLocalMap18, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash18 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl5.getInserting()) {
                }
                composerM3652constructorimpl5.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash5));
                composerM3652constructorimpl5.apply(Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash18);
                Updater.m3659setimpl(composerM3652constructorimpl5, modifierMaterializeModifier18, ComposeUiNode.INSTANCE.getSetModifier());
                int i2114 = (i1116 >> 6) & 14;
                i2 = 0;
                ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance3 = RowScopeInstance.INSTANCE;
                int i2115 = ((54 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, 205737978, "C:OverlayControlScreen.kt#naom5h");
                composer2.startReplaceGroup(145191295);
                ComposerKt.sourceInformation(composer2, "*702@25761L591");
                iterableListOf = CollectionsKt.listOf((Object[]) new Triple[]{new Triple("▲", Color.m4149boximpl(ColorKt.Color(4293008188L)), "Červená"), new Triple("◆", Color.m4149boximpl(ColorKt.Color(4279462094L)), "Modrá"), new Triple("●", Color.m4149boximpl(ColorKt.Color(4292386304L)), "Žlutá"), new Triple("■", Color.m4149boximpl(ColorKt.Color(4280715532L)), "Zelená")});
                i3 = 0;
                it = iterableListOf.iterator();
                while (it.hasNext()) {
                    Triple triple3 = (Triple) it.next();
                    String str11 = (String) triple3.component1();
                    long jM4169unboximpl3 = ((Color) triple3.component2()).m4169unboximpl();
                    String str12 = (String) triple3.component3();
                    Iterable iterable3 = iterableListOf;
                    Alignment.Horizontal centerHorizontally3 = Alignment.INSTANCE.getCenterHorizontally();
                    int i2116 = i3;
                    Iterator it4 = it;
                    ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                    Modifier modifier3 = Modifier.INSTANCE;
                    int i2117 = i2;
                    MeasurePolicy measurePolicyColumnMeasurePolicy9 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), centerHorizontally3, composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                    ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash6 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                    CompositionLocalMap currentCompositionLocalMap19 = composer2.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier19 = ComposedModifierKt.materializeModifier(composer2, modifier3);
                    constructor6 = ComposeUiNode.INSTANCE.getConstructor();
                    int i2118 = ((((384 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer2, -692256719, str2);
                    if (!(composer2.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composer2.startReusableNode();
                    if (composer2.getInserting()) {
                        function6 = constructor6;
                        composer2.createNode(function6);
                    } else {
                        function6 = constructor6;
                        composer2.useNode();
                    }
                    composerM3652constructorimpl6 = Updater.m3652constructorimpl(composer2);
                    Updater.m3659setimpl(composerM3652constructorimpl6, measurePolicyColumnMeasurePolicy9, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m3659setimpl(composerM3652constructorimpl6, currentCompositionLocalMap19, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash19 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (!composerM3652constructorimpl6.getInserting()) {
                    }
                    composerM3652constructorimpl6.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash6));
                    composerM3652constructorimpl6.apply(Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash19);
                    Updater.m3659setimpl(composerM3652constructorimpl6, modifierMaterializeModifier19, ComposeUiNode.INSTANCE.getSetModifier());
                    int i2119 = (i2118 >> 6) & 14;
                    ComposerKt.sourceInformationMarkerStart(composer2, -384862393, str);
                    ColumnScopeInstance columnScopeInstance10 = ColumnScopeInstance.INSTANCE;
                    int i2120 = ((384 >> 6) & 112) | 6;
                    String str13 = str;
                    ComposerKt.sourceInformationMarkerStart(composer2, 1357180620, "C703@25836L345,712@26196L40,713@26309L11,713@26251L87:OverlayControlScreen.kt#naom5h");
                    Modifier modifierM225backgroundbw27NRU$default3 = BackgroundKt.m225backgroundbw27NRU$default(ClipKt.clip(SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(36)), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8))), jM4169unboximpl3, null, 2, null);
                    Alignment center3 = Alignment.INSTANCE.getCenter();
                    ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                    MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy3 = BoxKt.maybeCachedBoxMeasurePolicy(center3, false);
                    ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                    currentCompositeKeyHash7 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                    CompositionLocalMap currentCompositionLocalMap110 = composer2.getCurrentCompositionLocalMap();
                    Modifier modifierMaterializeModifier110 = ComposedModifierKt.materializeModifier(composer2, modifierM225backgroundbw27NRU$default3);
                    constructor7 = ComposeUiNode.INSTANCE.getConstructor();
                    int i2121 = ((((48 << 3) & 112) << 6) & 896) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer2, -692256719, str2);
                    if (!(composer2.getApplier() instanceof Applier)) {
                        ComposablesKt.invalidApplier();
                    }
                    composer2.startReusableNode();
                    if (composer2.getInserting()) {
                        function7 = constructor7;
                        composer2.createNode(function7);
                    } else {
                        function7 = constructor7;
                        composer2.useNode();
                    }
                    composerM3652constructorimpl7 = Updater.m3652constructorimpl(composer2);
                    String str14 = str2;
                    Updater.m3659setimpl(composerM3652constructorimpl7, measurePolicyMaybeCachedBoxMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                    Updater.m3659setimpl(composerM3652constructorimpl7, currentCompositionLocalMap110, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash110 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                    if (composerM3652constructorimpl7.getInserting()) {
                        composer4 = composer2;
                        if (!Intrinsics.areEqual(composerM3652constructorimpl7.rememberedValue(), Integer.valueOf(currentCompositeKeyHash7))) {
                        }
                        Updater.m3659setimpl(composerM3652constructorimpl7, modifierMaterializeModifier110, ComposeUiNode.INSTANCE.getSetModifier());
                        int i21110 = (i2121 >> 6) & 14;
                        Composer composer9 = composer4;
                        ComposerKt.sourceInformationMarkerStart(composer9, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                        BoxScopeInstance boxScopeInstance5 = BoxScopeInstance.INSTANCE;
                        int i21111 = ((48 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart(composer9, 625702291, "C710@26080L85:OverlayControlScreen.kt#naom5h");
                        TextKt.m2693Text4IGK_g(str11, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(18), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer9, 200064, 0, 131026);
                        ComposerKt.sourceInformationMarkerEnd(composer9);
                        ComposerKt.sourceInformationMarkerEnd(composer9);
                        composer4.endNode();
                        ComposerKt.sourceInformationMarkerEnd(composer4);
                        ComposerKt.sourceInformationMarkerEnd(composer4);
                        ComposerKt.sourceInformationMarkerEnd(composer4);
                        SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(4)), composer2, 6);
                        TextKt.m2693Text4IGK_g(str12, (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(10), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3072, 0, 131058);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        composer2.endNode();
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        it = it4;
                        iterableListOf = iterable3;
                        i3 = i2116;
                        i2 = i2117;
                        str = str13;
                        str2 = str14;
                    } else {
                        composer4 = composer2;
                    }
                    composerM3652constructorimpl7.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash7));
                    composerM3652constructorimpl7.apply(Integer.valueOf(currentCompositeKeyHash7), setCompositeKeyHash110);
                    Updater.m3659setimpl(composerM3652constructorimpl7, modifierMaterializeModifier110, ComposeUiNode.INSTANCE.getSetModifier());
                    int i21112 = (i2121 >> 6) & 14;
                    Composer composer10 = composer4;
                    ComposerKt.sourceInformationMarkerStart(composer10, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                    BoxScopeInstance boxScopeInstance6 = BoxScopeInstance.INSTANCE;
                    int i21113 = ((48 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer10, 625702291, "C710@26080L85:OverlayControlScreen.kt#naom5h");
                    TextKt.m2693Text4IGK_g(str11, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(18), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer10, 200064, 0, 131026);
                    ComposerKt.sourceInformationMarkerEnd(composer10);
                    ComposerKt.sourceInformationMarkerEnd(composer10);
                    composer4.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(4)), composer2, 6);
                    TextKt.m2693Text4IGK_g(str12, (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(10), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3072, 0, 131058);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    it = it4;
                    iterableListOf = iterable3;
                    i3 = i2116;
                    i2 = i2117;
                    str = str13;
                    str2 = str14;
                }
                composer2.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composer3 = composer2;
            }
            objRememberedValue = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda5
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$84$lambda$83$lambda$74$lambda$73$lambda$72($preferences, $stealthBadgeMode$delegate, ((Boolean) obj).booleanValue());
                }
            };
            composer2.updateRememberedValue(objRememberedValue);
            ComposerKt.sourceInformationMarkerEnd(composer3);
            SwitchKt.Switch(zOverlayControlScreen$lambda$17, (Function1) objRememberedValue, modifierTestTag4, null, false, switchColorsM2575colorsV1nXRL7, null, composer3, 384, 88);
            ComposerKt.sourceInformationMarkerEnd(composer3);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
            long outlineVariant4 = MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOutlineVariant();
            DividerKt.m2072HorizontalDivider9IZ8Weo(null, 0.0f, Color.m4157copywmQWz5c(outlineVariant4, (14 & 1) != 0 ? Color.m4161getAlphaimpl(outlineVariant4) : 0.5f, (14 & 2) != 0 ? Color.m4165getRedimpl(outlineVariant4) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(outlineVariant4) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(outlineVariant4) : 0.0f), composer2, 0, 3);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
            Modifier modifierFillMaxWidth$default9 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween6 = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically6 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy9 = RowKt.rowMeasurePolicy(spaceBetween6, centerVertically6, composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap111 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier111 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default9);
            constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            int i1117 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function3 = constructor3;
                composer2.createNode(function3);
            } else {
                function3 = constructor3;
                composer2.useNode();
            }
            composerM3652constructorimpl3 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy9, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap111, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash111 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl3.getInserting()) {
            }
            composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
            composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash111);
            Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier111, ComposeUiNode.INSTANCE.getSetModifier());
            int i1118 = (i1117 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            int i1119 = ((438 >> 6) & 112) | 6;
            RowScope rowScope6 = RowScopeInstance.INSTANCE;
            ComposerKt.sourceInformationMarkerStart(composer2, 677737929, "C636@23380L527,655@24143L116,651@24000L105,649@23919L422:OverlayControlScreen.kt#naom5h");
            Modifier modifierWeight$default6 = RowScope.weight$default(rowScope6, Modifier.INSTANCE, 1.0f, false, 2, null);
            ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            MeasurePolicy measurePolicyColumnMeasurePolicy10 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap112 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier112 = ComposedModifierKt.materializeModifier(composer2, modifierWeight$default6);
            constructor4 = ComposeUiNode.INSTANCE.getConstructor();
            int i11110 = ((((0 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function4 = constructor4;
                composer2.createNode(function4);
            } else {
                function4 = constructor4;
                composer2.useNode();
            }
            composerM3652constructorimpl4 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyColumnMeasurePolicy10, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap112, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash112 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl4.getInserting()) {
            }
            composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
            composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash112);
            Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier112, ComposeUiNode.INSTANCE.getSetModifier());
            int i11111 = (i11110 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart(composer2, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance11 = ColumnScopeInstance.INSTANCE;
            int i11112 = ((0 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -1532896538, "C639@23524L10,637@23433L170,644@23795L10,645@23853L11,642@23616L279:OverlayControlScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g("Zakázat vyskakovací okno", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleSmall(), composer2, 196614, 0, 65502);
            TextKt.m2693Text4IGK_g("Nikdy nezobrazovat velké vyskakovací okno s textem odpovědi. Výsledek se zobrazí pouze jako symbol přímo v rohu.", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodySmall(), composer2, 6, 0, 65530);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            boolean zOverlayControlScreen$lambda$112 = OverlayControlScreen$lambda$19($isPopupCardDisabled$delegate);
            SwitchColors switchColorsM2575colorsV1nXRL9 = SwitchDefaults.INSTANCE.m2575colorsV1nXRL4(Color.INSTANCE.m4196getWhite0d7_KjU(), com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, composer2, 54, SwitchDefaults.$stable << 18, 65532);
            Modifier modifierTestTag6 = TestTagKt.testTag(Modifier.INSTANCE, "disable_popup_card_switch");
            ComposerKt.sourceInformationMarkerStart(composer2, 298976162, "CC(remember):OverlayControlScreen.kt#9igjgp");
            zChangedInstance2 = composer2.changedInstance($preferences);
            objRememberedValue2 = composer2.rememberedValue();
            if (!zChangedInstance2) {
            }
            objRememberedValue2 = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda6
                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Object obj) {
                    return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$84$lambda$83$lambda$78$lambda$77$lambda$76($preferences, $isPopupCardDisabled$delegate, ((Boolean) obj).booleanValue());
                }
            };
            composer2.updateRememberedValue(objRememberedValue2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SwitchKt.Switch(zOverlayControlScreen$lambda$112, (Function1) objRememberedValue2, modifierTestTag6, null, false, switchColorsM2575colorsV1nXRL9, null, composer2, 384, 88);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), composer2, 6);
            long indigoPrimary4 = com.example.ui.theme.ColorKt.getIndigoPrimary();
            SurfaceKt.m2543SurfaceT9BRK9s(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10)), Color.m4157copywmQWz5c(indigoPrimary4, (14 & 1) != 0 ? Color.m4161getAlphaimpl(indigoPrimary4) : 0.08f, (14 & 2) != 0 ? Color.m4165getRedimpl(indigoPrimary4) : 0.0f, (14 & 4) != 0 ? Color.m4164getGreenimpl(indigoPrimary4) : 0.0f, (14 & 8) != 0 ? Color.m4162getBlueimpl(indigoPrimary4) : 0.0f), 0L, 0.0f, 0.0f, null, ComposableSingletons$OverlayControlScreenKt.INSTANCE.m6940getLambda$1464817799$app(), composer2, 12583302, 120);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16)), composer2, 6);
            Modifier modifierFillMaxWidth$default10 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceEvenly4 = Arrangement.INSTANCE.getSpaceEvenly();
            ComposerKt.sourceInformationMarkerStart(composer2, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy10 = RowKt.rowMeasurePolicy(spaceEvenly4, Alignment.INSTANCE.getTop(), composer2, ((54 >> 3) & 14) | ((54 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
            CompositionLocalMap currentCompositionLocalMap113 = composer2.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier113 = ComposedModifierKt.materializeModifier(composer2, modifierFillMaxWidth$default10);
            constructor5 = ComposeUiNode.INSTANCE.getConstructor();
            int i11113 = ((((54 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!(composer2.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            composer2.startReusableNode();
            if (composer2.getInserting()) {
                function5 = constructor5;
                composer2.createNode(function5);
            } else {
                function5 = constructor5;
                composer2.useNode();
            }
            composerM3652constructorimpl5 = Updater.m3652constructorimpl(composer2);
            Updater.m3659setimpl(composerM3652constructorimpl5, measurePolicyRowMeasurePolicy10, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl5, currentCompositionLocalMap113, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash113 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl5.getInserting()) {
            }
            composerM3652constructorimpl5.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash5));
            composerM3652constructorimpl5.apply(Integer.valueOf(currentCompositeKeyHash5), setCompositeKeyHash113);
            Updater.m3659setimpl(composerM3652constructorimpl5, modifierMaterializeModifier113, ComposeUiNode.INSTANCE.getSetModifier());
            int i21114 = (i11113 >> 6) & 14;
            i2 = 0;
            ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance4 = RowScopeInstance.INSTANCE;
            int i21115 = ((54 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer2, 205737978, "C:OverlayControlScreen.kt#naom5h");
            composer2.startReplaceGroup(145191295);
            ComposerKt.sourceInformation(composer2, "*702@25761L591");
            iterableListOf = CollectionsKt.listOf((Object[]) new Triple[]{new Triple("▲", Color.m4149boximpl(ColorKt.Color(4293008188L)), "Červená"), new Triple("◆", Color.m4149boximpl(ColorKt.Color(4279462094L)), "Modrá"), new Triple("●", Color.m4149boximpl(ColorKt.Color(4292386304L)), "Žlutá"), new Triple("■", Color.m4149boximpl(ColorKt.Color(4280715532L)), "Zelená")});
            i3 = 0;
            it = iterableListOf.iterator();
            while (it.hasNext()) {
                Triple triple4 = (Triple) it.next();
                String str15 = (String) triple4.component1();
                long jM4169unboximpl4 = ((Color) triple4.component2()).m4169unboximpl();
                String str16 = (String) triple4.component3();
                Iterable iterable4 = iterableListOf;
                Alignment.Horizontal centerHorizontally4 = Alignment.INSTANCE.getCenterHorizontally();
                int i21116 = i3;
                Iterator it5 = it;
                ComposerKt.sourceInformationMarkerStart(composer2, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
                Modifier modifier4 = Modifier.INSTANCE;
                int i21117 = i2;
                MeasurePolicy measurePolicyColumnMeasurePolicy11 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), centerHorizontally4, composer2, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash6 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap114 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier114 = ComposedModifierKt.materializeModifier(composer2, modifier4);
                constructor6 = ComposeUiNode.INSTANCE.getConstructor();
                int i21118 = ((((384 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, str2);
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function6 = constructor6;
                    composer2.createNode(function6);
                } else {
                    function6 = constructor6;
                    composer2.useNode();
                }
                composerM3652constructorimpl6 = Updater.m3652constructorimpl(composer2);
                Updater.m3659setimpl(composerM3652constructorimpl6, measurePolicyColumnMeasurePolicy11, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl6, currentCompositionLocalMap114, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash114 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl6.getInserting()) {
                }
                composerM3652constructorimpl6.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash6));
                composerM3652constructorimpl6.apply(Integer.valueOf(currentCompositeKeyHash6), setCompositeKeyHash114);
                Updater.m3659setimpl(composerM3652constructorimpl6, modifierMaterializeModifier114, ComposeUiNode.INSTANCE.getSetModifier());
                int i21119 = (i21118 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart(composer2, -384862393, str);
                ColumnScopeInstance columnScopeInstance12 = ColumnScopeInstance.INSTANCE;
                int i2122 = ((384 >> 6) & 112) | 6;
                String str17 = str;
                ComposerKt.sourceInformationMarkerStart(composer2, 1357180620, "C703@25836L345,712@26196L40,713@26309L11,713@26251L87:OverlayControlScreen.kt#naom5h");
                Modifier modifierM225backgroundbw27NRU$default4 = BackgroundKt.m225backgroundbw27NRU$default(ClipKt.clip(SizeKt.m715size3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(36)), RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(8))), jM4169unboximpl4, null, 2, null);
                Alignment center4 = Alignment.INSTANCE.getCenter();
                ComposerKt.sourceInformationMarkerStart(composer2, 733328855, "CC(Box)P(2,1,3)72@3384L130:Box.kt#2w3rfo");
                MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy4 = BoxKt.maybeCachedBoxMeasurePolicy(center4, false);
                ComposerKt.sourceInformationMarkerStart(composer2, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash7 = ComposablesKt.getCurrentCompositeKeyHash(composer2, 0);
                CompositionLocalMap currentCompositionLocalMap115 = composer2.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier115 = ComposedModifierKt.materializeModifier(composer2, modifierM225backgroundbw27NRU$default4);
                constructor7 = ComposeUiNode.INSTANCE.getConstructor();
                int i2123 = ((((48 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart(composer2, -692256719, str2);
                if (!(composer2.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                composer2.startReusableNode();
                if (composer2.getInserting()) {
                    function7 = constructor7;
                    composer2.createNode(function7);
                } else {
                    function7 = constructor7;
                    composer2.useNode();
                }
                composerM3652constructorimpl7 = Updater.m3652constructorimpl(composer2);
                String str18 = str2;
                Updater.m3659setimpl(composerM3652constructorimpl7, measurePolicyMaybeCachedBoxMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl7, currentCompositionLocalMap115, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash115 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (composerM3652constructorimpl7.getInserting()) {
                    composer4 = composer2;
                    if (!Intrinsics.areEqual(composerM3652constructorimpl7.rememberedValue(), Integer.valueOf(currentCompositeKeyHash7))) {
                    }
                    Updater.m3659setimpl(composerM3652constructorimpl7, modifierMaterializeModifier115, ComposeUiNode.INSTANCE.getSetModifier());
                    int i211110 = (i2123 >> 6) & 14;
                    Composer composer11 = composer4;
                    ComposerKt.sourceInformationMarkerStart(composer11, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                    BoxScopeInstance boxScopeInstance7 = BoxScopeInstance.INSTANCE;
                    int i211111 = ((48 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer11, 625702291, "C710@26080L85:OverlayControlScreen.kt#naom5h");
                    TextKt.m2693Text4IGK_g(str15, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(18), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer11, 200064, 0, 131026);
                    ComposerKt.sourceInformationMarkerEnd(composer11);
                    ComposerKt.sourceInformationMarkerEnd(composer11);
                    composer4.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    ComposerKt.sourceInformationMarkerEnd(composer4);
                    SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(4)), composer2, 6);
                    TextKt.m2693Text4IGK_g(str16, (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(10), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3072, 0, 131058);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer2.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    it = it5;
                    iterableListOf = iterable4;
                    i3 = i21116;
                    i2 = i21117;
                    str = str17;
                    str2 = str18;
                } else {
                    composer4 = composer2;
                }
                composerM3652constructorimpl7.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash7));
                composerM3652constructorimpl7.apply(Integer.valueOf(currentCompositeKeyHash7), setCompositeKeyHash115);
                Updater.m3659setimpl(composerM3652constructorimpl7, modifierMaterializeModifier115, ComposeUiNode.INSTANCE.getSetModifier());
                int i211112 = (i2123 >> 6) & 14;
                Composer composer12 = composer4;
                ComposerKt.sourceInformationMarkerStart(composer12, -2146769399, "C73@3429L9:Box.kt#2w3rfo");
                BoxScopeInstance boxScopeInstance8 = BoxScopeInstance.INSTANCE;
                int i211113 = ((48 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer12, 625702291, "C710@26080L85:OverlayControlScreen.kt#naom5h");
                TextKt.m2693Text4IGK_g(str15, (Modifier) null, Color.INSTANCE.m4196getWhite0d7_KjU(), TextUnitKt.getSp(18), (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer12, 200064, 0, 131026);
                ComposerKt.sourceInformationMarkerEnd(composer12);
                ComposerKt.sourceInformationMarkerEnd(composer12);
                composer4.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(4)), composer2, 6);
                TextKt.m2693Text4IGK_g(str16, (Modifier) null, MaterialTheme.INSTANCE.getColorScheme(composer2, MaterialTheme.$stable).getOnSurfaceVariant(), TextUnitKt.getSp(10), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, composer2, 3072, 0, 131058);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                composer2.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                ComposerKt.sourceInformationMarkerEnd(composer2);
                it = it5;
                iterableListOf = iterable4;
                i3 = i21116;
                i2 = i21117;
                str = str17;
                str2 = str18;
            }
            composer2.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer2.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            ComposerKt.sourceInformationMarkerEnd(composer2);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$84$lambda$83$lambda$74$lambda$73$lambda$72(AppPreferences $preferences, MutableState $stealthBadgeMode$delegate, boolean it) {
        OverlayControlScreen$lambda$17($stealthBadgeMode$delegate, it);
        $preferences.setStealthBadgeMode(it);
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$84$lambda$83$lambda$78$lambda$77$lambda$76(AppPreferences $preferences, MutableState $isPopupCardDisabled$delegate, boolean it) {
        OverlayControlScreen$lambda$20($isPopupCardDisabled$delegate, it);
        $preferences.setPopupCardDisabled(it);
        return Unit.INSTANCE;
    }

    /* JADX WARN: Code duplicated, block: B:28:0x0271  */
    /* JADX WARN: Code duplicated, block: B:31:0x027d  */
    /* JADX WARN: Code duplicated, block: B:32:0x0283  */
    /* JADX WARN: Code duplicated, block: B:44:0x038c  */
    /* JADX WARN: Code duplicated, block: B:46:0x03b4  */
    /* JADX WARN: Code duplicated, block: B:47:0x03b7  */
    /* JADX WARN: Code duplicated, block: B:50:0x03d6  */
    /* JADX WARN: Code duplicated, block: B:53:0x03e1  */
    /* JADX WARN: Code duplicated, block: B:54:0x03e6  */
    /* JADX WARN: Code duplicated, block: B:59:0x0528  */
    /* JADX WARN: Code duplicated, block: B:62:0x0534  */
    /* JADX WARN: Code duplicated, block: B:63:0x053a  */
    /* JADX WARN: Code duplicated, block: B:74:0x0646  */
    /* JADX WARN: Code duplicated, block: B:77:0x0652  */
    /* JADX WARN: Code duplicated, block: B:78:0x0658  */
    /* JADX WARN: Code duplicated, block: B:81:0x0689  */
    /* JADX WARN: Code duplicated, block: B:84:0x069c  */
    /* JADX WARN: Code duplicated, block: B:85:0x069f  */
    /* JADX WARN: Code duplicated, block: B:89:0x0783  */
    /* JADX WARN: Code duplicated, block: B:93:0x0790  */
    /* JADX WARN: Code duplicated, block: B:96:0x0822  */
    /* JADX WARN: Code duplicated, block: B:99:0x0478 A[EDGE_INSN: B:99:0x0478->B:57:0x0478 BREAK  A[LOOP:0: B:42:0x0382->B:56:0x03f9], SYNTHETIC] */
    static final Unit OverlayControlScreen$lambda$96$lambda$95(final AppPreferences $preferences, final MutableIntState $autoDismiss$delegate, final MutableState $vibrationEnabled$delegate, ColumnScope Card, Composer $composer, int $changed) {
        Function0<ComposeUiNode> function0;
        int i;
        boolean z;
        int currentCompositeKeyHash;
        Function0<ComposeUiNode> constructor;
        Function0<ComposeUiNode> function1;
        Composer composerM3652constructorimpl;
        Iterable iterableListOf;
        int i2;
        Iterator it;
        Iterable iterable;
        int currentCompositeKeyHash2;
        Function0<ComposeUiNode> constructor2;
        Function0<ComposeUiNode> function2;
        Composer composerM3652constructorimpl2;
        int currentCompositeKeyHash3;
        Function0<ComposeUiNode> constructor3;
        Function0<ComposeUiNode> function3;
        Composer composerM3652constructorimpl3;
        Composer composer;
        boolean zChangedInstance;
        Object obj;
        final int iIntValue;
        boolean z2;
        boolean zChanged;
        Object objRememberedValue;
        MeasurePolicy measurePolicy;
        Intrinsics.checkNotNullParameter(Card, "$this$Card");
        ComposerKt.sourceInformation($composer, "C729@26717L2204:OverlayControlScreen.kt#naom5h");
        if (($changed & 17) == 16 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(153924521, $changed, -1, "com.example.ui.OverlayControlScreen.<anonymous>.<anonymous> (OverlayControlScreen.kt:729)");
            }
            Modifier modifierM670padding3ABfNKs = PaddingKt.m670padding3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(16));
            ComposerKt.sourceInformationMarkerStart($composer, -483455358, "CC(Column)P(2,3,1)85@4251L61,86@4317L133:Column.kt#2w3rfo");
            Arrangement.Vertical top = Arrangement.INSTANCE.getTop();
            Alignment.Horizontal start = Alignment.INSTANCE.getStart();
            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(top, start, $composer, ((6 >> 3) & 14) | ((6 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            int currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM670padding3ABfNKs);
            Function0<ComposeUiNode> constructor4 = ComposeUiNode.INSTANCE.getConstructor();
            int i3 = ((((6 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function0 = constructor4;
                $composer.createNode(function0);
            } else {
                function0 = constructor4;
                $composer.useNode();
            }
            Composer composerM3652constructorimpl4 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl4, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl4, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl4.getInserting()) {
                i = 6;
            } else {
                i = 6;
                if (!Intrinsics.areEqual(composerM3652constructorimpl4.rememberedValue(), Integer.valueOf(currentCompositeKeyHash4))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
                int i4 = (i3 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                int i5 = ((i >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, -1114738491, "C732@26846L10,730@26770L147,736@26927L41,740@27085L10,741@27139L11,738@26978L199,744@27187L40,746@27237L710,766@27957L41,768@28008L905:OverlayControlScreen.kt#naom5h");
                TextKt.m2693Text4IGK_g("Chování zobrazení", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleSmall(), $composer, 196614, 0, 65502);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), $composer, 6);
                TextKt.m2693Text4IGK_g("Doba zobrazení odpovědi (výchozí 3s, pak zmizí):", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodySmall(), $composer, 6, 0, 65530);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), $composer, 6);
                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                z = true;
                Arrangement.Horizontal horizontalM550spacedBy0680j_4 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
                ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalM550spacedBy0680j_4, Alignment.INSTANCE.getTop(), $composer, ((54 >> 3) & 14) | ((54 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
                CompositionLocalMap currentCompositionLocalMap2 = $composer.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default);
                constructor = ComposeUiNode.INSTANCE.getConstructor();
                int i6 = ((((54 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!($composer.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                $composer.startReusableNode();
                if ($composer.getInserting()) {
                    function1 = constructor;
                    $composer.createNode(function1);
                } else {
                    function1 = constructor;
                    $composer.useNode();
                }
                composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
                Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl.rememberedValue(), Integer.valueOf(currentCompositeKeyHash))) {
                    composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
                    composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash2);
                }
                Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
                int i7 = (i6 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                int i8 = ((54 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, -4482902, "C:OverlayControlScreen.kt#naom5h");
                $composer.startReplaceGroup(-1247068181);
                ComposerKt.sourceInformation($composer, "*753@27568L104,757@27696L33,758@27773L138,751@27487L438");
                iterableListOf = CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to(2, "2s"), TuplesKt.to(3, "3s (Doporučeno)"), TuplesKt.to(5, "5s"), TuplesKt.to(8, "8s"), TuplesKt.to(0, "Ručně")});
                i2 = 0;
                it = iterableListOf.iterator();
                while (true) {
                    iterable = iterableListOf;
                    if (it.hasNext()) {
                        break;
                    }
                    Pair pair = (Pair) it.next();
                    int i9 = i2;
                    iIntValue = ((Number) pair.component1()).intValue();
                    Iterator it2 = it;
                    final String str = (String) pair.component2();
                    Alignment.Horizontal horizontal = start;
                    if (OverlayControlScreen$lambda$10($autoDismiss$delegate) == iIntValue) {
                        z2 = z;
                    } else {
                        z2 = false;
                    }
                    boolean z3 = z2;
                    ComposerKt.sourceInformationMarkerStart($composer, 990824484, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChanged = $composer.changed(iIntValue) | $composer.changedInstance($preferences);
                    objRememberedValue = $composer.rememberedValue();
                    if (zChanged) {
                        measurePolicy = measurePolicyColumnMeasurePolicy;
                    } else {
                        measurePolicy = measurePolicyColumnMeasurePolicy;
                        if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        ChipKt.FilterChip(z3, (Function0) objRememberedValue, ComposableLambdaKt.rememberComposableLambda(1070547913, z, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda20
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$89$lambda$88$lambda$87(str, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), null, false, null, null, null, FilterChipDefaults.INSTANCE.m2111filterChipColorsXqyqHi0(0L, 0L, 0L, 0L, 0L, 0L, 0L, com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, 0L, $composer, 817889280, FilterChipDefaults.$stable << 6, 3455), null, null, null, $composer, 384, 0, 3832);
                        iterableListOf = iterable;
                        i2 = i9;
                        it = it2;
                        start = horizontal;
                        measurePolicyColumnMeasurePolicy = measurePolicy;
                        z = true;
                    }
                    objRememberedValue = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda19
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$89$lambda$88$lambda$86$lambda$85(iIntValue, $preferences, $autoDismiss$delegate);
                        }
                    };
                    $composer.updateRememberedValue(objRememberedValue);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ChipKt.FilterChip(z3, (Function0) objRememberedValue, ComposableLambdaKt.rememberComposableLambda(1070547913, z, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda20
                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj2, Object obj3) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$89$lambda$88$lambda$87(str, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }, $composer, 54), null, false, null, null, null, FilterChipDefaults.INSTANCE.m2111filterChipColorsXqyqHi0(0L, 0L, 0L, 0L, 0L, 0L, 0L, com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, 0L, $composer, 817889280, FilterChipDefaults.$stable << 6, 3455), null, null, null, $composer, 384, 0, 3832);
                    iterableListOf = iterable;
                    i2 = i9;
                    it = it2;
                    start = horizontal;
                    measurePolicyColumnMeasurePolicy = measurePolicy;
                    z = true;
                }
                $composer.endReplaceGroup();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), $composer, 6);
                Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
                CompositionLocalMap currentCompositionLocalMap3 = $composer.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default2);
                constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                int i10 = ((((438 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!($composer.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                $composer.startReusableNode();
                if ($composer.getInserting()) {
                    function2 = constructor2;
                    $composer.createNode(function2);
                } else {
                    function2 = constructor2;
                    $composer.useNode();
                }
                composerM3652constructorimpl2 = Updater.m3652constructorimpl($composer);
                Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (!composerM3652constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM3652constructorimpl2.rememberedValue(), Integer.valueOf(currentCompositeKeyHash2))) {
                    composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
                    composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash3);
                }
                Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
                int i11 = (i10 >> 6) & 14;
                ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                int i12 = ((438 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, -1593737752, "C773@28198L348,784@28636L101,788@28775L116,782@28558L345:OverlayControlScreen.kt#naom5h");
                Alignment.Vertical centerVertically2 = Alignment.INSTANCE.getCenterVertically();
                ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
                Modifier modifier = Modifier.INSTANCE;
                MeasurePolicy measurePolicyRowMeasurePolicy3 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically2, $composer, ((384 >> 3) & 14) | ((384 >> 3) & 112));
                ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
                currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
                CompositionLocalMap currentCompositionLocalMap4 = $composer.getCurrentCompositionLocalMap();
                Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier($composer, modifier);
                constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                int i13 = ((((384 << 3) & 112) << 6) & 896) | 6;
                ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
                if (!($composer.getApplier() instanceof Applier)) {
                    ComposablesKt.invalidApplier();
                }
                $composer.startReusableNode();
                if ($composer.getInserting()) {
                    function3 = constructor3;
                    $composer.createNode(function3);
                } else {
                    function3 = constructor3;
                    $composer.useNode();
                }
                composerM3652constructorimpl3 = Updater.m3652constructorimpl($composer);
                Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
                Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
                if (composerM3652constructorimpl3.getInserting()) {
                    composer = $composer;
                } else {
                    composer = $composer;
                    if (!Intrinsics.areEqual(composerM3652constructorimpl3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                    }
                    Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                    int i14 = (i13 >> 6) & 14;
                    Composer composer2 = composer;
                    ComposerKt.sourceInformationMarkerStart(composer2, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                    RowScopeInstance rowScopeInstance3 = RowScopeInstance.INSTANCE;
                    int i15 = ((384 >> 6) & 112) | 6;
                    ComposerKt.sourceInformationMarkerStart(composer2, -983431145, "C774@28264L76,775@28353L40,778@28499L10,776@28406L128:OverlayControlScreen.kt#naom5h");
                    IconKt.m2150Iconww6aTOc(VibrationKt.getVibration(Icons.INSTANCE.getDefault()), (String) null, (Modifier) null, com.example.ui.theme.ColorKt.getIndigoLight(), composer2, 3120, 4);
                    SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer2, 6);
                    TextKt.m2693Text4IGK_g("Tichá vibrace při kliknutí", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getBodyMedium(), composer2, 6, 0, 65534);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    ComposerKt.sourceInformationMarkerEnd(composer2);
                    composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    ComposerKt.sourceInformationMarkerEnd(composer);
                    boolean zOverlayControlScreen$lambda$13 = OverlayControlScreen$lambda$13($vibrationEnabled$delegate);
                    ComposerKt.sourceInformationMarkerStart($composer, -1852512801, "CC(remember):OverlayControlScreen.kt#9igjgp");
                    zChangedInstance = $composer.changedInstance($preferences);
                    Object objRememberedValue2 = $composer.rememberedValue();
                    if (!zChangedInstance || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                        obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda21
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj2) {
                                return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$93$lambda$92$lambda$91($preferences, $vibrationEnabled$delegate, ((Boolean) obj2).booleanValue());
                            }
                        };
                        $composer.updateRememberedValue(obj);
                    } else {
                        obj = objRememberedValue2;
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    SwitchKt.Switch(zOverlayControlScreen$lambda$13, (Function1) obj, null, null, false, SwitchDefaults.INSTANCE.m2575colorsV1nXRL4(Color.INSTANCE.m4196getWhite0d7_KjU(), com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, $composer, 54, SwitchDefaults.$stable << 18, 65532), null, $composer, 0, 92);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    $composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    $composer.endNode();
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                }
                composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
                composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash4);
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
                int i16 = (i13 >> 6) & 14;
                Composer composer3 = composer;
                ComposerKt.sourceInformationMarkerStart(composer3, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance4 = RowScopeInstance.INSTANCE;
                int i17 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer3, -983431145, "C774@28264L76,775@28353L40,778@28499L10,776@28406L128:OverlayControlScreen.kt#naom5h");
                IconKt.m2150Iconww6aTOc(VibrationKt.getVibration(Icons.INSTANCE.getDefault()), (String) null, (Modifier) null, com.example.ui.theme.ColorKt.getIndigoLight(), composer3, 3120, 4);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer3, 6);
                TextKt.m2693Text4IGK_g("Tichá vibrace při kliknutí", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer3, MaterialTheme.$stable).getBodyMedium(), composer3, 6, 0, 65534);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                ComposerKt.sourceInformationMarkerEnd(composer3);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                boolean zOverlayControlScreen$lambda$14 = OverlayControlScreen$lambda$13($vibrationEnabled$delegate);
                ComposerKt.sourceInformationMarkerStart($composer, -1852512801, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance = $composer.changedInstance($preferences);
                Object objRememberedValue3 = $composer.rememberedValue();
                if (zChangedInstance) {
                    obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda21
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$93$lambda$92$lambda$91($preferences, $vibrationEnabled$delegate, ((Boolean) obj2).booleanValue());
                        }
                    };
                    $composer.updateRememberedValue(obj);
                } else {
                    obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda21
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$93$lambda$92$lambda$91($preferences, $vibrationEnabled$delegate, ((Boolean) obj2).booleanValue());
                        }
                    };
                    $composer.updateRememberedValue(obj);
                }
                ComposerKt.sourceInformationMarkerEnd($composer);
                SwitchKt.Switch(zOverlayControlScreen$lambda$14, (Function1) obj, null, null, false, SwitchDefaults.INSTANCE.m2575colorsV1nXRL4(Color.INSTANCE.m4196getWhite0d7_KjU(), com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, $composer, 54, SwitchDefaults.$stable << 18, 65532), null, $composer, 0, 92);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            }
            composerM3652constructorimpl4.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash4));
            composerM3652constructorimpl4.apply(Integer.valueOf(currentCompositeKeyHash4), setCompositeKeyHash);
            Updater.m3659setimpl(composerM3652constructorimpl4, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
            int i18 = (i3 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -384862393, "C87@4365L9:Column.kt#2w3rfo");
            ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
            int i19 = ((i >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -1114738491, "C732@26846L10,730@26770L147,736@26927L41,740@27085L10,741@27139L11,738@26978L199,744@27187L40,746@27237L710,766@27957L41,768@28008L905:OverlayControlScreen.kt#naom5h");
            TextKt.m2693Text4IGK_g("Chování zobrazení", (Modifier) null, 0L, 0L, (FontStyle) null, FontWeight.INSTANCE.getBold(), (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleSmall(), $composer, 196614, 0, 65502);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), $composer, 6);
            TextKt.m2693Text4IGK_g("Doba zobrazení odpovědi (výchozí 3s, pak zmizí):", (Modifier) null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant(), 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodySmall(), $composer, 6, 0, 65530);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(6)), $composer, 6);
            Modifier modifierFillMaxWidth$default3 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            z = true;
            Arrangement.Horizontal horizontalM550spacedBy0680j_5 = Arrangement.INSTANCE.m550spacedBy0680j_4(Dp.m6622constructorimpl(8));
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy4 = RowKt.rowMeasurePolicy(horizontalM550spacedBy0680j_5, Alignment.INSTANCE.getTop(), $composer, ((54 >> 3) & 14) | ((54 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap5 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default3);
            constructor = ComposeUiNode.INSTANCE.getConstructor();
            int i20 = ((((54 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function1 = constructor;
                $composer.createNode(function1);
            } else {
                function1 = constructor;
                $composer.useNode();
            }
            composerM3652constructorimpl = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl, measurePolicyRowMeasurePolicy4, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl.getInserting()) {
            }
            composerM3652constructorimpl.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash));
            composerM3652constructorimpl.apply(Integer.valueOf(currentCompositeKeyHash), setCompositeKeyHash5);
            Updater.m3659setimpl(composerM3652constructorimpl, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
            int i21 = (i20 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance5 = RowScopeInstance.INSTANCE;
            int i22 = ((54 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -4482902, "C:OverlayControlScreen.kt#naom5h");
            $composer.startReplaceGroup(-1247068181);
            ComposerKt.sourceInformation($composer, "*753@27568L104,757@27696L33,758@27773L138,751@27487L438");
            iterableListOf = CollectionsKt.listOf((Object[]) new Pair[]{TuplesKt.to(2, "2s"), TuplesKt.to(3, "3s (Doporučeno)"), TuplesKt.to(5, "5s"), TuplesKt.to(8, "8s"), TuplesKt.to(0, "Ručně")});
            i2 = 0;
            it = iterableListOf.iterator();
            while (true) {
                iterable = iterableListOf;
                if (it.hasNext()) {
                    break;
                    break;
                }
                Pair pair2 = (Pair) it.next();
                int i23 = i2;
                iIntValue = ((Number) pair2.component1()).intValue();
                Iterator it3 = it;
                final String str2 = (String) pair2.component2();
                Alignment.Horizontal horizontal2 = start;
                if (OverlayControlScreen$lambda$10($autoDismiss$delegate) == iIntValue) {
                    z2 = z;
                } else {
                    z2 = false;
                }
                boolean z4 = z2;
                ComposerKt.sourceInformationMarkerStart($composer, 990824484, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChanged = $composer.changed(iIntValue) | $composer.changedInstance($preferences);
                objRememberedValue = $composer.rememberedValue();
                if (zChanged) {
                    measurePolicy = measurePolicyColumnMeasurePolicy;
                    if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ChipKt.FilterChip(z4, (Function0) objRememberedValue, ComposableLambdaKt.rememberComposableLambda(1070547913, z, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda20
                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj2, Object obj3) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$89$lambda$88$lambda$87(str2, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }, $composer, 54), null, false, null, null, null, FilterChipDefaults.INSTANCE.m2111filterChipColorsXqyqHi0(0L, 0L, 0L, 0L, 0L, 0L, 0L, com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, 0L, $composer, 817889280, FilterChipDefaults.$stable << 6, 3455), null, null, null, $composer, 384, 0, 3832);
                    iterableListOf = iterable;
                    i2 = i23;
                    it = it3;
                    start = horizontal2;
                    measurePolicyColumnMeasurePolicy = measurePolicy;
                    z = true;
                } else {
                    measurePolicy = measurePolicyColumnMeasurePolicy;
                }
                objRememberedValue = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda19
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$89$lambda$88$lambda$86$lambda$85(iIntValue, $preferences, $autoDismiss$delegate);
                    }
                };
                $composer.updateRememberedValue(objRememberedValue);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ChipKt.FilterChip(z4, (Function0) objRememberedValue, ComposableLambdaKt.rememberComposableLambda(1070547913, z, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda20
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj2, Object obj3) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$89$lambda$88$lambda$87(str2, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                }, $composer, 54), null, false, null, null, null, FilterChipDefaults.INSTANCE.m2111filterChipColorsXqyqHi0(0L, 0L, 0L, 0L, 0L, 0L, 0L, com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, Color.INSTANCE.m4196getWhite0d7_KjU(), 0L, 0L, $composer, 817889280, FilterChipDefaults.$stable << 6, 3455), null, null, null, $composer, 384, 0, 3832);
                iterableListOf = iterable;
                i2 = i23;
                it = it3;
                start = horizontal2;
                measurePolicyColumnMeasurePolicy = measurePolicy;
                z = true;
            }
            $composer.endReplaceGroup();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            SpacerKt.Spacer(SizeKt.m701height3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(12)), $composer, 6);
            Modifier modifierFillMaxWidth$default4 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
            Arrangement.Horizontal spaceBetween2 = Arrangement.INSTANCE.getSpaceBetween();
            Alignment.Vertical centerVertically3 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            MeasurePolicy measurePolicyRowMeasurePolicy5 = RowKt.rowMeasurePolicy(spaceBetween2, centerVertically3, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap6 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier6 = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default4);
            constructor2 = ComposeUiNode.INSTANCE.getConstructor();
            int i110 = ((((438 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function2 = constructor2;
                $composer.createNode(function2);
            } else {
                function2 = constructor2;
                $composer.useNode();
            }
            composerM3652constructorimpl2 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl2, measurePolicyRowMeasurePolicy5, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl2, currentCompositionLocalMap6, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash6 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (!composerM3652constructorimpl2.getInserting()) {
            }
            composerM3652constructorimpl2.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash2));
            composerM3652constructorimpl2.apply(Integer.valueOf(currentCompositeKeyHash2), setCompositeKeyHash6);
            Updater.m3659setimpl(composerM3652constructorimpl2, modifierMaterializeModifier6, ComposeUiNode.INSTANCE.getSetModifier());
            int i111 = (i110 >> 6) & 14;
            ComposerKt.sourceInformationMarkerStart($composer, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance6 = RowScopeInstance.INSTANCE;
            int i112 = ((438 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -1593737752, "C773@28198L348,784@28636L101,788@28775L116,782@28558L345:OverlayControlScreen.kt#naom5h");
            Alignment.Vertical centerVertically4 = Alignment.INSTANCE.getCenterVertically();
            ComposerKt.sourceInformationMarkerStart($composer, 693286680, "CC(Row)P(2,1,3)98@4939L58,99@5002L130:Row.kt#2w3rfo");
            Modifier modifier2 = Modifier.INSTANCE;
            MeasurePolicy measurePolicyRowMeasurePolicy6 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically4, $composer, ((384 >> 3) & 14) | ((384 >> 3) & 112));
            ComposerKt.sourceInformationMarkerStart($composer, -1323940314, "CC(Layout)P(!1,2)78@3182L23,81@3333L411:Layout.kt#80mrfh");
            currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash($composer, 0);
            CompositionLocalMap currentCompositionLocalMap7 = $composer.getCurrentCompositionLocalMap();
            Modifier modifierMaterializeModifier7 = ComposedModifierKt.materializeModifier($composer, modifier2);
            constructor3 = ComposeUiNode.INSTANCE.getConstructor();
            int i113 = ((((384 << 3) & 112) << 6) & 896) | 6;
            ComposerKt.sourceInformationMarkerStart($composer, -692256719, "CC(ReusableComposeNode)P(1,2)376@14062L9:Composables.kt#9igjgp");
            if (!($composer.getApplier() instanceof Applier)) {
                ComposablesKt.invalidApplier();
            }
            $composer.startReusableNode();
            if ($composer.getInserting()) {
                function3 = constructor3;
                $composer.createNode(function3);
            } else {
                function3 = constructor3;
                $composer.useNode();
            }
            composerM3652constructorimpl3 = Updater.m3652constructorimpl($composer);
            Updater.m3659setimpl(composerM3652constructorimpl3, measurePolicyRowMeasurePolicy6, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
            Updater.m3659setimpl(composerM3652constructorimpl3, currentCompositionLocalMap7, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash7 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
            if (composerM3652constructorimpl3.getInserting()) {
                composer = $composer;
                if (!Intrinsics.areEqual(composerM3652constructorimpl3.rememberedValue(), Integer.valueOf(currentCompositeKeyHash3))) {
                }
                Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier7, ComposeUiNode.INSTANCE.getSetModifier());
                int i114 = (i113 >> 6) & 14;
                Composer composer4 = composer;
                ComposerKt.sourceInformationMarkerStart(composer4, -407918630, "C100@5047L9:Row.kt#2w3rfo");
                RowScopeInstance rowScopeInstance7 = RowScopeInstance.INSTANCE;
                int i115 = ((384 >> 6) & 112) | 6;
                ComposerKt.sourceInformationMarkerStart(composer4, -983431145, "C774@28264L76,775@28353L40,778@28499L10,776@28406L128:OverlayControlScreen.kt#naom5h");
                IconKt.m2150Iconww6aTOc(VibrationKt.getVibration(Icons.INSTANCE.getDefault()), (String) null, (Modifier) null, com.example.ui.theme.ColorKt.getIndigoLight(), composer4, 3120, 4);
                SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer4, 6);
                TextKt.m2693Text4IGK_g("Tichá vibrace při kliknutí", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer4, MaterialTheme.$stable).getBodyMedium(), composer4, 6, 0, 65534);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                ComposerKt.sourceInformationMarkerEnd(composer4);
                composer.endNode();
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                ComposerKt.sourceInformationMarkerEnd(composer);
                boolean zOverlayControlScreen$lambda$15 = OverlayControlScreen$lambda$13($vibrationEnabled$delegate);
                ComposerKt.sourceInformationMarkerStart($composer, -1852512801, "CC(remember):OverlayControlScreen.kt#9igjgp");
                zChangedInstance = $composer.changedInstance($preferences);
                Object objRememberedValue4 = $composer.rememberedValue();
                if (zChangedInstance) {
                    obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda21
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$93$lambda$92$lambda$91($preferences, $vibrationEnabled$delegate, ((Boolean) obj2).booleanValue());
                        }
                    };
                    $composer.updateRememberedValue(obj);
                } else {
                    obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda21
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj2) {
                            return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$93$lambda$92$lambda$91($preferences, $vibrationEnabled$delegate, ((Boolean) obj2).booleanValue());
                        }
                    };
                    $composer.updateRememberedValue(obj);
                }
                ComposerKt.sourceInformationMarkerEnd($composer);
                SwitchKt.Switch(zOverlayControlScreen$lambda$15, (Function1) obj, null, null, false, SwitchDefaults.INSTANCE.m2575colorsV1nXRL4(Color.INSTANCE.m4196getWhite0d7_KjU(), com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, $composer, 54, SwitchDefaults.$stable << 18, 65532), null, $composer, 0, 92);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                $composer.endNode();
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                ComposerKt.sourceInformationMarkerEnd($composer);
                if (ComposerKt.isTraceInProgress()) {
                    ComposerKt.traceEventEnd();
                }
            } else {
                composer = $composer;
            }
            composerM3652constructorimpl3.updateRememberedValue(Integer.valueOf(currentCompositeKeyHash3));
            composerM3652constructorimpl3.apply(Integer.valueOf(currentCompositeKeyHash3), setCompositeKeyHash7);
            Updater.m3659setimpl(composerM3652constructorimpl3, modifierMaterializeModifier7, ComposeUiNode.INSTANCE.getSetModifier());
            int i116 = (i113 >> 6) & 14;
            Composer composer5 = composer;
            ComposerKt.sourceInformationMarkerStart(composer5, -407918630, "C100@5047L9:Row.kt#2w3rfo");
            RowScopeInstance rowScopeInstance8 = RowScopeInstance.INSTANCE;
            int i117 = ((384 >> 6) & 112) | 6;
            ComposerKt.sourceInformationMarkerStart(composer5, -983431145, "C774@28264L76,775@28353L40,778@28499L10,776@28406L128:OverlayControlScreen.kt#naom5h");
            IconKt.m2150Iconww6aTOc(VibrationKt.getVibration(Icons.INSTANCE.getDefault()), (String) null, (Modifier) null, com.example.ui.theme.ColorKt.getIndigoLight(), composer5, 3120, 4);
            SpacerKt.Spacer(SizeKt.m720width3ABfNKs(Modifier.INSTANCE, Dp.m6622constructorimpl(10)), composer5, 6);
            TextKt.m2693Text4IGK_g("Tichá vibrace při kliknutí", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, MaterialTheme.INSTANCE.getTypography(composer5, MaterialTheme.$stable).getBodyMedium(), composer5, 6, 0, 65534);
            ComposerKt.sourceInformationMarkerEnd(composer5);
            ComposerKt.sourceInformationMarkerEnd(composer5);
            composer.endNode();
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            ComposerKt.sourceInformationMarkerEnd(composer);
            boolean zOverlayControlScreen$lambda$16 = OverlayControlScreen$lambda$13($vibrationEnabled$delegate);
            ComposerKt.sourceInformationMarkerStart($composer, -1852512801, "CC(remember):OverlayControlScreen.kt#9igjgp");
            zChangedInstance = $composer.changedInstance($preferences);
            Object objRememberedValue5 = $composer.rememberedValue();
            if (zChangedInstance) {
                obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda21
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$93$lambda$92$lambda$91($preferences, $vibrationEnabled$delegate, ((Boolean) obj2).booleanValue());
                    }
                };
                $composer.updateRememberedValue(obj);
            } else {
                obj = new Function1() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda21
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj2) {
                        return OverlayControlScreenKt.OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$93$lambda$92$lambda$91($preferences, $vibrationEnabled$delegate, ((Boolean) obj2).booleanValue());
                    }
                };
                $composer.updateRememberedValue(obj);
            }
            ComposerKt.sourceInformationMarkerEnd($composer);
            SwitchKt.Switch(zOverlayControlScreen$lambda$16, (Function1) obj, null, null, false, SwitchDefaults.INSTANCE.m2575colorsV1nXRL4(Color.INSTANCE.m4196getWhite0d7_KjU(), com.example.ui.theme.ColorKt.getIndigoPrimary(), 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, $composer, 54, SwitchDefaults.$stable << 18, 65532), null, $composer, 0, 92);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            $composer.endNode();
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            ComposerKt.sourceInformationMarkerEnd($composer);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$89$lambda$88$lambda$86$lambda$85(int $sec, AppPreferences $preferences, MutableIntState $autoDismiss$delegate) {
        $autoDismiss$delegate.setIntValue($sec);
        $preferences.setAutoDismissSeconds($sec);
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$89$lambda$88$lambda$87(String $label, Composer $composer, int $changed) {
        ComposerKt.sourceInformation($composer, "C757@27698L29:OverlayControlScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(1070547913, $changed, -1, "com.example.ui.OverlayControlScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (OverlayControlScreen.kt:757)");
            }
            TextKt.m2693Text4IGK_g($label, (Modifier) null, 0L, TextUnitKt.getSp(12), (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3072, 0, 131062);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }

    static final Unit OverlayControlScreen$lambda$96$lambda$95$lambda$94$lambda$93$lambda$92$lambda$91(AppPreferences $preferences, MutableState $vibrationEnabled$delegate, boolean it) {
        OverlayControlScreen$lambda$14($vibrationEnabled$delegate, it);
        $preferences.setVibrationEnabled(it);
        return Unit.INSTANCE;
    }

    public static final void CornerPickerChip(final CornerPosition position, final boolean isSelected, final Function1<? super CornerPosition, Unit> onSelect, Modifier modifier, Composer $composer, final int $changed, final int i) {
        Modifier modifier2;
        Modifier.Companion modifier3;
        long surface;
        long outlineVariant;
        Object obj;
        Composer $composer2;
        final Modifier modifier4;
        Intrinsics.checkNotNullParameter(position, "position");
        Intrinsics.checkNotNullParameter(onSelect, "onSelect");
        Composer $composer3 = $composer.startRestartGroup(189153795);
        ComposerKt.sourceInformation($composer3, "C(CornerPickerChip)P(3!1,2)809@29166L22,817@29545L303,808@29143L705:OverlayControlScreen.kt#naom5h");
        int $dirty = $changed;
        if (($changed & 6) == 0) {
            $dirty |= $composer3.changed(position.ordinal()) ? 4 : 2;
        }
        if (($changed & 48) == 0) {
            $dirty |= $composer3.changed(isSelected) ? 32 : 16;
        }
        if (($changed & 384) == 0) {
            $dirty |= $composer3.changedInstance(onSelect) ? 256 : 128;
        }
        int i2 = i & 8;
        if (i2 != 0) {
            $dirty |= 3072;
            modifier2 = modifier;
        } else if (($changed & 3072) == 0) {
            modifier2 = modifier;
            $dirty |= $composer3.changed(modifier2) ? 2048 : 1024;
        } else {
            modifier2 = modifier;
        }
        if (($dirty & 1171) == 1170 && $composer3.getSkipping()) {
            $composer3.skipToGroupEnd();
            $composer2 = $composer3;
            modifier4 = modifier2;
        } else {
            if (i2 != 0) {
                modifier3 = Modifier.INSTANCE;
            } else {
                modifier3 = modifier2;
            }
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(189153795, $dirty, -1, "com.example.ui.CornerPickerChip (OverlayControlScreen.kt:807)");
            }
            if (isSelected) {
                $composer3.startReplaceGroup(1388178128);
                $composer3.endReplaceGroup();
                surface = com.example.ui.theme.ColorKt.getIndigoPrimary();
            } else {
                $composer3.startReplaceGroup(1388179562);
                ComposerKt.sourceInformation($composer3, "810@29251L11");
                surface = MaterialTheme.INSTANCE.getColorScheme($composer3, MaterialTheme.$stable).getSurface();
                $composer3.endReplaceGroup();
            }
            RoundedCornerShape roundedCornerShapeM953RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m953RoundedCornerShape0680j_4(Dp.m6622constructorimpl(10));
            float fM6622constructorimpl = Dp.m6622constructorimpl(1);
            if (isSelected) {
                $composer3.startReplaceGroup(1388183950);
                $composer3.endReplaceGroup();
                outlineVariant = com.example.ui.theme.ColorKt.getIndigoLight();
            } else {
                $composer3.startReplaceGroup(1388185329);
                ComposerKt.sourceInformation($composer3, "814@29431L11");
                outlineVariant = MaterialTheme.INSTANCE.getColorScheme($composer3, MaterialTheme.$stable).getOutlineVariant();
                $composer3.endReplaceGroup();
            }
            BorderStroke borderStrokeM252BorderStrokecXLIe8U = BorderStrokeKt.m252BorderStrokecXLIe8U(fM6622constructorimpl, outlineVariant);
            String lowerCase = position.name().toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            Modifier modifierTestTag = TestTagKt.testTag(modifier3, "corner_pick_" + lowerCase);
            ComposerKt.sourceInformationMarkerStart($composer3, 1388176473, "CC(remember):OverlayControlScreen.kt#9igjgp");
            boolean z = (($dirty & 896) == 256) | (($dirty & 14) == 4);
            Object objRememberedValue = $composer3.rememberedValue();
            if (z || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                obj = new Function0() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda23
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return OverlayControlScreenKt.CornerPickerChip$lambda$99$lambda$98(onSelect, position);
                    }
                };
                $composer3.updateRememberedValue(obj);
            } else {
                obj = objRememberedValue;
            }
            ComposerKt.sourceInformationMarkerEnd($composer3);
            Modifier modifier5 = modifier3;
            $composer2 = $composer3;
            SurfaceKt.m2546Surfaceo_FOJdg((Function0) obj, modifierTestTag, false, roundedCornerShapeM953RoundedCornerShape0680j_4, surface, 0L, 0.0f, 0.0f, borderStrokeM252BorderStrokecXLIe8U, null, ComposableLambdaKt.rememberComposableLambda(-570582770, true, new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda24
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return OverlayControlScreenKt.CornerPickerChip$lambda$100(position, isSelected, (Composer) obj2, ((Integer) obj3).intValue());
                }
            }, $composer3, 54), $composer2, 0, 6, 740);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
            modifier4 = modifier5;
        }
        ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
        if (scopeUpdateScopeEndRestartGroup != null) {
            scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.example.ui.OverlayControlScreenKt$$ExternalSyntheticLambda25
                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Object obj2, Object obj3) {
                    return OverlayControlScreenKt.CornerPickerChip$lambda$101(position, isSelected, onSelect, modifier4, $changed, i, (Composer) obj2, ((Integer) obj3).intValue());
                }
            });
        }
    }

    static final Unit CornerPickerChip$lambda$99$lambda$98(Function1 $onSelect, CornerPosition $position) {
        $onSelect.invoke($position);
        return Unit.INSTANCE;
    }

    static final Unit CornerPickerChip$lambda$100(CornerPosition $position, boolean $isSelected, Composer $composer, int $changed) {
        long onSurface;
        ComposerKt.sourceInformation($composer, "C818@29551L293:OverlayControlScreen.kt#naom5h");
        if (($changed & 3) == 2 && $composer.getSkipping()) {
            $composer.skipToGroupEnd();
        } else {
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventStart(-570582770, $changed, -1, "com.example.ui.CornerPickerChip.<anonymous> (OverlayControlScreen.kt:818)");
            }
            String title = $position.getTitle();
            long sp = TextUnitKt.getSp(11);
            FontWeight.Companion companion = FontWeight.INSTANCE;
            FontWeight bold = $isSelected ? companion.getBold() : companion.getNormal();
            if ($isSelected) {
                $composer.startReplaceGroup(1425777555);
                $composer.endReplaceGroup();
                onSurface = Color.INSTANCE.m4196getWhite0d7_KjU();
            } else {
                $composer.startReplaceGroup(1425778743);
                ComposerKt.sourceInformation($composer, "822@29746L11");
                onSurface = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurface();
                $composer.endReplaceGroup();
            }
            TextKt.m2693Text4IGK_g(title, PaddingKt.m671paddingVpY3zN4(Modifier.INSTANCE, Dp.m6622constructorimpl(8), Dp.m6622constructorimpl(6)), onSurface, sp, (FontStyle) null, bold, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 0, 0, (Function1<? super TextLayoutResult, Unit>) null, (TextStyle) null, $composer, 3120, 0, 131024);
            if (ComposerKt.isTraceInProgress()) {
                ComposerKt.traceEventEnd();
            }
        }
        return Unit.INSTANCE;
    }
}
