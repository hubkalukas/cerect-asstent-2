package com.example.data;

import android.util.Base64;
import androidx.compose.ui.platform.AndroidComposeViewAccessibilityDelegateCompat;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;

/* JADX INFO: compiled from: EncryptedApiKeyVault.kt */
/* JADX INFO: loaded from: classes4.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0005\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\b\u001a\u0004\u0018\u00010\u00052\u0006\u0010\t\u001a\u00020\u0005R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\n"}, d2 = {"Lcom/example/data/EncryptedApiKeyVault;", "", "<init>", "()V", "SALT_B64", "", "IV_B64", "CIPHER_B64", "unlock", "pin", "app"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class EncryptedApiKeyVault {
    public static final int $stable = 0;
    private static final String CIPHER_B64 = "YOUR_ENCRYPTED_VAULT_CIPHER";
    public static final EncryptedApiKeyVault INSTANCE = new EncryptedApiKeyVault();
    private static final String IV_B64 = "ORGvm7NXjuSRvKkw";
    private static final String SALT_B64 = "VMeXyo44btcebFbjl10zvg==";

    private EncryptedApiKeyVault() {
    }

    public final String unlock(String pin) {
        Intrinsics.checkNotNullParameter(pin, "pin");
        try {
            byte[] salt = Base64.decode(SALT_B64, 0);
            byte[] iv = Base64.decode(IV_B64, 0);
            byte[] cipherCombined = Base64.decode(CIPHER_B64, 0);
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            char[] charArray = pin.toCharArray();
            Intrinsics.checkNotNullExpressionValue(charArray, "toCharArray(...)");
            PBEKeySpec spec = new PBEKeySpec(charArray, salt, AndroidComposeViewAccessibilityDelegateCompat.ParcelSafeTextLength, 256);
            SecretKey secretKey = factory.generateSecret(spec);
            SecretKeySpec keySpec = new SecretKeySpec(secretKey.getEncoded(), "AES");
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            GCMParameterSpec gcmSpec = new GCMParameterSpec(128, iv);
            cipher.init(2, keySpec, gcmSpec);
            byte[] decrypted = cipher.doFinal(cipherCombined);
            Intrinsics.checkNotNull(decrypted);
            return new String(decrypted, Charsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }
}
